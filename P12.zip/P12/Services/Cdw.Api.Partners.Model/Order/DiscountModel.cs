﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds DiscountModel
    /// </summary>
    public class DiscountModel
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// holds Type
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}