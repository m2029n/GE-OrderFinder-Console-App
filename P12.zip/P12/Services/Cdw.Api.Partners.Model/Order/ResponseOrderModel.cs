﻿using System;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// Returned via post Orders/{orderNumber}
    /// </summary>
    public class ResponseOrderModel
    {
        /// <summary>
        /// The CDW order number.  This field is only present on responses from the API.
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        ///The status of the order. Valid values are:
        /// Processing
        /// Backordered Item(s)
        /// Partially Shipped
        /// Shipped
        /// Canceled
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// The date the order was created. Date format is ISO 8601.
        /// </summary>
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// An integer representing the CDW company. Valid values are:
        /// 1000  CDW
        /// </summary>
        public int Company { get; set; }

        ///<summary>
        /// Partner’s reference number for the order. This value should be unique for each order placed through the API. Orders placed through other channels may not include a reference number.
        /// Maximum Length: 100
        ///</summary>
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// An object identifying the customer who submitted the order.
        /// </summary>
        public AccountModel Account { get; set; }

        /// <summary>
        /// The calculated dollar amount of all line items including  line-level discounts.
        /// Calculation: SUM(LineItems.LinePrice)
        /// </summary>
        public decimal Subtotal { get; set; }

        /// <summary>
        /// A single calculated dollar amount value of all order level discounts applied.
        ///  Calculation: SUM(Discounts Dollar Amount)
        /// </summary>
        public decimal Discount { get; set; }

        /// <summary>
        /// A collection of tax objects indicating the taxes applied to the order.
        /// Multiple tax objects would exist if multiple types of tax are levied, or if taxes are levied at multiple rates.
        /// </summary>
        public TaxModel[] Taxes { get; set; }

        /// <summary>
        /// holds RecyclingFees
        /// </summary>
        public RecyclingFeesModel[] RecyclingFees { get; set; }

        /// <summary>
        /// The dollar amount for freight charges.
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// The dollar amount for handling charges.
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// The dollar amount for shipping insurance.
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// A single calculated dollar amount value of all taxes assessed.
        /// Calculation: SUM(Taxes.Amount)
        /// </summary>
        public decimal Tax { get; set; }

        /// <summary>
        ///  A single calculated dollar amount value of all recycling fees
        /// </summary>
        public decimal RecyclingFee { get; set; }

        /// <summary>
        /// The calculated dollar amount for the entire order.
        /// </summary>
        public decimal Total { get; set; }

        /// <summary>
        /// A collection of discount objects applied at the order level.
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// An object representing the billing information, comprised of a billing address and a payment method.
        /// </summary>
        public ResponseBillingModel Billing { get; set; }

        /// <summary>
        /// An object representing the shipping information, comprised of a shipping address and a shipping method.
        /// </summary>
        public ShippingModel Shipping { get; set; }

        /// <summary>
        /// A collection of line item objects representing the order lines.
        /// </summary>
        public LineItemModel[] LineItems { get; set; }

        /// <summary>
        /// A collection of objects representing additional properties of the order.
        /// </summary>
        public CustomPropertyModel[] CustomProperties { get; set; }
    }
}