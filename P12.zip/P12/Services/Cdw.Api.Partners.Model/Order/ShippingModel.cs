﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ShippingModel
    /// </summary>
    public class ShippingModel
    {
        /// <summary>
        /// holds Address
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public ShippingMethodModel Method { get; set; }
    }
}