﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds BillingInfoModel
    /// </summary>
    public class BillingInfoModel
    {
        /// <summary>
        /// holds Address
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public PaymentMethodModel Method { get; set; }
    }
}