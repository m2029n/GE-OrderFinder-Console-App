﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds OrderItemShippingRateModel
    /// </summary>
    public class OrderItemShippingRateModel
    {
        /// <summary>
        /// holds BoxHandling
        /// </summary>
        public decimal BoxHandling { get; set; }

        /// <summary>
        /// holds CdwCost
        /// </summary>
        public decimal CdwCost { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }
    }
}