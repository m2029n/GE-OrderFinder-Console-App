﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds TaxModel
    /// </summary>
    public class TaxModel
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds Rate
        /// </summary>
        public decimal Rate { get; set; }

        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}