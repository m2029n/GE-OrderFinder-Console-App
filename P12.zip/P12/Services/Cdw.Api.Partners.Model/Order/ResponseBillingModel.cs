﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ResponseBillingModel
    /// </summary>
    public class ResponseBillingModel
    {
        /// <summary>
        /// holds Address
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public ResponsePaymentMethodModel Method { get; set; }
    }
}