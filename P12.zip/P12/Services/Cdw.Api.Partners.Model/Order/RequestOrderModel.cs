﻿using System;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// Submited via post Orders/{orderNumber}
    /// </summary>
    public class RequestOrderModel
    {
        /// <summary>
        /// Response Only
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// The date the order was created. Date format is ISO 8601.
        /// (Required)
        /// </summary>
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// An integer representing the CDW company. Valid values are:
        /// 1000  CDW
        /// (Required)
        /// </summary>
        public int Company { get; set; }

        ///<summary>
        /// Partner’s reference number for the order. This value should be unique for each order placed through the API. Orders placed through other channels may not include a reference number.
        /// Maximum Length: 100
        ///</summary>
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// An object identifying the customer who submitted the order.
        /// </summary>
        public AccountModel Account { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public decimal Subtotal { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public decimal Discount { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public TaxModel[] Taxes { get; set; }

        /// <summary>
        /// The dollar amount for freight charges.
        /// (Required)
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// The dollar amount for handling charges.
        /// (Required)
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// The dollar amount for shipping insurance.
        /// (Required)
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public decimal Tax { get; set; }

        /// <summary>
        ///Response Only
        /// </summary>
        public decimal Total { get; set; }

        /// <summary>
        /// A collection of discount objects applied at the order level.
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// An object representing the billing information, comprised of a billing address and a payment method.
        /// (Required)
        /// </summary>
        public BillingInfoModel Billing { get; set; }

        /// <summary>
        /// An object representing the shipping information, comprised of a shipping address and a shipping method.
        /// (Required)
        /// </summary>
        public ShippingInfoModel Shipping { get; set; }

        /// <summary>
        /// A collection of line item objects representing the order lines.
        /// (Required)
        /// </summary>
        public LineItemModel[] LineItems { get; set; }

        /// <summary>
        /// A collection of objects representing additional properties of the order.
        /// </summary>
        public CustomPropertyModel[] CustomProperties { get; set; }

        /// <summary>
        /// holds IpAddress
        /// </summary>
        public string IpAddress { get; set; }

        /// <summary>
        /// holds Geolocation
        /// </summary>
        public string Geolocation { get; set; }

        /// <summary>
        /// holds UserAgent
        /// </summary>
        public string UserAgent { get; set; }
    }
}