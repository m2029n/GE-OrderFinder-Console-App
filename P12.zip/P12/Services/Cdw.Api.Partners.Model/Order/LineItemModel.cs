﻿using System.Linq;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds LineItemModel
    /// </summary>
    public class LineItemModel
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// holds ManufacturerItemDesc
        /// </summary>
        public string ManufacturerItemDesc { get; set; }

        /// <summary>
        /// holds Status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public uint Quantity { get; set; }

        /// <summary>
        /// holds UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// holds LinePrice
        /// </summary>
        public decimal LinePrice { get; set; }

        /// <summary>
        /// holds Discounts
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public CustomPropertyModel[] CustomProperties { get; set; }

        /// <summary>
        /// holds Shipments
        /// </summary>
        public ShipmentModel[] Shipments { get; set; }

        /// <summary>
        /// Returns the value of the customer property.
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public string GetCustomPropertiesValue(string propertyName)
        {
            if (CustomProperties == null || CustomProperties.Any() == false)
            {
                return string.Empty;
            }

            var count = CustomProperties.Count(item => item.Name == propertyName);
            if (count != 1)
            {
                return string.Empty;
            }

            return CustomProperties.Single(item => item.Name == propertyName).Value;
        }
    }
}