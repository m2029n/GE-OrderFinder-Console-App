﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ShippingInfoModel
    /// </summary>
    public class ShippingInfoModel
    {
        /// <summary>
        /// holds address
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// holds shipping method
        /// </summary>
        public ShippingMethodModel Method { get; set; }
    }
}