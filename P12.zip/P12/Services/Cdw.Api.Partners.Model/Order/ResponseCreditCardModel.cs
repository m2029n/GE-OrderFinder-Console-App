﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ResponseCreditCardModel
    /// </summary>
    public class ResponseCreditCardModel
    {
        /// <summary>
        /// holds Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// holds Number
        /// </summary>
        public string Number { get; set; }
    }
}