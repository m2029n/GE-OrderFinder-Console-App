﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ShippingMethodModel
    /// </summary>
    public class ShippingMethodModel
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }
    }
}