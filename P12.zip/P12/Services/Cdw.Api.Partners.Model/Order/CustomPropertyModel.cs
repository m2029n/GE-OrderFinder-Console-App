﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds CustomPropertyModel
    /// </summary>
    public class CustomPropertyModel
    {
        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// holds Value
        /// </summary>
        public string Value { get; set; }
    }
}