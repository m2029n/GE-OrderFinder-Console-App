﻿using System;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds OrderShippingRateModel
    /// </summary>
    public class OrderShippingRateModel
    {
        /// <summary>
        /// holds BoxCount
        /// </summary>
        public int BoxCount { get; set; }

        /// <summary>
        /// holds BoxHandlingCharge
        /// </summary>
        public decimal BoxHandlingCharge { get; set; }

        /// <summary>
        /// holds FreightCost
        /// </summary>
        public decimal FreightCost { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds OrderItems
        /// </summary>
        public OrderItemShippingRateModel OrderItems { get; set; }

        /// <summary>
        /// holds TotalShippingCharge
        /// </summary>
        public decimal TotalShippingCharge { get; set; }

        /// <summary>
        /// holds TotalWeight
        /// </summary>
        public decimal TotalWeight { get; set; }

        /// <summary>
        /// holds TransactionGUID
        /// </summary>
        public Guid TransactionGUID { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public ShippingMethodModel Method { get; set; }
    }
}