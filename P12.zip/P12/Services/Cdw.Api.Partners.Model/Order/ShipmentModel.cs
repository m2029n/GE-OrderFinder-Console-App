﻿using System;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ShipmentMOdel
    /// </summary>
    public class ShipmentModel
    {
        /// <summary>
        /// holds InvoiceNumber
        /// </summary>
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// holds Box info
        /// </summary>
        public int Box { get; set; }

        /// <summary>
        /// holds ShippedDate
        /// </summary>
        public DateTime ShippedDate { get; set; }

        /// <summary>
        /// holds ShippingMethod
        /// </summary>
        public ShippingMethodModel ShippingMethod { get; set; }

        /// <summary>
        /// holds TrackingNumber
        /// </summary>
        public string TrackingNumber { get; set; }

        /// <summary>
        /// holds TrackingUrl
        /// </summary>
        public string TrackingUrl { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }

        /// <summary>
        /// holds Contents
        /// </summary>
        public ShippedItemModel[] Contents { get; set; }
    }
}