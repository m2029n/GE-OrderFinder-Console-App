﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// An Order object represents the details of an order. While similar in format to the request data sent when creating an order, they should not be considered equivocal.
    /// </summary>
    public class AccountModel
    {
        /// <summary>
        /// used to identify customer by number
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// electronic account
        /// </summary>
        public string EAccount { get; set; }

        /// <summary>
        ///  email address of the account
        /// </summary>
        public string EmailAddress { get; set; }
    }
}