﻿using Newtonsoft.Json;

namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds PaymentMethodModel
    /// </summary>
    public class PaymentMethodModel
    {
        /// <summary>
        /// holds CreditCard, JsonIgnore to remove sensitive info from logs
        /// </summary>
        [JsonIgnore]
        public CreditCardModel CreditCard { get; set; }

        /// <summary>
        /// holds EncryptedCreditCard
        /// </summary>
        public string EncryptedCreditCard { get; set; }

        /// <summary>
        /// holds PONumber
        /// </summary>
        public string PONumber { get; set; }

        /// <summary>
        /// holds Terms
        /// </summary>
        public string Terms { get; set; }

        /// <summary>
        /// holds TransactionId
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// holds ReferenceNumber
        /// </summary>
        public string ReferenceNumber { get; set; }
    }
}