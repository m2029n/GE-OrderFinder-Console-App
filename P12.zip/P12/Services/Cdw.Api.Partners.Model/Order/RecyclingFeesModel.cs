﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds RecyclingFeesModel
    /// </summary>
    public class RecyclingFeesModel
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// holds Code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
    }
}