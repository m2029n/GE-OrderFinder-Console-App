﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ResponsePaymentMethodModel
    /// </summary>
    public class ResponsePaymentMethodModel
    {
        /// <summary>
        /// holds PONumber
        /// </summary>
        public string PONumber { get; set; }

        /// <summary>
        /// holds CreditCard
        /// </summary>
        public ResponseCreditCardModel CreditCard { get; set; }

        /// <summary>
        /// holds Terms
        /// </summary>
        public string Terms { get; set; }
    }
}