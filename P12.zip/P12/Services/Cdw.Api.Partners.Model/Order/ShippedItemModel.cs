﻿namespace Cdw.Api.Partners.Model.Order
{
    /// <summary>
    /// holds ShippedItemModel
    /// </summary>
    public class ShippedItemModel
    {
        /// <summary>
        /// holds productCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }
    }
}