﻿using System;

namespace Cdw.Api.Partners.Model.Cart
{
    /// <summary>
    /// used to identify partner cart request
    /// </summary>
    public class PartnerCartRequestModel
    {
        /// <summary>
        /// used to identify id of the request
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// used to identify source
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// used to identify CorrelationId
        /// </summary>
        public string CorrelationId { get; set; }

        /// <summary>
        /// used to identify CartUrl
        /// </summary>
        public string CartUrl { get; set; }

        /// <summary>
        /// used to identify WebSiteId
        /// </summary>
        public int WebSiteId { get; set; }

        /// <summary>
        /// date of when the request was created
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// line items in the request
        /// </summary>
        public PartnerCartRequestItemModel[] LineItems { get; set; }
    }
}