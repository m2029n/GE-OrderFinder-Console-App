﻿using System;

namespace Cdw.Api.Partners.Model.Cart
{
    /// <summary>
    /// holds PartnerCartResponseModel
    /// </summary>
    public class PartnerCartResponseModel
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// holds Source
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// holds CorrelationId
        /// </summary>
        public string CorrelationId { get; set; }

        /// <summary>
        /// holds CartUrl
        /// </summary>
        public string CartUrl { get; set; }

        /// <summary>
        /// holds WebSiteId
        /// </summary>
        public int WebSiteId { get; set; }

        /// <summary>
        /// holds Created
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public PartnerCartResponseItemModel[] LineItems { get; set; }
    }
}