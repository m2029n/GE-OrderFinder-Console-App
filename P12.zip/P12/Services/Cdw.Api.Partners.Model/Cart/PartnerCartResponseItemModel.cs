﻿namespace Cdw.Api.Partners.Model.Cart
{
    /// <summary>
    /// holds PartnerCartResponseItemModel
    /// </summary>
    public class PartnerCartResponseItemModel
    {
        /// <summary>
        /// holds Manufacturer
        /// </summary>
        public string Manufacturer { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
    }
}