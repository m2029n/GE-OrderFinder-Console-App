﻿namespace Cdw.Api.Partners.Model.Cart
{
    /// <summary>
    /// Used in Partner Cart requests items
    /// </summary>
    public class PartnerCartRequestItemModel
    {
        /// <summary>
        /// used to identify cart item id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// used to identify manufacturer
        /// </summary>
        public string Manufacturer { get; set; }

        /// <summary>
        /// used to identify manufacturer part number
        /// </summary>
        public string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// used to identify product code
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// used to identify quantity of items
        /// </summary>
        public int Quantity { get; set; }
    }
}