﻿namespace Cdw.Api.Partners.Model.Recycling
{
    /// <summary>
    /// implements RecyclingFeeSummary
    /// </summary>
    public class RecyclingFeeSummaryModel : IRecyclingFeeSummaryModel
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// holds ProductCodes
        /// </summary>
        public string ProductCodes { get; set; }
    }
}