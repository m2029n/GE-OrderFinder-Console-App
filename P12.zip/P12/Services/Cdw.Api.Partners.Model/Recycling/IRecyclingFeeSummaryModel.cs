﻿namespace Cdw.Api.Partners.Model.Recycling
{
    /// <summary>
    /// Recycling summary response object
    /// </summary>
    public interface IRecyclingFeeSummaryModel
    {
        /// <summary>
        /// Aggregated total of recycling fee for all Product Code/EDCs
        /// </summary>
        decimal Amount { get; set; }

        /// <summary>
        /// Comma separated Product Codes/EDCs given input
        /// </summary>
        string ProductCodes { get; set; }
    }
}