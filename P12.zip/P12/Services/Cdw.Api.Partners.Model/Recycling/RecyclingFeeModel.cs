﻿namespace Cdw.Api.Partners.Model.Recycling
{
    /// <summary>
    /// Implements IRecyclingFeeResponseModel
    /// </summary>
    public class RecyclingFeeModel : IRecyclingFeeModel
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// holds Code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds ProductFeeEDC
        /// </summary>
        public string ProductFeeEDC { get; set; }
    }
}