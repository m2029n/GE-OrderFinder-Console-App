﻿namespace Cdw.Api.Partners.Model.Recycling
{
    /// <summary>
    /// Defines the response from the recycling fee call
    /// </summary>
    public interface IRecyclingFeeModel
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        decimal Amount { get; }

        /// <summary>
        /// holds Code
        /// </summary>
        string Code { get; }

        /// <summary>
        /// holds Description
        /// </summary>
        string Description { get; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// holds ProductFeeEDC
        /// </summary>
        string ProductFeeEDC { get; }
    }
}