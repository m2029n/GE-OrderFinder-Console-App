﻿using Cdw.Common;

namespace Cdw.Api.Partners.Model.Recycling
{
    /// <summary>
    /// Recycling request model
    /// </summary>
    public class RecyclingFeeRequestModel
    {
        /// <summary>
        /// State code example CA,IL,MA etc.
        /// (Required)
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Comma separated Product Codes/EDCs
        /// (Required)
        /// </summary>
        public string ProductCodes { get; set; }

        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }
    }
}