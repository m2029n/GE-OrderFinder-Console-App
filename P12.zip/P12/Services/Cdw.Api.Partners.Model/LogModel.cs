﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Cdw.Api.Partners.Model
//{
//    public class LogModel
//    {
//        public string Version { get; set; }
//        public string Host { get; set; }
//        public string ShortMessage { get; set; }
//        public string FullMessage { get; set; }
//        public DateTime Timestamp { get; set; }
//        public int Level { get; set; }
//        public int UserId { get; set; }
//        public string SomeInfo { get; set; }
//        public string SomeEnvVar { get; set; }
//    }
//}