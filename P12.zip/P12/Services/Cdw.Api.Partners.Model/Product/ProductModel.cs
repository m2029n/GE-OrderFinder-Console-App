﻿namespace Cdw.Api.Partners.Model.Product
{
    /// <summary>
    /// holds ProductModel
    /// </summary>
    public class ProductModel
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds FriendlyName
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// holds FriendlyDescription
        /// </summary>
        public string FriendlyDescription { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }
    }
}