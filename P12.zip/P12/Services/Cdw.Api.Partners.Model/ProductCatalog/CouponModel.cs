﻿namespace Cdw.Api.Partners.Model.ProductCatalog
{
    /// <summary>
    /// used as an item in product Catalog response model
    /// </summary>
    public class CouponModel
    {
        /// <summary>
        /// in place of discounted_unit_price
        /// </summary>
        public decimal DiscountedPrice { get; set; }

        /// <summary>
        /// in place of coupon_code
        /// </summary>
        public string CouponCode { get; set; }

        /// <summary>
        /// in place of coupon_description
        /// </summary>
        public string CouponDescription { get; set; }

        /// <summary>
        /// in place of coupon_disclaimer
        /// </summary>
        public string CouponDisclaimer { get; set; }//

        /// <summary>
        /// inplace of coupon_expiration
        /// </summary>
        public string CouponExpiration { get; set; }
    }
}