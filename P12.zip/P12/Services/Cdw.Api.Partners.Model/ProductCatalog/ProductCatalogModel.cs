﻿using System.Collections.Generic;

namespace Cdw.Api.Partners.Model.ProductCatalog
{
    /// <summary>
    /// used as an item in product Catalog response model
    /// </summary>
    public class ProductCatalogModel
    {
        private string _stockStatus;

        /// <summary>
        /// in place of cdw_product_code
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// in place of sku
        /// </summary>
        public string ManufacturePartNumber { get; set; }

        /// <summary>
        /// in place of unit_price
        /// </summary>
        public double Price { get; set; }

        /// <summary>
        /// in place of stock_status
        /// </summary>
        public string StockStatus

        {
            get
            {
                if (string.IsNullOrEmpty(_stockStatus))
                {
                    return string.Empty;
                }
                return _stockStatus;
            }
            set => _stockStatus = value;
        }

        /// <summary>
        /// in place of estimated_availability
        /// </summary>
        public string EstimatedAvailability { get; set; }

        /// <summary>
        /// in place of weight
        /// </summary>
        public decimal Weight { get; set; }

        /// <summary>
        /// used to
        /// </summary>
        public List<CouponModel> Coupons { get; set; }
    }
}