﻿using System.Collections.Generic;

namespace Cdw.Api.Partners.Model.ProductCatalog
{
    /// <summary>
    /// use in productCatalog end point
    /// </summary>
    public class ResponseProductCatalogModel
    {
        /// <summary>
        /// ctor
        /// </summary>
        public ResponseProductCatalogModel()
        {
            Results = new List<ProductCatalogModel>();
        }

        /// <summary>
        /// list of products' details
        /// </summary>
        public List<ProductCatalogModel> Results { get; set; }

        /// <summary>
        /// result Count
        /// </summary>
        public int ResultCount => Results.Count;

        /// <summary>
        /// Total Available for Download
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// used to identify how many records where skipped in the search
        /// </summary>
        public int Offset { get; set; }

        /// <summary>
        /// used to identify number of records returned
        /// </summary>
        public int Limit { get; set; }
    }
}