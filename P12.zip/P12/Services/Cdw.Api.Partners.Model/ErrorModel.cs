﻿using Newtonsoft.Json;

namespace Cdw.Api.Partners.Model
{
    /// <summary>
    /// Holds ErrorModel
    /// </summary>
    public class ErrorModel
    {
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="message"></param>
        public ErrorModel(string message)
        {
            Message = message;
        }

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="field"></param>
        /// <param name="message"></param>
        [JsonConstructor]
        public ErrorModel(string field, string message)
        {
            Field = field;
            Message = message;
        }

        /// <summary>
        /// holds Field
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// holds Message
        /// </summary>
        public string Message { get; set; }
    }
}