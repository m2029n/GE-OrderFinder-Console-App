﻿using System.Collections.Generic;

namespace Cdw.Api.Partners.Model.Logs
{
    /// <summary>
    /// useds in logs end point
    /// </summary>
    public class ResponseLogsModel
    {
        /// <summary>
        /// ctor
        /// </summary>
        public ResponseLogsModel()
        {
            Results = new List<RequestResponseLogLimitedResponseModel>();
        }

        /// <summary>
        /// list of logs' details
        /// </summary>
        public List<RequestResponseLogLimitedResponseModel> Results { get; set; }

        /// <summary>
        /// result Count
        /// </summary>
        public int ResultCount => Results.Count;

        //TODO: commented for future use
        ///// <summary>
        ///// Total Available for Download
        ///// </summary>
        //public int TotalCount { get; set; }

        ///// <summary>
        ///// used to identify how many records where skipped in the search
        ///// </summary>
        //public int Offset { get; set; }

        ///// <summary>
        ///// used to identify number of records returned
        ///// </summary>
        //public int Limit { get; set; }
    }
}