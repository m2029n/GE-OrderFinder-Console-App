﻿using System;

namespace Cdw.Api.Partners.Model.Logs
{
    /// <summary>
    /// Used to return data from Logs endpoint
    /// </summary>
    public class RequestResponseLogModel
    {
        /// <summary>
        /// Id of the log
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name of the partner who requested the resource
        /// </summary>
        public string PartnerName { get; set; }

        /// <summary>
        /// The request path from owin.RequestPath.
        /// </summary>
        public string RequestPath { get; set; }

        /// <summary>
        /// uniform resource identifier (URI) associated with the request.
        /// </summary>
        public string RequestUri { get; set; }

        /// <summary>
        /// owin.RequestBody
        /// </summary>
        public string RequestBody { get; set; }

        /// <summary>
        ///  The request headers.
        /// </summary>
        public string RequestHeaders { get; set; }

        /// <summary>
        ///  The server.RemoteIpAddress.
        /// </summary>
        public string RequestIpFrom { get; set; }

        /// <summary>
        ///  The HTTP method.
        /// </summary>
        public string RequestMethod { get; set; }

        /// <summary>
        /// The response header collection.
        /// </summary>
        public string ResponseHeaders { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string ResponseBody { get; set; }

        /// <summary>
        /// Request start Date
        /// </summary>
        public DateTime RequestStartDateUtc { get; set; }

        /// <summary>
        /// Elapsed from start time in Milliseconds
        /// </summary>
        public long ResponseProcessingTime { get; set; }

        /// <summary>
        /// owin.ResponseStatusCode
        /// </summary>
        public int ResponseResultCode { get; set; }
    }
}