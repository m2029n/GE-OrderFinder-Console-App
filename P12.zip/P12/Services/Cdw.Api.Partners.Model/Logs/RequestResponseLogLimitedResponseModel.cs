﻿using System;

namespace Cdw.Api.Partners.Model.Logs
{
    /// <summary>
    /// used to return data from the logs list end point
    /// </summary>
    public class RequestResponseLogLimitedResponseModel
    {
        /// <summary>
        /// Id of the log
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The request path from owin.RequestPath.
        /// </summary>
        public string RequestPath { get; set; }

        /// <summary>
        /// uniform resource identifier (URI) associated with the request.
        /// </summary>
        public string RequestUri { get; set; }

        /// <summary>
        /// response HttpStatusCode
        /// </summary>
        public int HttpStatusCode { get; set; }

        /// <summary>
        /// Request start Date UTC
        /// </summary>
        public DateTime RequestStartDateUtc { get; set; }

        /// <summary>
        /// Elapsed time in Milliseconds
        /// </summary>
        public long ResponseProcessingTime { get; set; }

        /// <summary>
        /// path for the request of the Log resource
        /// </summary>
        public string Location { get; set; }
    }
}