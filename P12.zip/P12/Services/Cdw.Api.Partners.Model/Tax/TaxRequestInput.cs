﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// used for tax requests
    /// </summary>
    public class TaxRequestInput
    {
        /// <summary>
        /// holds Account
        /// </summary>
        public AccountModel Account { get; set; }

        /// <summary>
        /// holds Address
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// holds Company
        /// </summary>
        public int Company { get; set; }

        /// <summary>
        /// holds Discounts
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public LineItemModel[] LineItems { get; set; }
    }
}