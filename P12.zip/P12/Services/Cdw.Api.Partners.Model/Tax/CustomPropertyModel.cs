﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// A CustomProperty is a name-value pair object that allows additional custom attributes to be conveyed
    /// </summary>
    public class CustomPropertyModel
    {
        /// <summary>
        /// A descriptive name for the custom property or attribute
        /// (Required)
        /// Maximum Length 100
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The value assigned to the custom property or attribute
        /// (Required)
        /// Maximum Length 100
        /// </summary>
        public string Value { get; set; }
    }
}