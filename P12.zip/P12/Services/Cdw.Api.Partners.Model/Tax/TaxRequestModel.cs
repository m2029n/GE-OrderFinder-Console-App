﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// Tax Request Model
    /// </summary>
    public class TaxRequestModel
    {
        /// <summary>
        /// An object identifying the customer who submitted the order
        /// (Optional)
        /// </summary>
        public AccountModel Account { get; set; }

        /// <summary>
        /// The shipping address to which the order will be delivered
        /// (Required)
        /// </summary>
        public AddressModel Address { get; set; }

        /// <summary>
        /// The company where this order is  being fulfilled
        /// (Required)
        /// </summary>
        public int Company { get; set; }

        /// <summary>
        /// A collection of discount objects applied at the order level
        /// (Optional)
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// The dollar amount for freight charges
        /// (Required)
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// The dollar amount for handling charges
        /// (Required)
        /// </summary>
        ///<remarks>optional</remarks>
        public decimal Handling { get; set; }

        /// <summary>
        /// The dollar amount for shipping insurance
        /// (Required)
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// A collection of line item objects representing the order lines
        /// (Required)
        /// </summary>
        public LineItemModel[] LineItems { get; set; }

        /// <summary>
        /// A collection of line item objects representing the order lines.A collection of product fees elements
        /// (Required)
        /// </summary>
        public ProductFeeModel[] ProductFees { get; set; }
    }
}