﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// A collection of line item objects representing the order lines
    /// </summary>
    public class LineItemModel
    {
        /// <summary>
        /// A collection of custom properties for adding additional information about the line item
        /// (Optional)
        /// </summary>
        public CustomPropertyModel[] CustomProperties { get; set; }

        /// <summary>
        /// A collection of discount objects applied at the order level
        /// (Optional)
        /// </summary>
        public DiscountModel[] Discounts { get; set; }

        /// <summary>
        /// The CDW product code uniquely identifying a product
        /// (Required)
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// The quantity of the product desired. Orders placed via the API are limited to a quantity of 999 for any given product. Quantities greater than that should be directed through an Account Manager
        /// (Required)
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The price per unit for the product. This price should reflect the agreed upon price with CDW before any discounts. Discounts should be reflected in the Discounts field
        /// (Required)
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Line number order in the collection
        /// </summary>
        public int? LineNumber { get; set; }

        /// <summary>
        /// The part number of the product from the manufacturer
        /// </summary>
        public string ManufacturerPartNumber { get; set; }
    }
}