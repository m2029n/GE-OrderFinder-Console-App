﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// Account is the means of uniquely identifying the customer account on whose behalf the order is being placed
    /// </summary>
    public class AccountModel
    {
        /// <summary>
        /// The CDW Customer Number
        /// (Optional)
        /// Maximum Length: 8
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// The CDW.com (or CDWG.com, or CDW.ca) user name
        /// (Optional)
        /// Maximum Length: 50
        /// </summary>
        public string EAccount { get; set; }

        /// <summary>
        /// The email address of the customer placing the order. Must be a valid email address
        /// (Required)
        /// Maximum Length: 64
        /// </summary>
        public string EmailAddress { get; set; }
    }
}