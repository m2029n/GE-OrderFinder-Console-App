﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// A Discount object represents the discounts granted to a particular order or order line item. Numerous discount types are available but may take the form of either a fixed dollar amount or a percentage
    /// </summary>
    public class DiscountModel
    {
        /// <summary>
        /// The amount of the discount. The amount will indicate either a fixed amount or a percentage as determined by the Type field. All discount amounts should be represented as positive numbers. Percentage values should be indicated on a scale of 0.00 – 100.00, e.g. 25.00 = 25%
        /// (Required)
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// An identification of the applied discount
        /// (Required)
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The type of discount applied. Not every type is valid in every scenario.  Valid values are:
        ///Order Level Discount Types
        ///1000  Fixed Amount Off Order
        ///1001  Percentage Off Order
        ///Order Line Item Level Discount Types
        ///1002  Fixed Amount Off Unit Price
        ///1003  Percentage Off Unit Price
        ///1004  Fixed Amount Off Line Price
        /// 1005  Percentage Off Line Price
        /// (Required)
        /// </summary>
        public int Type { get; set; }
    }
}