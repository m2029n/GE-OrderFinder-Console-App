﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// A collection of line item objects representing the order lines. A collection of product fees elements
    /// </summary>
    public class ProductFeeModel
    {
        /// <summary>
        /// EDC for recycle fee. The [ProductFeeEDC] value from /recycling/details endpoint
        /// </summary>
        public string FeeProductCode { get; set; }

        /// <summary>
        /// Fee applicable as recycle fee. The ["Amount": value from /recycling/details ] * [Quantity]
        /// </summary>
        public decimal FeeUnitPrice { get; set; }

        /// <summary>
        /// Line number order in the collection
        /// </summary>
        public int? LineNumber { get; set; }

        /// <summary>
        /// The CDW product code uniquely identifying a product
        /// (Required)
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// The quantity of the product desired. Orders placed via the API are limited to a quantity of 999 for any given product. Quantities greater than that should be directed through an Account Manager
        /// (Required)
        /// </summary>
        public int Quantity { get; set; }
    }
}