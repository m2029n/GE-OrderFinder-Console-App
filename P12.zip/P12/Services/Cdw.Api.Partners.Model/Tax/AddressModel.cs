﻿namespace Cdw.Api.Partners.Model.Tax
{
    /// <summary>
    /// An Address object represents a postal address. It used in both billing and shipping scenarios
    /// </summary>
    public class AddressModel
    {
        /// <summary>
        /// The first name of the recipient or responsible party at the address
        /// (Required)
        /// Maximum Length: 12
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// The last name of the recipient or responsible party at the address
        /// (Required)
        /// Maximum Length: 15
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// The phone number of the party identified in the Addressee field. The format for the phone number may take any of the following forms:
        /// 1115551234
        /// (111) 555-1234
        /// 111-555-1234
        /// 111.555.1234
        /// (Required)
        /// Maximum Length: 20
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// The name of the company at the address
        /// (Optional)
        /// Maximum Length: 35
        /// </summary>
        public string Company { get; set; }

        /// <summary>
        /// Street address - Line1 associated with customer's shipping address
        /// (Required)
        /// Maximum Length: 35
        /// </summary>
        public string StreetAddress { get; set; }

        /// <summary>
        /// Street address - Line2 associated with customer's shipping address , e.g. a suite or office number
        /// (Optional)
        /// Maximum Length: 35
        /// </summary>
        public string SecondaryStreetAddress { get; set; }

        /// <summary>
        /// The city in which the address resides
        /// (Required)
        /// Maximum Length: 20
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// The state (US) or province (Canada) abbreviation
        /// (Required)
        /// Maximum Length: 2
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// The 5 or 5+4 digit ZIP code (US), or 6 character postal code (Canada)
        /// (Required)
        /// </summary>
        public string PostalCode { get; set; }

        /// <summary>
        /// The ISO 3166 two-character country code
        ///"US"  United States
        ///"CA"  Canada
        /// (Required)
        /// </summary>
        public string IsoCountryCode { get; set; }
    }
}