﻿namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    /// An object for shipping address
    /// </summary>
    public class RatingRequestShippingAddressModel
    {
        /// <summary>
        /// The name of the company at the address
        /// (Optional)
        /// Maximum Length: 35
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// The first name of the recipient or responsible party at the address
        /// (Required)
        /// Maximum Length: 12
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// The last name of the recipient or responsible party at the address
        /// (Required)
        /// Maximum Length: 15
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Street address - Line1 associated with customer's shipping address
        /// (Required)
        /// Maximum Length: 35
        /// </summary>
        public string Line1 { get; set; }

        /// <summary>
        /// Street address - Line2 associated with customer's shipping address , e.g. a suite or office number
        /// (Optional)
        /// Maximum Length: 35
        /// </summary>
        public string Line2 { get; set; }

        /// <summary>
        /// The city in which the address resides
        /// (Required)
        /// Maximum Length: 20
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// The state (US) or province (Canada) abbreviation
        /// (Required)
        /// Maximum Length: 2
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// The ISO 3166 two-character country code
        ///"US"  United States
        ///"CA"  Canada
        /// (Required)
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// The 5 or 5+4 digit ZIP code (US), or 6 character postal code (Canada)
        /// (Required)
        /// </summary>
        public string PostalCode { get; set; }

        /// <summary>
        /// Bool value to depict if address is residence
        /// </summary>
        public bool IsResidence { get; set; }
    }
}