namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    /// An object identifying the requester for rating. This object is optional from version 2.3
    /// </summary>
    public class RatingRequesterModel
    {
        /// <summary>
        /// Hostname of the requester
        /// (Optional)
        /// </summary>
        public string HostName { get; set; }

        /// <summary>
        /// Platform of the requester Eg: CS
        /// (Required)
        /// </summary>
        public string Platform { get; set; }

        /// <summary>
        /// Application name of the requeser Eg: WEB
        /// (Required)
        /// </summary>
        public string ApplicationName { get; set; }

        /// <summary>
        /// Job name of the requester
        /// (Optional)
        /// </summary>
        public string JobName { get; set; }
    }
}