﻿namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    /// A collection of line item objects representing the order lines
    /// </summary>
    public class RatingRequestFreightItemModel
    {
        /// <summary>
        /// Item line number order in the request Eg: 1 for first product 2 for second product
        /// </summary>
        public int OrderLineNumber { get; set; }

        /// <summary>
        ///
        /// </summary>
        public int? ParentOrderLineNumber { get; set; }

        /// <summary>
        /// The CDW product code uniquely identifying a product
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// The quantity of the product desired. Orders placed via the API are limited to a quantity of 999 for any given product. Quantities greater than that should be directed through an Account Manager
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The price per unit for the product. This price should reflect the agreed upon price with CDW before any discounts.
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string ContractReferenceNumber { get; set; }  // TODO: SMM 3/19 - This field is being mapped but the debundler sets it to null.  Research if it can be removed

        /// <summary>
        /// The part number of the product from the manufacturer
        /// </summary>
        public string ManufacturerPartNumber { get; set; }  // TODO: SMM 3/19 - This field is not being mapped.  Research if it can be removed
    }
}