﻿namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    /// Rating request model
    /// </summary>
    public class RatingRequestModel
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public RatingRequestModel()
        {
            Requester = new RatingRequesterModel
            {
                Platform = "CS"
            };
        }

        /// <summary>
        /// An object identifying the requester for rating
        /// (Optional)
        /// </summary>
        public RatingRequesterModel Requester { get; set; }

        /// <summary>
        ///
        /// </summary>
        public RatingRequestOptionsModel Options { get; set; }

        /// <summary>
        /// The company where this order is  being fulfilled
        /// </summary>
        public string CompanyCode { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string OrderReferenceNumber { get; set; }

        /// <summary>
        /// An Object of shipping address model where product is being shipped
        /// </summary>
        public RatingRequestShippingAddressModel ShipTo { get; set; }

        /// <summary>
        /// A collection of line item objects representing the order lines
        /// </summary>
        public RatingRequestFreightItemModel[] ItemsToShip { get; set; }

        /// <summary>
        ///
        /// </summary>
        public RatingRequestSalesChannelModel SalesChannel { get; set; }
    }
}