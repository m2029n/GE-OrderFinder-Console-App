﻿using Newtonsoft.Json;

namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    /// An object describing rating options for freight
    /// </summary>
    public class RatingRequestOptionsModel
    {
        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool Debug { get; set; }

        /// <summary>
        /// Set to true will include freight details in response
        /// </summary>
        public bool IncludeFreightDetails { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool IsCod { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool IsDropShip { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool IsFree { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool ExcludeExtendedInfo { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool ExcludePackages { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool ExcludeRates { get; set; }

        /// <summary>
        /// (Optional)
        /// </summary>
        [JsonIgnore]
        public bool IncludeUnavailableRates { get; set; }
    }
}