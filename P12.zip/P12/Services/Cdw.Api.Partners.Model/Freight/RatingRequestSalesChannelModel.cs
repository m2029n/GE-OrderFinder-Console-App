﻿namespace Cdw.Api.Partners.Model.Freight
{
    /// <summary>
    ///
    /// </summary>
    public class RatingRequestSalesChannelModel
    {
        /// <summary>
        /// Value provided to the partner by CDW
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string ShipMethodFilter { get; set; }
    }
}