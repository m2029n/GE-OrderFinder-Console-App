﻿using System;
using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Cdw.Domain.Partners.Common;

using Cdw.Domain.Partners.Orders;

namespace Cdw.Services.UnitTests.FakeObjects
{
    internal static class FakeExtensions
    {
        public static RequestOrderModel Fake(this RequestOrderModel obj)
        {
            obj.Company = 1000;

            return obj;
        }

        public static Order Fake(this Order order)
        {
            order.OrderNumber = "OrderNumber1";
            order.Cart = new Cart().Fake();
            order.ReferenceNumber = "ReferenceNumber1";
            order.Account = new Account().Fake();
            order.Taxes = new List<Tax>() { new Tax().Fake() };
            order.Total = 100;
            order.Shipments = new List<IShipment>() { new Shipment().Fake() };
            order.Billing = new BillingInfo().Fake();
            order.Shipping = new ShippingInfo().Fake();
            order.RecyclingFee = 1;
            order.RecyclingFees = new List<IRecyclingFee>() { new RecyclingFee().Fake() };
            return order;
        }

        public static RecyclingFee Fake(this RecyclingFee obj)
        {
            obj.ProductCode = "123456";
            obj.Amount = 1;
            obj.Code = "10";
            obj.Description = "Description";
            return obj;
        }

        public static BillingInfo Fake(this BillingInfo obj)
        {
            obj.Address = new Address().Fake();
            obj.Method = new PaymentMethod().Fake();
            return obj;
        }

        public static PaymentMethod Fake(this PaymentMethod obj)
        {
            obj.CreditCard = new CreditCard().Fake();
            obj.EncryptedCreditCard = "encryption";
            obj.PONumber = "PONumber";
            return obj;
        }

        public static CreditCard Fake(this CreditCard obj)
        {
            obj.Type = new CreditCardType().Fake();
            obj.ExpirationMonth = 11;
            obj.ExpirationYear = 2018;
            obj.Id = 1;
            obj.Name = "First Name Last Name";
            obj.Number = "4012000033330026";
            obj.Token = "123";
            return obj;
        }

        public static CreditCardType Fake(this CreditCardType obj)
        {
            obj.Type = PaymentMethodType.Visa;
            obj.CardNumberLength = 16;
            obj.Name = "First Name Last Name";

            return obj;
        }

        public static Address Fake(this Address obj)
        {
            obj.FirstName = "FirstName";
            obj.LastName = "LastName";
            obj.PhoneNumber = "PhoneNumber";
            obj.Company = "Company";
            obj.StreetAddress = "StreetAddress";
            obj.SecondaryStreetAddress = "SecondaryStreetAddress";
            obj.City = "City";
            obj.State = "State";
            obj.IsoCountryCode = "US";
            obj.PostalCode = "60661";

            return obj;
        }

        public static Shipment Fake(this Shipment obj)
        {
            obj.Box = 1;
            obj.ShippingMethod = new ShippingMethod().Fake();
            obj.Contents = new List<IShippedItem>()
            {
                new ShippedItem() {ManufacturerPartNumber = "partnumber", ProductCode = "123456", Quantity = 1}
            };
            obj.ShippedDate = DateTime.Now;
            obj.TrackingNumber = "trackingnumber";
            obj.TrackingUrl = "www.test.com";
            obj.Weight = 100;
            obj.Contents = new List<IShippedItem>()
            {
                new ShippedItem() {ManufacturerPartNumber = "partnumber", ProductCode = "123456", Quantity = 1}
            };
            return obj;
        }

        public static Cart Fake(this Cart obj)
        {
            obj.Id = 1;
            obj.Company = CdwCompany.CDW;
            obj.Items = new List<ICartItem>() { new CartItem().Fake() };
            obj.Discounts = new CartDiscounts().Fake();
            obj.CustomProperties = new List<ICustomProperty>() { new CustomProperty().Fake() };
            return obj;
        }

        public static CartDiscounts Fake(this CartDiscounts obj)
        {
            obj.FixedAmountDiscounts = new List<IDiscount>() { new Discount().Fake() };
            var per = new Discount().Fake();
            per.Type = 1001;
            obj.PercentOffDiscounts = new List<IDiscount>() { per };
            return obj;
        }

        public static Discount Fake(this Discount obj)
        {
            obj.Id = "1";
            obj.Type = 1000;
            obj.Amount = 10;

            return obj;
        }

        public static CartItem Fake(this CartItem obj)
        {
            obj.Id = 1;
            obj.Product = new Product().Fake();
            obj.Status = CartItemStatus.Canceled;
            obj.Quantity = 10;
            obj.UnitPrice = 10;
            obj.Discounts = new CartItemDiscounts().Fake();
            obj.CustomProperties = new List<ICustomProperty>() { new CustomProperty().Fake() };

            return obj;
        }

        public static CustomProperty Fake(this CustomProperty obj)
        {
            obj.Name = "key";
            obj.Value = "value";
            return obj;
        }

        public static CartItemDiscounts Fake(this CartItemDiscounts obj)
        {
            obj.FixedLinePriceDiscounts = new List<IDiscount>() { new Discount().Fake() };
            var dis = new Discount().Fake();
            dis.Type = 1003;
            obj.FixedUnitPriceDiscounts = new List<IDiscount>() { dis };
            var dis1 = new Discount().Fake();
            dis1.Type = 1004;
            obj.PercentOffLinePriceDiscounts = new List<IDiscount>() { dis1 };
            var dis2 = new Discount().Fake();
            dis2.Type = 1005;
            obj.PercentOffUnitPriceDiscounts = new List<IDiscount>() { dis2 };

            return obj;
        }

        public static Product Fake(this Product obj)
        {
            obj.ProductCode = "123456";
            return obj;
        }

        public static ShippingInfo Fake(this ShippingInfo obj)
        {
            obj.Method = new ShippingMethod().Fake();
            obj.Address = new Address().Fake();

            return obj;
        }

        public static ShippingMethod Fake(this ShippingMethod obj)
        {
            obj.Id = "1";
            obj.Description = "Description";
            obj.Rate = new OrderShippingRate().Fake();

            return obj;
        }

        public static OrderShippingRate Fake(this OrderShippingRate obj)
        {
            obj.Freight = 100;
            obj.Handling = 0;
            obj.Insurance = 0;
            return obj;
        }

        public static Tax Fake(this Tax obj)
        {
            obj.Id = "1";
            obj.Description = "Sales Tax";
            obj.Rate = 9;
            obj.Amount = 4;

            return obj;
        }

        public static Account Fake(this Account obj)
        {
            obj.EmailAddress = "testtest@cdw.com";
            obj.CustomerNumber = "CustomerNumber";
            obj.EAccount = "Eaccount";
            return obj;
        }
    }
}