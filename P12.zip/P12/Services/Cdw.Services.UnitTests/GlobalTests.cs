﻿using Cdw.Partners.Host;
using Xunit;

namespace Cdw.Services.UnitTests
{
    public class GlobalTests
    {
        [Fact]
        public void GlobalTest()
        {
            var sut = new Global();

            Assert.NotNull(sut);
        }
    }
}