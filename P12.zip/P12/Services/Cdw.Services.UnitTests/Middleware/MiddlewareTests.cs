﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Partners.Host.Middleware;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Middleware
{
    public class MiddlewareTests
    {
        [Fact]
        public async void It_Should_Log_Request()
        {
            //Arrange
            RequestResponseLog actual = null;
            var service = new Mock<ILogRequestResponseManager>();
            var expectedCall = new RequestResponseLog();
            expectedCall.PartnerName = "Kate Sky";
            service.Setup(s => s.InsertRequestResponseLogAsync(It.IsAny<RequestResponseLog>())).ReturnsAsync(expectedCall);
            service.Setup(x => x.InsertRequestResponseLogAsync(It.IsAny<RequestResponseLog>())).Callback<RequestResponseLog>(r =>
            {
                actual = r;
            }).ReturnsAsync(actual);
            var logRequestMiddleware = new LogRequestResponseMiddleware((innerHttpContext) => Task.FromResult(0), new LogRequestResponseMiddlewareOptions { Enabled = true, Service = service.Object });
            var environment = new Dictionary<string, object>();
            environment["owin.RequestHeaders"] = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
            environment["owin.RequestBody"] = new MemoryStream();
            environment["owin.ResponseBody"] = new MemoryStream();
            environment["owin.RequestPath"] = "/orders";
            //Act
            await logRequestMiddleware.Invoke(environment);
            //Assert
            service.Verify(m => m.InsertRequestResponseLogAsync(It.IsAny<RequestResponseLog>()));
            Assert.NotNull(actual);
        }

        [Fact]
        public async void It_Should_Log_Request_when_no_body()
        {
            //Arrange
            var service = new Mock<ILogRequestResponseManager>();
            var expectedCall = new RequestResponseLog();
            expectedCall.PartnerName = "Kate Sky";
            service.Setup(s => s.InsertRequestResponseLogAsync(new RequestResponseLog())).ReturnsAsync(expectedCall);
            var logRequestMiddleware = new LogRequestResponseMiddleware((innerHttpContext) => Task.FromResult(0), new LogRequestResponseMiddlewareOptions { Enabled = true, Service = service.Object });
            var environment = new Dictionary<string, object>();
            environment["owin.RequestHeaders"] = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
            environment["owin.RequestPath"] = "/orders";
            //Act
            await logRequestMiddleware.Invoke(environment);
            //Assert
            service.Verify(m => m.InsertRequestResponseLogAsync(It.IsAny<RequestResponseLog>()));
        }
    }
}