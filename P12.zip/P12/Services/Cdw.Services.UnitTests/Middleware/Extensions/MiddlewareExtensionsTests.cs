﻿using Cdw.Partners.Host.Middleware.Extensions;
using Microsoft.Owin;
using Xunit;

namespace Cdw.Services.UnitTests.Middleware.Extensions
{
    public class MiddlewareExtensionsTests
    {
        [Fact]
        public void GetResponseBodyObjectTest()
        {
            //Arrange
            var body = "{'message': 'test'}";
            //Act
            var sut = body.GetResponseBodyObject();
            //Assert
            Assert.NotNull(sut);
        }

        [Fact]
        public void GetResponseBodyObject_should_pass_when_Null_Test()
        {
            //Arrange
            var body = "";
            //Act
            var sut = body.GetResponseBodyObject();
            //Assert
            Assert.Null(sut);
        }

        [Fact]
        public void GetRequestBodyObjectTest()
        {
            //Arrange
            var body = "{'message': 'test'}";
            //Act
            var sut = body.GetRequestBodyObject(true);
            //Assert
            Assert.NotNull(sut);
        }

        [Fact]
        public void GetRequestBodyObject_should_pass_when_Null_Test()
        {
            //Arrange
            var body = "";
            //Act
            var sut = body.GetRequestBodyObject(true);
            //Assert
            Assert.Null(sut);
        }

        [Fact]
        public void GetRequestBodyObject_should_pass_when_biling_Test()
        {
            //Arrange
            var body = "{'Billing':{'Method':{'EncryptedCreditCard':'1234'}}}";
            //Act
            var sut = body.GetRequestBodyObject(true);
            //Assert
            Assert.Equal(sut["Billing"]["Method"]["EncryptedCreditCard"], "XXXX");
        }

        [Fact]
        public void GetRequestBodyObject_should_pass_when_error_Test()
        {
            //Arrange
            var body = "23";
            //Act
            var sut = body.GetRequestBodyObject(true);
            //Assert
            Assert.Null(sut);
        }

        [Fact()]
        public void GetUriTest()
        {
            //Arrange
            var request = new OwinRequest();
            //Act
            var sut = request.GetUri();
            //Assert
            Assert.Equal(sut, "");
        }

        [Fact]
        public void GetHeadersTest()
        {
            //Arrange
            //Act
            var sut = ((IOwinRequest)null).GetHeaders();
            //Assert
            Assert.NotNull(sut);
        }

        [Fact]
        public void GetHeaders_response_Test()
        {
            //Arrange
            var response = new OwinResponse();
            //Act
            var sut = response.GetHeaders();
            //Assert
            Assert.NotNull(sut);
        }
    }
}