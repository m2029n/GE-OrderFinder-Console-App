﻿using System;
using Cdw.Domain.Partners.Orders;
using Cdw.Partners.Utilities;
using Cdw.Services.UnitTests.FakeObjects;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests
{
    public class LoggerExtensionMethodTests
    {
        [Fact]
        public void FatalTest1()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Fatal(logger, null, null, null, new Order().Fake());
            Assert.True(true);
        }

        [Fact]
        public void ErrorTest()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Error(logger, null, null, null);
            Assert.True(true);
        }

        [Fact]
        public void ErrorTest1()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Error(logger, null, null, null, new Order().Fake());
            Assert.True(true);
        }

        [Fact]
        public void ErrorTest2()
        {
            ILog logger = new Mock<ILog>().Object;
            logger.Error("Order log error", new Exception(), new Order().Fake());
            Assert.True(true);
        }

        [Fact]
        public void InfoTest()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Info(logger, null, null);
            Assert.True(true);
        }

        [Fact]
        public void DebugTest()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Debug(logger, null, null);
            Assert.True(true);
        }

        [Fact]
        public void DebugTest1()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Debug(logger, new Order().Fake(), "test", null);
            Assert.True(true);
        }

        [Fact]
        public void DebugTest2()
        {
            ILog logger = new Mock<ILog>().Object;
            LoggerExtensionMethod.Debug(logger, new Order().Fake(), null, null);
            Assert.True(true);
        }
    }
}