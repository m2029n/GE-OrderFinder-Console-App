﻿using Cdw.Api.Partners.Service.Infrastructure.Converters.Order.ResponseObject;
using Cdw.Domain.Partners.Orders;
using Cdw.Test.Common.Xunit;
using Xunit;

namespace Cdw.Services.UnitTests
{
    [CI]
    public class ConverterTests
    {
        [Theory(DisplayName = "PostCodeValidations")]
        [InlineData("60661-", "US", "60661-")]
        [InlineData("606612-", "CA", "606612-")]
        [InlineData("606114249", "US", "60611-4249")]
        [InlineData("60611454", "US", "60611454")]
        [InlineData("606114-49", "US", "60611-4-49")]
        [InlineData("T2P3G6", "CA", "T2P 3G6")]
        [InlineData("T2P3-6", "CA", "T2P 3-6")]
        public void PostCodeValidations(string postalCode, string isoCountryCode, string expectedValue)
        {
            var target = new ResponseOrderConverter();
            var address = new Address
            {
                PostalCode = postalCode,
                IsoCountryCode = isoCountryCode
            };
            var retVal = target.FormatPostalCode(address);

            Assert.Equal(expectedValue, retVal);
        }
    }
}