﻿using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.Controllers;
using Moq;

namespace Cdw.Services.UnitTests
{
    internal static class Helper
    {
        public static HttpRequestContext FakeControllerContext(string partnerName)
        {
            var userMock = new Mock<IPrincipal>();
            userMock.SetupGet(p => p.Identity.Name).Returns(partnerName);
            userMock.SetupGet(p => p.Identity.IsAuthenticated).Returns(true);
            var requestContext = new Mock<HttpRequestContext>();
            requestContext.Setup(x => x.Principal).Returns(userMock.Object);
            requestContext.Setup(x => x.Configuration).Returns(new HttpConfiguration());
            return requestContext.Object;
        }
    }
}