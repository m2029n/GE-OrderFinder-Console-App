﻿using AutoMapper;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Encryption;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Common;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Services.UnitTests.FakeObjects;
using Cdw.Test.Common.Xunit;
using Common.Logging;
using Moq;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using Xunit;

namespace Cdw.Services.UnitTests
{
    [CI]
    public class OrdersControllerTests
    {
        private Mock<ILog> _logger;
        private Mock<IPartnerDetails> _helper;
        private Mock<IOrderManager> _orderManager;

        private Mock<IEncryptionService> _encryptionService;

        private OrdersController _ordersController;

        public OrdersControllerTests()
        {
            Mapper.AddProfile(new TaxMappingProfile());
            Mapper.AddProfile(new ProductMappingProfile());
            Mapper.AddProfile(new CartMappingProfile());
            Mapper.AddProfile(new OrdersMappingProfile());
            Mapper.AddProfile(new ResponseOrdersMappingProfile());

            _helper = new Mock<IPartnerDetails>();
            _helper.Setup(x => x.GetPartnerSourceCode(It.IsAny<Partner>())).Returns(FakeHelper.GetFakeIdentityFakeObject());

            _logger = new Mock<ILog>();
            _orderManager = new Mock<IOrderManager>();
            _encryptionService = new Mock<IEncryptionService>();

            _ordersController = new OrdersController(_logger.Object, _orderManager.Object, _encryptionService.Object, _helper.Object);
            _ordersController.RequestContext = Helper.FakeControllerContext("Xerox Direct");
            _ordersController.Request = new HttpRequestMessage();
        }

        [Fact(DisplayName = "GetHeartbeat_Test")]
        public async void GetHeartbeat_Test()
        {
            var act = await _ordersController.Heartbeat().ConfigureAwait(false);

            Assert.NotNull(act);
        }

        [Fact(DisplayName = "GetOrder_Test")]
        public async void GetOrder_Test()
        {
            _orderManager.Setup(x => x.GetOrderAsync("Abc", It.IsAny<ITrackingValues>(), It.IsAny<string>()))
                .ReturnsAsync(new Order().Fake());
            var act = await _ordersController.GetOrder("Abc").ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.OK);
            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JObject o = JObject.Parse(json);
            Assert.Equal((string)o["OrderNumber"], "OrderNumber1");
        }

        [Theory(DisplayName = "CreateOrder_Test")]
        [InlineData("Xerox Direct", 1000)]
        [InlineData("Xerox Canada", 1012)]
        public async void CreateOrder_Test(string partnerName, int companyCode)
        {
            _ordersController = new OrdersController(_logger.Object, _orderManager.Object, _encryptionService.Object, _helper.Object);
            _ordersController.RequestContext = Helper.FakeControllerContext(partnerName);
            _ordersController.Request = new HttpRequestMessage();

            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = companyCode;
            requestObj.ReferenceNumber = "ReferenceNumber1";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };
            requestObj.LineItems = new[]
            {
                new LineItemModel()
                {
                    ProductCode = "2443006",
                    Status = "Shipped",
                    Quantity = 1,
                    UnitPrice = 895.46M,
                    LinePrice = 895.46M,
                }
            };
            _orderManager.Setup(x => x.CreateOrderAsync(It.IsAny<IRequestOrder>())).ReturnsAsync(new Order().Fake());

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.Created, act.StatusCode);
            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JObject o = JObject.Parse(json);
            Assert.Equal((string)o["ReferenceNumber"], "ReferenceNumber1");
        }
    }
}