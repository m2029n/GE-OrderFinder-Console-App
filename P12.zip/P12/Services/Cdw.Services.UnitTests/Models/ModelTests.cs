﻿using System;
using System.Collections.Generic;
using Cdw.Common;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.PartnerCart;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Models
{
    public class ModelTests
    {
        [Fact]
        public void XeroxDirectTest()
        {
            var sut = new XeroxDirect();
            sut.ClientId = 123;

            sut.FreightRaterSpecialCode = "FreightRaterSpecialCode";

            Assert.Equal(sut.ClientId, 123);
            Assert.Equal(sut.ClientName, "Xerox Direct");
            Assert.Equal(sut.FreightRaterSpecialCode, "FreightRaterSpecialCode");
        }

        [Fact]
        public void PartnerCartRequestTest()
        {
            var sut = new PartnerCartRequest();
            sut.Id = 123;

            sut.Source = "Source";
            sut.CorrelationId = "CorrelationId";
            sut.CartUrl = "CartUrl";
            sut.WebSiteId = 132;
            sut.Created = DateTime.MaxValue;
            sut.CartUrl = "CartUrl";
            var mokItems = new Mock<IEnumerable<IPartnerCartRequestItem>>();
            sut.LineItems = mokItems.Object;
            sut.TrackingValues = new Mock<ITrackingValues>().Object;
            Assert.Equal(sut.CartUrl, "CartUrl");
            Assert.Equal(sut.Id, 123);
            Assert.Equal(sut.Source, "Source");
            Assert.Equal(sut.CorrelationId, "CorrelationId");
            Assert.Equal(sut.WebSiteId, 132);
            Assert.Equal(sut.Created, DateTime.MaxValue);
            Assert.NotNull(sut.LineItems);
            Assert.NotNull(sut.TrackingValues);
        }

        [Fact]
        public void PartnerCartRequestItemTest()
        {
            var sut = new PartnerCartRequestItem();
            sut.Id = 123;

            sut.Manufacturer = "Manufacturer";
            sut.ManufacturerPartNumber = "ManufacturerPartNumber";
            sut.ProductCode = "ProductCode";
            sut.Quantity = 132;

            Assert.Equal(sut.Manufacturer, "Manufacturer");
            Assert.Equal(sut.Id, 123);
            Assert.Equal(sut.ManufacturerPartNumber, "ManufacturerPartNumber");
            Assert.Equal(sut.ProductCode, "ProductCode");
            Assert.Equal(sut.Quantity, 132);
        }
    }
}