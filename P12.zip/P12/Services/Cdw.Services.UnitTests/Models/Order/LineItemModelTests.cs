﻿using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Xunit;

namespace Cdw.Services.UnitTests.Models
{
    public class LineItemModelTests
    {
        [Fact]
        public void GetCustomPropertiesValue_ShouldReturnEmptyWhenNull()
        {
            // Arrange
            var model = new LineItemModel();

            // Act
            var actual = model.GetCustomPropertiesValue("DoesNotMatter");

            // Assert
            Assert.Equal(string.Empty, actual);
        }

        [Fact]
        public void GetCustomPropertiesValue_ShouldReturnEmptyWhenEmptyArray()
        {
            // Arrange
            var model = new LineItemModel
            {
                CustomProperties = new List<CustomPropertyModel>().ToArray()
            };

            // Act
            var actual = model.GetCustomPropertiesValue("DoesNotMatter");

            // Assert
            Assert.Equal(string.Empty, actual);
        }

        [Fact]
        public void GetCustomPropertiesValue_ShouldReturnEmptyWhenMultipleMatchesFound()
        {
            const string propertyName = "DoesNotMatter";

            // Arrange
            var model = new LineItemModel
            {
                CustomProperties = new List<CustomPropertyModel>
                {
                    new CustomPropertyModel { Name = propertyName },
                    new CustomPropertyModel { Name = propertyName }
                }.ToArray()
            };

            // Act
            var actual = model.GetCustomPropertiesValue(propertyName);

            // Assert
            Assert.Equal(string.Empty, actual);
        }

        [Fact]
        public void GetCustomPropertiesValue_ShouldReturnValueWhenSingleMatchesFound()
        {
            const string propertyName = "DoesNotMatter";
            const string expectedValue = "I like coffee";

            // Arrange
            var model = new LineItemModel
            {
                CustomProperties = new List<CustomPropertyModel>
                {
                    new CustomPropertyModel { Name = propertyName, Value = expectedValue }
                }.ToArray()
            };

            // Act
            var actual = model.GetCustomPropertiesValue(propertyName);

            // Assert
            Assert.Equal(expectedValue, actual);
        }
    }
}