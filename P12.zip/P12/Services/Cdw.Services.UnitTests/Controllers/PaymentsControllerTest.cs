﻿using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Payments;
using Common.Logging;
using Moq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class PaymentsControllerTest
    {
        private readonly PaymentsController _sut;
        private readonly Mock<ILog> _logger = new Mock<ILog>();
        private readonly Mock<IMappingEngine> _mapper = new Mock<IMappingEngine>();
        private readonly Mock<IPaymentDomainManager> _paymentDomainManager = new Mock<IPaymentDomainManager>();
        private readonly Mock<IPartnerDetails> _partnerDetails = new Mock<IPartnerDetails>();
        private readonly PaymentRequestModel _paymentRequestModel = new PaymentRequestModel();

        public PaymentsControllerTest()
        {
            Mapper.AddProfile(new PaymentsMappingProfile());
            _sut = new PaymentsController(_logger.Object, _mapper.Object, _paymentDomainManager.Object, _partnerDetails.Object);
            _sut.RequestContext = Helper.FakeControllerContext("Xerox Direct");
            _sut.Request = new HttpRequestMessage();

            _paymentRequestModel.CreditCard = new CreditCardModel
            {
                Number = "411111111111111111",
                Name = "Name LastName",
                CVV = "123",
                ExpirationMonth = 12,
                ExpirationYear = 2025
            };
            _paymentRequestModel.TransactionId = Guid.NewGuid().ToString();
        }

        [Fact]
        public async Task Should_Fail_AuthorizeTests()
        {
            PaymentRequestModel paymentRequestModel = new PaymentRequestModel();
            var actual = await _sut.Authorize(paymentRequestModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task Should_Pass_AuthorizeTests()
        {
            var actual = await _sut.Authorize(_paymentRequestModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.OK);
        }

        [Fact]
        public async Task Should_Fail_WithApplicationException_AuthorizeTests()
        {
            _paymentDomainManager.Setup(p => p.AuthorizeAsync(It.IsAny<PaymentRequest>())).Throws(new ApplicationException("bad data"));
            var actual = await _sut.Authorize(_paymentRequestModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task Should_Fail_WithServiceCallException_AuthorizeTests()
        {
            _paymentDomainManager.Setup(p => p.AuthorizeAsync(It.IsAny<PaymentRequest>())).Throws(new ServiceCallException("bad data", "exception", new Exception("exception")));
            var actual = await _sut.Authorize(_paymentRequestModel).ConfigureAwait(false);
            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.ServiceUnavailable);
        }

        [Fact]
        public async Task Should_Fail_WithException_AuthorizeTests()
        {
            _paymentDomainManager.Setup(p => p.AuthorizeAsync(It.IsAny<PaymentRequest>())).Throws(new Exception("bad data"));
            var actual = await _sut.Authorize(_paymentRequestModel).ConfigureAwait(false);
            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public void GetHeartbeat()
        {
            var actual = _sut.GetHeartbeat();
            Assert.NotNull(actual);
        }
    }
}