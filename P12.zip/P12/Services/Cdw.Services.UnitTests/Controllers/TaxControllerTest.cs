﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Partners.Model.Tax;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Tax;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class TaxControllerTest
    {
        private TaxController _sut;
        private readonly Mock<ILog> _mockLogger = new Mock<ILog>();
        private readonly Mock<IMappingEngine> _mockMapper = new Mock<IMappingEngine>();
        private readonly Mock<ITaxDomainManager> _mockTaxDomainManager = new Mock<ITaxDomainManager>();
        private readonly Mock<IGetIdentityService> _mockGetIdentityService = new Mock<IGetIdentityService>();

        private readonly TaxRequestModel _valieTaxRequestModel;
        private readonly TaxRequest _validTaxRequest;

        public TaxControllerTest()
        {
            Mapper.AddProfile(new TaxMappingProfile());
            _sut = new TaxController(_mockLogger.Object, _mockMapper.Object, _mockTaxDomainManager.Object, _mockGetIdentityService.Object)
            {
                RequestContext = Helper.FakeControllerContext("NotBlackBox"),
                Request = new HttpRequestMessage()
            };

            _valieTaxRequestModel = new TaxRequestModel();
            _validTaxRequest = new TaxRequest();
        }

        [Fact]
        public void GetTaxSummary_ShouldSetEmptyProductCodesToNewItemForBlackBox()
        {
            // Arrange
            _sut = GetTaxController("Black Box");
            var taxRequestModel = GetTaxRequestModelWithEmptyProductCode();

            string testCode = null;
            _mockMapper.Setup(x => x.Map<TaxRequest>(taxRequestModel))
                .Returns(_validTaxRequest)
                .Callback<TaxRequestModel>((request) =>
                {
                    testCode = request.LineItems.First().ProductCode;
                });

            // Act
            var actual = _sut.GetTaxSummary(taxRequestModel);
            Assert.Equal("NEW-ITEM", testCode);

            // Assert done in callback
        }

        [Fact]
        public async Task GetTaxSummary_ShouldNotSetEmptyProductCodesToNewItemForNonBlackBox()
        {
            // Arrange
            _sut = GetTaxController("NotBlackBox");
            var taxRequestModel = GetTaxRequestModelWithEmptyProductCode();

            _mockMapper.Setup(x => x.Map<TaxRequest>(taxRequestModel))
                .Returns(_validTaxRequest)
                .Callback<TaxRequestModel>((request) =>
             {
                 Assert.Equal(string.Empty, request.LineItems.First().ProductCode);
             });

            // Act
            await _sut.GetTaxSummary(taxRequestModel);

            // Assert done in callback
        }

        [Fact]
        public void GetHeartbeat()
        {
            // Arrange

            // Act
            var actual = _sut.GetHeartbeat();

            // Assert
            Assert.NotNull(actual);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_NullTest()
        {
            // Arrange
            TaxRequestModel taxRequestModel = null;

            // Act
            var actual = await _sut.GetTaxSummary(taxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Request body was empty or unparseable", msg);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_IsoCountryCodeNotProvidedTest()
        {
            // Arrange
            _validTaxRequest.Address = new Address();
            _mockMapper.Setup(x => x.Map<TaxRequest>(_valieTaxRequestModel))
               .Returns(_validTaxRequest);

            // Act
            var actual = await _sut.GetTaxSummary(_valieTaxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Country code not found", msg);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_UnsupportedCompanyCodeTest()
        {
            // Arrange
            _validTaxRequest.Address = new Address { IsoCountryCode = "DoesNotMatter" };
            _validTaxRequest.Company = 9876;
            _mockMapper.Setup(x => x.Map<TaxRequest>(_valieTaxRequestModel))
               .Returns(_validTaxRequest);

            // Act
            var actual = await _sut.GetTaxSummary(_valieTaxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Unsupported company code", msg);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_InvalidCompanyCountryCodeTest()
        {
            // Arrange
            _validTaxRequest.Address = new Address { IsoCountryCode = "CA" };
            _validTaxRequest.Company = 1000;
            _mockMapper.Setup(x => x.Map<TaxRequest>(_valieTaxRequestModel))
               .Returns(_validTaxRequest);

            // Act
            var actual = await _sut.GetTaxSummary(_valieTaxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Company code 1000 is invalid for country code 'CA'", msg);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_InvalidPostCodeForUSTest()
        {
            // Arrange
            _validTaxRequest.Address = new Address
            {
                IsoCountryCode = "US",
                PostalCode = "1234-5678"
            };
            _validTaxRequest.Company = 1000;
            _mockMapper.Setup(x => x.Map<TaxRequest>(_valieTaxRequestModel))
               .Returns(_validTaxRequest);

            // Act
            var actual = await _sut.GetTaxSummary(_valieTaxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Invalid US postal code", msg);
        }

        [Fact]
        public async Task GetTaxSummary_Validate_InvalidPostCodeForCATest()
        {
            // Arrange
            _validTaxRequest.Address = new Address
            {
                IsoCountryCode = "CA",
                PostalCode = "1234-5678"
            };
            _validTaxRequest.Company = 1012;
            _mockMapper.Setup(x => x.Map<TaxRequest>(_valieTaxRequestModel))
               .Returns(_validTaxRequest);

            // Act
            var actual = await _sut.GetTaxSummary(_valieTaxRequestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Invalid Canada postal code", msg);
        }

        private TaxController GetTaxController(string partner)
        {
            return new TaxController(_mockLogger.Object, _mockMapper.Object, _mockTaxDomainManager.Object, _mockGetIdentityService.Object)
            {
                RequestContext = Helper.FakeControllerContext(partner),
                Request = new HttpRequestMessage()
            };
        }

        private TaxRequestModel GetTaxRequestModelWithEmptyProductCode()
        {
            return new TaxRequestModel
            {
                LineItems = new List<LineItemModel>
                {
                    new LineItemModel { ProductCode = string.Empty }
                }.ToArray()
            };
        }
    }
}