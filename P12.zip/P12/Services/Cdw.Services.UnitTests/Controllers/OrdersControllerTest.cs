﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Encryption;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Common;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class OrdersControllerTest
    {
        private readonly OrdersController _sut;
        private readonly Mock<ILog> _logger = new Mock<ILog>();
        private readonly Mock<IOrderManager> _orderManager = new Mock<IOrderManager>();
        private readonly Mock<IEncryptionService> _encryptionService = new Mock<IEncryptionService>();
        private readonly Mock<IPartnerDetails> _partnerDetails = new Mock<IPartnerDetails>();

        public OrdersControllerTest()
        {
            Mapper.AddProfile(new OrdersMappingProfile());
            Mapper.AddProfile(new ResponseOrdersMappingProfile());
            _sut = new OrdersController(_logger.Object, _orderManager.Object, _encryptionService.Object, _partnerDetails.Object);
            _sut.RequestContext = Helper.FakeControllerContext("Xerox Direct");
            _sut.Request = new HttpRequestMessage();
            _partnerDetails.Setup(x => x.GetPartnerSourceCode(It.IsAny<Partner>()))
                .Returns(FakeHelper.GetFakeIdentityFakeObject());
        }

        [Fact]
        public async Task ShouldFail_If_NoPartner_GetOrderDetailsAsync()
        {
            var actual = Assert.ThrowsAsync<ApplicationException>(async () => await _sut.GetOrderDetailsAsync("123", "345").ConfigureAwait(false));
            var actual2 = await _sut.GetOrderDetailsAsync("123", "345").ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual2.StatusCode, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task ShouldFail_If_NoPartnerCompany_CreateAsyncFails()
        {
            // Arrange
            _sut.RequestContext = Helper.FakeControllerContext("Adobe");

            // Act
            var actual = Assert.ThrowsAsync<ApplicationException>(async () => await _sut.GetOrderDetailsAsync(null, null).ConfigureAwait(false));
            var actual2 = await _sut.GetOrderDetailsAsync(null, null).ConfigureAwait(false);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(actual2.StatusCode, HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task ShouldReturnNoTFound_CreateAsyncFails()
        {
            // Arrange
            _sut.RequestContext = Helper.FakeControllerContext("Adobe");

            // Act
            var actual = await _sut.GetOrderDetailsAsync("123", "123").ConfigureAwait(false);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task ShouldReturnFound_CreateAsyncFails()
        {
            // Arrange
            _sut.RequestContext = Helper.FakeControllerContext("Adobe");
            _orderManager.Setup(s => s.SearchOrderAsync("123", "123", It.IsAny<ITrackingValues>()))
                        .ReturnsAsync(new OrderDetails());

            // Act
            var actual = await _sut.GetOrderDetailsAsync("123", "123").ConfigureAwait(false);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.OK);
        }

        [Fact]
        public async Task ShouldFail_CreateAsyncFails()
        {
            // Arrange
            _sut.RequestContext = Helper.FakeControllerContext("Adobe");
            _orderManager.Setup(s => s.SearchOrderAsync("123", "123", It.IsAny<ITrackingValues>()))
                        .Throws(new ServiceCallException("test", "test", new Exception()));

            // Act
            var actual = await _sut.GetOrderDetailsAsync("123", "123").ConfigureAwait(false);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.ServiceUnavailable);
        }

        private RequestOrderModel GetOrderRequestModel()
        {
            var requestOrderModel = new RequestOrderModel
            {
                Company = 1000,
                ReferenceNumber = "ReferenceNumber1",
                TransactionDate = new DateTime(1973, 1, 1),
                Account = new AccountModel()
                {
                    EmailAddress =
                    "qatester@cdw.com",
                    CustomerNumber = "123ABC",
                },
                Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } },
                Billing = new BillingInfoModel()
                {
                    Address = new AddressModel()
                    {
                        FirstName = "Ganesh",
                        LastName = "Eswaran",
                        Company = "CDW Gets IT",
                        StreetAddress = "53150 N. Main St.",
                        SecondaryStreetAddress = "Suite 100",
                        City = "Mattawan",
                        State = "MI",
                        PostalCode = "49071",
                        IsoCountryCode = "US",
                        PhoneNumber = "800-800-4239"
                    },
                    Method = new PaymentMethodModel()
                    {
                        EncryptedCreditCard = "abc",
                        PONumber = "CRE4232"
                    }
                },
                Shipping = new ShippingInfoModel()
                {
                    Address = new AddressModel()
                    {
                        FirstName = "Ganesh",
                        LastName = "Eswaran",
                        Company = "CDW Gets IT",
                        StreetAddress = "53150 N. Main St.",
                        SecondaryStreetAddress = "Suite 100",
                        City = "Mattawan",
                        State = "MI",
                        PostalCode = "49071",
                        IsoCountryCode = "US",
                        PhoneNumber = "800-800-4239"
                    },
                    Method = new ShippingMethodModel()
                    {
                        Description = "abc",
                        Id = "XC"
                    }
                },
                LineItems = new[]
            {
                new LineItemModel()
                {
                    ProductCode = "2443006",
                    Status = "Shipped",
                    Quantity = 1,
                    UnitPrice = 895.46M,
                    LinePrice = 895.46M,
                }
            }
            };

            return requestOrderModel;
        }
    }
}