﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Domain.Partners;
using Cdw.Domain.Partners.Freight;
using Cdw.Domain.Partners.Implementation.Common;
using Common.Logging;
using Moq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class FreightControllerTest
    {
        private FreightController _sut;

        private readonly Mock<ILog> _mockLogger = new Mock<ILog>();
        private readonly Mock<IFreightDomainManager> _mockFreightDomainManager = new Mock<IFreightDomainManager>();
        private readonly Mock<IGetIdentityService> _mockGetIdentityService = new Mock<IGetIdentityService>();

        private readonly RatingRequestModel _requestModel;

        public FreightControllerTest()
        {
            _mockGetIdentityService.Setup(x => x.GetPartnersIdentity(It.IsAny<string>())).Returns(new Identity());
            _sut = new FreightController(_mockLogger.Object, _mockFreightDomainManager.Object, _mockGetIdentityService.Object)
            {
                RequestContext = Helper.FakeControllerContext("NotBlackBox"),
                Request = new HttpRequestMessage()
            };

            _requestModel = new RatingRequestModel();
        }

        [Fact]
        public void GetHeartbeat()
        {
            // Arrange

            // Act
            var actual = _sut.GetHeartbeat();

            // Assert
            Assert.NotNull(actual);
        }

        [Fact]
        public async Task GetFreight_Validate_IsoCountryCodeNotProvidedTest()
        {
            // Arrang
            _requestModel.ShipTo = new RatingRequestShippingAddressModel();

            // Act
            var actual = await _sut.GetFreight(_requestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Country code not found", msg);
        }

        [Fact]
        public async Task GetFreight_Validate_UnsupportedCompanyCodeTest()
        {
            // Arrange
            _requestModel.CompanyCode = "10";
            _requestModel.ShipTo = new RatingRequestShippingAddressModel { Country = "CA" };

            // Act
            var actual = await _sut.GetFreight(_requestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Unsupported company code", msg);
        }

        [Fact]
        public async Task GetFreight_Validate_InvalidCompanyCountryCodeTest()
        {
            // Arrange
            _requestModel.CompanyCode = "01";
            _requestModel.ShipTo = new RatingRequestShippingAddressModel { Country = "CA" };

            // Act
            var actual = await _sut.GetFreight(_requestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Company code 01 is invalid for country code 'CA'", msg);
        }

        [Fact]
        public async Task GetFreight_Validate_InvalidPostCodeForUSTest()
        {
            // Arrange
            _requestModel.ShipTo = new RatingRequestShippingAddressModel
            {
                Country = "US",
                PostalCode = "1234-5678"
            };
            _requestModel.CompanyCode = "01";

            // Act
            var actual = await _sut.GetFreight(_requestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Invalid US postal code", msg);
        }

        [Fact]
        public async Task GetFreight_Validate_InvalidPostCodeForCATest()
        {
            // Arrange
            _requestModel.ShipTo = new RatingRequestShippingAddressModel
            {
                Country = "CA",
                PostalCode = "1234-5678"
            };
            _requestModel.CompanyCode = "17";

            // Act
            var actual = await _sut.GetFreight(_requestModel);

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, actual.StatusCode);
            var msg = (actual.Content as ObjectContent<string>).Value;
            Assert.Equal("Invalid Canada postal code", msg);
        }
    }
}