﻿using System.Net.Http;
using AutoMapper;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Domain.Partners;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Domain.Partners.Product;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class ProductControllerTest
    {
        private ProductController _sut;

        private readonly Mock<ILog> _mockLogger = new Mock<ILog>();
        private readonly Mock<IProductDomainManager> _mockProductDomainManager = new Mock<IProductDomainManager>();
        private readonly Mock<IProductsCatalogService> _mockProductCatalogService = new Mock<IProductsCatalogService>();
        private readonly Mock<IGetIdentityService> _mockGetIdentityService = new Mock<IGetIdentityService>();

        public ProductControllerTest()
        {
            Mapper.AddProfile(new ProductMappingProfile());

            _mockGetIdentityService.Setup(x => x.GetPartnersIdentity(It.IsAny<string>())).Returns(new Identity());
            _sut = new ProductController(_mockLogger.Object, _mockProductDomainManager.Object, _mockProductCatalogService.Object, _mockGetIdentityService.Object)
            {
                RequestContext = Helper.FakeControllerContext("NotBlackBox"),
                Request = new HttpRequestMessage()
            };
        }

        [Fact]
        public void GetHeartbeat()
        {
            // Arrange

            // Act
            var actual = _sut.GetHeartbeat();

            // Assert
            Assert.NotNull(actual);
        }
    }
}