﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model.Cart;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.PartnerCart;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.Controllers
{
    public class PartnerCartControllerTest
    {
        private PartnerCartController sut;
        private Mock<IPartnerCartRequestDomainManager> cartDomainManager;

        public PartnerCartControllerTest()
        {
            Mapper.AddProfile(new CartMappingProfile());

            var log = new Mock<ILog>();
            var mapper = new Mock<IMappingEngine>();
            cartDomainManager = new Mock<IPartnerCartRequestDomainManager>();
            var partnerDetails = new Mock<IPartnerDetails>();
            sut = new PartnerCartController(log.Object, mapper.Object, cartDomainManager.Object, partnerDetails.Object);
            sut.RequestContext = Helper.FakeControllerContext("Xerox Direct");
            sut.Request = new HttpRequestMessage();
        }

        [Fact]
        public async Task TestCreateVendorCartRequest()
        {
            PartnerCartRequestModel cartModel = new PartnerCartRequestModel();
            var actual = await sut.CreateVendorCartRequest(cartModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual.StatusCode, HttpStatusCode.Created);
        }

        [Fact(DisplayName = "ShouldFail_If_CreateAsyncFails")]
        public async Task TestCreateVendorCartRequestFails()
        {
            PartnerCartRequestModel cartModel = new PartnerCartRequestModel();
            cartDomainManager.Setup(s => s.CreateAsync(It.IsAny<PartnerCartRequest>())).Throws(new ServiceCallException("error", "url", new Exception()));

            var actual = Assert.ThrowsAsync<ServiceCallException>(async () => await sut.CreateVendorCartRequest(cartModel).ConfigureAwait(false));
            var actual2 = await sut.CreateVendorCartRequest(cartModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual2.StatusCode, HttpStatusCode.ServiceUnavailable);
        }

        [Fact(DisplayName = "ShouldFail_If_CreateAsyncFailsOther")]
        public async Task TestCreateVendorCartRequestOther()
        {
            PartnerCartRequestModel cartModel = new PartnerCartRequestModel();
            cartDomainManager.Setup(s => s.CreateAsync(It.IsAny<PartnerCartRequest>())).Throws(new Exception("error"));

            var actual = Assert.ThrowsAsync<Exception>(async () => await sut.CreateVendorCartRequest(cartModel).ConfigureAwait(false));
            var actual2 = await sut.CreateVendorCartRequest(cartModel).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.Equal(actual2.StatusCode, HttpStatusCode.InternalServerError);
        }
    }
}