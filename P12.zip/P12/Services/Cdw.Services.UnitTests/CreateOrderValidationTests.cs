﻿using AutoMapper;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Service.Controller;
using Cdw.Api.Partners.Service.Encryption;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Services.UnitTests.FakeObjects;
using Cdw.Test.Common.Xunit;
using Common.Logging;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using Xunit;

namespace Cdw.Services.UnitTests
{
    [CI]
    public class CreateOrderValidationTests
    {
        private Mock<ILog> _logger;
        private Mock<IPartnerDetails> _helper;
        private Mock<IOrderManager> _orderManager;

        private Mock<IEncryptionService> _encryptionService;

        private OrdersController _ordersController;

        public CreateOrderValidationTests()
        {
            Mapper.AddProfile(new TaxMappingProfile());
            Mapper.AddProfile(new ProductMappingProfile());
            Mapper.AddProfile(new CartMappingProfile());
            Mapper.AddProfile(new OrdersMappingProfile());
            Mapper.AddProfile(new ResponseOrdersMappingProfile());
            //_helper.GetPartnerSourceCode

            _logger = new Mock<ILog>();
            _helper = new Mock<IPartnerDetails>();
            _helper.Setup(x => x.GetPartnerSourceCode(It.IsAny<Partner>())).Returns(FakeHelper.GetFakeIdentityFakeObject());

            _orderManager = new Mock<IOrderManager>();
            _encryptionService = new Mock<IEncryptionService>();

            _ordersController = new OrdersController(_logger.Object, _orderManager.Object, _encryptionService.Object, _helper.Object);
            _ordersController.RequestContext = Helper.FakeControllerContext("Xerox Direct");
            _ordersController.Request = new HttpRequestMessage();
        }

        [Fact(DisplayName = "CreateOrder_ReferenceNumber_Validation")]
        public async void CreateOrder_ReferenceNumber_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.TransactionDate = new DateTime(1971, 1, 1);

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("ReferenceNumber", (string)o.First["Field"]);
            Assert.Equal("ReferenceNumber must be a non-null, non-empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_ReferenceNumber_GreaterThan100_Validation")]
        public async void CreateOrder_ReferenceNumber_GreaterThan100_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.TransactionDate = new DateTime(1971, 1, 1);
            requestObj.ReferenceNumber =
                "100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("ReferenceNumber", (string)o.First["Field"]);
            Assert.Equal("RefernceNumber exceeds the maximum length of 100 characters", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_TransactionDate_Validation")]
        public async void CreateOrder_TransactionDate_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1960, 1, 1);

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("TransactionDate", (string)o.First["Field"]);
            Assert.Equal("TransactionDate must be greater than January 1, 1970", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Null_Request_Validation")]
        public async void CreateOrder_Null_Request_Validation()
        {
            var act = await _ordersController.CreateOrder(null).ConfigureAwait(false);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("External Dependency Error", (string)o.First["Field"]);
            Assert.Equal("Request body was empty or unparseable", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_Null_Validation")]
        public async void CreateOrder_Account_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = null;

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account", (string)o.First["Field"]);
            Assert.Equal("Account must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_EmailAddress_Null_Validation")]
        public async void CreateOrder_Account_EmailAddress_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel();

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account.EmailAddress", (string)o.First["Field"]);
            Assert.Equal("Account.EmailAddress must be defined and not an empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_EmailAddress_Greater64_Validation")]
        public async void CreateOrder_Account_EmailAddress_Greater64_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "adsfasdfsdfdsfasdfsdfdasasasasasasasasasasasasasasasasasadsfasdfsdfdsfasdfsdfdasasasasasasasasasasasasasasasasas@gmail.com"
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account.EmailAddress", (string)o.First["Field"]);
            Assert.Equal("Account.EmailAddress exceeds the maximum length of 64 characters", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_EmailAddress_Invalid_Validation")]
        public async void CreateOrder_Account_EmailAddress_Invalid_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest"
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account.EmailAddress", (string)o.First["Field"]);
            Assert.Equal("Account.EmailAddress does not appear to be valid", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_CustomerNumber_Greater_8_Validation")]
        public async void CreateOrder_Account_CustomerNumber_Greater_8_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsdafasdfsdafsdfsdafsdfsdafdsfadfasdfasdfd"
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account.CustomerNumber", (string)o.First["Field"]);
            Assert.Equal("Account.CustomerNumber exceeds the maximum length of 8 characters",
                (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Account_EAccount_Greater_50_Validation")]
        public async void CreateOrder_Account_EAccount_Greater_50_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasddsfasd"
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Account.EAccount", (string)o.First["Field"]);
            Assert.Equal("Account.EAccount exceeds the maximum length of 50 characters", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Discounts_Type_Validation")]
        public async void CreateOrder_Discounts_Type_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1 } };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Discount.Type", (string)o.First["Field"]);
            Assert.Equal("Discount.Type must be one of the following: 1000(Fixed amount off order), 1001(Percentage off order)", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Discounts_ID_Validation")]
        public async void CreateOrder_Discounts_ID_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Type = 1000 } };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Discount.Id", (string)o.First["Field"]);
            Assert.Equal("Discount.Id must be defined and not an empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Discounts_Type1000_Amount_Validation")]
        public async void CreateOrder_Discounts_Type1000_Amount_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = -1, Id = "1", Type = 1000 } };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Discount.Amount", (string)o.First["Field"]);
            Assert.Equal("Discount.Amount must be greater than or equal to 0", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Discounts_Type1000_Amount_negative_Validation")]
        public async void CreateOrder_Discounts_Type1000_Amount_negative_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = -1, Id = "1", Type = 1001 } };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Discount.Amount", (string)o.First["Field"]);
            Assert.Equal("Discount.Amount must be greater than or equal to 0 and less than or equal to 100", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Discounts_Type1000_Amount_Greater_100_Validation")]
        public async void CreateOrder_Discounts_Type1000_Amount_Greater_100_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 200, Id = "1", Type = 1001 } };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Discount.Amount", (string)o.First["Field"]);
            Assert.Equal("Discount.Amount must be greater than or equal to 0 and less than or equal to 100", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Billing_NUll_Validation")]
        public async void CreateOrder_Billing_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = null;

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Billing", (string)o.First["Field"]);
            Assert.Equal("Billing must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Billing_Address_NUll_Validation")]
        public async void CreateOrder_Billing_Address_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = null
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Billing.Address", (string)o.First["Field"]);
            Assert.Equal("Billing.Address must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Billing_Method_NUll_Validation")]
        public async void CreateOrder_Billing_Method_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = null
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Billing.Method", (string)o.First["Field"]);
            Assert.Equal("Billing.Method must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Billing_Method_EncryptedCC_Null_Validation")]
        public async void CreateOrder_Billing_Method_EncryptedCC_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "",
                    PONumber = "abc"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Billing.Method", (string)o.First["Field"]);
            Assert.Equal("Billing Method details should be defined correctly.", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Billing_Method_POnumber_Greater_30_Validation")]
        public async void CreateOrder_Billing_Method_POnumber_Greater_30_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE42326dfsafadsfasdfsdafasdfsdafsdafdsafdsafdsfasdfdsfasdfdsafasdfasdfdsfsda"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("PONumber", (string)o.First["Field"]);
            Assert.Equal("PONumber exceeds the maximum length of 30 characters", (string)o.First["Message"]);
        }

        [Theory(DisplayName = "CreateOrder_Billing_Address_Validation")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US'}",
            "Address.PhoneNumber",
            "Address.PhoneNumber must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-423955555555555555555555555'}",
            "Address.PhoneNumber",
            "Address.PhoneNumber exceeds the maximum length of 20 characters")]
        [InlineData(
            "{'Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.FirstName",
            "Address.FirstName must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganeshdsfadfsdfsdafsdafdsafsdafasdfdsafdsfsdafasdfasdfdsafasd','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.FirstName",
            "Address.FirstName exceeds the maximum length of 12 characters")]
        [InlineData(
            "{'Firstname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.LastName",
            "Address.LastName must be defined and not an empty string")]
        [InlineData(
            "{'LastName': 'Ganeshdsfadfsdfsdafsdafdsafsdafasdfdsafdsfsdafasdfasdfdsafasd','FirstName': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.LastName",
            "Address.LastName exceeds the maximum length of 15 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfadsCDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfadsCDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfads','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.Company",
               "Address.Company exceeds the maximum length of 35 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.StreetAddress",
               "Address.StreetAddress must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.StreetAddress",
               "Address.StreetAddress exceeds the maximum length of 35 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.SecondaryStreetAddress",
               "Address.SecondaryStreetAddress exceeds the maximum length of 35 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.City",
               "Address.City must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'MattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.City",
               "Address.City exceeds the maximum length of 20 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.State",
                "Address.State must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MIee','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.State",
             "Address.State exceeds the maximum length of 2 characters")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI' ,'IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.PostalCode",
               "Address.PostalCode must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': 'wwwww','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.PostalCode",
               "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '606616','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.PostalCode",
               "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '606','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
            "Address.PostalCode",
               "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': 'wwwww','IsoCountryCode': 'CA','PhoneNumber': '800-800-4239'}",
            "Address.PostalCode",
               "Canadian address zip codes must contain 6 letters or numbers")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','PostalCode': '49071','State': 'IL','PhoneNumber': '800-800-4239'}",
            "Address.IsoCountryCode",
                "Address.IsoCountryCode must be defined and not an empty string")]
        [InlineData(
            "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MIee','PostalCode': '49071','State': 'IL','IsoCountryCode': 'CAd','PhoneNumber': '800-800-4239'}",
            "Address.IsoCountryCode",
             "Address.IsoCountryCode exceeds the maximum length of 2 characters")]
        public async void CreateOrder_Billing_Address_Validation(string addressJson, string fieldName,
            string errorMessage)
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };

            var addressModel = JsonConvert.DeserializeObject<AddressModel>(addressJson);

            requestObj.Billing = new BillingInfoModel()
            {
                Address = addressModel,
                Method = new PaymentMethodModel()
                {
                    PONumber = "CRE42326",
                    EncryptedCreditCard =
                        "AAEAABAAAACLDFmdSN8uG5Q/nX7H5Ca/7stpruoeLFm"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal(fieldName, (string)o.First["Field"]);
            Assert.Equal(errorMessage, (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Shipping_NUll_Validation")]
        public async void CreateOrder_Shipping_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = null;

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Shipping", (string)o.First["Field"]);
            Assert.Equal("Shipping must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Shipping_Address_NUll_Validation")]
        public async void CreateOrder_Shipping_Address_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = null,
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Shipping.Address", (string)o.First["Field"]);
            Assert.Equal("Shipping.Address must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Shipping_Method_NUll_Validation")]
        public async void CreateOrder_Shipping_Method_NUll_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = null
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("Shipping.Method", (string)o.First["Field"]);
            Assert.Equal("Shipping.Method must be defined", (string)o.First["Message"]);
        }

        [Theory(DisplayName = "CreateOrder_Shipping_Address_Validation")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US'}",
           "Address.PhoneNumber",
           "Address.PhoneNumber must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-423955555555555555555555555'}",
           "Address.PhoneNumber",
           "Address.PhoneNumber exceeds the maximum length of 20 characters")]
        [InlineData(
           "{'Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.FirstName",
           "Address.FirstName must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganeshdsfadfsdfsdafsdafdsafsdafasdfdsafdsfsdafasdfasdfdsafasd','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.FirstName",
           "Address.FirstName exceeds the maximum length of 12 characters")]
        [InlineData(
           "{'Firstname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.LastName",
           "Address.LastName must be defined and not an empty string")]
        [InlineData(
           "{'LastName': 'Ganeshdsfadfsdfsdafsdafdsafsdafasdfdsafdsfsdafasdfasdfdsafasd','FirstName': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.LastName",
           "Address.LastName exceeds the maximum length of 15 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfadsCDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfadsCDW Gets ITdfasfdsfsdafafdsafasdfdasfdasfdasfasdfasdfads','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.Company",
              "Address.Company exceeds the maximum length of 35 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.StreetAddress",
              "Address.StreetAddress must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St50 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.StreetAddress",
              "Address.StreetAddress exceeds the maximum length of 35 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.SecondaryStreetAddress",
              "Address.SecondaryStreetAddress exceeds the maximum length of 35 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.City",
              "Address.City must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'MattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawanMattawan','State': 'MI','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.City",
              "Address.City exceeds the maximum length of 20 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.State",
               "Address.State must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MIee','PostalCode': '49071','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.State",
            "Address.State exceeds the maximum length of 2 characters")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI' ,'IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.PostalCode",
              "Address.PostalCode must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': 'wwwww','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.PostalCode",
              "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '606616','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.PostalCode",
              "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': '606','IsoCountryCode': 'US','PhoneNumber': '800-800-4239'}",
           "Address.PostalCode",
              "US address zip codes must contain 5 or 9 numbers")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MI','PostalCode': 'wwwww','IsoCountryCode': 'CA','PhoneNumber': '800-800-4239'}",
           "Address.PostalCode",
              "Canadian address zip codes must contain 6 letters or numbers")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','PostalCode': '49071','State': 'IL','PhoneNumber': '800-800-4239'}",
           "Address.IsoCountryCode",
               "Address.IsoCountryCode must be defined and not an empty string")]
        [InlineData(
           "{'Firstname': 'Ganesh','Lastname': 'Eswaran','Company': 'CDW Gets IT','StreetAddress': '53150 N. Main St.','SecondaryStreetAddress': 'Suite 100','City': 'Mattawan','State': 'MIee','PostalCode': '49071','State': 'IL','IsoCountryCode': 'CAd','PhoneNumber': '800-800-4239'}",
           "Address.IsoCountryCode",
            "Address.IsoCountryCode exceeds the maximum length of 2 characters")]
        public async void CreateOrder_Shipping_Address_Validation(string addressJson, string fieldName,
           string errorMessage)
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };

            var addressModel = JsonConvert.DeserializeObject<AddressModel>(addressJson);

            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = addressModel,
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(act.StatusCode, HttpStatusCode.BadRequest);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal(fieldName, (string)o.First["Field"]);
            Assert.Equal(errorMessage, (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Shipping_Method_Id_Validation")]
        public async void CreateOrder_Shipping_Method_Id_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("ShippingMethod.Id", (string)o.First["Field"]);
            Assert.Equal("ShippingMethod.Id must be defined and not an empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_Shipping_Method_Description_Validation")]
        public async void CreateOrder_Shipping_Method_Description_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Id = "XC"
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("ShippingMethod.Description", (string)o.First["Field"]);
            Assert.Equal("ShippingMethod.Description must be defined and not an empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_LineItems_Null_Validation")]
        public async void CreateOrder_LineItems_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };
            requestObj.LineItems = null;

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("LineItems", (string)o.First["Field"]);
            Assert.Equal("LineItems must be defined", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_LineItems_ProductCode_Null_Validation")]
        public async void CreateOrder_LineItems_ProductCode_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };
            requestObj.LineItems = new[]
            {
                new LineItemModel()
                {
                    //ProductCode = "2443006",
                    Status = "Shipped",
                    Quantity = 1,
                    UnitPrice = 895.46M,
                    LinePrice = 895.46M,
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("LineItem.ProductCode", (string)o.First["Field"]);
            Assert.Equal("LineItem.ProductCode must be defined and not an empty string", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_LineItems_ProductCode_Null_Validation")]
        public async void CreateOrder_LineItems_Quantity_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };
            requestObj.LineItems = new[]
            {
                new LineItemModel()
                {
                    ProductCode = "2443006",
                    Status = "Shipped",
                    //Quantity = 1,
                    UnitPrice = 895.46M,
                    LinePrice = 895.46M,
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("LineItem.Quantity", (string)o.First["Field"]);
            Assert.Equal("LineItem.Quantity must be an integer between 1 and 999", (string)o.First["Message"]);
        }

        [Fact(DisplayName = "CreateOrder_LineItems_UnitPrice_Null_Validation")]
        public async void CreateOrder_LineItems_UnitPrice_Null_Validation()
        {
            var requestObj = new RequestOrderModel().Fake();
            requestObj.Company = 1000;
            requestObj.ReferenceNumber = "ReferenceNumber";
            requestObj.TransactionDate = new DateTime(1973, 1, 1);
            requestObj.Account = new AccountModel()
            {
                EmailAddress =
                    "testtesttest@gmail.com",
                CustomerNumber = "adfsd",
                EAccount = "dsfasd"
            };
            requestObj.Discounts = new[] { new DiscountModel() { Amount = 1, Id = "1", Type = 1001 } };
            requestObj.Billing = new BillingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new PaymentMethodModel()
                {
                    EncryptedCreditCard = "abc",
                    PONumber = "CRE4232"
                }
            };
            requestObj.Shipping = new ShippingInfoModel()
            {
                Address = new AddressModel()
                {
                    FirstName = "Ganesh",
                    LastName = "Eswaran",
                    Company = "CDW Gets IT",
                    StreetAddress = "53150 N. Main St.",
                    SecondaryStreetAddress = "Suite 100",
                    City = "Mattawan",
                    State = "MI",
                    PostalCode = "49071",
                    IsoCountryCode = "US",
                    PhoneNumber = "800-800-4239"
                },
                Method = new ShippingMethodModel()
                {
                    Description = "abc",
                    Id = "XC"
                }
            };
            requestObj.LineItems = new[]
            {
                new LineItemModel()
                {
                    ProductCode = "2443006",
                    Status = "Shipped",
                    Quantity = 1,
                    //UnitPrice = 895.46M,
                    LinePrice = 895.46M,
                }
            };

            var act = await _ordersController.CreateOrder(requestObj).ConfigureAwait(false);

            Assert.NotNull(act);
            Assert.Equal(HttpStatusCode.BadRequest, act.StatusCode);

            var json = await act.Content.ReadAsStringAsync().ConfigureAwait(false);
            JArray o = JArray.Parse(json);

            Assert.Equal("LineItem.UnitPrice", (string)o.First["Field"]);
            Assert.Equal("LineItem.UnitPrice must be a decimal and greater than 0.00", (string)o.First["Message"]);
        }
    }
}