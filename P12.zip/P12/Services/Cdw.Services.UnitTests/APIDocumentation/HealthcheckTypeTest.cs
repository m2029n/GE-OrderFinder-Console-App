﻿using Cdw.Api.Partners.Service.APIDocumentation;
using Xunit;

namespace Cdw.Services.UnitTests.APIDocumentation
{
    public class HealthcheckTypeTest
    {
        [Fact]
        public void TestClass()
        {
            var sut = new HealthcheckType();

            sut.Service = "service";
            sut.Status = "status";

            Assert.Equal(sut.Service, "service");
            Assert.Equal(sut.Status, "status");
        }
    }
}