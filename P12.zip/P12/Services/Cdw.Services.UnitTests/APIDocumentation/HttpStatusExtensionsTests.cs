﻿using Cdw.Api.Partners.Service.APIDocumentation;
using Xunit;

namespace Cdw.Services.UnitTests.APIDocumentation
{
    public class HttpStatusExtensionsTests
    {
        [Theory(DisplayName = "CodesReturned.HttpStatusExtensionsTests")]
        [InlineData("200")]
        [InlineData("201")]
        [InlineData("400")]
        [InlineData("401")]
        [InlineData("404")]
        [InlineData("500")]
        [InlineData("503")]
        public void ApplyTest(string code)
        {
            Assert.NotNull(code.CdwStatusCode());
        }

        [Fact]
        public void ApplyTestNull()
        {
            string code = null;
            Assert.Null(code.CdwStatusCode());
            Assert.Null("invalidValue".CdwStatusCode());
        }
    }
}