﻿using System;
using System.Web.Http.Description;
using Cdw.Api.Partners.Service.APIDocumentation;
using Moq;
using Xunit;

namespace Cdw.Services.UnitTests.APIDocumentation
{
    public class AssignOAuth2SecurityRequirementsTests
    {
        [Fact(DisplayName = "ApplyThrowsException.AssignOAuth2SecurityRequirementsTest")]
        public void ApplyTest()
        {
            var sut = new AssignOAuth2SecurityRequirements();
            var apiDescription = new Mock<ApiDescription>();
            var actual = Assert.Throws<NullReferenceException>(() => sut.Apply(null, null, apiDescription.Object));

            Assert.NotNull(actual);
        }
    }
}