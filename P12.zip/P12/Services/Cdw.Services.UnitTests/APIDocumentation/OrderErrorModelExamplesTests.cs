﻿using System.Collections.Concurrent;
using System.Web.Http.Description;
using Cdw.Api.Partners.Service.APIDocumentation;
using Moq;
using Swashbuckle.Swagger;
using Xunit;

namespace Cdw.Services.UnitTests.APIDocumentation
{
    public class OrderErrorModelExamplesTests
    {
        [Fact(DisplayName = "ApplyWorks.OrderErrorModelExamplesTests")]
        public void ApplyWorks()
        {
            var sut = new OrderErrorModelExamples();
            var operation = new Operation();
            operation.responses = new ConcurrentDictionary<string, Response>();
            operation.responses.Add("500", new Response());
            operation.responses.Add("503", new Response());
            operation.operationId = "GetOrder";
            var apiDescription = new Mock<ApiDescription>();

            sut.Apply(operation, null, apiDescription.Object);

            Assert.Equal(operation.responses["500"].description, "500".CdwStatusCode());
            Assert.Equal(operation.responses["503"].description, "503".CdwStatusCode());
        }

        [Fact(DisplayName = "ApplyFailsIfNoOperation.OrderErrorModelExamplesTests")]
        public void ApplyFailsIfNoOperation()
        {
            var sut = new OrderErrorModelExamples();
            var operation = new Operation();
            var apiDescription = new Mock<ApiDescription>();
            sut.Apply(operation, null, apiDescription.Object);
            Assert.Null(operation.responses);
        }
    }
}