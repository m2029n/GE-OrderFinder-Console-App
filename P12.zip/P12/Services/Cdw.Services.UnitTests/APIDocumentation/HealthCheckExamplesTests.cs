﻿using System.Collections.Concurrent;
using System.Web.Http.Description;
using Cdw.Api.Partners.Service.APIDocumentation;
using Moq;
using Swashbuckle.Swagger;
using Xunit;

namespace Cdw.Services.UnitTests.APIDocumentation
{
    public class HealthCheckExamplesTests
    {
        [Fact(DisplayName = "ApplyWorks.HealthCheckExamples")]
        public void ApplyWorks()
        {
            var sut = new HealthCheckExamples();
            var operation = new Operation();
            operation.responses = new ConcurrentDictionary<string, Response>();
            operation.responses.Add("200", new Response());

            operation.operationId = "Orders_Healthcheck";
            var apiDescription = new Mock<ApiDescription>();
            sut.Apply(operation, null, apiDescription.Object);

            Assert.NotNull(operation.responses["200"].description);
            Assert.NotNull(operation.responses["200"].examples);
        }

        [Fact(DisplayName = "ApplyWorksWithNulls.HealthCheckExamples")]
        public void ApplyWorksWithNulls()
        {
            var sut = new HealthCheckExamples();
            var operation = new Operation();
            var apiDescription = new Mock<ApiDescription>();
            sut.Apply(operation, null, apiDescription.Object);
            Assert.Null(operation.responses);
        }

        [Fact(DisplayName = "ApplyIgnoresErrorsWithNulls.OrderErrorModelExamplesTests")]
        public void ApplyIgnoresErrorsWithNulls()
        {
            var sut = new HealthCheckExamples();
            var operation = new Operation();
            operation.operationId = "Orders_Healthcheck";

            var apiDescription = new Mock<ApiDescription>();
            sut.Apply(operation, null, apiDescription.Object);
            Assert.Null(operation.responses);
        }
    }
}