﻿using Autofac;
using Autofac.Integration.WebApi;
using AutoMapper;
using Cdw.Api.Partners.Service.Encryption;
using Cdw.Api.Partners.Service.Infrastructure.Mapping;

namespace Cdw.Api.Partners.Service
{
    /// <summary>
    /// implements PartnersModule
    /// </summary>
    public class PartnersModule : Module
    {
        /// <summary>
        /// holds EncryptionCertificateName
        /// </summary>
        public static string EncryptionCertificateName { get; set; }

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="encryptionCertificateName"></param>
        public PartnersModule(string encryptionCertificateName)
        {
            EncryptionCertificateName = encryptionCertificateName;
        }

        /// <summary>
        /// Implements Load
        /// </summary>
        /// <param name="builder"></param>
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterType<EncryptionService>()
                  .AsImplementedInterfaces();

            builder.RegisterApiControllers(typeof(PartnersModule).Assembly);

            Mapper.AddProfile(new TaxMappingProfile());
            Mapper.AddProfile(new ProductMappingProfile());
            Mapper.AddProfile(new CartMappingProfile());
            Mapper.AddProfile(new OrdersMappingProfile());
            Mapper.AddProfile(new ResponseOrdersMappingProfile());
            Mapper.AddProfile(new PaymentsMappingProfile());
        }
    }
}