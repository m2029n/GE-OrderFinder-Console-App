﻿namespace Cdw.Api.Partners.Service.APIDocumentation
{
    /// <summary>
    /// Used to get custom documentations
    /// </summary>
    public static class HttpStatusExtensions
    {
        /// <summary>
        /// Used to get custom documentation per status code
        /// </summary>
        /// <param name="statusCode"></param>
        /// <returns></returns>
        public static string CdwStatusCode(this string statusCode)
        {
            switch (statusCode)
            {
                case "200":
                    {
                        return "The operation completed successfully.";
                    }
                case "201":
                    {
                        return "The entity in question has been created.";
                    }
                case "400":
                    {
                        return "Bad Request.";
                    }
                case "401":
                    {
                        return "A valid bearer token was not sent in the Authorization header of the request.";
                    }
                case "404":
                    {
                        return "Not Found";
                    }

                case "500":
                    {
                        return "An internal server error has occurred";
                    }
                case "503":
                    {
                        return "The service is temporarily unavailable.";
                    }
                default:
                    {
                        return null;
                    }
            }
        }
    }
}