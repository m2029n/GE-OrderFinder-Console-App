﻿namespace Cdw.Api.Partners.Service.APIDocumentation
{
    /// <summary>
    /// Used in healthcheck calls for API
    /// </summary>
    public class HealthcheckType
    {
        /// <summary>
        /// Service Name
        /// </summary>
        public string Service { get; set; }

        /// <summary>
        /// Service Status
        /// </summary>
        public string Status { get; set; }
    }
}