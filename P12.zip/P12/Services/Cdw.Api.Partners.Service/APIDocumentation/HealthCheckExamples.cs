﻿using System;
using System.Collections.Generic;
using System.Web.Http.Description;
using Swashbuckle.Swagger;

namespace Cdw.Api.Partners.Service.APIDocumentation
{
    /// <summary>
    /// Used to Provide APi Documentation Examples for healthcheck calls
    /// </summary>
    public class HealthCheckExamples : IOperationFilter
    {
        /// <summary>
        /// filter implementation
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            if (operation?.operationId != "Orders_Healthcheck")
            {
                return;
            }
            try
            {
                var successResponse = operation.responses["200"];

                successResponse.description = "The operation completed successfully.";

                successResponse.examples = new Dictionary<string, HealthcheckType>
                {
                    { "application/json",
                        new HealthcheckType
                        {
                            Service= "Order Service",
                            Status="Ready"
                        }}
                };
            }
            catch (Exception)
            {
                // Intentionally eating any exceptions
            }
        }
    }
}