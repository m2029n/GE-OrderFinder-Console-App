﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using Swashbuckle.Swagger;

namespace Cdw.Api.Partners.Service.APIDocumentation
{
    /// <summary>
    /// Security Descriptor
    /// </summary>
    public class AssignOAuth2SecurityRequirements : IOperationFilter
    {
        /// <summary>
        /// Filter implementation
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            //All methods are secured by default, unless explicitly specifying an AllowAnonymous attribute.
            var anonymous = apiDescription.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>();
            if (anonymous.Any())
            {
                return;
            }

            if (operation.security == null)
            {
                operation.security = new List<IDictionary<string, IEnumerable<string>>>();
            }

            var requirements =
                new Dictionary<string, IEnumerable<string>>
                {
                        {"OAuth 2.0 Client Credentials", Enumerable.Empty<string>()}
                };
            operation.security.Add(requirements);
        }
    }
}