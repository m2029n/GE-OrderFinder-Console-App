﻿using System;
using System.Collections.Generic;
using System.Web.Http.Description;
using Cdw.Api.Partners.Model;
using Swashbuckle.Swagger;

namespace Cdw.Api.Partners.Service.APIDocumentation
{
    /// <summary>
    /// Provides example error data for the api calls
    /// </summary>
    public class OrderErrorModelExamples : IOperationFilter
    {
        /// <summary>
        /// filter override
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            var response500 = GetFromOperation(operation, "500");
            var response503 = GetFromOperation(operation, "503");

            var error500 = new ErrorModel("External Dependency Error", "Order could temporarily not be created");
            var error503 = new ErrorModel("External Dependency Error", "Order could temporarily not be created");
            if (operation?.operationId == "GetOrder")
            {
                error500 = new ErrorModel("", "Order with input \'xxx\' could not be retrieved");
                error503 = new ErrorModel("", "Order with code xxx could temporarily not be retrieved");
            }

            if (response500 != null)
            {
                response500.examples = new Dictionary<string, ErrorModel>()
                {
                    {
                        "application/json",
                        error500
                    }
                };
            }
            if (response503 != null)
            {
                response503.examples = new Dictionary<string, ErrorModel>()
                {
                    {
                        "application/json",
                        error503
                    }
                };
            }
        }

        private Response GetFromOperation(Operation operation, string status)
        {
            try
            {
                var response = operation?.responses[status];
                if (response != null)
                {
                    response.description = status.CdwStatusCode();
                }
                return response;
            }
            catch (Exception)
            {
                // Intentionally eating any exceptions
            }
            return null;
        }
    }
}