﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Cdw.Api.Partners.Model.Order;

using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Service.Infrastructure.Converters.Order.RequestObject
{
    internal class AccountConverter : TypeConverter<AccountModel, IAccount>
    {
        protected override IAccount ConvertCore(AccountModel source)
        {
            var result = new Account()
            {
                CustomerNumber = source.CustomerNumber,
                EAccount = source.EAccount,
                EmailAddress = source.EmailAddress
            };

            return result;
        }
    }

    internal class BillingInfoConverter : TypeConverter<BillingInfoModel, IBillingInfo>
    {
        protected override IBillingInfo ConvertCore(BillingInfoModel source)
        {
            var result = new BillingInfo()
            {
                Address = Mapper.Map<IAddress>(source.Address),
                Method = Mapper.Map<IPaymentMethod>(source.Method)
            };

            return result;
        }
    }

    internal class PaymentMethodConverter : TypeConverter<PaymentMethodModel, IPaymentMethod>
    {
        protected override IPaymentMethod ConvertCore(PaymentMethodModel source)
        {
            var result = new PaymentMethod()
            {
                CreditCard = Mapper.Map<ICreditCard>(source.CreditCard),
                PONumber = source.PONumber,
                EncryptedCreditCard = source.EncryptedCreditCard,
                Terms = source.Terms,
                TransactionId = source.TransactionId,
                ReferenceNumber = source.ReferenceNumber
            };
            return result;
        }
    }

    internal class AddressConverter : TypeConverter<AddressModel, IAddress>
    {
        protected override IAddress ConvertCore(AddressModel source)
        {
            var result = new Address()
            {
                FirstName = source.FirstName,
                LastName = source.LastName,
                PhoneNumber = source.PhoneNumber,
                Company = source.Company,
                StreetAddress = source.StreetAddress,
                SecondaryStreetAddress = source.SecondaryStreetAddress,
                City = source.City,
                State = source.State,
                PostalCode = source.PostalCode,
                IsoCountryCode = source.IsoCountryCode
            };

            return result;
        }
    }

    internal class TaxConverter : TypeConverter<TaxModel, ITax>
    {
        protected override ITax ConvertCore(TaxModel source)
        {
            var result = new Domain.Partners.Orders.Tax()
            {
                Id = source.Id,
                Rate = source.Rate,
                Description = source.Description,
                Amount = source.Amount
            };

            return result;
        }
    }

    internal class DiscountConverter : TypeConverter<DiscountModel, IDiscount>
    {
        protected override IDiscount ConvertCore(DiscountModel source)
        {
            var result = new Discount()
            {
                Id = source.Id,
                Amount = source.Amount,
                Type = source.Type
            };

            return result;
        }
    }

    internal class ShippingInfoConverter : TypeConverter<ShippingInfoModel, IShippingInfo>
    {
        protected override IShippingInfo ConvertCore(ShippingInfoModel source)
        {
            var result = new ShippingInfo()
            {
                Address = Mapper.Map<IAddress>(source.Address),
                Method = Mapper.Map<IShippingMethod>(source.Method)
            };

            return result;
        }
    }

    internal class ShippingMethodConverter : TypeConverter<ShippingMethodModel, IShippingMethod>
    {
        protected override IShippingMethod ConvertCore(ShippingMethodModel source)
        {
            var result = new ShippingMethod()
            {
                Description = source.Description,
                Id = source.Id
            };

            return result;
        }
    }

    internal class CustomPropertyConverter : TypeConverter<CustomPropertyModel, ICustomProperty>
    {
        protected override ICustomProperty ConvertCore(CustomPropertyModel source)
        {
            var result = new CustomProperty()
            {
                Name = source.Name,
                Value = source.Value
            };

            return result;
        }
    }

    internal class ShippedItemConverter : TypeConverter<ShippedItemModel, IShippedItem>
    {
        protected override IShippedItem ConvertCore(ShippedItemModel source)
        {
            var result = new ShippedItem()
            {
                ProductCode = source.ProductCode,
                Quantity = source.Quantity,
                ManufacturerPartNumber = source.ManufacturerPartNumber
            };

            return result;
        }
    }

    internal class CreditCardConverter : TypeConverter<CreditCardModel, ICreditCard>
    {
        protected override ICreditCard ConvertCore(CreditCardModel source)
        {
            var result = new CreditCard()
            {
                ExpirationMonth = source.ExpirationMonth,
                ExpirationYear = source.ExpirationYear,
                Id = source.Id,
                Name = source.Name,
                Number = source.Number,
                Token = source.Token
            };
            return result;
        }
    }

    internal class CreditCardTypeConverter : TypeConverter<ICreditCardType, CreditCardTypeModel>
    {
        protected override CreditCardTypeModel ConvertCore(ICreditCardType source)
        {
            var result = new CreditCardTypeModel()
            {
                Type = (PaymentMethodTypeModel)((int)source.Type),
                Name = source.Name,
                AlternateNames = source.AlternateNames,
                CardNumberLength = source.CardNumberLength
            };

            return result;
        }
    }

    internal class RequestOrderConverter : TypeConverter<RequestOrderModel, RequestOrder>
    {
        protected override RequestOrder ConvertCore(RequestOrderModel source)
        {
            var result = new RequestOrder()
            {
                OrderNumber = source.OrderNumber,
                Status = source.Status,
                TransactionDate = source.TransactionDate,
                Company = source.Company,
                ReferenceNumber = source.ReferenceNumber,
                Account = Mapper.Map<IAccount>(source.Account),
                Subtotal = source.Subtotal,
                Discount = source.Discount,
                Taxes = Mapper.Map<IEnumerable<ITax>>(source.Taxes),
                Freight = source.Freight,
                Handling = source.Handling,
                Insurance = source.Insurance,
                Tax = source.Tax,
                Total = source.Total,
                Discounts = Mapper.Map<IEnumerable<IDiscount>>(source.Discounts),
                Billing = Mapper.Map<IBillingInfo>(source.Billing),
                Shipping = Mapper.Map<IShippingInfo>(source.Shipping),
                LineItems = Mapper.Map<IEnumerable<ILineItem>>(source.LineItems),
                CustomProperties = Mapper.Map<IEnumerable<ICustomProperty>>(source.CustomProperties),
                Geolocation = source.Geolocation,
                IpAddress = source.IpAddress,
                UserAgent = source.UserAgent
            };

            return result;
        }
    }

    internal class LineItemsConverter : TypeConverter<LineItemModel, ILineItem>
    {
        protected override ILineItem ConvertCore(LineItemModel source)
        {
            var result = new LineItem()
            {
                ProductCode = source.ProductCode,
                Status = source.Status,
                Quantity = source.Quantity,
                UnitPrice = source.UnitPrice,
                LinePrice = source.LinePrice,
                Discounts = Mapper.Map<IEnumerable<IDiscount>>(source.Discounts),
                CustomProperties = Mapper.Map<IEnumerable<ICustomProperty>>(source.CustomProperties),
                Shipments = Mapper.Map<IEnumerable<IShipment>>(source.Shipments)
            };

            return result;
        }
    }

    internal class ShipmentConverter : TypeConverter<ShipmentModel, IShipment>
    {
        protected override IShipment ConvertCore(ShipmentModel source)
        {
            var result = new Shipment()
            {
                Box = source.Box,
                Contents = Mapper.Map<IEnumerable<IShippedItem>>(source.Contents),
                InvoiceNumber = source.InvoiceNumber,
                ShippedDate = source.ShippedDate,
                ShippingMethod = Mapper.Map<IShippingMethod>(source.ShippingMethod),
                TrackingNumber = source.TrackingNumber,
                TrackingUrl = source.TrackingUrl,
                Weight = source.Weight
            };

            return result;
        }
    }
}

namespace Cdw.Api.Partners.Service.Infrastructure.Converters.Order.ResponseObject
{
    /// <summary>
    /// Converter mapping between domain and model Order objects.
    /// </summary>
    public class ResponseOrderConverter : TypeConverter<IOrder, ResponseOrderModel>
    {
        /// <summary>
        /// Overidden conversion between domain and model Order objects.
        /// </summary>
        /// <param name="order">Order Request Object.</param>
        /// <returns></returns>
        protected override ResponseOrderModel ConvertCore(IOrder order)
        {
            var result = new ResponseOrderModel
            {
                OrderNumber = order.OrderNumber,
                Status = order.Status.ToString(),
                TransactionDate = order.TransactionDate,
                Company = (int)order.Cart.Company,
                ReferenceNumber = order.ReferenceNumber,
                Account = Create(order.Account),
                Subtotal = order.Cart.Subtotal,
                Discount = order.Cart.DiscountValue,
                Taxes = Create(order.Taxes),
                Freight = order.Shipping.Method.Rate.Freight,
                Handling = order.Shipping.Method.Rate.Handling,
                Insurance = order.Shipping.Method.Rate.Insurance,
                Tax = order.Tax,
                Total = order.Total,
                Discounts = Create(order.Cart.Discounts),
                LineItems = order.Cart.Items.Select(i => Create(i, order.Shipments)).ToArray(),
                Billing = Create(order.Billing),
                Shipping = Create(order.Shipping),
                CustomProperties = order.Cart.CustomProperties.Select(Create).ToArray(),
                RecyclingFee = order.RecyclingFee,
                RecyclingFees = Create(order.RecyclingFees)
            };

            return result;
        }

        private RecyclingFeesModel[] Create(IEnumerable<IRecyclingFee> recyclingFees)
        {
            return recyclingFees != null
                ? recyclingFees.Select(e => new RecyclingFeesModel()
                {
                    ProductCode = e.ProductCode,
                    Amount = e.Amount,
                    Code = e.Code,
                    Description = e.Description
                }).ToArray()
                : Enumerable.Empty<RecyclingFeesModel>().ToArray();
        }

        private AccountModel Create(IAccount account)
        {
            return new AccountModel
            {
                EmailAddress = SafeTrim(account.EmailAddress),
                CustomerNumber = SafeTrim(account.CustomerNumber),
                EAccount = SafeTrim(account.EAccount)
            };
        }

        private string SafeTrim(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return string.Empty;
            }

            return input.Trim();
        }

        private AddressModel Create(IAddress address)
        {
            return new AddressModel
            {
                FirstName = address.FirstName,
                LastName = address.LastName,
                PhoneNumber = address.PhoneNumber ?? string.Empty,
                Company = address.Company ?? string.Empty,
                StreetAddress = address.StreetAddress ?? string.Empty,
                SecondaryStreetAddress = address.SecondaryStreetAddress ?? string.Empty,
                City = address.City ?? string.Empty,
                State = address.State ?? string.Empty,
                PostalCode = FormatPostalCode(address) ?? string.Empty,
                IsoCountryCode = address.IsoCountryCode ?? string.Empty
            };
        }

        internal string FormatPostalCode(IAddress address)
        {
            if (address.IsoCountryCode == "US")
            {
                if (address.PostalCode.Length == 9)
                {
                    return $"{address.PostalCode.Substring(0, 5)}-{address.PostalCode.Substring(5, 4)}";
                }
            }
            else if (address.IsoCountryCode == "CA")
            {
                if (address.PostalCode.Length == 6)
                {
                    return $"{address.PostalCode.Substring(0, 3)} {address.PostalCode.Substring(3, 3)}";
                }
            }

            return address.PostalCode;
        }

        private TaxModel[] Create(IEnumerable<ITax> taxes)
        {
            return taxes
                .Select(t => new TaxModel
                {
                    Id = t.Id,
                    Description = t.Description,
                    Rate = t.Rate,
                    Amount = t.Amount
                }).ToArray();
        }

        private DiscountModel[] Create(ICartDiscounts discounts)
        {
            return discounts.FixedAmountDiscounts.Select(d => Create(1000, d))
                .Union(discounts.PercentOffDiscounts.Select(d => Create(1001, d)))
                .ToArray();
        }

        private DiscountModel Create(int type, IDiscount discount)
        {
            return new DiscountModel
            {
                Type = type,
                Id = discount.Id,
                Amount = discount.Amount
            };
        }

        private ResponseBillingModel Create(IBillingInfo billing)
        {
            return new ResponseBillingModel
            {
                Address = Create(billing.Address),
                Method = Create(billing.Method)
            };
        }

        private ResponsePaymentMethodModel Create(IPaymentMethod method)
        {
            if (method.CreditCard.Type != null)
            {
                return new ResponsePaymentMethodModel
                {
                    PONumber = method.PONumber,

                    CreditCard = new ResponseCreditCardModel
                    {
                        Type = method.CreditCard.Type.Type.ToString(),
                        Number = $"************{method.CreditCard.Number}"
                    }
                };
            }
            else if (!string.IsNullOrEmpty(method.Terms))
            {
                return new ResponsePaymentMethodModel
                {
                    PONumber = method.PONumber,
                    Terms = method.Terms
                };
            }
            else
            {
                return new ResponsePaymentMethodModel
                {
                    PONumber = method.PONumber,

                    CreditCard = new ResponseCreditCardModel
                    {
                        Type = "UnKnown",
                        Number = "************0000"
                    }
                };
            }
        }

        private ShippingModel Create(IShippingInfo shipping)
        {
            return new ShippingModel
            {
                Address = Create(shipping.Address),
                Method = Create(shipping.Method)
            };
        }

        private ShippingMethodModel Create(IShippingMethod method)
        {
            return new ShippingMethodModel
            {
                Id = method.Id,
                Description = method.Description
            };
        }

        private LineItemModel Create(ICartItem item, IEnumerable<IShipment> shipments)
        {
            return new LineItemModel
            {
                ProductCode = item.Product.ProductCode,
                Status = item.Status.ToString(),
                Quantity = item.Quantity,
                UnitPrice = item.UnitPrice,
                LinePrice = item.DiscountedLinePrice,
                Discounts = Create(item.Discounts).ToArray(),
                CustomProperties = item.CustomProperties?.Select(Create).ToArray() ?? new List<CustomPropertyModel>().ToArray(),
                Shipments = shipments?.Select(Create).ToArray() ?? new List<ShipmentModel>().ToArray()
            };
        }

        private IEnumerable<DiscountModel> Create(ICartItemDiscounts discounts)
        {
            return discounts.FixedUnitPriceDiscounts.Select(d => Create(1002, d))
                .Union(discounts.PercentOffUnitPriceDiscounts.Select(d => Create(1003, d)))
                .Union(discounts.FixedLinePriceDiscounts.Select(d => Create(1004, d)))
                .Union(discounts.PercentOffLinePriceDiscounts.Select(d => Create(1005, d)));
        }

        private CustomPropertyModel Create(ICustomProperty property)
        {
            return new CustomPropertyModel
            {
                Name = property.Name,
                Value = property.Value
            };
        }

        private ShipmentModel Create(IShipment shipment)
        {
            return new ShipmentModel
            {
                Box = shipment.Box,
                // The invoice number currently assigned to the shipment is the internal invoice
                // number. This needs to be fixed to show the external invoice number. For now,
                // we'll return the empty string as it is not being used by anyone.
                //InvoiceNumber = shipment.InvoiceNumber,
                InvoiceNumber = string.Empty,
                ShippedDate = shipment.ShippedDate,
                TrackingNumber = shipment.TrackingNumber,
                TrackingUrl = shipment.TrackingUrl,
                Weight = shipment.Weight,
                ShippingMethod = new ShippingMethodModel
                {
                    Description = shipment.ShippingMethod.Description,
                    Id = shipment.ShippingMethod.Id
                },
                Contents = shipment.Contents.Select(Create).ToArray()
            };
        }

        private ShippedItemModel Create(IShippedItem shippedItem)
        {
            return new ShippedItemModel
            {
                ProductCode = shippedItem.ProductCode,
                Quantity = shippedItem.Quantity
            };
        }
    }

    internal class ResponseShipmentConverter : TypeConverter<IShipment, ShipmentModel>
    {
        protected override ShipmentModel ConvertCore(IShipment source)
        {
            var result = new ShipmentModel()
            {
                Box = source.Box,
                Contents = Mapper.Map<ShippedItemModel[]>(source.Contents),
                InvoiceNumber = source.InvoiceNumber,
                ShippedDate = source.ShippedDate,
                ShippingMethod = Mapper.Map<ShippingMethodModel>(source.ShippingMethod),
                TrackingNumber = source.TrackingNumber,
                TrackingUrl = source.TrackingUrl,
                Weight = source.Weight
            };

            return result;
        }
    }

    internal class ResponseShippedItemConverter : TypeConverter<IShippedItem, ShippedItemModel>
    {
        protected override ShippedItemModel ConvertCore(IShippedItem source)
        {
            var result = new ShippedItemModel()
            {
                ProductCode = source.ProductCode,
                Quantity = source.Quantity,
                ManufacturerPartNumber = source.ManufacturerPartNumber
            };

            return result;
        }
    }

    internal class ResponseTaxConverter : TypeConverter<ITax, TaxModel>
    {
        protected override TaxModel ConvertCore(ITax source)
        {
            var result = new TaxModel()
            {
                Id = source.Id,
                Rate = source.Rate,
                Description = source.Description,
                Amount = source.Amount
            };

            return result;
        }
    }

    internal class ResponseAccountConverter : TypeConverter<IAccount, AccountModel>
    {
        protected override AccountModel ConvertCore(IAccount source)
        {
            var result = new AccountModel()
            {
                CustomerNumber = source.CustomerNumber,
                EAccount = source.EAccount,
                EmailAddress = source.EmailAddress
            };

            return result;
        }
    }

    internal class ReseponseResponseBillingConverter : TypeConverter<IResponseBilling, ResponseBillingModel>
    {
        protected override ResponseBillingModel ConvertCore(IResponseBilling source)
        {
            var result = new ResponseBillingModel()
            {
                Address = Mapper.Map<AddressModel>(source.Address),
                Method = Mapper.Map<ResponsePaymentMethodModel>(source.Method)
            };

            return result;
        }
    }

    internal class ResponseResponsePaymentMethodConverter : TypeConverter<IResponsePaymentMethod, ResponsePaymentMethodModel>
    {
        protected override ResponsePaymentMethodModel ConvertCore(IResponsePaymentMethod source)
        {
            var result = new ResponsePaymentMethodModel()
            {
                PONumber = source.PONumber,
                CreditCard = Mapper.Map<ResponseCreditCardModel>(source.CreditCard)
            };

            return result;
        }
    }

    internal class ResponseResponseCreditCardConverter : TypeConverter<IResponseCreditCard, ResponseCreditCardModel>
    {
        protected override ResponseCreditCardModel ConvertCore(IResponseCreditCard source)
        {
            var result = new ResponseCreditCardModel()
            {
                Type = source.Type,
                Number = source.Number
            };
            return result;
        }
    }

    internal class ResponseLineItemConverter : TypeConverter<ILineItem, LineItemModel>
    {
        protected override LineItemModel ConvertCore(ILineItem source)
        {
            var result = new LineItemModel()
            {
                ProductCode = source.ProductCode,
                LinePrice = source.LinePrice,
                Quantity = source.Quantity,
                UnitPrice = source.UnitPrice,
                Status = source.Status,
                CustomProperties = Mapper.Map<CustomPropertyModel[]>(source.CustomProperties),
                Discounts = Mapper.Map<DiscountModel[]>(source.Discounts),
                Shipments = Mapper.Map<ShipmentModel[]>(source.Shipments),
            };

            return result;
        }
    }

    internal class ResponseCustomPropertyConverter : TypeConverter<ICustomProperty, CustomPropertyModel>
    {
        protected override CustomPropertyModel ConvertCore(ICustomProperty source)
        {
            var result = new CustomPropertyModel()
            {
                Name = source.Name,
                Value = source.Value
            };
            return result;
        }
    }

    internal class ResponseShippingConverter : TypeConverter<IShipping, ShippingModel>
    {
        protected override ShippingModel ConvertCore(IShipping source)
        {
            var result = new ShippingModel()
            {
                Address = Mapper.Map<AddressModel>(source.Address),
                Method = Mapper.Map<ShippingMethodModel>(source.Method)
            };

            return result;
        }
    }

    internal class ResponseShippingMethodConverter : TypeConverter<IShippingMethod, ShippingMethodModel>
    {
        protected override ShippingMethodModel ConvertCore(IShippingMethod source)
        {
            var result = new ShippingMethodModel()
            {
                Description = source.Description,
                Id = source.Id
            };
            return result;
        }
    }

    internal class ResponseAddressConverter : TypeConverter<IAddress, AddressModel>
    {
        protected override AddressModel ConvertCore(IAddress source)
        {
            var result = new AddressModel()
            {
                FirstName = source.FirstName,
                LastName = source.LastName,
                PhoneNumber = source.PhoneNumber,
                Company = source.Company,
                StreetAddress = source.StreetAddress,
                SecondaryStreetAddress = source.SecondaryStreetAddress,
                City = source.City,
                State = source.State,
                PostalCode = source.PostalCode,
                IsoCountryCode = source.IsoCountryCode
            };

            return result;
        }
    }

    internal class ResponseDiscountConverter : TypeConverter<IDiscount, DiscountModel>
    {
        protected override DiscountModel ConvertCore(IDiscount source)
        {
            var result = new DiscountModel()
            {
                Id = source.Id,
                Amount = source.Amount,
                Type = source.Type
            };

            return result;
        }
    }
}