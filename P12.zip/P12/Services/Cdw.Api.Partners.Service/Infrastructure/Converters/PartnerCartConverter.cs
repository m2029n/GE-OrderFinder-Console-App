﻿using System.Collections.Generic;
using AutoMapper;
using Cdw.Api.Partners.Model.Cart;
using Cdw.Domain.Partners.PartnerCart;

namespace Cdw.Api.Partners.Service.Infrastructure.Converters.PartnerCart.RequestObject
{
    internal class PartnerCartRequestConverter : TypeConverter<PartnerCartRequestModel, Cdw.Domain.Partners.PartnerCart.PartnerCartRequest>
    {
        protected override Cdw.Domain.Partners.PartnerCart.PartnerCartRequest ConvertCore(PartnerCartRequestModel source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new Cdw.Domain.Partners.PartnerCart.PartnerCartRequest()
            {
                Id = source.Id,
                Source = source.Source,
                CorrelationId = source.CorrelationId,
                CartUrl = source.CartUrl,
                WebSiteId = source.WebSiteId,
                Created = source.Created,
                LineItems = Mapper.Map<IEnumerable<IPartnerCartRequestItem>>(source.LineItems)
            };

            return result;
        }
    }

    internal class PartnerCartRequestItemConverter : TypeConverter<PartnerCartRequestItemModel, IPartnerCartRequestItem>
    {
        protected override IPartnerCartRequestItem ConvertCore(PartnerCartRequestItemModel source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new Cdw.Domain.Partners.PartnerCart.PartnerCartRequestItem()
            {
                Id = source.Id,
                Manufacturer = source.Manufacturer,
                ManufacturerPartNumber = source.ManufacturerPartNumber,
                ProductCode = source.ProductCode,
                Quantity = source.Quantity
            };

            return result;
        }
    }
}

namespace Cdw.Api.Partners.Service.Infrastructure.Converters.PartnerCart.ResponseObject
{
    internal class PartnerCartResponseConverter : TypeConverter<IPartnerCartRequest, PartnerCartResponseModel>
    {
        protected override PartnerCartResponseModel ConvertCore(IPartnerCartRequest source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new PartnerCartResponseModel()
            {
                Id = source.Id,
                Source = source.Source,
                CorrelationId = source.CorrelationId,
                CartUrl = source.CartUrl,
                WebSiteId = source.WebSiteId,
                Created = source.Created,
                LineItems = Mapper.Map<PartnerCartResponseItemModel[]>(source.LineItems)
            };

            return result;
        }
    }

    internal class PartnerCartResponseItemConverter : TypeConverter<IPartnerCartRequestItem, PartnerCartResponseItemModel>
    {
        protected override PartnerCartResponseItemModel ConvertCore(IPartnerCartRequestItem source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new PartnerCartResponseItemModel()
            {
                Manufacturer = source.Manufacturer,
                ManufacturerPartNumber = source.ManufacturerPartNumber,
                ProductCode = source.ProductCode,
                Quantity = source.Quantity
            };

            return result;
        }
    }
}