﻿using AutoMapper;
using Cdw.Api.Partners.Model.Payment;

namespace Cdw.Domain.Partners.Payments
{
    internal class PaymentConverter : TypeConverter<PaymentRequestModel, PaymentRequest>
    {
        protected override PaymentRequest ConvertCore(PaymentRequestModel source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new PaymentRequest
            {
                TransactionId = source.TransactionId,
                CreditCard = Mapper.Map<CreditCard>(source.CreditCard),
                IpAddress = source.IpAddress,
                GeoLocation = source.GeoLocation,
                UserAgent = source.UserAgent
            };

            return result;
        }
    }

    internal class CreditCardConverter : TypeConverter<CreditCardModel, CreditCard>
    {
        protected override CreditCard ConvertCore(CreditCardModel source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new CreditCard
            {
                Name = source.Name,
                Number = source.Number,
                ExpirationMonth = source.ExpirationMonth,
                ExpirationYear = source.ExpirationYear,
                CVV = source.CVV
            };

            return result;
        }
    }
}