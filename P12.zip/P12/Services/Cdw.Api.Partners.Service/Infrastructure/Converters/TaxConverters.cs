﻿using System.Linq;
using AutoMapper;
using Cdw.Api.Partners.Model.Tax;
using Cdw.Domain.Partners.Tax;

namespace Cdw.Api.Partners.Service.Infrastructure.Converters.Tax.RequestObject
{
    internal class TaxRequestConverter : TypeConverter<TaxRequestModel, TaxRequest>
    {
        protected override TaxRequest ConvertCore(TaxRequestModel source)
        {
            if (source == null)
            {
                return null;
            }

            var lineitemlist = source.LineItems.Select(lineItem => new LineItem()
            {
                ProductCode = lineItem.ProductCode,
                Quantity = lineItem.Quantity,
                UnitPrice = lineItem.UnitPrice,
                CustomProperties = Mapper.Map<CustomProperty[]>(lineItem.CustomProperties),
                Discounts = Mapper.Map<Discount[]>(lineItem.Discounts),
                LineNumber = lineItem.LineNumber
            }).ToList();

            var result = new TaxRequest()
            {
                Account = Mapper.Map<Account>(source.Account),
                Address = Mapper.Map<Address>(source.Address),
                Company = source.Company,
                Discounts = Mapper.Map<Discount[]>(source.Discounts),
                Freight = source.Freight,
                Handling = source.Handling,
                Insurance = source.Insurance,
                LineItems = lineitemlist,
                ProductFees = Mapper.Map<ProductFee[]>(source.ProductFees)
            };
            return result;
        }
    }
}