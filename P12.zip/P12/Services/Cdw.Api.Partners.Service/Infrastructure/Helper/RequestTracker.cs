﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace Cdw.Api.Partners.Service.Infrastructure.Helper
{
    /// <summary>
    /// holds RequestTracker
    /// </summary>
    public class RequestTracker
    {
        private const string AkamiGeoHeader = "X-AKAMAI-EDGESCAPE";
        private const string AkamiClientIp = "True-Client-IP";

        private readonly HttpRequestMessage _request;

        /// <summary>
        /// ctor RequestTracker
        /// </summary>
        /// <param name="request"></param>
        public RequestTracker(HttpRequestMessage request)
        {
            _request = request;
        }

        /// <summary>
        /// gets IP
        /// </summary>
        /// <returns></returns>
        public string GetClientIp()
        {
            IEnumerable<string> valuEnumerable;
            var hasValue = _request.Headers.TryGetValues(AkamiClientIp, out valuEnumerable);
            return hasValue ? valuEnumerable.FirstOrDefault() : null;
        }

        /// <summary>
        /// gets location
        /// </summary>
        /// <returns></returns>
        public string GetClientAkamaiGeoLocation()
        {
            IEnumerable<string> valuEnumerable;
            var hasValue = _request.Headers.TryGetValues(AkamiGeoHeader, out valuEnumerable);
            return hasValue ? valuEnumerable.FirstOrDefault() : null;
        }

        /// <summary>
        /// gets useragent
        /// </summary>
        /// <returns></returns>
        public string GetUseAgent()
        {
            return _request.Headers.UserAgent.ToString();
        }
    }
}