﻿namespace Cdw.Api.Partners.Service.Infrastructure.Helper
{
    //TODO:change this with cdwcompany enum in domain layer.
    /// <summary>
    /// Holds CdwCompanyCodes
    /// </summary>
    public static class CdwCompanyCodes
    {
        public static string CDWDirect { get { return "01"; } }
        public static string CDWCanada { get { return "17"; } }
    }
}