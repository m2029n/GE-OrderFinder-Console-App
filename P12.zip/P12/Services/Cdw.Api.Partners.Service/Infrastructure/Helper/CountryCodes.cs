﻿namespace Cdw.Api.Partners.Service.Infrastructure.Helper
{
    /// <summary>
    /// enum that  defines country
    /// </summary>
    public enum CountryCodes
    {
        /// <summary>
        /// defines US
        /// </summary>
        US,

        /// <summary>
        /// defines CA
        /// </summary>
        CA
    }
}