﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Common;

namespace Cdw.Api.Partners.Service.Infrastructure.Helper
{
    public static class Lookups
    {
        private static Dictionary<int, string> cdwCompanyIdCountryLookup = new Dictionary<int, string>() // we only support a subset of CDW companies currently
        {
            {(int)CdwCompany.CDW, CountryCodes.US.ToString()},
            {(int)CdwCompany.CDWCa, CountryCodes.CA.ToString()}
        };

        public static Dictionary<int, string> CdwCompanyIdCountryLookup => cdwCompanyIdCountryLookup;

        private static Dictionary<string, string> cdwCompanyCodeCountryLookup = new Dictionary<string, string>() // we only support a subset of CDW companies currently
        {
            {CdwCompanyCodes.CDWDirect, CountryCodes.US.ToString()},
            {CdwCompanyCodes.CDWCanada, CountryCodes.CA.ToString()}
        };

        public static Dictionary<string, string> CdwCompanyCodeCountryLookup => cdwCompanyCodeCountryLookup;
    }
}