﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Filters;

namespace Cdw.Api.Partners.Service.Infrastructure.Filters
{
    public class EnableCorsAttribute: ActionFilterAttribute
    {
        private readonly string _whitelist;

        public EnableCorsAttribute(string whitelist = null)
        {
            _whitelist = whitelist;
           
        }
        public override void OnActionExecuted(HttpActionExecutedContext filterContext)
        {
          
            string origin = HttpContext.Current.Request.Url.Host;
            if (string.IsNullOrWhiteSpace(_whitelist))
            {
                HttpContext.Current.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            }
            else if (ResourceAccessService.IsAllowed(origin,_whitelist))
            {
                HttpContext.Current.Response.Headers.Add("Access-Control-Allow-Origin", origin);
                HttpContext.Current.Response.Headers.Add("Access-Control-Allow-Methods", "Get");
            }
        }
    }
}
