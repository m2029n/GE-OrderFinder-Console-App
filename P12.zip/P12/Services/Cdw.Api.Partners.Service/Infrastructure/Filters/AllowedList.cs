﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Api.Partners.Service.Infrastructure.Filters
{
   public class AllowedList
    {
        public static readonly string Whitelist = "adobe.com";
        public static readonly string Headers = "";
        public static readonly string Methods = "";
    }
}
