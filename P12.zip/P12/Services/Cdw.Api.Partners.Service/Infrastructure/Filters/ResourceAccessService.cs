﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Api.Partners.Service.Infrastructure.Filters
{
    internal class ResourceAccessService
    {
        internal static bool IsAllowed(string origin, string whitelist)
        {
            try
            {
                string[] allowedList = whitelist.Split(',').ToArray();
                if (string.IsNullOrEmpty(origin)) return false;
                var count = origin.Count(s => s == ':');
                if (count > 2) return false;

                if (count == 2)
                {
                    origin = origin.Remove(origin.LastIndexOf(':'));
                }

                return allowedList.Contains(origin);
            }
            catch
            {
                return false;
            }
        }
    }
}
