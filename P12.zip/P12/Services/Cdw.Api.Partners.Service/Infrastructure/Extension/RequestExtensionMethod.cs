﻿//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Http;

//namespace Cdw.Api.Partners.Service.Infrastructure.Extension
//{
//    public static class RequestExtensionMethod
//    {
//        private const string TrackingHeader = "x-cdw-tracking-id";
//        private const string CorrelationHeader = "x-cdw-correlation-id";

//        public static string GetCdwTrackingId(this HttpRequestMessage request)
//        {
//            if (request == null) return null;

//            IEnumerable<string> outparm;
//            request.Headers.TryGetValues(TrackingHeader, out outparm);
//            return outparm?.FirstOrDefault();
//        }

//        public static string GetCdwCorrelationId(this HttpRequestMessage request)
//        {
//            if (request == null) return null;

//            IEnumerable<string> outparm;
//            request.Headers.TryGetValues(CorrelationHeader, out outparm);
//            return outparm?.FirstOrDefault();
//        }
//    }
//}