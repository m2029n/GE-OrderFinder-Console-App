﻿using System;
using System.Text.RegularExpressions;

namespace Cdw.Api.Partners.Service.Infrastructure.Extension
{
    /// <summary>
    /// StringExtension
    /// </summary>
    public static class StringExtension
    {
        /// <summary>
        /// Regex used to validate a US postal code.
        /// Valid value must be
        ///  6 numeric characters e.g. "60060"
        /// or
        ///  6 numeric characters with hyphen followed by 4 additional characters e.g. "60060-1234".
        /// </summary>
        private static Regex regexValidUSPostalCode = new Regex(@"^[0-9]{5}(?:-[0-9]{4})?$", RegexOptions.Compiled);

        /// <summary>
        /// Regex used to validate a Canada postal code.
        /// Valid value must be 6 characters with an optional space in middle
        /// and
        ///  first character must be alpha
        /// and
        ///  second character must be numeric
        /// and
        ///  third character must be alpha
        /// and
        ///  fourth character must be numeric
        /// and
        ///  fifth character must be alpha
        /// and
        ///  sixth character must be numeric e.g. "A1A1A1" or "A1A 1A1"
        /// and
        ///  is not case sensitive
        /// </summary>
        private static Regex regexValidCanadaPostalCode = new Regex(@"^[A-Z]{1}[0-9]{1}[A-Z]{1}[ ]?[0-9]{1}[A-Z]{1}[0-9]{1}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        /// <summary>
        /// IsValidUSPostalCode
        /// </summary>
        /// <param name="postalCode"></param>
        /// <returns></returns>
        public static bool IsValidUSPostalCode(this String postalCode)
        {
            if (postalCode == null)
            {
                return false;
            }

            return regexValidUSPostalCode.IsMatch(postalCode);
        }

        /// <summary>
        /// IsValidCanadaPostalCode
        /// </summary>
        /// <param name="postalCode"></param>
        /// <returns></returns>
        public static bool IsValidCanadaPostalCode(this String postalCode)
        {
            if (postalCode == null)
            {
                return false;
            }

            return regexValidCanadaPostalCode.IsMatch(postalCode);
        }
    }
}