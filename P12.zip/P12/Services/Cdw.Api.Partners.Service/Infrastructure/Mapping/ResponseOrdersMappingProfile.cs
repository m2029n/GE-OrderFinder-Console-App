﻿using AutoMapper;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Service.Infrastructure.Converters.Order.ResponseObject;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class ResponseOrdersMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<IOrder, ResponseOrderModel>()
                .ConvertUsing(new ResponseOrderConverter());

            Mapper.CreateMap<ITax, TaxModel>()
                .ConvertUsing(new ResponseTaxConverter());

            Mapper.CreateMap<IAccount, AccountModel>()
                .ConvertUsing(new ResponseAccountConverter());

            Mapper.CreateMap<IResponseBilling, ResponseBillingModel>()
                .ConvertUsing(new ReseponseResponseBillingConverter());

            Mapper.CreateMap<IResponsePaymentMethod, ResponsePaymentMethodModel>()
                .ConvertUsing(new ResponseResponsePaymentMethodConverter());

            Mapper.CreateMap<IResponseCreditCard, ResponseCreditCardModel>()
                .ConvertUsing(new ResponseResponseCreditCardConverter());

            Mapper.CreateMap<ILineItem, LineItemModel>()
                .ConvertUsing(new ResponseLineItemConverter());

            Mapper.CreateMap<ICustomProperty, CustomPropertyModel>()
                .ConvertUsing(new ResponseCustomPropertyConverter());

            Mapper.CreateMap<IShipping, ShippingModel>()
                .ConvertUsing(new ResponseShippingConverter());

            Mapper.CreateMap<IShippingMethod, ShippingMethodModel>()
                .ConvertUsing(new ResponseShippingMethodConverter());

            Mapper.CreateMap<IAddress, AddressModel>()
                .ConvertUsing(new ResponseAddressConverter());

            Mapper.CreateMap<IDiscount, DiscountModel>()
                .ConvertUsing(new ResponseDiscountConverter());

            Mapper.CreateMap<IShipment, ShipmentModel>()
                .ConvertUsing(new ResponseShipmentConverter());

            Mapper.CreateMap<IShippedItem, ShippedItemModel>()
               .ConvertUsing(new ResponseShippedItemConverter());
        }
    }
}