﻿using AutoMapper;
using Cdw.Api.Partners.Model.Tax;
using Cdw.Api.Partners.Service.Infrastructure.Converters.Tax.RequestObject;
using Cdw.Domain.Partners.Tax;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class TaxMappingProfile : Profile
    {
        protected override void Configure()
        {
            Mapper.CreateMap<AccountModel, Account>();
            Mapper.CreateMap<DiscountModel, Discount>();
            Mapper.CreateMap<AddressModel, Address>();
            Mapper.CreateMap<LineItemModel, LineItem>();
            Mapper.CreateMap<ProductFeeModel, ProductFee>();
            Mapper.CreateMap<CustomPropertyModel, CustomProperty>();
            Mapper.CreateMap<TaxModel, Tax>();
            Mapper.CreateMap<TaxRequestModel, TaxRequest>()
              .ConvertUsing(new TaxRequestConverter());
        }
    }
}