﻿using AutoMapper;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class PaymentsMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<PaymentRequestModel, PaymentRequest>().
                ConvertUsing(new PaymentConverter());

            Mapper.CreateMap<CreditCardModel, CreditCard>().
                ConvertUsing(new CreditCardConverter());
        }
    }
}