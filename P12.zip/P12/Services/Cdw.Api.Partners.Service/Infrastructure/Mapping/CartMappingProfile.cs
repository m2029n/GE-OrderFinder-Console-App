﻿using AutoMapper;
using Cdw.Api.Partners.Model.Cart;
using Cdw.Api.Partners.Service.Infrastructure.Converters.PartnerCart.RequestObject;
using Cdw.Api.Partners.Service.Infrastructure.Converters.PartnerCart.ResponseObject;
using Cdw.Domain.Partners.PartnerCart;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class CartMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<PartnerCartRequestModel, PartnerCartRequest>()
                .ConvertUsing(new PartnerCartRequestConverter());

            Mapper.CreateMap<PartnerCartRequestItemModel, IPartnerCartRequestItem>()
                .ConvertUsing(new PartnerCartRequestItemConverter());

            Mapper.CreateMap<IPartnerCartRequest, PartnerCartResponseModel>()
                .ConvertUsing(new PartnerCartResponseConverter());

            Mapper.CreateMap<IPartnerCartRequestItem, PartnerCartResponseItemModel>()
                .ConvertUsing(new PartnerCartResponseItemConverter());
        }
    }
}