﻿using AutoMapper;
using Cdw.Api.Partners.Model.Product;
using Cdw.Domain.Partners.Product;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class ProductMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<ProductModel, Product>();

            Mapper.CreateMap<IProduct, ProductModel>();
        }
    }
}