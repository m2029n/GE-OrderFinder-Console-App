﻿using AutoMapper;
using Cdw.Api.Partners.Model.Order;

using Cdw.Api.Partners.Service.Infrastructure.Converters.Order.RequestObject;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Service.Infrastructure.Mapping
{
    internal class OrdersMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<RequestOrderModel, RequestOrder>()
                .ConvertUsing(new RequestOrderConverter());

            Mapper.CreateMap<AccountModel, IAccount>()
                .ConvertUsing(new AccountConverter());

            Mapper.CreateMap<BillingInfoModel, IBillingInfo>()
                .ConvertUsing(new BillingInfoConverter());

            Mapper.CreateMap<PaymentMethodModel, IPaymentMethod>()
                .ConvertUsing(new PaymentMethodConverter());

            Mapper.CreateMap<AddressModel, IAddress>()
                .ConvertUsing(new AddressConverter());

            Mapper.CreateMap<TaxModel, ITax>().
                ConvertUsing(new TaxConverter());

            Mapper.CreateMap<DiscountModel, IDiscount>()
                .ConvertUsing(new DiscountConverter());

            Mapper.CreateMap<ShippingInfoModel, IShippingInfo>()
                .ConvertUsing(new ShippingInfoConverter());

            Mapper.CreateMap<ShippingMethodModel, IShippingMethod>()
                .ConvertUsing(new ShippingMethodConverter());

            Mapper.CreateMap<CustomPropertyModel, ICustomProperty>()
                .ConvertUsing(new CustomPropertyConverter());

            Mapper.CreateMap<ShipmentModel, IShipment>()
                .ConvertUsing(new ShipmentConverter());

            Mapper.CreateMap<LineItemModel, ILineItem>()
                .ConvertUsing(new LineItemsConverter());

            Mapper.CreateMap<ShipmentModel, IShipment>()
                .ConvertUsing(new ShipmentConverter());

            Mapper.CreateMap<ShippedItemModel, IShippedItem>()
                .ConvertUsing(new ShippedItemConverter());

            Mapper.CreateMap<CreditCardModel, ICreditCard>()
                .ConvertUsing(new CreditCardConverter());

            Mapper.CreateMap<ICreditCardType, CreditCardTypeModel>()
                .ConvertUsing(new CreditCardTypeConverter());
        }
    }
}