﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Api.Partners.Service.APIDocumentation;
using Cdw.Api.Partners.Service.Infrastructure.Helper;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Payments;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Cdw.Partners.Validation.Payments;
using Cdw.Services.Core;
using Common.Logging;
using Swashbuckle.Swagger.Annotations;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Payment end point for PCI compliance
    /// </summary>
    [RoutePrefix("payments")]
    public class PaymentsController : PartnerBaseController
    {
        private readonly ILog _logger;

        private readonly IMappingEngine _mapper;

        private readonly IPaymentDomainManager _paymentDomainManager;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="log"></param>
        /// <param name="mapper"></param>
        /// <param name="paymentDomainManager"></param>
        /// <param name="partnerDetails"></param>
        public PaymentsController(
            ILog log,
            IMappingEngine mapper,
            IPaymentDomainManager paymentDomainManager,
            IPartnerDetails partnerDetails

            )
            : base(new HealthCheck(""), log, partnerDetails)
        {
            _logger = log;
            _mapper = mapper;
            _paymentDomainManager = paymentDomainManager;
        }

        /// <summary>
        ///  Used to probe the health the the Payment endpoint
        /// </summary>
        ///<remarks>
        /// Only requests submitted by the authenticated partner can be retrieved.
        /// </remarks>
        [HttpGet]
        [Route("healthcheck")]
        [SwaggerOperation("Payments_Healthcheck", Tags = new[] { "Payments" })]
        [ResponseType(typeof(HealthcheckType))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(HealthcheckType))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        public HttpResponseMessage GetHeartbeat()
        {
            return Heartbeat().Result;
        }

        /// <summary>
        /// Gets RefrenceNumber for processed Credit Card
        /// </summary>
        /// <param name="paymentRequestModel">Credit Card Data to be processed By CDW</param>
        /// <returns>Submitted transactionId and Reference Number of processed credit card</returns>
        [HttpPost]
        [Route("_authorize")]
        [ResponseType(typeof(AuthResponse))]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(AuthResponse))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(List<ErrorModel>))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(List<ErrorModel>))]
        [SwaggerOperation("Authorize", Tags = new[] { "Payments" })]
        public async Task<HttpResponseMessage> Authorize([FromBody] PaymentRequestModel paymentRequestModel)
        {
            try
            {
                MapRequestTrackingDetails(paymentRequestModel);

                var validObject = new DefaultValidator(paymentRequestModel);

                if (!validObject.IsValid)
                {
                    throw new PaymentValidationException(validObject.Failures);
                }
                var paymentRequest = this._mapper.Map<PaymentRequest>(paymentRequestModel);

                var response =await  _paymentDomainManager.AuthorizeAsync(paymentRequest).ConfigureAwait(false);

                return CreateResponse(HttpStatusCode.OK, response);
            }
            catch (PaymentValidationException ex)
            {
                _logger.Debug(ex.Failures, "Payment Validation Error", null);
                return CreateResponse(HttpStatusCode.BadRequest, ex.Failures.Select(f => new ErrorModel(f.Field, f.Message)));
            }
            catch (ApplicationException ex)
            {
                _logger.Error("Payments Authorization Error: ApplicationException", ex, null, paymentRequestModel);
                return CreateResponse(HttpStatusCode.BadRequest, new[] { new ErrorModel("External Dependency Error", ex.Message) });
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("Payments Authorization Error: ServiceCallException", ex, null, paymentRequestModel);

                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { new ErrorModel("External Dependency Error", "Payments could temporarily not be authorized.") });
            }
            catch (Exception ex)
            {
                _logger.Fatal("Payments Authorization Error: Exception", ex, null, paymentRequestModel);

                return CreateResponse(HttpStatusCode.InternalServerError, new[] { new ErrorModel("External Dependency Error", "Payment could not be authorized.") });
            }
        }

        private void MapRequestTrackingDetails(PaymentRequestModel paymentRequestModel)
        {
            var requestDetails = new RequestTracker(Request);
            paymentRequestModel.IpAddress = requestDetails.GetClientIp();
            paymentRequestModel.UserAgent = requestDetails.GetUseAgent();
            paymentRequestModel.GeoLocation = requestDetails.GetClientAkamaiGeoLocation();
        }
    }
}