﻿using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.Freight;
using Cdw.Api.Partners.Service.Infrastructure.Extension;
using Cdw.Api.Partners.Service.Infrastructure.Helper;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners.Freight;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Tax;
using Cdw.Partners.Utilities;
using Cdw.Services.Core;
using Common.Logging;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Freight endpoint provides access to freight data
    /// </summary>
    [RoutePrefix("freight")]
    public class FreightController : PartnerBaseController
    {
        private readonly ILog _logger;
        private readonly IFreightDomainManager _freightDomainManager;

        /// <summary>
        /// Ctor
        /// </summary>
        public FreightController(ILog log, IFreightDomainManager freightDomainManager, IGetIdentityService getIdentityService)
            : base(freightDomainManager as IHealthCheck, log, getIdentityService)
        {
            _logger = log;
            _freightDomainManager = freightDomainManager;
        }

        /// <summary>
        /// Used to probe the health the the Freight endpoint
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("healthcheck")]
        public HttpResponseMessage GetHeartbeat()
        {
            return base.Heartbeat().Result;
        }

        /// <summary>
        /// Gets the freight for the specified input
        /// </summary>
        /// <param name="ratingRequestModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(IRatingResponse))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(ITax))]
        [SwaggerResponse(HttpStatusCode.BadRequest, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetFreight([FromBody] RatingRequestModel ratingRequestModel)
        {
            var trackingValues = Request.TrackingValues();

            try
            {
                _logger.Debug("Step 1: Freight Request Mapping", trackingValues);

                ApplyInboundTransformation(ratingRequestModel);


                _logger.Debug("Step 2: Freight Request Validation", trackingValues);
                var validationResult = Validate(ratingRequestModel);

                if (validationResult != null)
                {
                    _logger.Debug("Step 2.1: Freight Request Validation Failed", trackingValues);
                    return validationResult;
                }

                _logger.Debug("Step 3: Freight Request call tax domain manager", trackingValues);
                var freight = await _freightDomainManager.RateAsync(User.Identity.Name, ratingRequestModel, trackingValues).ConfigureAwait(false);

                ApplyOutboundTransformation(freight);

                _logger.Debug("Step 4: Freight Return result ", trackingValues);
                return CreateResponse(HttpStatusCode.OK, freight);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("Freight Error: ServiceCallException", ex, trackingValues, ratingRequestModel);
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { new Error("Freight could not be retrieved temporarily") });
            }
            catch (Exception ex)
            {
                _logger.Fatal("Freight Error: Exception", ex, trackingValues, ratingRequestModel);
                return CreateResponse(HttpStatusCode.InternalServerError, new[] { new ErrorModel("Unknown server error, please contact administrator") });
            }
        }

        private HttpResponseMessage Validate(RatingRequestModel model)
        {
            // Validate country code exists.
            if (string.IsNullOrWhiteSpace(model.ShipTo.Country))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Country code not found");
            }

            var countryCode = model.ShipTo.Country;

            // Validate company code is supported and matches country code.
            var companyCode = string.IsNullOrWhiteSpace(model.CompanyCode) ? CdwCompanyCodes.CDWDirect : model.CompanyCode; // default company code to CDWDirect if missing

            //Todo: ask jeff to use this common cdw enum instead of a custom logic
            //var companyCode = string.IsNullOrWhiteSpace(request.CompanyCode)
            //    ? CdwCompany.CDW.Description()
            //    : request.CompanyCode;
            string countryCodeOut = null;
            if (!Lookups.CdwCompanyCodeCountryLookup.TryGetValue(companyCode, out countryCodeOut))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Unsupported company code");
            }

            if (countryCodeOut != countryCode)
            {
                return CreateResponse(HttpStatusCode.BadRequest, $"Company code {companyCode} is invalid for country code '{countryCode}'");
            }

            // Validate postal codes.
            switch (countryCode)
            {
                case "US":
                    if (!model.ShipTo.PostalCode.IsValidUSPostalCode())
                    {
                        return CreateResponse(HttpStatusCode.BadRequest, "Invalid US postal code");
                    }
                    break;

                case "CA":
                    if (!model.ShipTo.PostalCode.IsValidCanadaPostalCode())
                    {
                        return CreateResponse(HttpStatusCode.BadRequest, "Invalid Canada postal code");
                    }
                    break;

                default:
                    return CreateResponse(HttpStatusCode.BadRequest, "Unsupported postal code");
            }

            return null;
        }

        /// <summary>
        /// This is being done to break the dependancy on the Partner enumeration and the TransformFactory 'stuff'.
        /// This pattern is not to be repeated.  TODO:  Look for a way to remove this.
        /// </summary>
        /// <param name="ratingRequestModel"></param>
        private void ApplyInboundTransformation(RatingRequestModel ratingRequestModel)
        {
            // HACK: Needed for BlackBox.  Do not repliacte this pattern
            if (User.Identity.Name == "Black Box")
            {
                foreach (var lineItem in ratingRequestModel.ItemsToShip)
                {
                    if (lineItem.ProductCode == string.Empty)
                    {
                        lineItem.ProductCode = "NEW-ITEM";
                    }
                }
            }
        }

        /// <summary>
        /// This is being done to break the dependancy on the Partner enumeration and the TransformFactory 'stuff'.
        /// This pattern is not to be repeated.  TODO:  Look for a way to remove this.
        /// </summary>
        private void ApplyOutboundTransformation(IRatingResponse freightResponse)
        {
            // HACK: Needed for BlackBox.  Do not repliacte this pattern
            if (User.Identity.Name == "Black Box")
            {
                freightResponse.Freight.ShippingMethods = freightResponse.Freight.ShippingMethods
                                                            .Where(x => x.IsCustomerAccount == false && x.Code != "WC");
            }
        }
    }
}