﻿using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.Recycling;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Recycling;
using Cdw.Partners.Utilities;
using Cdw.Services.Core;
using Common.Logging;
using Newtonsoft.Json;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Recycling endpoint provides access to recycling fee
    /// </summary>
    [RoutePrefix("recycling")]
    public class RecyclingController : PartnerBaseController
    {
        private readonly ILog _logger;
        private readonly IMappingEngine _mapper;
        private readonly IRecyclingDomainManager _recyclingDomainManager;

        /// <summary>
        /// Ctor
        /// </summary>
        public RecyclingController(ILog log, IMappingEngine mapper, IRecyclingDomainManager recyclingDomainManager, IPartnerDetails partnerDetails)
            : base(new HealthCheck("Recycling Service"), log, partnerDetails)
        {
            _logger = log;
            _mapper = mapper;
            _recyclingDomainManager = recyclingDomainManager;
        }

        /// <summary>
        /// Used to probe the health the the Recycling endpoint
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("healthcheck")]
        public HttpResponseMessage GetHeartbeat()
        {
            return Heartbeat().Result;
        }

        /// <summary>
        /// Gets recycling summary for the specified input
        /// </summary>
        /// <param name="recyclingFeeRequestModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(IRecyclingFeeSummaryModel))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(IRecyclingFeeSummaryModel))]
        [SwaggerResponse(HttpStatusCode.BadRequest, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetRecyclingFeeSummary([FromBody] RecyclingFeeRequestModel recyclingFeeRequestModel)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                recyclingFeeRequestModel.TrackingValues = trackingValues;
                var validationResult = Validate(recyclingFeeRequestModel);

                if (validationResult != null)
                {
                    return validationResult;
                }

                var recyclingFeeSummary = await _recyclingDomainManager.GetRecyclingFeeSummaryAsync(recyclingFeeRequestModel).ConfigureAwait(false);

                return CreateResponse(HttpStatusCode.OK, recyclingFeeSummary);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("GetRecyclingFeeSummary  Error: ServiceCallException", ex, trackingValues, recyclingFeeRequestModel);
                var error = new Error("Recycling fee summary could not be retrieved temporarily");
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetRecyclingFeeSummary Error: Exception", ex, trackingValues, JsonConvert.SerializeObject(recyclingFeeRequestModel));
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        /// <summary>
        /// Gets tax details for the specified input
        /// </summary>
        /// <param name="recyclingFeeRequestModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("details")]
        [ResponseType(typeof(IRecyclingFeeModel))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(IRecyclingFeeModel))]
        [SwaggerResponse(HttpStatusCode.BadRequest, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetRecyclingFees([FromBody] RecyclingFeeRequestModel recyclingFeeRequestModel)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                recyclingFeeRequestModel.TrackingValues = trackingValues;
                var validationResult = Validate(recyclingFeeRequestModel);
                if (validationResult != null)
                {
                    return validationResult;
                }

                var recyclingFees = await _recyclingDomainManager.GetRecyclingFeesAsync(recyclingFeeRequestModel).ConfigureAwait(false);

                return CreateResponse(HttpStatusCode.OK, recyclingFees);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("GetRecyclingFees Error: ServiceCallException", ex, trackingValues, recyclingFeeRequestModel);

                var error = new Error($"Recycling fee summary could not be retrieved with input '{JsonConvert.SerializeObject(recyclingFeeRequestModel)} temporarily");
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetRecyclingFees Error: Exception", ex, trackingValues, recyclingFeeRequestModel);

                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        private HttpResponseMessage ConstructHttpResponseMessageForUnknownError(string errorMsg)
        {
            const string errorMessage = "Unknown server error, please contact administrator";
            return CreateResponse(HttpStatusCode.InternalServerError, new[] { new Error((int)ErrorCode.General, errorMessage) });
        }

        private HttpResponseMessage Validate(RecyclingFeeRequestModel request)
        {
            // Validate request exists.
            if (request == null)
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Request body was empty or unparseable");
            }

            // Validate state/province code exists.
            if (string.IsNullOrWhiteSpace(request.State))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "State not found");
            }

            // Validate product codes exists.
            if (string.IsNullOrWhiteSpace(request.ProductCodes))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "ProductCodes code not found");
            }
            return null;
        }

        /// <summary>
        /// holds ErrorCode
        /// </summary>
        protected enum ErrorCode // we should move this to base class
        {
            General = 1100
        }
    }
}