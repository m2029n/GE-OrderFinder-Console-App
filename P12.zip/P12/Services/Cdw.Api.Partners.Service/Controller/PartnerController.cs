﻿using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
using Cdw.Api.Controllers;
using Cdw.Domain.Partners.Freight;
using Cdw.Domain.Partners.PartnerCart;
using Cdw.Domain.Partners.Product;
using Cdw.Domain.Partners.Recycling;
using Cdw.Domain.Partners.Tax;
using Cdw.Services.Core;
using Common.Logging;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Used to Check the API
    /// </summary>
    public class PartnerController : BaseApiController
    {
        /// <summary>
        /// PartnerAPI Health end point
        /// </summary>
        /// <param name="log"></param>
        /// <param name="taxReqestDomainManager"></param>
        /// <param name="freightDomainManager"></param>
        /// <param name="partnerCartRequestDomainManager"></param>
        /// <param name="productDomainManager"></param>
        /// <param name="recyclingDomainManager"></param>
        public PartnerController(ILog log,
            ITaxDomainManager taxReqestDomainManager,
            IFreightDomainManager freightDomainManager,
            IPartnerCartRequestDomainManager partnerCartRequestDomainManager,
            IProductDomainManager productDomainManager,
            IRecyclingDomainManager recyclingDomainManager)
            : base(
                () =>
                    new List<IHealthCheck>()
                    {
                        taxReqestDomainManager as IHealthCheck,
                        freightDomainManager as IHealthCheck,
                        partnerCartRequestDomainManager as IHealthCheck,
                        recyclingDomainManager as IHealthCheck
                    })
        {
        }

        /// <summary>
        /// Used to probe the health the the PartnersAPI
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("healthcheck")]
        public HttpResponseMessage GetHeartbeat()
        {
            return base.Heartbeat().Result;
        }
    }
}