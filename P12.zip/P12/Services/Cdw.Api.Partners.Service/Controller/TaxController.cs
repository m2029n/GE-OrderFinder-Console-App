﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.Tax;
using Cdw.Api.Partners.Service.Infrastructure.Extension;
using Cdw.Api.Partners.Service.Infrastructure.Helper;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Tax;
using Cdw.Partners.Utilities;
using Cdw.Services.Core;
using Common.Logging;
using Newtonsoft.Json;
using Swashbuckle.Swagger.Annotations;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Tax endpoint provides access to tax data
    /// </summary>
    [RoutePrefix("tax")]
    public class TaxController : PartnerBaseController
    {
        private readonly ILog _logger;
        private readonly IMappingEngine _mapper;
        private readonly ITaxDomainManager _taxRequestDomainManager;

        /// <summary>
        /// Ctor
        /// </summary>
        public TaxController(ILog log, IMappingEngine mapper, ITaxDomainManager taxReqestDomainManager, IGetIdentityService getIdentityService)
            : base(taxReqestDomainManager as IHealthCheck, log, getIdentityService)
        {
            _logger = log;
            _mapper = mapper;
            _taxRequestDomainManager = taxReqestDomainManager;
        }

        /// <summary>
        /// Used to probe the health the the Tax endpoint
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("healthcheck")]
        public HttpResponseMessage GetHeartbeat()
        {
            return base.Heartbeat().Result;
        }

        /// <summary>
        /// Gets tax summary for the specified input
        /// </summary>
        /// <param name="taxRequestModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(ITax))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(ITax))]
        [SwaggerResponse(HttpStatusCode.BadRequest, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetTaxSummary([FromBody] TaxRequestModel taxRequestModel)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                ApplyTransformation(taxRequestModel);

                _logger.Debug(" Step 1: Tax Summary Request Mapping", trackingValues);
                var itaxrequest = _mapper.Map<TaxRequest>(taxRequestModel);

                _logger.Debug(" Step 2: Tax Summary Request Validation", trackingValues);
                var validationResult = Validate(itaxrequest);

                if (validationResult != null)
                {
                    _logger.Debug(" Step 2.1: Tax Summary Validation Failed", trackingValues);
                    return validationResult;
                }

                _logger.Debug(" Step 3: Tax Summary call tax domain manager", trackingValues);
                itaxrequest.TrackingValues = trackingValues;

                var itax = await _taxRequestDomainManager.GetTaxLinesAsync(itaxrequest).ConfigureAwait(false);

                _logger.Debug(" Step 4: Tax Summary Return result", trackingValues);
                return CreateResponse(HttpStatusCode.OK, itax);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("GetTaxSummary Error: ServiceCallException", ex, trackingValues, taxRequestModel);

                var error = new Error("Tax Summary could not be retrieved temporarily");
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetTaxSummary Error: Exception", ex, trackingValues, taxRequestModel);
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        /// <summary>
        /// Gets tax details for the specified input
        /// </summary>
        /// <param name="taxRequestModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("details")]
        [ResponseType(typeof(ITax))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(ITax))]
        [SwaggerResponse(HttpStatusCode.BadRequest, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetTaxDetails([FromBody] TaxRequestModel taxRequestModel)
        {
            var trackingValues = Request.TrackingValues();

            try
            {
                ApplyTransformation(taxRequestModel);

                _logger.Debug(" Step 1: Tax Detail Request Mapping", trackingValues);
                var itaxrequest = _mapper.Map<TaxRequest>(taxRequestModel);

                _logger.Debug(" Step 2: Tax Detail Request Validation", trackingValues);
                var validationResult = Validate(itaxrequest);

                if (validationResult != null)
                {
                    _logger.Debug(" Step 2.1: Tax Detail Validation Failed", trackingValues);
                    return validationResult;
                }

                _logger.Debug(" Step 3: Tax Detail call tax domain manager", trackingValues);

                itaxrequest.TrackingValues = trackingValues;
                var itax = await _taxRequestDomainManager.GetTaxDetailsAsync(itaxrequest).ConfigureAwait(false);

                _logger.Debug(" Step 4: Tax Detail Return result", trackingValues);
                return CreateResponse(HttpStatusCode.OK, itax);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("GetTaxDetails Error: ServiceCallException", ex, trackingValues, taxRequestModel);
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { new Error("Tax Detail could not be retrieved temporarily") });
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetTaxDetails Error: Exception", ex, trackingValues, taxRequestModel);
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        private new HttpResponseMessage ConstructHttpResponseMessageForUnknownError(string errorMsg)
        {
            _logger.Fatal(errorMsg);
            ErrorModel[] model = null;

            try
            {
                model = JsonConvert.DeserializeObject<ErrorModel[]>(errorMsg);
            }
            catch
            {
            }
            return CreateResponse(HttpStatusCode.InternalServerError, model);
        }

        private HttpResponseMessage Validate(TaxRequest request)
        {
            // Validate request exists.
            if (request == null)
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Request body was empty or unparseable");
            }

            // Validate country code exists.
            if (string.IsNullOrWhiteSpace(request.Address?.IsoCountryCode))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Country code not found");
            }

            // Validate company id is supported and matches country code.
            string countryCodeOut = null;
            if (!Lookups.CdwCompanyIdCountryLookup.TryGetValue(request.Company, out countryCodeOut))
            {
                return CreateResponse(HttpStatusCode.BadRequest, "Unsupported company code");
            }

            var countryCode = request.Address.IsoCountryCode;

            if (countryCodeOut != countryCode)
            {
                return CreateResponse(HttpStatusCode.BadRequest, $"Company code {request.Company} is invalid for country code '{countryCode}'");
            }

            // Validate postal codes.
            switch (countryCode)
            {
                case "US":
                    if (!request.Address.PostalCode.IsValidUSPostalCode())
                    {
                        return CreateResponse(HttpStatusCode.BadRequest, "Invalid US postal code");
                    }
                    break;

                case "CA":
                    if (!request.Address.PostalCode.IsValidCanadaPostalCode())
                    {
                        return CreateResponse(HttpStatusCode.BadRequest, "Invalid Canada postal code");
                    }
                    break;

                default:
                    //  Given Lookups.CdwCompanyIdCountryLookup.TryGetValue done above this condition will never be true
                    return CreateResponse(HttpStatusCode.BadRequest, "Unsupported postal code");
            }

            return null;
        }

        /// <summary>
        /// This is being done to break the dependancy on the Partner enumeration and the TransformFactory 'stuff'.
        /// This patter is not to be repeated.  TODO:  Look for a way to remove this.
        /// </summary>
        /// <param name="taxRequestModel"></param>
        private void ApplyTransformation(TaxRequestModel taxRequestModel)
        {
            // HACK: Needed for BlackBox.  Do not repliacte this pattern
            if (User.Identity.Name == "Black Box")
            {
                foreach (var lineItem in taxRequestModel.LineItems)
                {
                    if (lineItem.ProductCode == string.Empty)
                    {
                        lineItem.ProductCode = "NEW-ITEM";
                    }
                }
            }
        }
    }
}