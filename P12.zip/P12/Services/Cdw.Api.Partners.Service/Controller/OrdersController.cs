﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Service.APIDocumentation;
using Cdw.Api.Partners.Service.Encryption;
using Cdw.Api.Partners.Service.Infrastructure.Helper;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Cdw.Partners.Validation.Orders.DefaultValidators;
using Cdw.Services.Core;
using Common.Logging;
using Swashbuckle.Swagger.Annotations;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Orders endpoint allows for the submission and retrieval of orders
    /// </summary>
    [RoutePrefix("Orders")]
    public class OrdersController : PartnerBaseController
    {
        private readonly ILog _logger;

        private readonly IOrderManager _orderManager;

        private readonly IEncryptionService _encryptionService;

        /// <summary>
        /// Ctor
        /// </summary>
        public OrdersController(ILog log, IOrderManager orderManager, IEncryptionService encryptionService, IPartnerDetails partnerDetails)
            : base(new HealthCheck("Order Service"), log, partnerDetails)
        {
            _logger = log;
            _orderManager = orderManager;
            _encryptionService = encryptionService;
        }

        /// <summary>
        /// Used to probe the health the the Orders endpoint
        /// </summary>
        ///<remarks>
        /// Only orders submitted by the authenticated partner can be retrieved.
        /// </remarks>
        [HttpGet]
        [Route("healthcheck")]
        [SwaggerOperation("Orders_Healthcheck", Tags = new[] { "Orders" })]
        [ResponseType(typeof(HealthcheckType))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(HealthcheckType))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        public async Task<HttpResponseMessage> GetHeartbeat()
        {
            return await Heartbeat().ConfigureAwait(false);
        }

        /// <summary>
        /// Gets an order by partner’s reference number.
        /// </summary>
        /// <returns>
        /// Details and status of an order.
        /// </returns>
        /// <param name="code"> A partner’s reference number ex: {1ABWJXY}.</param>
        ///<remarks>
        /// Only orders submitted by the authenticated partner can be retrieved.
        ///
        ///An alias is provided for looking up using a partner’s reference number instead of a CDW order number.
        /// </remarks>
        [HttpGet]
        [Route("{code:regex([A-Za-z0-9]{7})}", Name = "GetOrder")]
        [ResponseType(typeof(ResponseOrderModel))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(ResponseOrderModel))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Order Not Found")]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        [SwaggerOperationFilter(typeof(OrderErrorModelExamples))]
        [SwaggerOperation("GetOrder", Tags = new[] { "Orders" })]
        public async Task<HttpResponseMessage> GetOrder(string code)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                var response = await _orderManager.GetOrderAsync(code, trackingValues, User.Identity.Name).ConfigureAwait(false);
                if (response == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
                var res = Mapper.Map<ResponseOrderModel>(response);
                res.Company = response.Company;
                return CreateResponse(HttpStatusCode.OK, res);
            }
            catch (ServiceCallException ex)
            {
                var error = new ErrorModel("", $"Order with code '{code} could temporarily not be retrieved");
                _logger.Fatal("GetOrder Error: ServiceCallException", ex, trackingValues, error);
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                var err = new ErrorModel("", $"Order with input '{code}' could not be retrieved");

                _logger.Fatal("GetOrder Error: Exception", ex, trackingValues, err);
                return CreateResponse(HttpStatusCode.InternalServerError, new[] { err });
            }
        }

        /// <summary>
        /// Creates a new order returns the details and status of the created order.
        /// </summary>
        /// <returns>
        /// Details and status of an order.
        /// </returns>
        /// <param name="orderModel"> A partner’s order request.</param>
        ///<remarks>Only orders submitted by the authenticated partner can be created.</remarks>
        [HttpPost]
        [Route("")]
        [ResponseType(typeof(ResponseOrderModel))]
        [SwaggerOperationFilter(typeof(OrderErrorModelExamples))]
        [SwaggerResponseRemoveDefaults]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Created, Type = typeof(ResponseOrderModel))]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, null, typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, null, typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.BadRequest, null, typeof(ErrorModel))]
        [SwaggerOperation("CreateOrder", Tags = new[] { "Orders" })]
        public async Task<HttpResponseMessage> CreateOrder([FromBody] RequestOrderModel orderModel)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                //Step 1: Validate empty request model.
                if (orderModel == null)
                {
                    throw new ApplicationException("Request body was empty or unparseable");
                }

                //Step 2: Request tracking details.
                MapRequestTrackingDetails(orderModel);

                //Step 3: Decrypt the credit card.
                if (!(string.IsNullOrEmpty(orderModel.Billing?.Method?.EncryptedCreditCard)))
                {
                    orderModel.Billing.Method.CreditCard =
                        _encryptionService.DecryptEncryptedCreditCard(orderModel.Billing.Method.EncryptedCreditCard,
                            PartnersModule.EncryptionCertificateName);
                }

                //Step 4: Validate the request model, validation is specific for each partner.
                ValidateModel(orderModel);

                //Step 5: Log the occurence of valid TransactionId and empty ReferenceNumber in Billing.Method payload
                if (!string.IsNullOrEmpty(orderModel.Billing?.Method?.TransactionId) && (orderModel.Billing?.Method?.TransactionId.Length == 0))
                {
                    _logger.Debug($"Order with No CreditCard - Empty Billing.Method.ReferenceNumber sent with Billing.Method.TransactionId {orderModel.Billing?.Method?.TransactionId}", trackingValues);
                }

                //Step 6: If collection is null convert into empty collection. Like the TAX[],Freight[],etc
                VerifyCollectionsAreNotNull(orderModel);

                //Step 7: Custom transformation per partner.
                ApplyInboundTransformation(orderModel);

                //Step 8: Map model to the domain object.
                var orderrequest = Mapper.Map<RequestOrder>(orderModel);
                orderrequest.TrackingValues = trackingValues;
                orderrequest.ClientName = User.Identity.Name;
                //Step 9: Create order in domain manager.
                var response = await _orderManager.CreateOrderAsync(orderrequest).ConfigureAwait(false);

                //Step 10: Convert domain model to response order model
                var res = Mapper.Map<ResponseOrderModel>(response);

                //Step 11: send the response back
                return CreateResponse(HttpStatusCode.Created, res);
            }
            catch (OrderValidationException ex)
            {
                _logger.Error("Partner Order Validation Error", ex, trackingValues, ex.Failures);
                return CreateResponse(HttpStatusCode.BadRequest, ex.Failures.Select(f => new ErrorModel(f.Field, f.Message)));
            }
            catch (ApplicationException ex)
            {
                ClearEncryptedCreditCard(orderModel);
                _logger.Error("CreateOrder Error: ApplicationException", ex, trackingValues, orderModel);
                return CreateResponse(HttpStatusCode.BadRequest, new[] { new ErrorModel("External Dependency Error", ex.Message) });
            }
            catch (ServiceCallException ex)
            {
                ClearEncryptedCreditCard(orderModel);
                _logger.Fatal("CreateOrder Error: ServiceCallException", ex, trackingValues, orderModel);
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { new ErrorModel("External Dependency Error", "Order could temporarily not be created") });
            }
            catch (Exception ex)
            {
                ClearEncryptedCreditCard(orderModel);
                _logger.Fatal("CreateOrder Error: Exception", ex, trackingValues, orderModel);
                return CreateResponse(HttpStatusCode.InternalServerError, new[] { new ErrorModel("External Dependency Error", "Order could not be created") });
            }
        }

        private void ClearEncryptedCreditCard(RequestOrderModel orderModel)
        {
            try
            {
                if (orderModel != null)
                {
                    orderModel.Billing.Method.EncryptedCreditCard = "XXXX";
                }
            }
            catch
            {
                //left unhandled to supress errors
            }
        }

        /// <summary>
        /// Gets the order details for the given customer and purchase order number
        /// </summary>
        /// <returns>
        /// Details and status of an order.
        /// </returns>
        /// <param name="customerNumber"> A partner’s number.</param>
        /// <param name="poNumber"> A purchase order number.</param>
        ///<remarks>
        /// Only orders submitted by the authenticated partner can be retrieved.  This endpoint is limited to only Adobe
        /// </remarks>
        [HttpGet]
        [Route("Search/{customerNumber}/{*poNumber}")]
        [SwaggerOperation("SearchOrder", Tags = new[] { "Orders" })]
        [ResponseType(typeof(IOrderDetails))]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(IOrderDetails))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Order Not Found")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Must supply both Customer Number and PONumber")]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(Error))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        [ApiExplorerSettings(IgnoreApi = true)]
        public async Task<HttpResponseMessage> GetOrderDetailsAsync(string customerNumber, string poNumber)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                if (User.Identity.Name != "Adobe")
                {
                    throw new ApplicationException("Invalid Company Details");
                }

                if (string.IsNullOrEmpty(customerNumber) || string.IsNullOrEmpty(poNumber))
                {
                    return CreateResponse(HttpStatusCode.BadRequest, "Must supply both Customer Number and PONumber");
                }

                var response = await _orderManager.SearchOrderAsync(customerNumber, poNumber, trackingValues).ConfigureAwait(false);
                if (response == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return CreateResponse(HttpStatusCode.OK, response);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("PoNumber Error: ServiceCallException", ex, trackingValues, poNumber);
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { new Error($"Orders with input '{poNumber}' could temporarily not be retrieved") });
            }
            catch (Exception ex)
            {
                _logger.Fatal("PoNumber Error: Exception", ex, trackingValues, poNumber);
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        private void MapRequestTrackingDetails(RequestOrderModel orderModel)
        {
            var requestDetails = new RequestTracker(Request);
            orderModel.IpAddress = requestDetails.GetClientIp();
            orderModel.UserAgent = requestDetails.GetUseAgent();
            orderModel.Geolocation = requestDetails.GetClientAkamaiGeoLocation();
        }

        private void ValidateModel(RequestOrderModel orderModel)
        {
            var validObject = new DefaultValidator(orderModel);

            if (!validObject.IsValid)
            {
                throw new OrderValidationException(validObject.Failures);
            }
        }

        private void VerifyCollectionsAreNotNull(RequestOrderModel orderModel)
        {
            SetNullToEmpty.Collection(orderModel, o => o.Taxes, (o, t) => o.Taxes = t);
            SetNullToEmpty.Collection(orderModel, o => o.Discounts, (o, d) => o.Discounts = d);
            SetNullToEmpty.Collection(orderModel, o => o.LineItems, (o, l) => o.LineItems = l);
            SetNullToEmpty.Collection(orderModel, o => o.CustomProperties, (o, p) => o.CustomProperties = p);

            foreach (var lineItem in orderModel.LineItems)
            {
                SetNullToEmpty.Collection(lineItem, li => li.Discounts, (li, d) => li.Discounts = d);
                SetNullToEmpty.Collection(lineItem, li => li.CustomProperties, (li, cp) => li.CustomProperties = cp);
            }
        }

        /// <summary>
        /// This is being done to break the dependancy on the Partner enumeration and the TransformFactory 'stuff'.
        /// This pattern is not to be repeated.  TODO:  Look for a way to remove this.
        /// </summary>
        private void ApplyInboundTransformation(RequestOrderModel model)
        {
            // HACK: Needed for BlackBox.  Do not repliacte this pattern
            if (User.Identity.Name == "Black Box")
            {
                foreach (var lineItem in model.LineItems)
                {
                    if (lineItem.ProductCode == string.Empty
                       && lineItem.GetCustomPropertiesValue("ManufacturerPartNumber") != string.Empty
                       && lineItem.GetCustomPropertiesValue("ManufacturerItemDesc") != string.Empty
                       )
                    {
                        lineItem.ProductCode = "NEW-ITEM";
                    }
                }
            }
        }
    }
}