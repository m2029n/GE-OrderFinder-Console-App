﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using AutoMapper;
using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model.Cart;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.PartnerCart;
using Cdw.Partners.Utilities;
using Common.Logging;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Used to transfer Carts
    /// </summary>
    [RoutePrefix("transferredcarts")]
    public class PartnerCartController : PartnerBaseController
    {
        private readonly ILog _logger;

        private readonly IMappingEngine _mapper;

        private readonly IPartnerCartRequestDomainManager _cartDomainManager;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="log"></param>
        /// <param name="mapper"></param>
        /// <param name="cartDomainManager"></param>
        /// <param name="partnerDetails"></param>
        public PartnerCartController(
            ILog log,
            IMappingEngine mapper,
            IPartnerCartRequestDomainManager cartDomainManager, IPartnerDetails partnerDetails)
            : base(cartDomainManager, log, partnerDetails)
        {
            _logger = log;
            _mapper = mapper;
            _cartDomainManager = cartDomainManager;
        }

        /// <summary>
        /// Used to probe the health the the transferredcarts endpoint
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("healthcheck")]
        public HttpResponseMessage GetHeartbeat()
        {
            return base.Heartbeat().Result;
        }

        /// <summary>
        /// Used to create a transfer request
        /// </summary>
        /// <param name="cartModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        public async Task<HttpResponseMessage> CreateVendorCartRequest(
            [FromBody] PartnerCartRequestModel cartModel)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                cartModel.Source = GetCurrentUserName();
                cartModel.Created = DateTime.Now;

                var model = Mapper.Map<PartnerCartRequest>(cartModel);

                var taskResponse = await _cartDomainManager.CreateAsync(model).ConfigureAwait(false);

                var response = Mapper.Map<PartnerCartResponseModel>(taskResponse);

                return this.CreateResponse(HttpStatusCode.Created, response);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("Cart Error: ServiceCallException", ex, trackingValues, cartModel);
                var error =
                    new Error("Cart could not be created/retrieved temporarily");
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                _logger.Fatal("Cart Error: Exception", ex, trackingValues, cartModel);
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        private HttpResponseMessage ConstructHttpResponseMessageForUnknownError(string errorMsg)
        {
            const string errorMessage = "Unknown server error, please contact administrator";
            return CreateResponse(
                HttpStatusCode.InternalServerError, new[] { new Error(1100, errorMessage) });
        }
    }
}