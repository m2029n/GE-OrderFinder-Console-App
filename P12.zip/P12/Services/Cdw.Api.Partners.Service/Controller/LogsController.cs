﻿using Cdw.Api.Partners.Model.Logs;
using Cdw.Api.Partners.Service.APIDocumentation;
using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Services.Core;
using Common.Logging;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// End point used to get list of logs of requests
    /// </summary>
    [RoutePrefix("Logs")]
    public class LogsController : PartnerBaseController
    {
        private readonly ILog _logger;
        private readonly ILogRequestResponseManager _requestResponseManager;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="healthCheck"></param>
        /// <param name="logger"></param>
        /// <param name="requestResponseManager"></param>
        public LogsController(IHealthCheck healthCheck, ILog logger, ILogRequestResponseManager requestResponseManager) : base(healthCheck, logger)
        {
            _logger = logger;
            _requestResponseManager = requestResponseManager;
        }

        /// <summary>
        /// returns a list with limited number of records from the Logs
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="httpMethod"></param>
        /// <param name="requestPath"></param>
        /// <param name="httpStatusCode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("", Name = "GetLogs")]
        [ResponseType(typeof(List<RequestResponseLogLimitedResponseModel>))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(List<RequestResponseLogLimitedResponseModel>))]
        [SwaggerOperationFilter(typeof(OrderErrorModelExamples))]
        [SwaggerOperation("GetLogs", Tags = new[] { "Logs" })]
        public async Task<HttpResponseMessage> GetLogs(DateTime startDate, DateTime endDate, string  httpMethod, string requestPath="", int httpStatusCode = 0 )
        {
            try
            {
                var response = await _requestResponseManager.SearchLogsByClientNameAsync(User.Identity.Name, startDate, endDate, httpMethod, requestPath,httpStatusCode).ConfigureAwait(false);
                if (response == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
                return CreateResponse(HttpStatusCode.OK, response);
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetLogs failed", ex);
                return CreateResponse(HttpStatusCode.InternalServerError, "Unable to return logs");
            }
        }

        /// <summary>
        /// returns logs by id for authorized Partner
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{id}", Name = "GetLog")]
        [ResponseType(typeof(RequestResponseLogModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(RequestResponseLogModel))]
        [SwaggerOperationFilter(typeof(OrderErrorModelExamples))]
        [SwaggerOperation("GetLog", Tags = new[] { "Logs" })]
        public async Task<HttpResponseMessage> GetLog(int id)
        {
            try
            {
                var response = await _requestResponseManager.GetLogsByIdAsync(User.Identity.Name, id).ConfigureAwait(false);
                if (response == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
                return CreateResponse(HttpStatusCode.OK, response);
            }
            catch (Exception ex)
            {
                _logger.Fatal("GetLog failed", ex);
                return CreateResponse(HttpStatusCode.InternalServerError, "Unable to return log");
            }
        }
    }
}