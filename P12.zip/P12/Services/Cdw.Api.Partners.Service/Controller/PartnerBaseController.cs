﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using Cdw.Api.Controllers;
using Cdw.Api.Partners.Model;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Partners.Utilities;
using Cdw.Services.Core;
using Common.Logging;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Order endpoint allows for order lookup and processing
    /// </summary>
    public class PartnerBaseController : BaseApiController
    {
        private readonly IGetIdentityService _identityService;
        private readonly ILog _logger;
        private readonly IPartnerDetails _partnerDetails;

        /// <summary>
        /// default ctor
        /// </summary>
        /// <param name="healthCheck"></param>
        /// <param name="logger"></param>
        public PartnerBaseController(IHealthCheck healthCheck, ILog logger) : base(healthCheck)
        {
            _logger = logger;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="healthCheck"></param>
        /// <param name="logger"></param>
        /// <param name="partnerDetails"></param>
        public PartnerBaseController(IHealthCheck healthCheck, ILog logger, IPartnerDetails partnerDetails) : base(healthCheck)
        {
            _logger = logger;
            _partnerDetails = partnerDetails;
        }

        /// <summary>
        /// Constructor for new GetIdentity
        /// </summary>
        /// <param name="healthCheck"></param>
        /// <param name="logger"></param>
        /// <param name="identityService"></param>
        protected PartnerBaseController(IHealthCheck healthCheck, ILog logger, IGetIdentityService identityService) : base(healthCheck)
        {
            _logger = logger;
            _identityService = identityService;
        }

        /// <summary>
        /// Makes an Internal error status
        /// </summary>
        /// <param name="errorMsg"></param>
        /// <returns></returns>
        public HttpResponseMessage ConstructHttpResponseMessageForUnknownError(string errorMsg)
        {
            const string errorMessage = "Unknown server error, please contact administrator";
            _logger.Error(errorMsg);
            return CreateResponse(
                HttpStatusCode.InternalServerError, new[] { new ErrorModel(errorMessage) });
        }

        /// <summary>
        /// new method to get Identity of the caller Partners
        /// </summary>
        /// <returns></returns>
        public IIdentity GetPartnersIdentity()
        {
            var user = GetCurrentUserName();
            var partnerIdentity = _identityService.GetPartnersIdentity(user);
            return partnerIdentity;
        }

        /// <summary>
        /// Gets Partner Identity and sets Company Code
        /// </summary>
        /// <returns></returns>
        [Obsolete("GetIdentity is deprecated, please use GetPartnersIdentity instead.")]
        public IIdentity GetIdentity()
        {
            var partner = GetPartner();
            var partnerIdentity = partner != null ? _partnerDetails.GetPartnerSourceCode(partner.Value) : null;
            if (partnerIdentity != null)
            {
                partnerIdentity.CompanyCode = GetPartnerCdwCompanyCode();
            }
            return partnerIdentity;
        }

        private Partner? GetPartner()
        {
            var user = GetCurrentUserName();
            var enums = EnumHelper.GetValues<Partner>();
            foreach (var @enum in enums.Where(@enum => string.Equals(@enum.Description(), user, StringComparison.CurrentCultureIgnoreCase)))
            {
                return @enum;
            }
            return null;
        }

        private int GetPartnerCdwCompanyCode()
        {
            var user = GetCurrentUserName();
            var enums = EnumHelper.GetValues<Partner>();

            foreach (var @enum in enums.Where(@enum => string.Equals(@enum.Description(), user,
                StringComparison.CurrentCultureIgnoreCase)))
            {
                switch (@enum)
                {
                    case Partner.XeroxDirect:
                    case Partner.BlackBox:
                        return (int)CdwCompany.CDW;

                    case Partner.XeroxCanada:
                        return (int)CdwCompany.CDWCa;
                }
            }
            return 0;
        }
    }
}