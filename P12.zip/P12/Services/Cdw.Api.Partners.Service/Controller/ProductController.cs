﻿using Cdw.Api.Exceptions;
using Cdw.Api.Partners.Model;
using Cdw.Api.Partners.Model.ProductCatalog;
using Cdw.Api.Partners.Service.APIDocumentation;
using Cdw.Api.Responses.Content;
using Cdw.Common.Http;
using Cdw.Domain.Partners;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Domain.Partners.Product;
using Cdw.Partners.Utilities;
using Cdw.Services.Core;
using Common.Logging;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace Cdw.Api.Partners.Service.Controller
{
    /// <summary>
    /// Products endpoint allows for products lookup
    /// </summary>
    [RoutePrefix("products")]
    public class ProductController : PartnerBaseController
    {
        private readonly ILog _logger;

        private readonly IProductDomainManager _productDomainManager;

        private readonly IProductsCatalogService _productsCatalogService;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="log"></param>
        /// <param name="productDomainManager"></param>
        /// <param name="productsCatalogService"></param>
        /// <param name="identityService"></param>
        public ProductController(
            ILog log,
            IProductDomainManager productDomainManager, IProductsCatalogService productsCatalogService, IGetIdentityService identityService)
            : base(new HealthCheck("Product Service"), log, identityService)
        {
            _logger = log;
            _productDomainManager = productDomainManager;
            _productsCatalogService = productsCatalogService;
        }

        /// <summary>
        /// Used to probe the health the the Pruducts endpoint
        /// </summary>
        ///
        [HttpGet]
        [ResponseType(typeof(HealthcheckType))]
        [SwaggerOperationFilter(typeof(HealthCheckExamples))]
        [Route("healthcheck")]
        [SwaggerOperation(Tags = new[] { "Products" })]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK)]
        public HttpResponseMessage GetHeartbeat()
        {
            return Heartbeat().Result;
        }

        /// <summary>
        /// Return’s the details of a product.
        /// </summary>
        /// <param name="code"> The CDW product code that identifies a product.</param>
        [HttpGet]
        [Route("{code:regex([A-Za-z0-9]{6,15})}")]
        [ResponseType(typeof(IProduct))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(IProduct))]
        [SwaggerOperation("GetProduct", Tags = new[] { "Products" })]
        public async Task<HttpResponseMessage> GetProduct(string code)
        {
            var trackingValues = Request.TrackingValues();

            try
            {
                var request = new ProductRequest
                {
                    ProductCodes = code.Split(',').ToList(),
                    ClientName = User.Identity.Name,
                    TrackingValues = trackingValues
                };
                var iProduct = await _productDomainManager.GetProductAsync(request).ConfigureAwait(false);
                return CreateResponse(HttpStatusCode.OK, iProduct);
            }
            catch (ServiceCallException ex)
            {
                _logger.Fatal("Product Error: ServiceCallException", ex, trackingValues, code);
                var error = new Error($"Product with input '{code}' could temporarily not be retrieved");
                return CreateResponse(HttpStatusCode.ServiceUnavailable, new[] { error });
            }
            catch (Exception ex)
            {
                _logger.Fatal("Product Error: Exception", ex, trackingValues, code);
                return ConstructHttpResponseMessageForUnknownError(ex.Message);
            }
        }

        /// <summary>
        /// Used to Get Partners' Products in a paged catalog
        /// </summary>
        /// <returns>List of Paged Products</returns>
        /// <param name="limit">Used for paged results</param>
        /// <param name="offset">Used for paged results to skip previously loaded records</param>
        [Route("", Name = "Get Paged result")]
        [ResponseType(typeof(ResponseProductCatalogModel))]
        [SwaggerResponse(HttpStatusCode.Unauthorized, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(ResponseProductCatalogModel))]
        [SwaggerResponse(HttpStatusCode.NotFound, "Products Not Found")]
        [SwaggerResponse(HttpStatusCode.ServiceUnavailable, Type = typeof(ErrorModel))]
        [SwaggerResponse(HttpStatusCode.InternalServerError, Type = typeof(ErrorModel))]
        [SwaggerOperation("GetProducts", Tags = new[] { "Products" })]
        public async Task<HttpResponseMessage> Get(int limit = 5000, int offset = 0)
        {
            var trackingValues = Request.TrackingValues();
            try
            {
                var partner = GetPartnersIdentity();
                _logger.Info($"GetPagedProductCatalog called with:limit={limit}/offset={offset}", trackingValues, partner);

                var products = await _productsCatalogService.GetAsync(partner as Identity, limit, offset).ConfigureAwait(false);
                products.Limit = limit;
                products.Offset = offset;

                return CreateResponse(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                var err = new ErrorModel("", "GetProductCatalog could not be retrieved");

                _logger.Fatal("GetProductCatalog Error: Exception", ex, trackingValues, err);
                return CreateResponse(HttpStatusCode.InternalServerError, new[] { err });
            }
        }
    }
}