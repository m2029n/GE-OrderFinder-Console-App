﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Api.Partners.Service.Encryption
{
    /// <summary>
    /// defines IEncryptionService
    /// </summary>
    public interface IEncryptionService
    {
        /// <summary>
        /// defines DecryptEncryptedCreditCard
        /// </summary>
        /// <param name="encryptedCreditCard"></param>
        /// <param name="certificateName"></param>
        /// <returns></returns>
        CreditCardModel DecryptEncryptedCreditCard(string encryptedCreditCard, string certificateName);
    }
}