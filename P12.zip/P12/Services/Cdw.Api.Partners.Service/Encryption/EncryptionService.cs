﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Orders;
using Cdw.Partners.Validation;
using Newtonsoft.Json;

namespace Cdw.Api.Partners.Service.Encryption
{
    internal class EncryptionService : IEncryptionService
    {
        private X509Certificate2 _cerificate;

        public CreditCardModel DecryptEncryptedCreditCard(string encryptedCreditCard, string certificateName)
        {
            _cerificate = GetValidCertificate(certificateName);
            CreditCardModel creditCardModel;

            try
            {
                var decryptedCreditCardJson = Decrypt(Convert.FromBase64String(encryptedCreditCard));
                creditCardModel = JsonConvert.DeserializeObject<CreditCardModel>(decryptedCreditCardJson);
            }
            catch (Exception)
            {
                throw new OrderValidationException(new List<IOrderValidationFailure>()
                {
                    new FailedRequestValidationResult("EncryptedCreditCard",
                        "EncryptedCreditCard could not be decrypted")
                });
            }
            return creditCardModel;
        }

        private X509Certificate2 GetValidCertificate(string certificateName)
        {
            var store = new X509Store(StoreLocation.LocalMachine);

            store.Open(OpenFlags.ReadOnly);

            var certCollection = store.Certificates;

            var signingCert = certCollection.Find(
                X509FindType.FindBySubjectDistinguishedName,
                certificateName,
                false);

            if (signingCert.Count == 0)
            {
                throw new Exception($"Certificate Not found in StoreLocation.LocalMachine: Cert Name {certificateName}");
            }

            return signingCert[0];
        }

        private string Decrypt(byte[] cipher)
        {
            using (var memoryStream = new MemoryStream(cipher))
            {
                var keyLengthBytes = new byte[4];
                var initializationVectorLengthBytes = new byte[4];

                memoryStream.Seek(0, SeekOrigin.Begin);
                memoryStream.Read(keyLengthBytes, 0, 4);
                memoryStream.Read(initializationVectorLengthBytes, 0, 4);

                var keyLength = BitConverter.ToInt32(keyLengthBytes, 0);

                var initializationVectorLength = BitConverter.ToInt32(initializationVectorLengthBytes, 0);

                var encryptedAesKeyBytes = new byte[keyLength];
                var initializationVectorBytes = new byte[initializationVectorLength];

                memoryStream.Read(encryptedAesKeyBytes, 0, keyLength);

                memoryStream.Read(initializationVectorBytes, 0, initializationVectorLength);

                var privateKey = (RSACryptoServiceProvider)_cerificate.PrivateKey;
                var aesKeyDecrypted = privateKey.Decrypt(encryptedAesKeyBytes, false);

                byte[] plainTextBytes;

                using (var aes = new AesCryptoServiceProvider())
                {
                    aes.Key = aesKeyDecrypted;
                    aes.IV = initializationVectorBytes;

                    using (var transform = aes.CreateDecryptor())
                    {
                        using (var outputStream = new MemoryStream())
                        {
                            using (var cryptoStream = new CryptoStream(outputStream, transform, CryptoStreamMode.Write))
                            {
                                int count;
                                var readBytes = new byte[1024];

                                do
                                {
                                    count = memoryStream.Read(readBytes, 0, 1024);
                                    cryptoStream.Write(readBytes, 0, count);
                                } while (count > 0);

                                cryptoStream.FlushFinalBlock();
                            }

                            plainTextBytes = outputStream.ToArray();
                            return Encoding.UTF8.GetString(plainTextBytes);
                        }
                    }
                }
            }
        }
    }
}