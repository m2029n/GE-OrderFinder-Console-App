USE [GlobalDB]
GO

/*********************************************************************************************
  Change history :                                                                             
  Development        Changers        Project #                          Description of Change
  Date                                    name                              INC #
  =============================================================================================
  11/24/2017        Shankar R             Partners API                     Insertion of 
                                                                           - Alert parameters for
                                                                           Partner API v2.3.
**********************************************************************************************/
/*********************************************************************************************
  Tables -  [dbo].[Alert_Settings_APIs],[dbo].[Alert_Settings_Logging_ApplicationLogs]

  Description: Insertion of - Alert parameters for  Partner API v2.3.
**********************************************************************************************/


IF NOT EXISTS(SELECT [APIGuid] FROM [dbo].[Alert_Settings_APIs] WHERE [APIGuid]='041d881b-1748-4ad0-8f81-98d441338462')
BEGIN
	INSERT INTO [dbo].[Alert_Settings_APIs] VALUES ('CDW Partner API v2.3','041d881b-1748-4ad0-8f81-98d441338462')
END
GO



IF NOT EXISTS (SELECT [APIGuid] FROM [dbo].[Alert_Settings_Logging_ApplicationLogs] WHERE [APIGuid]='041d881b-1748-4ad0-8f81-98d441338462')
BEGIN
	INSERT INTO [dbo].[Alert_Settings_Logging_ApplicationLogs]
	VALUES('CDW Partner API v2.3','041d881b-1748-4ad0-8f81-98d441338462',10,1,1,null,'tibiior@cdw.com,andrcoe@cdw.com,scottob@cdw.com,ganeesw@cdw.com,shanram@cdw.com,prasmod@cdw.com,sokhsun@cdw.com,jyotmac@cdw.com,katesky@cdw.com,stepmcd@cdw.com',getdate(),getdate(),'Partner API v2.3 alert settings')
END
GO

