USE [WebDB]
GO
/******************************************************************************
Table: [API_Partners_RequestResponseLogs]
Description: Stores the requests and responses for each partner call to API
		
Change history:
Date		Changer			Project			Change
===============================================================================
03/06/2017  Shankar R	    Partners API	Removed Drop and recreation of tables per
                                            Architecture Team input.
02/12/2017  Kate SKy	                    Added a new column [InsertDateUtc]
01/1/2018	Kate Sky		PSCC - Message Logging		New

******************************************************************************/

IF NOT  EXISTS 
(
    SELECT name 
    FROM sys.objects WHERE
        OBJECT_ID = OBJECT_ID(N'[dbo].[API_Partners_RequestResponseLogs]')
        AND Type IN (N'U')
)

BEGIN

CREATE TABLE [dbo].[API_Partners_RequestResponseLogs](
	[ID] [int] IDENTITY(1,1) NOT NULL,  
	[PartnerName][varchar](1000) NULL,
	[RequestPath][varchar](200) NOT NULL,
	[RequestUri][varchar](200) NOT NULL,
	[RequestBody][varchar](max) NULL,
	[RequestHeaders][varchar](1000) NULL,
	[RequestIpFrom][varchar](100) NULL,
	[RequestMethod][varchar](50) NOT NULL,
	[ResponseHeaders][varchar](1000) NULL,
	[ResponseBody][varchar](max) NULL,
	[ResponseProcessingTime] bigint NOT NULL,
	[RequestStartDateUTC] [datetime] NOT NULL,
	[ResponseResultCode] int NOT NULL,
	[InsertDateUtc] [datetime] NOT NULL,
 CONSTRAINT [PK_API_Partners_RequestResponseLogsID] PRIMARY KEY CLUSTERED ([ID] ASC)
 WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [PRIMARY]
) ON [PRIMARY]

END

GO

SET ANSI_PADDING OFF
GO
 


