USE [WebDB]
GO
/******************************************************************************
Table: [API_Orders_PaymentMethods]
Description: Stores the mapping between partner and allowed payment methods.
		
Change history:
Date		Changer			Project			Change
===============================================================================
03/06/2017  Shankar R	    Partners API	Removed Drop and recreation of tables per
                                            Architecture Team input.
09/01/2017	Shankar R		Partners API	New

******************************************************************************/

IF  NOT EXISTS 
(
    SELECT name 
    FROM sys.objects WHERE
        OBJECT_ID = OBJECT_ID(N'[dbo].[API_Orders_PaymentMethods]')
        AND Type IN (N'U')
)

BEGIN

CREATE TABLE [dbo].[API_Orders_PaymentMethods](
	[PaymentMethodID] [int] IDENTITY(1,1) NOT NULL,
	[OAuth2ClientID] [int] NOT NULL,
	[PaymentMethod] [varchar](15) NOT NULL,
	[PaymentCode] [varchar](15) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[Source] [varchar](5) NOT NULL,
 CONSTRAINT [PK_API_Orders_PaymentMethods_PaymentMethodID] PRIMARY KEY CLUSTERED 
(
	[PaymentMethodID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [PRIMARY]
) ON [PRIMARY]

END
GO

SET ANSI_PADDING OFF
GO

IF  NOT EXISTS (Select [PaymentMethod] FROM [dbo].[API_Orders_PaymentMethods] WHERE 
											[PaymentMethod] = 'NET30' AND [Source]='BBX')
    BEGIN
            INSERT INTO [dbo].[API_Orders_PaymentMethods]
			([OAuth2ClientID]
			,[PaymentMethod]
			,[PaymentCode]
			,[DateCreated]
			,[Source])
			VALUES
			(20
			,'NET30'
			,'010'
			,GETDATE()
			,'BBX')

    END
GO   

