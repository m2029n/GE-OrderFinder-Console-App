USE [WebDB]
GO
/******************************************************************************
Table: [API_Orders_PaymentTokens]
Description: Stores the mapping between partner provided transactio id, internal credi card token & the reference number returned to partner.
		
Change history:
Date		Changer			Project			Change
===============================================================================
03/06/2017  Shankar R	    Partners API	Removed Drop and recreation of tables per
                                            Architecture Team input.
09/15/2017	Shankar R		PRJ55866		New.

******************************************************************************/

IF NOT EXISTS 
(
    SELECT name 
    FROM sys.objects WHERE
        OBJECT_ID = OBJECT_ID(N'[dbo].[API_Orders_PaymentTokens]')
        AND Type IN (N'U')
)

BEGIN

CREATE TABLE [dbo].[API_Orders_PaymentTokens](
	[PaymentAuthID] [int] IDENTITY(1,1) NOT NULL,
	[TransactionID] [char](40) NOT NULL,
	[CreditCardToken] [char](40) NOT NULL,
	[ReferenceNumber] [char](40) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[IpAddress][varchar](32),
	[GeoLocation][varchar](1000),
	[UserAgent][varchar](2000)
 CONSTRAINT [PK_API_Orders_PaymentTokens_PaymentAuthID] PRIMARY KEY CLUSTERED ([PaymentAuthID] ASC)
 WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [PRIMARY]
) ON [PRIMARY]

END

GO

SET ANSI_PADDING OFF
GO
 


