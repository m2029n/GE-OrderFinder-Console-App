USE [WebDB]
GO

/******************************************************************************
 Procedure: API_Partners_GetAllowedPaymentMethods
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  09/14/2017 Shankar R	    Partners API	New	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[API_Partners_GetAllowedPaymentMethods]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[API_Partners_GetAllowedPaymentMethods]
GO

CREATE PROCEDURE [dbo].[API_Partners_GetAllowedPaymentMethods] (

	@source varchar(15),

	@paymentmethod varchar(15) = null

) AS

BEGIN

	SET NOCOUNT ON  
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  

	SELECT 
		[PM].[PaymentMethodId],
		[PM].[PaymentMethod],
		[PM].[PaymentCode],
		[PM].[Source]
	FROM 
		[dbo].[API_Orders_PaymentMethods] AS PM WITH(nolock) 
	WHERE
		[PM].[Source] = @source
	AND
		[PM].[PaymentMethod] = ISNULL(@paymentmethod, PM.PaymentMethod)

	SET NOCOUNT OFF  
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED  


END
GO


GRANT EXECUTE
ON OBJECT::[dbo].[API_Partners_GetAllowedPaymentMethods]
TO [Webaccess]
AS [dbo]
GO 
