USE [WebDB]
GO

/******************************************************************************
 Procedure: API_Orders_GetAuthCreditCardToken
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  10/14/2017 Shankar R	    PRJ55866	New	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[API_Orders_GetAuthCreditCardToken]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[API_Orders_GetAuthCreditCardToken]
GO

CREATE PROCEDURE [dbo].[API_Orders_GetAuthCreditCardToken] (

	@transactionid char(40),

	@referencenumber char(40)

) AS

BEGIN

	SET NOCOUNT ON  
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  

	SELECT 
		PT.CreditCardToken
	FROM 
		[dbo].[API_Orders_PaymentTokens] AS PT WITH(nolock) 
	WHERE
		PT.TransactionID = @transactionid
	and
		PT.ReferenceNumber = @referencenumber


	SET NOCOUNT OFF  
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED  

END
GO

GRANT EXECUTE
ON OBJECT::[dbo].[API_Orders_GetAuthCreditCardToken]
TO [Webaccess]
AS [dbo]
GO 
