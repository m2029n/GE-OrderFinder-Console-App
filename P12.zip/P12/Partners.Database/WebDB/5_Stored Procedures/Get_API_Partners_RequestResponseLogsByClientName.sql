USE [WebDB]
GO

/******************************************************************************
 Procedure: Get_API_Partners_RequestResponseLogsByClientName
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  02/02/2018 Kate Sky 	   Logs Get - Message Logging Get -  New	
  02/12/2018 Kate Sky 	   Added a GO to grant permissions	
  02/20/2018 Kate Sky      Made @resultCode optional
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[Get_API_Partners_RequestResponseLogsByClientName]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Get_API_Partners_RequestResponseLogsByClientName]
GO
CREATE PROCEDURE [dbo].[Get_API_Partners_RequestResponseLogsByClientName]
(
	@PartnerName varchar(1000),
	@startDate datetime,
	@endDate datetime, 
	@messageType varchar(50), 
	@requestPath varchar(200) = '',	
	@resultCode int = 0
)

AS
BEGIN
    SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    	 		
		SELECT [ID]
		,[PartnerName]
		,[RequestPath]
		,[RequestUri]
		,[RequestBody]
		,[RequestHeaders]
		,[RequestIpFrom]
		,[RequestMethod]
		,[ResponseHeaders]
		,[ResponseBody]
		,[ResponseProcessingTime]
		,[RequestStartDateUTC]
		,[InsertDateUtc]
		,[ResponseResultCode] FROM [dbo].[API_Partners_RequestResponseLogs]
		WHERE PartnerName = @PartnerName
		AND RequestMethod = @messageType
		AND ( ResponseResultCode = @resultCode OR @resultCode = 0 )
		AND (RequestPath = @requestPath or @requestPath ='')
		AND RequestStartDateUtc Between  @startDate AND @endDate
 END 
 GO

GRANT EXECUTE
ON OBJECT::[dbo].[Get_API_Partners_RequestResponseLogsByClientName]
TO [Webaccess]
AS [dbo]
GO 
