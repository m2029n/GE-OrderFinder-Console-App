﻿USE [WebDB]
GO

/******************************************************************************
 Procedure: API_Orders_GetAS400UploadStatus
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  03/01/2018 Shankar R	    PRJ55866	New.
										Returns 1 if order is not found in [orderupload_status]
										& sets @uploadstatus to 1.
									    Checks if order exists in [orderupload_status] and status is
										[C]& sets @uploadstatus to 1 if order is found ; 0 if not found.
										For usage in Partner API v2.3 onwards.
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[API_Orders_GetAS400UploadStatus]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[API_Orders_GetAS400UploadStatus]
GO

CREATE PROCEDURE [dbo].[API_Orders_GetAS400UploadStatus]

(

@OrderCode VARCHAR(7),

@uploadstatus INT OUTPUT

)

AS

BEGIN
      SET NOCOUNT ON
	  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	  DECLARE @ErrorCode TINYINT, @Error INT, @Rowcount INT

      IF NOT EXISTS (SELECT 1 FROM [dbo].[orderupload_status] (NOLOCK) WHERE [ordercode] = @ordercode)
		  BEGIN
	  		SELECT @uploadstatus = 1 -- explicitly set upload status to 1 despite/when order not found
			RETURN 1
		  END
	  

      IF EXISTS(SELECT 1 FROM [dbo].[orderupload_status] (NOLOCK) WHERE [ordercode] = @ordercode and [status] = 'C') 
		  BEGIN
	  		SELECT @uploadstatus = 1 ---- explicitly set upload status to 1 when order is found AND status is 'C'
		  END
	  ELSE
		  BEGIN
			SELECT @uploadstatus = 0
		  END

	-- Save Error State, must be selected at the same time

      SELECT @Error = @@ERROR, @Rowcount = @@ROWCOUNT
	-- Error select
      IF @Error <> 0
	    BEGIN
		    SET @ErrorCode = 1
			GOTO on_error
		END

      -- No select

      IF @Rowcount = 0
	  BEGIN
	    SET @ErrorCode = 2
		RAISERROR('No rows matched check Name!', 1, @ErrorCode)
		GOTO on_error
      END
	  
	  SET NOCOUNT OFF
	  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	  RETURN(0)

      on_error:
	  SET NOCOUNT OFF
	  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	  RETURN(@ErrorCode)

END
GO

GRANT EXECUTE
ON OBJECT::[dbo].[API_Orders_GetAS400UploadStatus]
TO [Webaccess]
AS [dbo]
GO 
