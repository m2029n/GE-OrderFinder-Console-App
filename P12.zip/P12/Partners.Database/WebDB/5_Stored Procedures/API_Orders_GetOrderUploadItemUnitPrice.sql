﻿USE [WebDB]
GO

/******************************************************************************
 Procedure: API_Orders_GetOrderUploadItemUnitPrice
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  03/03/2018 Jyothsna M	    PartnerAPI	New.
										Returns Unit Price for given order code
										and line item from [OrderUpload_OrderItems]
										table.
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[API_Orders_GetOrderUploadItemUnitPrice]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[API_Orders_GetOrderUploadItemUnitPrice]
GO

CREATE PROCEDURE [dbo].[API_Orders_GetOrderUploadItemUnitPrice]

(

@ProductCode VARCHAR(15),

@OrderCode VARCHAR(7),

@UnitPrice MONEY OUTPUT

)

AS

BEGIN
      SET NOCOUNT ON
	  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	  DECLARE @ErrorCode TINYINT, @Error INT, @Rowcount INT

     
	 SELECT @UnitPrice = UnitPrice 
	 FROM [dbo].[OrderUpload_OrderItems]
	 WHERE OrderCode = @OrderCode
	 AND ProductCode = @ProductCode
     

	-- Save Error State, must be selected at the same time

      SELECT @Error = @@ERROR, @Rowcount = @@ROWCOUNT
	-- Error select
      IF @Error <> 0
	    BEGIN
		    SET @ErrorCode = 1
			GOTO on_error
		END

      -- No select

      IF @Rowcount = 0
	  BEGIN
	    SET @ErrorCode = 2
		RAISERROR('No rows matched check Name!', 1, @ErrorCode)
		GOTO on_error
      END
	  
	  SET NOCOUNT OFF
	  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	  RETURN(0)

      on_error:
	  SET NOCOUNT OFF
	  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	  RETURN(@ErrorCode)

END
GO

GRANT EXECUTE
ON OBJECT::[dbo].[API_Orders_GetOrderUploadItemUnitPrice]
TO [Webaccess]
AS [dbo]
GO 
