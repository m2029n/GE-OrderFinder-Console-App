﻿ USE [WebDB]
GO
/******************************************************************************
 Procedure: [API_Partner_GetXeroxFriendlyName]
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
 03/16/2018 KAte Sky undo drop of the sp untill v1.5 retires
 02/19/2018Kate Sky   [API_Partner_GetXeroxFriendlyName] is dropped bc is no longer needed	USER STORY 150880
******************************************************************************/

--IF  EXISTS (SELECT name 
--				FROM sys.objects 
--				WHERE object_id = OBJECT_ID(N'[dbo].[API_Partner_GetXeroxFriendlyName]') 
--					AND type IN (N'P', N'PC'))
--	DROP PROCEDURE [dbo].[API_Partner_GetXeroxFriendlyName]
--GO
