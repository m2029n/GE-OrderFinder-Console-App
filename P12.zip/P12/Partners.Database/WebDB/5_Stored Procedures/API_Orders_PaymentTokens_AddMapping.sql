USE [WebDB]
GO
/******************************************************************************
 Procedure: API_Orders_PaymentTokens_AddMapping
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  10/04/2017 Shankar R	    PRJ55866	New	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[API_Orders_PaymentTokens_AddMapping]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[API_Orders_PaymentTokens_AddMapping]
GO

CREATE PROCEDURE [dbo].[API_Orders_PaymentTokens_AddMapping]

(

	@TransactionID CHAR(40),
	@CreditCardToken CHAR(40),
	@IpAddress VARCHAR(32) = NULL,
	@GeoLocation VARCHAR(1000) = NULL,
	@UserAgent VARCHAR(2000) = NULL,
	@ReferenceNumber CHAR(40) OUTPUT

)

AS

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;



	DECLARE @ErrorCode TINYINT

	SET @ReferenceNumber = CONVERT(CHAR(40), NEWID())

	INSERT INTO [dbo].[API_Orders_PaymentTokens]	
		(
			[TransactionID],
			[CreditCardToken],
			[ReferenceNumber],
			[DateCreated],
			[IpAddress],
			[GeoLocation],
			[UserAgent]

        )
		VALUES
		(
			@TransactionID,
			@CreditCardToken,
			@ReferenceNumber,
			GETDATE(),
			@IpAddress,
			@GeoLocation,
			@UserAgent
		)

	-- Error insert

	IF @@ERROR <> 0

	BEGIN
		SET @ErrorCode = 1
		GOTO on_error
	END

	SET NOCOUNT OFF
	RETURN(0)

 on_error:

	SET NOCOUNT OFF
	RETURN(@ErrorCode)

GO

GRANT EXECUTE
ON OBJECT::[dbo].[API_Orders_PaymentTokens_AddMapping]
TO [Webaccess]
AS [dbo]
GO 
