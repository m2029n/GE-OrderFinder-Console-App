USE [WebDB]
GO

/******************************************************************************
 Procedure: Security_OAuth2_GetClientInfoById
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  01/02/2018 Kate Sky R	    Partners API	New	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[Security_OAuth2_GetClientInfoById]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Security_OAuth2_GetClientInfoById]
GO
CREATE PROCEDURE [dbo].[Security_OAuth2_GetClientInfoById]
(
	@ClientId int
)

AS
BEGIN
    SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    
	SELECT 
		[SA].ClientId,
		[SA].ClientKey,
		[SA].ClientName,
		[SA].ClientSecret,	
		RTRIM(ISNULL(osc.SourceCode,'')) AS SourceCode,
		RTRIM(ISNULL(sc.FreightRaterSpecialCode,'')) AS FreightRaterSpecialCode
	FROM [dbo].[Security_OAuth2Clients] AS SA WITH(nolock) 
	LEFT JOIN [API_Orders_OrderUploadSourceCodes] OSC WITH(nolock) ON [OSC].[OAuth2ClientID] = [SA].ClientId
	LEFT JOIN [API_Orders_FreightRaterSpecialCodeByOrderSource] SC WITH(nolock) ON [SC].[OAuth2ClientID] = [SA].ClientId
	WHERE [SA].ClientId = @ClientId

	SET NOCOUNT OFF  
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED  
END
GO

GRANT EXECUTE
ON OBJECT::[dbo].[Security_OAuth2_GetClientInfoById]
TO [Webaccess]
AS [dbo]
GO 
