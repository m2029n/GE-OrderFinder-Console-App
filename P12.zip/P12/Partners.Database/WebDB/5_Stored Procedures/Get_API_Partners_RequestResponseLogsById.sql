USE [WebDB]
GO

/******************************************************************************
 Procedure: Get_API_Partners_RequestResponseLogsById
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  02/06/2018 Kate Sky 	   Logs Get by Id - Message Logging Get -  New	
  02/12/2018 Kate Sky 	   Added a GO to grant permissions	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[Get_API_Partners_RequestResponseLogsById]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Get_API_Partners_RequestResponseLogsById]
GO
CREATE PROCEDURE [dbo].[Get_API_Partners_RequestResponseLogsById]
(
	@PartnerName varchar(1000),
	@id int
)

AS
BEGIN
    SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    	 		
		SELECT [ID]
		,[PartnerName]
		,[RequestPath]
		,[RequestUri]
		,[RequestBody]
		,[RequestHeaders]
		,[RequestIpFrom]
		,[RequestMethod]
		,[ResponseHeaders]
		,[ResponseBody]
		,[ResponseProcessingTime]
		,[RequestStartDateUTC]
		,[InsertDateUtc]
		,[ResponseResultCode]  FROM [dbo].[API_Partners_RequestResponseLogs]
		WHERE Id = @id AND
		PartnerName = @PartnerName
 END 
GO

GRANT EXECUTE
ON OBJECT::[dbo].[Get_API_Partners_RequestResponseLogsById]
TO [Webaccess]
AS [dbo]
GO 
