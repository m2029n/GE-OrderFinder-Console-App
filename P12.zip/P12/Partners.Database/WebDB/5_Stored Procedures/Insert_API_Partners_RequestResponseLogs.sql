USE [WebDB]
GO

/******************************************************************************
 Procedure: Insert_API_Partners_RequestResponseLogs
 
 Change history:
 Date       Author          Project     Change
 ==============================================================================
  01/12/2018 Kate Sky 	   PSCC - Message Logging 	New	
  02/12/2018 Kate Sky 	   Added a GO to grant permissions	
******************************************************************************/

IF  EXISTS (SELECT name 
				FROM sys.objects 
				WHERE object_id = OBJECT_ID(N'[dbo].[Insert_API_Partners_RequestResponseLogs]') 
					AND type IN (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Insert_API_Partners_RequestResponseLogs]
GO
CREATE PROCEDURE [dbo].[Insert_API_Partners_RequestResponseLogs]
(
	@PartnerName varchar(1000),
	@RequestPath  varchar(200),
	@RequestUri varchar(200),
	@RequestBody varchar(max),
	@RequestHeaders varchar(1000),
	@RequestIpFrom varchar(100),
	@RequestMethod varchar(50),
	@ResponseHeaders varchar(1000),
	@ResponseBody varchar(max),
	@ResponseProcessingTime bigint,
	@RequestStartDateUTC datetime,
	@ResponseResultCode int
)

AS
BEGIN
    SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
	INSERT INTO [dbo].[API_Partners_RequestResponseLogs]
           ([PartnerName]
           ,[RequestPath]
           ,[RequestUri]
           ,[RequestBody]
           ,[RequestHeaders]
           ,[RequestIpFrom]
           ,[RequestMethod]
           ,[ResponseHeaders]
           ,[ResponseBody]
           ,[ResponseProcessingTime]
           ,[RequestStartDateUTC]
           ,[ResponseResultCode]
		   ,[InsertDateUtc])
     VALUES
			(@PartnerName, 
			@RequestPath,
			@RequestUri,
			@RequestBody, 
			@RequestHeaders, 
			@RequestIpFrom, 
			@RequestMethod, 
			@ResponseHeaders,
			@ResponseBody,
			@ResponseProcessingTime,
			@RequestStartDateUTC,
			@ResponseResultCode,
			GETUTCDATE()) 
		
	SELECT [ID]
		,[PartnerName]
		,[RequestPath]
		,[RequestUri]
		,[RequestBody]
		,[RequestHeaders]
		,[RequestIpFrom]
		,[RequestMethod]
		,[ResponseHeaders]
		,[ResponseBody]
		,[ResponseProcessingTime]
		,[RequestStartDateUTC]
		,[InsertDateUtc]
		,[ResponseResultCode] 
	FROM [dbo].[API_Partners_RequestResponseLogs]
	WHERE ID = SCOPE_IDENTITY()
 END 
GO


GRANT EXECUTE
ON OBJECT::[dbo].[Insert_API_Partners_RequestResponseLogs]
TO [Webaccess]
AS [dbo]
GO 
