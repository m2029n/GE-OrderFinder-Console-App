﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation
{
    /// <summary>
    /// holds OrderValidationException
    /// </summary>
    public class OrderValidationException : Exception
    {
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="failures"></param>
        public OrderValidationException(IEnumerable<IOrderValidationFailure> failures)
        {
            Failures = failures;
        }

        /// <summary>
        /// list of Errors
        /// </summary>
        public IEnumerable<IOrderValidationFailure> Failures { get; private set; }
    }
}