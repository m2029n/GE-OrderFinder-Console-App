﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation
{
    /// <summary>
    /// new PaymentValidationException used for Payments
    /// </summary>
    public class PaymentValidationException : Exception
    {
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="failures"></param>
        public PaymentValidationException(IEnumerable<IPaymentValidationFailure> failures)
        {
            this.Failures = failures;
        }

        /// <summary>
        /// holds list of Failures
        /// </summary>
        public IEnumerable<IPaymentValidationFailure> Failures { get; private set; }
    }
}