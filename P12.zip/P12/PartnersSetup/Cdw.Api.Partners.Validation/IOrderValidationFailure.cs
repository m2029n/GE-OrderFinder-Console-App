﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Cdw.Api.Partners.Validation
//{
//    public interface IOrderValidationFailure
//    {
//        string Field { get; }

//        string Message { get; }
//    }
//}