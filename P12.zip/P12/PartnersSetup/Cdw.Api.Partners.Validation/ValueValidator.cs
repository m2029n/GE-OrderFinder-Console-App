﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Validation.Orders.Validators
{
    /// <summary>
    /// holds validators
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class ValueValidator<T> where T : struct
    {
        /// <summary>
        /// method to validate
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public abstract IEnumerable<IOrderValidationFailure> Validate(T value);
    }
}