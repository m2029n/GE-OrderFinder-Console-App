﻿using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Api.Partners.Validation
{
    /// <summary>
    /// impelemnts validation for Failed requests
    /// </summary>
    public class FailedRequestValidationResult : IOrderValidationFailure, IPaymentValidationFailure
    {
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="field"></param>
        /// <param name="message"></param>
        public FailedRequestValidationResult(
            string field,
            string message)
        {
            Field = field;
            Message = message;
        }

        /// <summary>
        /// holds Field
        /// </summary>
        public string Field
        {
            get;
            private set;
        }

        /// <summary>
        /// holds Message
        /// </summary>
        public string Message
        {
            get;
            private set;
        }
    }
}