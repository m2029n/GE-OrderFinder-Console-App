﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation.Payments
{
    /// <summary>
    /// class use for validations
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class Validator<T>
    {
        /// <summary>
        /// checks model for nulls
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual IEnumerable<IPaymentValidationFailure> Validate(T model)
        {
            if (model == null)
            {
                return Enumerable.Empty<IPaymentValidationFailure>();
            }

            return this.ValidateModelProperties(model);
        }

        /// <summary>
        /// ValidateNullModel
        /// </summary>
        /// <param name="model"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public virtual IEnumerable<IPaymentValidationFailure> ValidateNullModel(T model, string fieldName)
        {
            if (model == null)
            {
                return new List<IPaymentValidationFailure>()
                {
                    new FailedRequestValidationResult(fieldName, $"{fieldName} must be defined")
                };
            }

            return this.ValidateModelProperties(model);
        }

        /// <summary>
        /// abstract method?
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected abstract IEnumerable<IPaymentValidationFailure> ValidateModelProperties(T model);

        /// <summary>
        /// checks for nulls
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <typeparam name="TValue"></typeparam>
        /// <returns></returns>
        protected IEnumerable<IPaymentValidationFailure> ValidateIsNotNull<TValue>(
            TValue value,
            string fieldName)
        {
            if (value == null)
            {
                return new IPaymentValidationFailure[] {
                    new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined")
                };
            }

            return null;
        }

        /// <summary>
        /// checks for nulls
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <param name="validationIfNotNull"></param>
        /// <typeparam name="TValue"></typeparam>
        /// <returns></returns>
        protected IEnumerable<IPaymentValidationFailure> ValidateIsNotNull<TValue>(
            TValue value,
            string fieldName,
            Func<TValue, IEnumerable<IPaymentValidationFailure>> validationIfNotNull)
        {
            if (value == null)
            {
                return new IPaymentValidationFailure[] {
                    new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined")
                };
            }

            return validationIfNotNull(value);
        }

        /// <summary>
        /// checks for strings that are not null
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IPaymentValidationFailure ValidateStringIsNotNullOrEmpty(
            string value,
            string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined and not an empty string");
            }

            return null;
        }

        /// <summary>
        /// validates strings
        /// </summary>
        /// <param name="value"></param>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IPaymentValidationFailure ValidateStringIsNotNullOrEmpty(
            string value, string value1, string value2,
            string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value) && (string.IsNullOrWhiteSpace(value1) || string.IsNullOrWhiteSpace(value2)))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined and not an empty string");
            }

            return null;
        }

        /// <summary>
        /// ValidateStringMatchesRegex
        /// </summary>
        /// <param name="value"></param>
        /// <param name="regexToMatch"></param>
        /// <param name="fieldName"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        protected IPaymentValidationFailure ValidateStringMatchesRegex(
            string value,
            Regex regexToMatch,
            string fieldName,
            string errorMessage)
        {
            if (string.IsNullOrEmpty(value) || !regexToMatch.IsMatch(value))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    errorMessage);
            }

            return null;
        }

        /// <summary>
        /// ValidateStringLengthIsLessThanOrEqualToMaxLength
        /// </summary>
        /// <param name="value"></param>
        /// <param name="maxLength"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IPaymentValidationFailure ValidateStringLengthIsLessThanOrEqualToMaxLength(
            string value,
            int maxLength,
            string fieldName)
        {
            if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " exceeds the maximum length of " + maxLength.ToString() + " characters");
            }

            return null;
        }
    }

    public static class ListExtensions
    {
        public static IList<T> AddIfNotNull<T>(this IList<T> list, T value)
        {
            if (value != null)
            {
                list.Add(value);
            }

            return list;
        }
    }
}