﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation.Payments
{
    /// <summary>
    /// defines IValidator
    /// </summary>
    public interface IValidator
    {
        /// <summary>
        /// defines IsValid
        /// </summary>
        bool IsValid { get; }

        /// <summary>
        /// defines Failures
        /// </summary>
        List<IPaymentValidationFailure> Failures { get; set; }
    }
}