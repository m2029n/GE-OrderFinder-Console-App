﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation.Payments
{
    /// <summary>
    /// default validation for payments
    /// </summary>
    public class DefaultValidator : IValidator
    {
        private PaymentRequestModel _paymentRequestModel;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="paymentRequestModel"></param>
        public DefaultValidator(PaymentRequestModel paymentRequestModel)
        {
            _paymentRequestModel = paymentRequestModel;
        }

        /// <summary>
        /// holds IsValid
        /// </summary>
        public virtual bool IsValid
        {
            get
            {
                Validate();
                return !Failures.Any();
            }
        }

        /// <summary>
        /// holds Failures
        /// </summary>
        public List<IPaymentValidationFailure> Failures { get; set; }

        private void Validate()
        {
            var taskArray = new List<Task<IEnumerable<IPaymentValidationFailure>>>
            {
                //Transaction Id validation
                Task<IEnumerable<IPaymentValidationFailure>>.Factory.StartNew(
                    () => new TransactionIdValidator().Validate(_paymentRequestModel.TransactionId)),
                //Credit Card Validations
                Task<IEnumerable<IPaymentValidationFailure>>.Factory.StartNew(
                    () => new CreditCardValidator().Validate(_paymentRequestModel.CreditCard))
        };

            Failures = new List<IPaymentValidationFailure>();
            foreach (var task in taskArray)
            {
                Failures.AddRange(task.Result);
            }
        }
    }
}