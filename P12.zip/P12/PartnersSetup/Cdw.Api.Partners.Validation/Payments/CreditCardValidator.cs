﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation.Payments
{
    /// <summary>
    /// Credit Card validations.
    /// </summary>
    public class CreditCardValidator : Validator<CreditCardModel>
    {
        /// <summary>
        /// Validate the given credit card model.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public override IEnumerable<IPaymentValidationFailure> Validate(CreditCardModel model)
        {
            var failures = new List<IPaymentValidationFailure>();
            if (model == null)
            {
                failures.Add(new FailedRequestValidationResult(
                    "Credit Card",
                    "Credit Card must not be null."));
            }
            if (string.IsNullOrEmpty(model?.Number))
            {
                failures.Add(new FailedRequestValidationResult(
                    "CreditCard.Number",
                    "Credit Card Number must not be null."));
            }

            if (model != null && (model.ExpirationMonth < 1 || model.ExpirationMonth > 12))
            {
                failures.Add(new FailedRequestValidationResult(
                    "CreditCard.ExpirationMonth",
                    "CreditCard.ExpirationMonth must be an integer between 1 and 12"));
            }

            if (model != null && (model.ExpirationYear < 1 || model.ExpirationYear > 9999))
            {
                failures.Add(new FailedRequestValidationResult(
                    "CreditCard.ExpirationYear",
                    "CreditCard.ExpirationYear must be an integer between 1 and 9999"));
            }
            return failures;
        }

        /// <summary>
        /// Valdiate credit card model properties.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IPaymentValidationFailure> ValidateModelProperties(CreditCardModel model)
        {
            return Enumerable.Empty<IPaymentValidationFailure>();
        }
    }
}