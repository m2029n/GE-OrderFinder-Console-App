﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Partners.Validation.Payments
{
    internal class TransactionIdValidator
    {
        public IEnumerable<IPaymentValidationFailure> Validate(string transactionId)
        {
            if (string.IsNullOrEmpty(transactionId))
            {
                return new IPaymentValidationFailure[] {
                    new FailedRequestValidationResult(
                        "TransactionId",
                        "TransactionId must be a non-null, non-empty string")
                };
            }

            bool isValid = Guid.TryParse(transactionId, out var guidOutput);

            if (!isValid)
            {
                return new[] {
                    new FailedRequestValidationResult(
                        "TransactionId",
                        "TransactionId should be a GUID.")
                };
            }

            return Enumerable.Empty<IPaymentValidationFailure>();
        }
    }
}