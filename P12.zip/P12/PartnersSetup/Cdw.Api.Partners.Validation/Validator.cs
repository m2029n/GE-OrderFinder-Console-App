﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Validation.Orders.Validators
{
    /// <summary>
    /// holds order validators
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class Validator<T>
    {
        /// <summary>
        /// Validates Model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual IEnumerable<IOrderValidationFailure> Validate(T model)
        {
            if (model == null)
            {
                return Enumerable.Empty<IOrderValidationFailure>();
            }

            return this.ValidateModelProperties(model);
        }

        /// <summary>
        /// used to check model for null
        /// </summary>
        /// <param name="model"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public virtual IEnumerable<IOrderValidationFailure> ValidateNullModel(T model, string fieldName)
        {
            if (model == null)
            {
                return new List<IOrderValidationFailure>()
                {
                    new FailedRequestValidationResult(fieldName, $"{fieldName} must be defined")
                };
            }

            return this.ValidateModelProperties(model);
        }

        /// <summary>
        /// uesd to validate model properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected abstract IEnumerable<IOrderValidationFailure> ValidateModelProperties(T model);

        /// <summary>
        /// checks for nulls
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <typeparam name="TValue"></typeparam>
        /// <returns></returns>
        protected IEnumerable<IOrderValidationFailure> ValidateIsNotNull<TValue>(
            TValue value,
            string fieldName)
        {
            if (value == null)
            {
                return new IOrderValidationFailure[] {
                    new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined")
                };
            }

            return null;
        }

        /// <summary>
        /// used to validate value and check for nulls
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <param name="validationIfNotNull"></param>
        /// <typeparam name="TValue"></typeparam>
        /// <returns></returns>
        protected IEnumerable<IOrderValidationFailure> ValidateIsNotNull<TValue>(
            TValue value,
            string fieldName,
            Func<TValue, IEnumerable<IOrderValidationFailure>> validationIfNotNull)
        {
            if (value == null)
            {
                return new IOrderValidationFailure[] {
                    new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined")
                };
            }

            return validationIfNotNull(value);
        }

        /// <summary>
        /// Used to validate field for null values
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IOrderValidationFailure ValidateStringIsNotNullOrEmpty(
            string value,
            string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined and not an empty string");
            }

            return null;
        }

        /// <summary>
        /// Used to validate null strings
        /// </summary>
        /// <param name="value"></param>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IOrderValidationFailure ValidateStringIsNotNullOrEmpty(
            string value, string value1, string value2,
            string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value) && (string.IsNullOrWhiteSpace(value1) || string.IsNullOrWhiteSpace(value2)))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " must be defined and not an empty string");
            }

            return null;
        }

        /// <summary>
        /// validates strings
        /// </summary>
        /// <param name="value"></param>
        /// <param name="regexToMatch"></param>
        /// <param name="fieldName"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        protected IOrderValidationFailure ValidateStringMatchesRegex(
            string value,
            Regex regexToMatch,
            string fieldName,
            string errorMessage)
        {
            if (string.IsNullOrEmpty(value) || !regexToMatch.IsMatch(value))
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    errorMessage);
            }

            return null;
        }

        /// <summary>
        /// checks for valid lengths
        /// </summary>
        /// <param name="value"></param>
        /// <param name="maxLength"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        protected IOrderValidationFailure ValidateStringLengthIsLessThanOrEqualToMaxLength(
            string value,
            int maxLength,
            string fieldName)
        {
            if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
            {
                return new FailedRequestValidationResult(
                    fieldName,
                    fieldName + " exceeds the maximum length of " + maxLength.ToString() + " characters");
            }

            return null;
        }
    }

    public static class ListExtensions
    {
        public static IList<T> AddIfNotNull<T>(this IList<T> list, T value)
        {
            if (value != null)
            {
                list.Add(value);
            }

            return list;
        }
    }
}