﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// Validates Order Discounts
    /// </summary>
    public class OrderDiscountsValidator : CollectionValidator<DiscountModel>
    {
        /// <summary>
        /// ctor
        /// </summary>
        public OrderDiscountsValidator()
            : base(new OrderDiscountValidator())
        { }
    }
}