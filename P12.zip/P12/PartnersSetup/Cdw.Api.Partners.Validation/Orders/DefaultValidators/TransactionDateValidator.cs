﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    internal class TransactionDateValidator
    {
        public IEnumerable<IOrderValidationFailure> Validate(DateTime transactionDate)
        {
            if (transactionDate < new DateTime(1970, 1, 1))
            {
                return new IOrderValidationFailure[] {
                    new FailedRequestValidationResult(
                        "TransactionDate",
                        "TransactionDate must be greater than January 1, 1970")
                };
            }

            return Enumerable.Empty<IOrderValidationFailure>();
        }
    }
}