﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// defines alidation for Line Item Discounts
    /// </summary>
    public class LineItemDiscountsValidator : CollectionValidator<DiscountModel>
    {
        /// <summary>
        /// ctor
        /// </summary>
        public LineItemDiscountsValidator()
            : base(new LineItemDiscountValidator())
        { }
    }
}