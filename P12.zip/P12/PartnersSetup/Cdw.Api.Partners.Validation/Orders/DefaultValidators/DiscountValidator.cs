﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// validates discount
    /// </summary>
    public abstract class DiscountValidator : Validator<DiscountModel>
    {
        private readonly IDictionary<int, string> _validDiscountTypes;

        private readonly IDictionary<int, Func<decimal, IOrderValidationFailure>> _amountValidators;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="validDiscountTypes"></param>
        /// <param name="amountValidators"></param>
        protected DiscountValidator(
            IDictionary<int, string> validDiscountTypes,
            IDictionary<int, Func<decimal, IOrderValidationFailure>> amountValidators)
        {
            this._validDiscountTypes = validDiscountTypes;
            this._amountValidators = amountValidators;
        }

        /// <summary>
        /// returns validated properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            DiscountModel model)
        {
            var results = new List<IOrderValidationFailure>();

            results.AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.Id, "Discount.Id"));

            if (!this._validDiscountTypes.ContainsKey(model.Type))
            {
                results.Add(new FailedRequestValidationResult(
                    "Discount.Type",
                    "Discount.Type must be one of the following: "
                    + string.Join(", ", this._validDiscountTypes.Select(vd => vd.Key.ToString() + "(" + vd.Value + ")"))));
            }
            else
            {
                results.AddIfNotNull(this._amountValidators[model.Type](model.Amount));
            }

            return results;
        }

        /// <summary>
        /// validates amount
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        protected static IOrderValidationFailure ValidatePercentageDiscountAmount(decimal amount)
        {
            if (amount < 0m || amount > 100.0m)
            {
                return new FailedRequestValidationResult(
                    "Discount.Amount",
                    "Discount.Amount must be greater than or equal to 0 and less than or equal to 100");
            }

            return null;
        }

        /// <summary>
        /// validates fixed discount amount
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        protected static IOrderValidationFailure ValidateFixedDiscountAmount(decimal amount)
        {
            if (amount < 0m)
            {
                return new FailedRequestValidationResult(
                    "Discount.Amount",
                    "Discount.Amount must be greater than or equal to 0");
            }

            return null;
        }
    }
}