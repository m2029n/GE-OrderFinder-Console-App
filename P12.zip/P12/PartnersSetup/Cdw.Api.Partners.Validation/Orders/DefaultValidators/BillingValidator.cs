﻿using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// validator for billing
    /// </summary>
    public class BillingValidator : Validator<BillingInfoModel>
    {
        /// <summary>
        /// returns properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            BillingInfoModel model)
        {
            var results = new List<IOrderValidationFailure>();

            results.AddRange(ValidateIsNotNull(
                model.Address,
                "Billing.Address",
                m => new AddressValidator().Validate(m)));
            results.AddRange(ValidateIsNotNull(
                model.Method,
                "Billing.Method",
                m => new PaymentMethodValidator().Validate(m)));

            return results;
        }
    }
}