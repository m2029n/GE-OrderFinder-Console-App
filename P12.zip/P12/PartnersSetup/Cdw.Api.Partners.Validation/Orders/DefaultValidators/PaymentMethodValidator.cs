﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// validates PaymentMethod
    /// </summary>
    public class PaymentMethodValidator : Validator<PaymentMethodModel>
    {
        /// <summary>
        /// defines a list of properties to validate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            PaymentMethodModel model)
        {
            var failures = new List<IOrderValidationFailure>();

            if (!string.IsNullOrEmpty(model.PONumber))
            {
                failures.AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                    model.PONumber,
                    30,
                    "PONumber"));
            }

            var billingMethodFields = new List<string> { model.EncryptedCreditCard,
                                                         model.Terms,
                                                         model.TransactionId };

            if (billingMethodFields.Count(x => !string.IsNullOrEmpty(x)) != 1)
            {
                failures.Add(new FailedRequestValidationResult(
                        "Billing.Method",
                        "Billing Method details should be defined correctly."));
            }

            if (!string.IsNullOrEmpty(model.TransactionId) && (model.ReferenceNumber == null))
            {
                failures.Add(new FailedRequestValidationResult(
                        "Billing.Method",
                        "Billing Method details should be defined correctly."));
            }

            return failures;
        }
    }
}