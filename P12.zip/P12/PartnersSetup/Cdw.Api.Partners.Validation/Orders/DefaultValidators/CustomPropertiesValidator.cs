﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// defines valitator fr custom property model
    /// </summary>
    public class CustomPropertiesValidator : CollectionValidator<CustomPropertyModel>
    {
        /// <summary>
        /// ctor
        /// </summary>
        public CustomPropertiesValidator()
            : base(new CustomPropertyValidator())
        { }
    }
}