﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// defines default validations
    /// </summary>
    public class DefaultValidator : IValidator
    {
        private RequestOrderModel _orderModel;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="orderModel"></param>
        public DefaultValidator(RequestOrderModel orderModel)
        {
            _orderModel = orderModel;
        }

        /// <summary>
        /// returns IsValid
        /// </summary>
        public bool IsValid
        {
            get
            {
                Validate();
                return !Failures.Any();
            }
        }

        /// <summary>
        /// holds Failures
        /// </summary>
        public List<IOrderValidationFailure> Failures { get; set; }

        private void Validate()
        {
            var taskArray = new List<Task<IEnumerable<IOrderValidationFailure>>>
            {
                //Transaction Date validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new TransactionDateValidator().Validate(_orderModel.TransactionDate)),

                //Company validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new CompanyValidator().Validate(_orderModel.Company)),

                //ReferenceNumber validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new ReferenceNumberValidator().Validate(_orderModel.ReferenceNumber)),

                //Account validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new AccountValidator().ValidateNullModel(_orderModel.Account,"Account")),

                //OrderDiscount validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new OrderDiscountsValidator().Validate(_orderModel.Discounts)),

                //Billing validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new BillingValidator().ValidateNullModel(_orderModel.Billing,"Billing")),

                //Shipping validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new ShippingValidator().ValidateNullModel(_orderModel.Shipping,"Shipping")),

                //Shipping validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new LineItemsValidator().ValidateNullModel(_orderModel.LineItems,"LineItems")),

                //Custom Property validation
                Task<IEnumerable<IOrderValidationFailure>>.Factory.StartNew(
                    () => new CustomPropertiesValidator().Validate(_orderModel.CustomProperties))
            };
            Failures = new List<IOrderValidationFailure>();
            foreach (var task in taskArray)
            {
                Failures.AddRange(task.Result);
            }
        }
    }
}