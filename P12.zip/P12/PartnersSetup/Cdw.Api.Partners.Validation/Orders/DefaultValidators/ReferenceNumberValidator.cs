﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    internal class ReferenceNumberValidator
    {
        public IEnumerable<IOrderValidationFailure> Validate(string referenceNumber)
        {
            if (string.IsNullOrEmpty(referenceNumber))
            {
                return new IOrderValidationFailure[] {
                    new FailedRequestValidationResult(
                        "ReferenceNumber",
                        "ReferenceNumber must be a non-null, non-empty string")
                };
            }

            if (referenceNumber.Length > 100)
            {
                return new[] {
                    new FailedRequestValidationResult(
                        "ReferenceNumber",
                        "RefernceNumber exceeds the maximum length of 100 characters")
                };
            }

            return Enumerable.Empty<IOrderValidationFailure>();
        }
    }
}