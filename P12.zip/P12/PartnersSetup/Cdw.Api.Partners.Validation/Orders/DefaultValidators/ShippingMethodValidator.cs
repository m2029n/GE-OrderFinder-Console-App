﻿using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// ShippingMethodValidator
    /// </summary>
    public class ShippingMethodValidator : Validator<ShippingMethodModel>
    {
        /// <summary>
        /// ValidateModelProperties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            ShippingMethodModel model)
        {
            var result = new List<IOrderValidationFailure>();

            result.AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                model.Id,
                "ShippingMethod.Id"));
            result.AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                model.Description,
                "ShippingMethod.Description"));

            return result;
        }
    }
}