﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// Line item validator
    /// </summary>
    public class LineItemsValidator : CollectionValidator<LineItemModel>
    {
        /// <summary>
        /// ctor
        /// </summary>
        public LineItemsValidator()
            : base(new LineItemValidator())
        {
        }
    }
}