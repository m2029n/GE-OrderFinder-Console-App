﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// Validates Line Items Discount
    /// </summary>
    public class LineItemDiscountValidator : DiscountValidator
    {
        /// <summary>
        /// Setting up the validations
        /// </summary>
        public LineItemDiscountValidator()
            : base(new Dictionary<int, string> {
                { 1002, "Fixed amount off unit price"},
                { 1003, "Percentage off unit price"},
                { 1004, "Fixed amount off line price"},
                { 1005, "Percentage off line price"}
            }, new Dictionary<int, Func<decimal, IOrderValidationFailure>> {
                { 1002, ValidateFixedDiscountAmount },
                { 1003, ValidatePercentageDiscountAmount },
                { 1004, ValidateFixedDiscountAmount },
                { 1005, ValidatePercentageDiscountAmount }
            })
        { }
    }
}