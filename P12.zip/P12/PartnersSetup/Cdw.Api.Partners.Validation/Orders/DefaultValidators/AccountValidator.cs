﻿using System.Collections.Generic;
using System.Text.RegularExpressions;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// used to validate account model
    /// </summary>
    public class AccountValidator : Validator<AccountModel>
    {
        private static Regex EmailAddressRegex = new Regex(
            @"[A-Z0-9\._%+-]+@[A-Z0-9\.-]+\.[A-Z]{2,4}",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private const string EmailAddressFieldName = "Account.EmailAddress";

        /// <summary>
        /// returns validations fro properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            AccountModel model)
        {
            var result = new List<IOrderValidationFailure>();

            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                    model.EmailAddress,
                    EmailAddressFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                    model.EmailAddress,
                    64,
                    EmailAddressFieldName))
                .AddIfNotNull(ValidateStringMatchesRegex(
                    model.EmailAddress,
                    EmailAddressRegex,
                    EmailAddressFieldName,
                    "Account.EmailAddress does not appear to be valid"));

            result.AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                model.CustomerNumber,
                8,
                "Account.CustomerNumber"));

            result.AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                model.EAccount,
                50,
                "Account.EAccount"));

            return result;
        }
    }
}