﻿using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// validates custom properties
    /// </summary>
    public class CustomPropertyValidator : Validator<CustomPropertyModel>
    {
        /// <summary>
        /// returns validated properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            CustomPropertyModel model)
        {
            var result = new List<IOrderValidationFailure>();

            result.AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                model.Name,
                "CustomProperty.Name"))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                model.Name,
                100,
                "CustomProperty.Name"));
            result.AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                model.Value,
                "CustomProperty.Value"))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(
                model.Value,
                500,
                "CustomProperty.Value"));

            return result;
        }
    }
}