﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// generic validator for typse
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class CollectionValidator<T> : Validator<IEnumerable<T>>
    {
        private readonly Validator<T> _elementValidator;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="elementValidator"></param>
        public CollectionValidator(Validator<T> elementValidator)
        {
            this._elementValidator = elementValidator;
        }

        /// <summary>
        /// validates collection
        /// </summary>
        /// <param name="collectionOfT"></param>
        /// <returns></returns>
        public override IEnumerable<IOrderValidationFailure> Validate(IEnumerable<T> collectionOfT)
        {
            if (collectionOfT == null || !collectionOfT.Any())
            {
                return Enumerable.Empty<IOrderValidationFailure>();
            }

            return ValidateModelProperties(collectionOfT);
        }

        /// <summary>
        /// validates model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            IEnumerable<T> model)
        {
            return model.SelectMany(m => _elementValidator.Validate(m));
        }
    }
}