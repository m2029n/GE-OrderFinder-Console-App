﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// Validates Line Items
    /// </summary>
    public class LineItemValidator : Validator<LineItemModel>
    {
        /// <summary>
        /// returns valdations for each property
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            LineItemModel model)
        {
            var results = new List<IOrderValidationFailure>();
            var manufacturerPartNumber = GetCustomValue("ManufacturerPartNumber", model);
            var manufacturerItemDesc = GetCustomValue("ManufacturerItemDesc", model);

            results.AddIfNotNull(ValidateStringIsNotNullOrEmpty(
                model.ProductCode, manufacturerPartNumber, manufacturerItemDesc,
                "LineItem.ProductCode"));

            if (model.Quantity < 1 || model.Quantity > 999)
            {
                results.Add(new FailedRequestValidationResult(
                    "LineItem.Quantity",
                    "LineItem.Quantity must be an integer between 1 and 999"));
            }

            if (model.UnitPrice <= 0m)
            {
                results.Add(new FailedRequestValidationResult(
                    "LineItem.UnitPrice",
                    "LineItem.UnitPrice must be a decimal and greater than 0.00"));
            }

            results.AddRange(new LineItemDiscountsValidator().Validate(model.Discounts));
            results.AddRange(new CustomPropertiesValidator().Validate(model.CustomProperties));

            return results;
        }

        private string GetCustomValue(string propertyName, LineItemModel model)
        {
            if (model.CustomProperties == null || !model.CustomProperties.Any())
            {
                return "";
            }

            var count = model.CustomProperties.Count(item => item.Name == propertyName);
            if (count != 1) return "";
            {
                var customPropertyModel = model.CustomProperties.FirstOrDefault(item => item.Name == propertyName);
                if (customPropertyModel != null)
                {
                    return customPropertyModel.Value;
                }
            }

            return "";
        }
    }
}