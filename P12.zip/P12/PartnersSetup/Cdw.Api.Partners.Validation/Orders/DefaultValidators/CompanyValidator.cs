﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Validation;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// validator for company
    /// </summary>
    public class CompanyValidator : ValueValidator<int>
    {
        /// <summary>
        /// validator for hardcodes company code TODO: should be changed
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IEnumerable<IOrderValidationFailure> Validate(int value)
        {
            if (value != 1000 && value != 1006 && value != 1012)
            {
                return new IOrderValidationFailure[] {
                    new FailedRequestValidationResult(
                        "Company",
                        "Company must be one of the following values: 1000, 1006, 1012")
                };
            }

            return Enumerable.Empty<IOrderValidationFailure>().ToList();
        }
    }
}