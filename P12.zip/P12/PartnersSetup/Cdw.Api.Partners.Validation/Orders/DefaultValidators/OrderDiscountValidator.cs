﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// Validates Order Discount
    /// </summary>
    public class OrderDiscountValidator : DiscountValidator
    {
        /// <summary>
        /// ctor
        /// </summary>
        public OrderDiscountValidator()
            : base(new Dictionary<int, string> {
                { 1000, "Fixed amount off order"},
                { 1001, "Percentage off order"}
            }, new Dictionary<int, Func<decimal, IOrderValidationFailure>> {
                { 1000, ValidateFixedDiscountAmount },
                { 1001, ValidatePercentageDiscountAmount }
            })
        { }
    }
}