﻿using System.Collections.Generic;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// ShippingValidator
    /// </summary>
    public class ShippingValidator : Validator<ShippingInfoModel>
    {
        /// <summary>
        /// ValidateModelProperties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            ShippingInfoModel model)
        {
            var results = new List<IOrderValidationFailure>();

            results.AddRange(ValidateIsNotNull(
                model.Address,
                "Shipping.Address",
                m => new AddressValidator().Validate(m)));
            results.AddRange(ValidateIsNotNull(
                model.Method,
                "Shipping.Method",
                m => new ShippingMethodValidator().Validate(m)));

            return results;
        }
    }
}