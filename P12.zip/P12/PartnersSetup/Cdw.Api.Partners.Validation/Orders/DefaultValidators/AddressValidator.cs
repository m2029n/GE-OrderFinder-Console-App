﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.Order;
using Cdw.Api.Partners.Validation;
using Cdw.Api.Partners.Validation.Orders.Validators;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Partners.Validation.Orders.DefaultValidators
{
    /// <summary>
    /// defines address validation
    /// </summary>
    public class AddressValidator : Validator<AddressModel>
    {
        private const string PhoneNumberFieldName = "Address.PhoneNumber";

        private const string FirstNameFieldName = "Address.FirstName";

        private const string LastNameFieldName = "Address.LastName";

        private const string StreetAddressFieldName = "Address.StreetAddress";

        private const string CityFieldName = "Address.City";

        private const string StateFieldName = "Address.State";

        private const string CompanyFieldName = "Address.Company";

        private const string PostalCodeFieldName = "Address.PostalCode";

        private const string CountryCodeFieldName = "Address.IsoCountryCode";

        /// <summary>
        /// returns validations for properties
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override IEnumerable<IOrderValidationFailure> ValidateModelProperties(
            AddressModel model)
        {
            IList<IOrderValidationFailure> result = new List<IOrderValidationFailure>();

            ValidatePhoneNumber(model, result);
            ValidateFirstName(model, result);
            ValidateLastName(model, result);
            ValidateCompany(model, result);
            ValidateStreetAddress(model, result);
            ValidateSecondaryStreetAddress(model, result);
            ValidateCity(model, result);
            ValidateState(model, result);
            ValidatePostalCode(model, result);
            ValidateCountryCode(model, result);

            return result;
        }

        private void ValidatePhoneNumber(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.PhoneNumber, PhoneNumberFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.PhoneNumber, 20, PhoneNumberFieldName));
        }

        private void ValidateFirstName(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.FirstName, FirstNameFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.FirstName, 12, FirstNameFieldName));
        }

        private void ValidateLastName(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.LastName, LastNameFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.LastName, 15, LastNameFieldName));
        }

        private void ValidateCompany(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.Company, 35, CompanyFieldName));
        }

        private void ValidateStreetAddress(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.StreetAddress, StreetAddressFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.StreetAddress, 35, StreetAddressFieldName));
        }

        private void ValidateSecondaryStreetAddress(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.SecondaryStreetAddress, 35, "Address.SecondaryStreetAddress"));
        }

        private void ValidateCity(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.City, CityFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.City, 20, CityFieldName));
        }

        private void ValidateState(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.State, StateFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.State, 2, StateFieldName));
        }

        private void ValidatePostalCode(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.PostalCode, PostalCodeFieldName));

            if (string.IsNullOrEmpty(model.IsoCountryCode) || string.IsNullOrEmpty(model.PostalCode))
            {
                return;
            }

            var countryCode = model.IsoCountryCode.ToUpper();

            if (countryCode == "US")
            {
                ValidateUSPostalCode(result, model);
            }

            if (countryCode == "CA")
            {
                ValidateCanadianPostalCode(result, model);
            }
        }

        private static void ValidateCanadianPostalCode(IList<IOrderValidationFailure> result, AddressModel address)
        {
            address.PostalCode = string.Join(string.Empty, address.PostalCode.ToCharArray().Where(c => char.IsLetterOrDigit(c)));

            if (address.PostalCode.Length != 6)
            {
                result.Add(new FailedRequestValidationResult("Address.PostalCode",
                    "Canadian address zip codes must contain 6 letters or numbers"));
            }
        }

        private static void ValidateUSPostalCode(IList<IOrderValidationFailure> result, AddressModel address)
        {
            address.PostalCode = string.Join(string.Empty, address.PostalCode.ToCharArray().Where(c => char.IsNumber(c)));

            if (address.PostalCode.Length != 5 && address.PostalCode.Length != 9)
            {
                result.Add(new FailedRequestValidationResult("Address.PostalCode",
                    "US address zip codes must contain 5 or 9 numbers"));
            }
        }

        private void ValidateCountryCode(AddressModel model, IList<IOrderValidationFailure> result)
        {
            result
                .AddIfNotNull(ValidateStringIsNotNullOrEmpty(model.IsoCountryCode, CountryCodeFieldName))
                .AddIfNotNull(ValidateStringLengthIsLessThanOrEqualToMaxLength(model.IsoCountryCode, 2, CountryCodeFieldName));
        }
    }
}