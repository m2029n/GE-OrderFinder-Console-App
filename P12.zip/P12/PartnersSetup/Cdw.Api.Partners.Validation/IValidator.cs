﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Api.Partners.Validation.Orders
{
    /// <summary>
    /// defines Validator
    /// </summary>
    public interface IValidator
    {
        /// <summary>
        /// defines isValid
        /// </summary>
        bool IsValid { get; }

        /// <summary>
        /// defines Failures
        /// </summary>
        List<IOrderValidationFailure> Failures { get; set; }
    }
}