﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Transform
{
    public interface ITransform
    {
        RequestOrderModel Transform(RequestOrderModel orderModel);
    }
}
