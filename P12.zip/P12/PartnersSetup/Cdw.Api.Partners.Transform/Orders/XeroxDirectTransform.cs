﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Transform
{
    public class XeroxDirectTransform : DefaultTransform, ITransform
    {
        public XeroxDirectTransform(RequestOrderModel orderModel): base(orderModel)
        {            
        }

        public override RequestOrderModel Transform(RequestOrderModel orderModel)
        {
            return orderModel;
        }        
    }
}