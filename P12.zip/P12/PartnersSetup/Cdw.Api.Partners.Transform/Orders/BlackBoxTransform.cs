﻿using System.Linq;
using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Transform
{
    public class BlackBoxTransform : DefaultTransform, ITransform
    {
        public BlackBoxTransform(RequestOrderModel orderModel) : base(orderModel)
        {
        }
        
        public override RequestOrderModel Transform(RequestOrderModel orderModel)
        {
            foreach (var lineItem in orderModel.LineItems)
            {
                if (lineItem.ProductCode == string.Empty
                   && GetCustomValue("ManufacturerPartNumber", lineItem) != string.Empty
                   && GetCustomValue("ManufacturerItemDesc", lineItem) != string.Empty
                   )
                {
                    lineItem.ProductCode = "NEW-ITEM";
                }
            }

            return orderModel;
        }

        private string GetCustomValue(string propertyName, LineItemModel model)
        {
            if (model.CustomProperties == null || !model.CustomProperties.Any())
            {
                return string.Empty;
            }

            var count = model.CustomProperties.Count(item => item.Name == propertyName);
            if (count != 1) return "";
            {
                var customPropertyModel = model.CustomProperties.FirstOrDefault(item => item.Name == propertyName);
                if (customPropertyModel != null)
                {
                    return customPropertyModel.Value;
                }
            }

            return string.Empty;
        }      
    }
}
