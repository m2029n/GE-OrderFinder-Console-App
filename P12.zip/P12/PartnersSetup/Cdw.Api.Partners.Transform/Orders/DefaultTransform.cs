﻿using Cdw.Api.Partners.Model.Order;

namespace Cdw.Partners.Transform
{
    public abstract class DefaultTransform : ITransform
    {
        private RequestOrderModel _orderModel;

        protected DefaultTransform(RequestOrderModel orderModel)
        {
            _orderModel = orderModel;
        }

        public virtual RequestOrderModel Transform(RequestOrderModel orderModel)
        {
            //There is no default transform right now.
            return _orderModel;
        }
    }
}
