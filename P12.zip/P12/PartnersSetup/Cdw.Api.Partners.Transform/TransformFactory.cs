﻿using Cdw.Api.Partners.Model.Order;
using Cdw.Domain.Partners.Common;

namespace Cdw.Partners.Transform
{
    public static class TransformFactory
    {
        public static ITransform Create(Partner partner, RequestOrderModel orderModel)
        {
            switch (partner)
            {
                case Partner.XeroxDirect:
                    return new XeroxDirectTransform(orderModel);
                case Partner.XeroxCanada:
                    return new XeroxCanadaTransform(orderModel);
                case Partner.BlackBox:
                    return new BlackBoxTransform(orderModel);
                default:
                    return null;
            }
        }       
    }
}
