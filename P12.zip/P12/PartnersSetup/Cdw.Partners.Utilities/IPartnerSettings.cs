﻿namespace Cdw.Partners.Utilities
{
    public interface IPartnerSettings
    {
        string CreditCardCertificateName { get; }
        string CreditCardAPIKey { get; }
    }
}