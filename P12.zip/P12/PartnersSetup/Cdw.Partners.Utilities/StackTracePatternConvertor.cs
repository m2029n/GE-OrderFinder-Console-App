﻿using System;
using System.IO;
using log4net.Util;
using Newtonsoft.Json;

namespace Cdw.Partners.Utilities
{
    public class StackTracePatternConvertor : PatternConverter
    {
        protected override void Convert(TextWriter writer, object state)
        {
            var loggingEvent = state as log4net.Core.LoggingEvent;

            if (loggingEvent == null)
            {
                return;
            }
            if (loggingEvent.ExceptionObject != null && loggingEvent.ExceptionObject.StackTrace != null)
            {
                var trace = loggingEvent.ExceptionObject.StackTrace.Replace(Environment.NewLine, "\\n");
                trace = JsonConvert.SerializeObject(trace);
                writer.Write(trace);
            }
            else
            {
                writer.Write(JsonConvert.SerializeObject(""));
            }
        }
    }
}