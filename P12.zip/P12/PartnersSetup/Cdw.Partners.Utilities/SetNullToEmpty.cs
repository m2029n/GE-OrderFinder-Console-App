﻿using System;
using System.Linq;

namespace Cdw.Partners.Utilities
{
    public static class SetNullToEmpty
    {
        public static void Collection<TModel, TProp>(
         TModel model,
         Func<TModel, TProp[]> getter,
         Action<TModel, TProp[]> setter)
        {
            setter(model, getter(model) ?? Enumerable.Empty<TProp>().ToArray());
        }
    }
}