﻿using log4net.Layout;
using log4net.Util;

namespace Cdw.Partners.Utilities
{
    public class CustomPatternLayout : PatternLayout
    {
        public CustomPatternLayout()
        {
            AddConverter(new ConverterInfo { Name = "stacktrace", Type = typeof(StackTracePatternConvertor) });
            AddConverter(new ConverterInfo { Name = "message", Type = typeof(MessagePatternConvertor) });
            AddConverter(new ConverterInfo { Name = "exceptionMessage", Type = typeof(ExceptionMessagePatternConvertor) });
        }
    }
}