﻿using System;
using System.Threading.Tasks;
using Cdw.Common;
using Cdw.Logging;
using Common.Logging;
using Newtonsoft.Json;

namespace Cdw.Partners.Utilities
{
    public static class LoggerExtensionMethod
    {
        private const string TrackingHeader = "x-cdw-tracking-id";
        private const string CorrelationHeader = "x-cdw-correlation-id";

        #region Fatal

        public static void Fatal<T>(this ILog log, string message, Exception ex, ITrackingValues trackingValues,
            T input)
        {
            var data = new { message, input };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString(), JsonConvert.SerializeObject(input));

            Task.Run(() =>
            {
                var msg = new LogObject(data, additionalItems);
                log.Fatal(msg, ex);
            });
        }

        #endregion Fatal

        #region Error

        public static void Error(this ILog log, string message, Exception ex, ITrackingValues trackingValues)
        {
            var data = new { message };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString());

            Task.Run(() =>
            {
                var msg = new LogObject(data, additionalItems);
                log.Error(msg, ex);
            });
        }

        public static void Error<T>(this ILog log, string message, Exception ex, ITrackingValues trackingValues,
            T input)
        {
            var data = new { message, input };
            var additionalItems = GetAdditionalInfo(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString(), input);

            Task.Run(() =>
            {
                var msg = new LogObject(data, additionalItems);
                log.Error(msg, ex);
            });
        }
        public static void Error<T>(this ILog log, string message, Exception ex, T input)
        {
            var data = new { message, input };                   
            Task.Run(() =>
            {
                var msg = new LogObject(data);
                log.Error(msg, ex);
            });
        }
        private static GroupedItemsDictionary GetAdditionalInfo<T>(string trackingId, string correlationId, T input)
        {
            var inputVal = JsonConvert.SerializeObject(input);
            if (typeof(T).IsValueType || typeof(T).FullName == "System.String")
            {
                inputVal = input as string;
            }
            return GetAdditionItem(trackingId, correlationId, inputVal);
        }

        #endregion Error

        #region Info

        public static void Info(this ILog log, string message, ITrackingValues trackingValues)
        {
            var data = new
            {
                message
            };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString());
            Task.Run(() =>
            {
                var msg = new LogObject(data, additionalItems);
                log.Info(msg);
            });
        }

        public static void Info<T>(this ILog log, string message, ITrackingValues trackingValues, T input)
        {
            var data = new
            {
                message,
                input
            };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString());
            Task.Run(() =>
            {
                var msg = new LogObject(data, additionalItems);
                log.Info(msg);
            });
        }

        #endregion Info

        #region Debug

        public static void Debug(this ILog log, string message, ITrackingValues trackingValues)
        {
            var data = new
            {
                message
            };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString());
            Task.Run(() => log.Debug(new LogObject(data, additionalItems))).ConfigureAwait(false);
        }

        public static void Debug<T>(this ILog log, T model, string message, ITrackingValues trackingValues)
        {
            var data = new
            {
                message,
                model
            };
            var additionalItems = GetAdditionItem(trackingValues?.TrackingId.ToString(),
                trackingValues?.CorrelationId.ToString());

            Task.Run(() => log.Debug(new LogObject(data, additionalItems))).ConfigureAwait(false);
        }

        #endregion Debug

        private static GroupedItemsDictionary GetAdditionItem(string cdwTrackingId, string cdwCorrelationId)
        {
            var additionalInfo = new GroupedItemsDictionary();
            if (!string.IsNullOrEmpty(cdwCorrelationId))
            {
                additionalInfo.AddGroupItem("Tracking", CorrelationHeader, cdwCorrelationId);
            }
            if (!string.IsNullOrEmpty(cdwTrackingId))
            {
                additionalInfo.AddGroupItem("Tracking", TrackingHeader, cdwTrackingId);
            }
            return additionalInfo;
        }

        private static GroupedItemsDictionary GetAdditionItem(string cdwTrackingId, string cdwCorrelationId,
            string input)
        {
            var additionalInfo = new GroupedItemsDictionary();
            if (!string.IsNullOrEmpty(cdwCorrelationId))
            {
                additionalInfo.AddGroupItem("Tracking", CorrelationHeader, cdwCorrelationId);
            }
            if (!string.IsNullOrEmpty(cdwTrackingId))
            {
                additionalInfo.AddGroupItem("Tracking", TrackingHeader, cdwTrackingId);
            }
            if (!string.IsNullOrEmpty(input))
            {
                additionalInfo.AddGroupItem("InputRequest", "Input", input);
            }

            return additionalInfo;
        }
    }
}