﻿using System.IO;
using log4net.Util;
using Newtonsoft.Json;

namespace Cdw.Partners.Utilities
{
    public class MessagePatternConvertor : PatternConverter
    {
        protected override void Convert(TextWriter writer, object state)
        {
            var loggingEvent = state as log4net.Core.LoggingEvent;

            if (loggingEvent == null)
            {
                return;
            }
            if (loggingEvent.MessageObject.ToString().StartsWith("[{") || loggingEvent.MessageObject.ToString().StartsWith("{") && !loggingEvent.MessageObject.ToString().Replace(" ", "").StartsWith("{message="))
            {
                writer.Write(loggingEvent.MessageObject);
                return;
            }
            var jsonData = JsonConvert.SerializeObject(loggingEvent.MessageObject);
            writer.Write(jsonData);
        }
    }
}