﻿using System;

namespace Cdw.Partners.Utilities
{
    public class LogModel
    {
        public string Message { get; set; }
        public string CdwTrackingId { get; set; }
        public string CdwCorrelationId { get; set; }
        public DateTime Timestamp { get; set; }
        public int Level { get; set; }
        public string StackTrace { get; set; }
    }
}