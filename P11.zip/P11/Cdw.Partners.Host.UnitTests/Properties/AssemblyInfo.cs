using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cdw.Partners.Host.UnitTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CDW")]
[assembly: AssemblyProduct("Cdw.Partners.Host.UnitTests")]
[assembly: AssemblyCopyright("Copyright © CDW 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4fbee156-fc3c-4637-a1e0-3b8b12ee0142")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]