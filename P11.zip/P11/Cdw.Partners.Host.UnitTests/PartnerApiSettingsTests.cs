﻿using Xunit;

namespace Cdw.Partners.Host.UnitTests
{
    public class PartnerApiSettingsTests
    {
        [Fact]
        public void Ctor_ShouldFindAllAppSettignsAndSetValues()
        {
            // Arrange
            // app.config has been configured with approppriate apiSettings

            // Act
            var x = new PartnerApiSettings();

            // Assert
            Assert.Equal("base", x.Base.Name);
            Assert.Equal("csitecart", x.Csitecart.Name);
            Assert.Equal("gsitecart", x.Gsitecart.Name);
            Assert.Equal("casitecart", x.Casitecart.Name);
            Assert.Equal("orderstatus", x.OrderStatus.Name);
            Assert.Equal("product", x.ProductApi.Name);
            Assert.Equal("price", x.PriceApi.Name);
            Assert.Equal("search", x.SearchApi.Name);
            Assert.Equal("tax", x.TaxApi.Name);
            Assert.Equal("creditcard", x.CreditCardApi.Name);

           
        }
    }
}