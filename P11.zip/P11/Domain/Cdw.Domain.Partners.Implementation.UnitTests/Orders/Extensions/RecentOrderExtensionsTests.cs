﻿using Cdw.Domain.Partners.Implementation.Orders.Extensions;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Ecommerce.Domain.Order;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Extensions
{
    public class RecentOrderExtensionsTests
    {
        [Theory()]
        [InlineData("01", CompanyCode.Cdw)]
        [InlineData("02", CompanyCode.CdwG)]
        [InlineData("17", CompanyCode.CdwCa)]
        [InlineData("33", CompanyCode.Cdw)]
        public void CompanyCodeEnum_Pass_Tests(string code, CompanyCode expected)
        {
            //Arrange test
            var order = new RecentOrder().AssignFakeValues();
            order.CompanyCode = code;

            //Act test
            var result = order.CompanyCodeEnum();

            //Assert test
            Assert.Equal(result, expected);
        }
    }
}