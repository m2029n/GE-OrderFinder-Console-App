﻿using Cdw.Domain.Partners.Implementation.Orders.Extensions;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Extensions
{
    public class OrderExtensionsTests
    {
        [Theory(DisplayName = "OrderExtensions_HappyPath_Tests")]
        [InlineData("12345", 10, 100)]
        [InlineData(null, 1, 0)]
        [InlineData("not a valid code", 1, 0)]
        public void OrderExtensions_Pass_Tests(string productCode, decimal amount, decimal expectedResult)
        {
            //Arrange test
            var order = new Order().Fake();
            order.Cart = new Cart().Fake();

            //Act test
            var result = order.Quantity(productCode, amount);

            //Assert test
            Assert.Equal(expectedResult, result);
        }
    }
}