﻿using System;
using Cdw.Domain.Messaging;
using Cdw.Domain.Partners.Implementation.Orders;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Email;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders
{
    public class OrderCreatedHandlerTests
    {
        private OrderCreatedHandler _sut;
        private readonly Mock<IMessagingDomainManager> _messagingManager = new Mock<IMessagingDomainManager>();
        private readonly Mock<IEmailDomainManager> _emailDomainManager = new Mock<IEmailDomainManager>();
        private readonly Mock<ILog> _log = new Mock<ILog>();

        public OrderCreatedHandlerTests()
        {
            _sut = new OrderCreatedHandler(_messagingManager.Object, _emailDomainManager.Object, _log.Object);
        }

        [Fact]
        public void TestObject()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void TestObject_Handle_Should_fail_when_Source_null()
        {
            var order = new Order();
            var request = new OrderCreatedEvent(order);
            var actual = Assert.Throws<NullReferenceException>(() => _sut.Handle(request));
            Assert.NotNull(actual);
        }

        [Fact]
        public void TestObject_Handle_Should_fail_when_Source_has_no_name()
        {
            var order = new Order();
            order.Source = new OrderSource();
            var request = new OrderCreatedEvent(order);
            var actual = Assert.Throws<NullReferenceException>(() => _sut.Handle(request));
            Assert.NotNull(actual);
        }

        [Fact]
        public void TestObject_Handle_Should_fail_when_Cart_null()
        {
            var order = new Order();
            order.Source = new OrderSource { Name = "name" };
            var request = new OrderCreatedEvent(order);
            _sut.Handle(request);
            Assert.True(true);
        }

        [Fact]
        public void TestObject_Handle_Should_fail_when_Source_not_XDR()
        {
            var order = new Order().Fake();
            order.Cart = new Cart().Fake();
            order.Source = new OrderSource { Name = "name" };
            var request = new OrderCreatedEvent(order);
            _sut.Handle(request);
            Assert.True(true);
        }

        [Fact]
        public void TestObject_Handle_Should_fail_when_Source_XDR()
        {
            var order = new Order().Fake();
            order.Cart = new Cart().Fake();
            order.Source = new OrderSource { Name = "XDR" };
            var request = new OrderCreatedEvent(order);

            _sut.Handle(request);
            Assert.True(true);
        }
    }
}