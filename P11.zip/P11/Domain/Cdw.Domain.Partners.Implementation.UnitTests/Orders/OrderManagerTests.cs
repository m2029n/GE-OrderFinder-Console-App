﻿using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Ecommerce.Domain.Order;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Cdw.Partners.Utilities;
using Common.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using IOrderDetails = Cdw.Ecommerce.Domain.Order.IOrderDetails;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders
{
    public class OrderManagerTests
    {
        private readonly OrderManager _sut;

        private readonly Mock<ILog> _logger = new Mock<ILog>();

        private readonly Mock<IOrderDomainManager> _orderDomainManager = new Mock<IOrderDomainManager>();

        private readonly Mock<IProductManager> _productManager = new Mock<IProductManager>();

        private readonly Mock<IOrderCreateHelperService> _orderCreateHelperService = new Mock<IOrderCreateHelperService>();

        private readonly Mock<IGetAs400OrderDetailsService> _as400OrderDetailsService = new Mock<IGetAs400OrderDetailsService>();
        private readonly Mock<IPartnerConfigurationSettingsManager> _mockPartnerConfigurationSettingsManager = new Mock<IPartnerConfigurationSettingsManager>();

        //
        public OrderManagerTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());
            _sut = new OrderManager(_logger.Object, _orderDomainManager.Object, _productManager.Object, _orderCreateHelperService.Object, _as400OrderDetailsService.Object, _mockPartnerConfigurationSettingsManager.Object);
        }

        [Fact]
        public void OrderManager_NotNull_Test()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task GetOrderAsync_Passes_Test()
        {
            // Arrange
            var orderCode = "123";
            var sourceCode = "456";
            var orderNumber = "789";
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            var identity = new Identity { SourceCode = sourceCode };

            order.OrderNumber = orderNumber;

            _orderCreateHelperService.Setup(s => s.GetOrderDetails(orderCode, sourceCode)).Returns(Task.FromResult(order));
            _as400OrderDetailsService.Setup(s => s.Process(It.IsAny<Order>(), orderCode, It.IsAny<ITrackingValues>())).Verifiable();
            PartnerConfigurationSettings settings = new PartnerConfigurationSettings();
            settings.ClientName = "Black Box";
            settings.OrderManagerSettings = new OrderManagerSettings { SourceCode = sourceCode };

            _mockPartnerConfigurationSettingsManager.Setup(s => s.GetPartnerConfigurationSettingsByNameAsync("Black Box")).ReturnsAsync(settings);

            // Act
            var actual = await _sut.GetOrderAsync(orderCode, trackingValues, "Black Box").ConfigureAwait(false);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(actual.OrderNumber, orderNumber);
        }

        [Fact]
        public async Task GetOrderAsync_Passes_WhenOrderIsNotFound_Test()
        {
            // Arrange
            var orderCode = "123";
            var sourceCode = "456";
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            var identity = new Identity();
            identity.SourceCode = sourceCode;

            _orderCreateHelperService.Setup(s => s.GetOrderDetails(orderCode, sourceCode)).Returns(Task.FromResult((Order)null));
            _as400OrderDetailsService.Setup(s => s.Process(It.IsAny<Order>(), orderCode, It.IsAny<ITrackingValues>())).Verifiable();
            PartnerConfigurationSettings settings = new PartnerConfigurationSettings();
            settings.ClientName = "Black Box";
            settings.OrderManagerSettings = new OrderManagerSettings { SourceCode = sourceCode };

            _mockPartnerConfigurationSettingsManager.Setup(s => s.GetPartnerConfigurationSettingsByNameAsync("Black Box")).ReturnsAsync(settings);

            // Act
            var actual = await _sut.GetOrderAsync(orderCode, trackingValues, "Black Box").ConfigureAwait(false);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task CreateOrderAsync_Passes_WhenNoRequest_Async()
        {
            //Arrange test
            SetupMocks(null, null, null, 0, null, null, null);

            //Act test
            var actual = await _sut.CreateOrderAsync(null).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public async Task CreateOrderAsync_Passes_WhenNoOrder_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            SetupMocks(null, null, null, 0, null, null, null);

            //Act test
            var actual = await _sut.CreateOrderAsync(request).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public async Task CreateOrderAsync_Passes_WhenNoTaxFound_Test()
        {
            //Arrange test

            IRequestOrder request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            var oder = new Order().Fake();
            var shippingInfo = new ShippingInfo().Fake();
            SetupMocks(oder, null, shippingInfo, 0, null, null, null);

            //Act test
            var actual = await _sut.CreateOrderAsync(request).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public async Task CreateOrderAsync_Passes_WhenNoShippingFound_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            IEnumerable<Partners.Orders.Tax> taxes = new List<Partners.Orders.Tax>() { new Partners.Orders.Tax().Fake() };

            var oder = new Order().Fake();
            SetupMocks(oder, null, null, 0, taxes, null, null);

            //Act test
            var actual = await _sut.CreateOrderAsync(request).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public async Task CreateOrder_ShouldCreateOrderSourceCustomProperty_WhenRqstCustomPropertiesNull()
        {
            // Arrange
            var fakeRequest = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            SetupMocks(null, null, null, 0, null, null, null);
            IRequestOrder actualRequest = null;
            _orderCreateHelperService.Setup(x => x.ProcessCreditCardAsync(fakeRequest, It.IsAny<Action>()))
                .Callback<IRequestOrder, Action>((req, action) =>
            {
                actualRequest = req;
            }).Returns(() => Task.FromResult<ICreditCardAuthorizationResponse>(new CreditCardAuthorizationResponse()));

            // Act
            var actual = await _sut.CreateOrderAsync(fakeRequest).ConfigureAwait(false);

            // Assert
            Assert.NotNull(actualRequest);

            var customProperty = actualRequest.CustomProperties.SingleOrDefault(x => x.Name == "OrderSource");
            Assert.Equal("OrderSource", customProperty.Name);
            Assert.Equal("XDR", customProperty.Value);
        }

        [Fact]
        public async Task CreateOrder_ShouldConcatOrderSourceCustomProperty_WhenRqstCustomPropertiesNotNull()
        {
            // Arrange
            var fakeRequest = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            fakeRequest.CustomProperties.ToList().Add(new CustomProperty { Name = "ABC", Value = "123" });
            SetupMocks(null, null, null, 0, null, null, null);
            IRequestOrder actualRequest = null;
            _orderCreateHelperService.Setup(x => x.ProcessCreditCardAsync(fakeRequest, It.IsAny<Action>()))
                                     .Callback<IRequestOrder, Action>((req, action) =>
                                     {
                                         actualRequest = req;
                                     }).Returns(() => Task.FromResult<ICreditCardAuthorizationResponse>(new CreditCardAuthorizationResponse()));

            // Act
            var actual = await _sut.CreateOrderAsync(fakeRequest).ConfigureAwait(false);

            // Assert
            Assert.NotNull(actualRequest);
            Assert.Equal(2, actualRequest.CustomProperties.Count());
        }

        [Fact]
        public async void CreateOrder_CompanyCode_Validation()
        {
            // Arrange
            SetupMocks(null, null, null, 0, null, null, null);

            var request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            request.Company = 999999;

            // Act
            var ex = await Assert.ThrowsAsync<ApplicationException>(() => _sut.CreateOrderAsync(request));

            // Assert
            Assert.Equal("Invalid Company Details", ex.Message);
        }

        [Fact]
        public async Task CreateOrderAsync_Passes_Test()
        {
            // Arrange
            var request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            var taxes = new List<Partners.Orders.Tax>() { new Partners.Orders.Tax().Fake() };
            var shippingInfo = new ShippingInfo().Fake();
            var ordercode = "213";
            var sourceCode = "456";
            var oder = new Order().Fake();
            request.PartnerSourceCode = sourceCode;

            SetupMocks(oder, null, shippingInfo, 16, taxes, ordercode, sourceCode);
            var settings = new PartnerConfigurationSettings
            {
                ClientName = "Black Box",
                CompanyCode = 1000,
                OrderManagerSettings = new OrderManagerSettings { SourceCode = sourceCode }
            };
            request.ClientName = "Black Box";
            _mockPartnerConfigurationSettingsManager.Setup(s => s.GetPartnerConfigurationSettingsByNameAsync("Black Box")).ReturnsAsync(settings);

            // Act
            var actual = await _sut.CreateOrderAsync(request).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(actual.Total, 20);
            Assert.Equal(actual.OrderNumber, ordercode);
        }
        [Fact]
        public async Task CreateOrderWithFailedGetAsync_Passes_Test()
        {
            // Arrange
            var request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            var taxes = new List<Partners.Orders.Tax>() { new Partners.Orders.Tax().Fake() };
            var shippingInfo = new ShippingInfo().Fake();
            var orderNumber = "213";
            var sourceCode = "456";
            var oder = new Order().Fake();
            request.PartnerSourceCode = sourceCode;

            SetupMocks(oder, null, shippingInfo, 16, taxes, orderNumber, sourceCode);
            _orderCreateHelperService.Setup(s => s.GetOrderDetails(orderNumber, sourceCode)).Throws(new Exception("some exception"));

            var settings = new PartnerConfigurationSettings
            {
                ClientName = "Black Box",
                CompanyCode = 1000,
                OrderManagerSettings = new OrderManagerSettings { SourceCode = sourceCode }
            };
            request.ClientName = "Black Box";
            _mockPartnerConfigurationSettingsManager.Setup(s => s.GetPartnerConfigurationSettingsByNameAsync("Black Box")).ReturnsAsync(settings);

            // Act
            var actual = await _sut.CreateOrderAsync(request).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(100, actual.Total);
            Assert.Equal(orderNumber, actual.OrderNumber);
        }
        [Fact]
        public async void SearchOrderAsync_Passes_WhenNoOrderFound_Test()
        {
            //Arrange
            var trackingValues = new Mock<ITrackingValues>().Object;
            const string customerNumber = "123";
            const string poNumber = "abc";
            _orderDomainManager.Setup(s => s.GetOrderHeaderByPONumber(customerNumber, poNumber)).Returns(Task.FromResult((IRecentOrder)null));

            //Act
            var actual = await _sut.SearchOrderAsync(customerNumber, poNumber, trackingValues).ConfigureAwait(false);

            //Assert
            Assert.Null(actual);
        }

        [Fact]
        public async void SearchOrderAsync_Passes_WhenNoOrderDetailsFound_Test()
        {
            //Arrange
            var trackingValues = new Mock<ITrackingValues>().Object;
            IRecentOrder order = new RecentOrder().AssignFakeValues();
            const string customerNumber = "123";
            const string poNumber = "abc";
            const string orderCode = "xyz";
            order.OrderCode = orderCode;

            _orderDomainManager.Setup(s => s.GetOrderHeaderByPONumber(customerNumber, poNumber)).Returns(Task.FromResult(order));
            _orderDomainManager.Setup(s => s.GetOrderDetails(It.IsAny<CompanyCode>(), orderCode, It.IsAny<DataMap>())).Returns(Task.FromResult((IOrderDetails)null));

            //Act
            var actual = await _sut.SearchOrderAsync(customerNumber, poNumber, trackingValues).ConfigureAwait(false);

            //Assert
            Assert.Null(actual);
        }

        [Fact]
        public async void SearchOrderAsync_Passes_Test()
        {
            //Arrange
            var trackingValues = new Mock<ITrackingValues>().Object;
            IRecentOrder order = new RecentOrder().AssignFakeValues();
            var orderDetails = FakerOrderDetails.GetOrderDetails();
            var products = new List<IProductCore>() { new FakeProductCode().GetFakeObject("070807") }.AsEnumerable();
            const string customerNumber = "123";
            const string poNumber = "abc";
            const string orderCode = "xyz";
            var productCodes = orderDetails.LineItems.Select(x => x.ProductCode).ToList();
            order.OrderCode = orderCode;

            _orderDomainManager.Setup(s => s.GetOrderHeaderByPONumber(customerNumber, poNumber)).Returns(Task.FromResult(order));
            _orderDomainManager.Setup(s => s.GetOrderDetails(It.IsAny<CompanyCode>(), orderCode, It.IsAny<DataMap>())).Returns(Task.FromResult(orderDetails));
            _productManager.Setup(s => s.GetProductsAsync(productCodes, CdwCompany.CDW.Description())).Returns(Task.FromResult(products));

            //Act
            var actual = await _sut.SearchOrderAsync(customerNumber, poNumber, trackingValues).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
        }

        private void SetupMocks(Order order, ICreditCardAuthorizationResponse creditCardResponse, ShippingInfo shippingInfo, decimal recyclingFee,
            IEnumerable<Partners.Orders.Tax> taxes, string orderNumber, string sourceCode)
        {
            var partnerConfigurationSettings = new PartnerConfigurationSettings
            {
                CompanyCode = 1000,
                OrderManagerSettings = new OrderManagerSettings
                {
                    SourceCode = "XDR"
                }
            };
            _mockPartnerConfigurationSettingsManager.Setup(x => x.GetPartnerConfigurationSettingsByNameAsync(FakeHelper.ClientName)).ReturnsAsync(partnerConfigurationSettings);

            _orderCreateHelperService.Setup(s => s.ProcessCreditCardAsync(It.IsAny<IRequestOrder>(), It.IsAny<Action>())).ReturnsAsync(creditCardResponse);

            _orderCreateHelperService.Setup(s => s.ValidateTerms(It.IsAny<IRequestOrder>(), It.IsAny<Action>())).Verifiable();

            _orderCreateHelperService.Setup(s => s.CheckUniqueReferenceNumber(It.IsAny<IRequestOrder>())).Verifiable();

            _orderCreateHelperService.Setup(s => s.GetOrderFromRequest(It.IsAny<IRequestOrder>())).Returns(order);

            _orderCreateHelperService.Setup(s => s.InsertPaymentInformation(It.IsAny<Order>(), It.IsAny<ITrackingValues>(), It.IsAny<ICreditCardAuthorizationResponse>(), It.IsAny<string>())).Verifiable();

            _orderCreateHelperService.Setup(s => s.GetShippingInfoAsync(It.IsAny<Order>(), It.IsAny<IRequestOrder>(), It.IsAny<ITrackingValues>(), It.IsAny<Action>())).Returns(Task.FromResult(shippingInfo));

            _orderCreateHelperService.Setup(s => s.GetRecyclingFeeAsync(It.IsAny<Order>(), It.IsAny<Action>())).Returns(Task.FromResult(recyclingFee));

            _orderCreateHelperService.Setup(s => s.GetTaxesAsync(It.IsAny<Order>(), It.IsAny<ITrackingValues>(), It.IsAny<Action>())).Returns(Task.FromResult(taxes));

            _orderCreateHelperService.Setup(s => s.InsertOrder(It.IsAny<Order>(), It.IsAny<IRequestOrder>())).Returns(orderNumber);
           
            _orderCreateHelperService.Setup(s => s.RaiseDomainEvents(It.IsAny<Order>(), It.IsAny<IRequestOrder>(), It.IsAny<ITrackingValues>(), It.IsAny<Action>())).Verifiable();

            if (order != null)
            {
                order.OrderNumber = orderNumber;
            }
            _orderCreateHelperService.Setup(s => s.GetOrderDetails(orderNumber, sourceCode)).Returns(Task.FromResult(order));

            _as400OrderDetailsService.Setup(s => s.Process(It.IsAny<Order>(), orderNumber, It.IsAny<ITrackingValues>())).Verifiable();
        }
    }
}