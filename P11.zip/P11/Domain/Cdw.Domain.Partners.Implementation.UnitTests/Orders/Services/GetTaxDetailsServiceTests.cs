﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Clients.Tax;
using Cdw.Security.OAuth2.Client;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class GetTaxDetailsServiceTests
    {
        private readonly GetTaxDetailsService _sut;
        private readonly Mock<ILog> _logMoq = new Mock<ILog>();
        private readonly Mock<ITaxRequestClientDomainManager> _taxRequestDomainManagerMoq = new Mock<ITaxRequestClientDomainManager>();
        private readonly Order _order;
        private readonly ITrackingValues _trackingValues;

        public GetTaxDetailsServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());
            _sut = new GetTaxDetailsService(_logMoq.Object, _taxRequestDomainManagerMoq.Object);
            _order = new Order().Fake();
            _trackingValues = new FakeTrackingValues().GetFakeObject();
        }

        [Fact]
        public void GetTaxDetailsService_NotNull_Test()
        {
            //Assert test
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task GetTaxesAsync_Passes_WithTaxes_Test()
        {
            //Arrange test
            ITaxResponse itaxentity = new FakeTaxResponse().GetFakeObject();
            _taxRequestDomainManagerMoq.Setup(s => s.GetTaxLinesAsync(It.IsAny<ITaxRequest>())).Returns(Task.FromResult(itaxentity));

            //Act test
            var result = await _sut.ProcessAsync(_order, _trackingValues).ConfigureAwait(false);

            //Assert test
            Assert.NotNull(result);
            Assert.True(result.Any());
        }

        [Fact]
        public void GetTaxesAsync_ThrowsException_WhenTaxRequestDomainManagerHasCDWException_Test()
        {
            //Arrange test
            var exception = FormatterServices.GetUninitializedObject(typeof(CdwHttpException)) as CdwHttpException;
            _taxRequestDomainManagerMoq.Setup(s => s.GetTaxLinesAsync(It.IsAny<ITaxRequest>())).Throws(exception);

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _trackingValues).ConfigureAwait(false));

            //Assert test
            Assert.NotNull(result);
            Assert.NotNull(result.Exception);
        }

        [Fact]
        public void GetTaxesAsync_ThrowsException_WhenaxRequestDomainManagerHasGenericException_Test()
        {
            //Arrange test
            _taxRequestDomainManagerMoq.Setup(s => s.GetTaxLinesAsync(It.IsAny<ITaxRequest>())).Throws(new Exception());

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _trackingValues).ConfigureAwait(false));

            //Assert test
            Assert.NotNull(result);
            Assert.NotNull(result.Result);
            Assert.NotNull(result.Result.Message);
            Assert.Equal(result.Result.Message, "Exception of type 'System.Exception' was thrown.");
        }
    }
}