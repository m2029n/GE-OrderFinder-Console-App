﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Implementation.UnitTests.MockObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Partners.Validation;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class PartnerOrderServiceTests
    {
        private readonly PartnerOrderService _sut;
        private readonly Mock<IPartnerOrderRepository> _partnerOrderRepositoryMoq = new Mock<IPartnerOrderRepository>();
        private readonly Mock<ILog> _logMoq = new Mock<ILog>();

        public PartnerOrderServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());
            _sut = new PartnerOrderService(_partnerOrderRepositoryMoq.Object, _logMoq.Object);
        }

        [Fact]
        public void PartnerOrderService_NotNull_Test()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void CheckUniqueReferenceNumber_Passes_WhenUnique_Test()
        {
            // Arrange
            var sourceCode = "123";
            var referenceNumber = "abc";
            _partnerOrderRepositoryMoq.Setup(x => x.UniqueReferenceNumber(sourceCode, referenceNumber)).Returns(true);

            var request = FakeHelper.GetFakeRequestorderFakeObject();
            request.PartnerSourceCode = sourceCode;
            request.ReferenceNumber = referenceNumber;

            // Act
            _sut.CheckUniqueReferenceNumber(request);

            // Assert
            Assert.True(true);
        }

        [Fact]
        public void CheckUniqueReferenceNumber_ThrowsExeption_WhenNotUnique_Test()
        {
            // Arrange
            var sourceCode = "123";
            var referenceNumber = "abc";
            _partnerOrderRepositoryMoq.Setup(x => x.UniqueReferenceNumber(sourceCode, referenceNumber)).Returns(false);
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            request.PartnerSourceCode = sourceCode;
            request.ReferenceNumber = referenceNumber;

            // Act
            var ex = Assert.Throws<OrderValidationException>(() => _sut.CheckUniqueReferenceNumber(request));

            // Assert
            Assert.NotNull(ex);
        }

        [Fact]
        public void ValidateTerms_ThrowsException_WhenTermNotAllowed_Test()
        {
            // Arrange
            var sourceCode = "123";
            var term = "abc";
            _partnerOrderRepositoryMoq.Setup(x => x.IsTermsAllowed(sourceCode, term)).Returns(false);

            // Act
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            request.PartnerSourceCode = sourceCode;
            request.Billing.Method.Terms = term;

            // Assert
            Assert.Throws<OrderValidationException>(() => _sut.ValidateTerms(request));
        }

        [Fact]
        public void ValidateTerms_Passes_WhenTermIsAllowed_Test()
        {
            // Arrange
            var sourceCode = "123";
            var term = "abc";
            _partnerOrderRepositoryMoq.Setup(x => x.IsTermsAllowed(sourceCode, term)).Returns(true);
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            request.PartnerSourceCode = sourceCode;
            request.Billing.Method.Terms = term;

            // Act
            var actual = _sut.ValidateTerms(request);

            // Assert
            Assert.True(actual);
        }

        [Fact]
        public void GetProductEntities_Passes_Test()
        {
            //Arrange test
            var lookUpList = new List<string>() { "3378793" };
            var expectedList = new List<ProductEntity>() { MockHelper.MockProductEntityObject(123) };

            _partnerOrderRepositoryMoq.Setup(x => x.GetProduct(lookUpList)).Returns(expectedList);

            //Act test
            var actual = _sut.GetProductEntities(lookUpList);

            //Assert test
            Assert.Equal(expectedList.Count, actual.ToList().Count);
        }

        [Fact]
        public async Task GetShippingMethodPropertyAsync_Passes_Test()
        {
            //Arrange test
            var clientName = "abc";
            var shippingMehod = "123";
            var shippingMethod = "Test";

            var expectedEntity = new ShippingMethodPropertiesEntity
            {
                FreeShippingMethod = shippingMethod
            };
            _partnerOrderRepositoryMoq.Setup(x => x.GetShippingMethodProperty(clientName, shippingMehod)).Returns(Task.FromResult(expectedEntity));

            //Act test
            var actual = await _sut.GetShippingMethodPropertyAsync(clientName, shippingMehod).ConfigureAwait(false);

            //Assert test
            Assert.Equal(actual.FreeShippingMethod, shippingMethod);
        }

        [Fact]
        public void InsertCart_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var cartEntity = MockHelper.MockCartEntityObject(123);
            cartEntity.CartID = 123;
            _partnerOrderRepositoryMoq.Setup(x => x.InsertApiCarts(It.IsAny<CartEntity>())).Returns(cartEntity);

            //Act test
            _sut.InsertCart(order);

            //Assert test
            Assert.NotNull(order);
        }

        [Fact]
        public void InsertPaymentInformation_Passes_WhenCreaditCardIsNull_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            string authCreditCardToken = "";
            //Act test
            _sut.InsertPaymentInformation(order, trackingValues, null, authCreditCardToken);

            //Assert test
            Assert.True(true);
        }

        [Fact]
        public void InsertPaymentInformation_Passes_Test()
        {
            //Arrange test
            var ccTocken = "123";
            ICreditCardAuthorizationResponse creditCardResponse = new FakeCreditCardAuthorizationResponse();
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            var fakeCcCardEntity = MockHelper.MockCreditCardEntityObject();
            fakeCcCardEntity.CreditCardToken = ccTocken;
            _partnerOrderRepositoryMoq.Setup(s => s.GetCreditCardByToken(ccTocken)).Returns(fakeCcCardEntity);

            //Act test
            _sut.InsertPaymentInformation(order, trackingValues, creditCardResponse, null);

            //Assert test
            Assert.Equal(order.Billing.Method.CreditCard.Token, fakeCcCardEntity.CreditCardToken);
        }

        [Fact]
        public void InsertPaymentInformation_ThrowsException_WhenRepositoryThrowsAggregateException_Test()
        {
            //Arrange test

            ICreditCardAuthorizationResponse creditCardResponse = new FakeCreditCardAuthorizationResponse();
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            string authCreditCardTOken = null;
            _partnerOrderRepositoryMoq.Setup(s => s.GetCreditCardByToken(It.IsAny<string>())).Throws(new AggregateException("AggregateException raised"));

            //Act test
            var actual = Assert.Throws<AggregateException>(() => _sut.InsertPaymentInformation(order, trackingValues, creditCardResponse, authCreditCardTOken));

            //Assert test
            Assert.NotNull(actual);
            Assert.NotNull(actual.Message);
            Assert.Equal(actual.Message, "AggregateException raised");
        }

        [Fact]
        public void InsertPaymentInformation_ThrowsException__WhenRepositoryThrowsException_Test()
        {
            //Arrange test

            ICreditCardAuthorizationResponse creditCardResponse = new FakeCreditCardAuthorizationResponse();
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            string authCreditCardToken = null;

            _partnerOrderRepositoryMoq.Setup(s => s.GetCreditCardByToken(It.IsAny<string>())).Throws(new Exception("Exception raised"));

            //Act test
            var actual = Assert.Throws<Exception>(() => _sut.InsertPaymentInformation(order, trackingValues, creditCardResponse, authCreditCardToken));

            //Assert test
            Assert.NotNull(actual);
            Assert.NotNull(actual.Message);
            Assert.Equal(actual.Message, "Exception raised");
        }

        [Fact]
        public void InsertOrder_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var request = FakeHelper.GetFakeRequestorderFakeObject();

            var fake = new OrderEntity().AssignFakeValues();
            _partnerOrderRepositoryMoq.Setup(s => s.Create(It.IsAny<OrderEntity>())).Returns(fake);

            //Act test
            var actual = _sut.InsertOrder(order, request);

            //Assert test
            Assert.Equal(actual, fake.OrderCode);
        }

        [Fact]
        public void GetPaymentCode_Passes_Test()
        {
            //Arrange test
            var orderSource = "123";
            var paymentMethod = "abc";
            var fake = new TermsEntity().AssignFakeValues();
            _partnerOrderRepositoryMoq.Setup(s => s.GetPaymentMethodDetails(orderSource, paymentMethod)).Returns(fake);

            //Act test
            var actual = _sut.GetPaymentCode(orderSource, paymentMethod);

            //Assert test
            Assert.Equal(actual, fake.PaymentCode);
        }

        [Fact]
        public void GetPaymentCode_Passes_WhenRepositoryReturnsNoDetails_Test()
        {
            //Arrange test
            var orderSource = "123";
            var paymentMethod = "abc";
            _partnerOrderRepositoryMoq.Setup(s => s.GetPaymentMethodDetails(orderSource, paymentMethod)).Returns((TermsEntity)null);

            //Act test
            var actual = _sut.GetPaymentCode(orderSource, paymentMethod);

            //Assert test
            Assert.Equal(actual, "");
        }

        [Fact]
        public void GetAuthCreditCardToken_Passes_Test()
        {
            //Arrange test
            var transactionId = "70EAB72E-7A92-4DF6-AA33-143719B9BD31";
            var referenceNumber = "47A2957A-8905-4C02-9526-AAAD9129306C";
            var authCreditCardToken = "89B2957A-8905-5C02-9526-XXAD9129306C";
            _partnerOrderRepositoryMoq.Setup(s => s.GetAuthCreditCardToken(transactionId, referenceNumber))
                                                    .Returns(authCreditCardToken);

            //Act test
            var actual = _sut.GetAuthCreditCardToken(transactionId, referenceNumber);
            //Assert test
            Assert.Equal(actual, authCreditCardToken);
        }

        [Fact]
        public void GetAuthCreditCardToken_ThrowsOrderValidationException_WhenRepositoryReturnsNull()
        {
            //Arrange test
            var transactionId = "70EAB72E-7A92-4DF6-AA33-143719B9BD31";
            var referenceNumber = "47A2957A-8905-4C02-9526-AAAD9129306C";

            _partnerOrderRepositoryMoq.Setup(s => s.GetAuthCreditCardToken(transactionId, referenceNumber))
                .Returns((string)null);

            //Act test
            var result = Assert.Throws<OrderValidationException>(() => _sut.GetAuthCreditCardToken(transactionId, referenceNumber));
            //Assert test
            Assert.Equal("The given TransactionId or ReferenceNumber or both are incorrect.", result.Failures.FirstOrDefault()?.Message);
        }

        [Fact]
        public void GetAuthCreditCardToken_ThrowsOrderValidationException_WhenRepositoryReturnsEmptyString()
        {
            //Arrange test
            var transactionId = "70EAB72E-7A92-4DF6-AA33-143719B9BD31";
            var referenceNumber = "47A2957A-8905-4C02-9526-AAAD9129306C";

            _partnerOrderRepositoryMoq.Setup(s => s.GetAuthCreditCardToken(transactionId, referenceNumber))
                .Returns(string.Empty);

            //Act test
            var actual = Assert.Throws<OrderValidationException>(() => _sut.GetAuthCreditCardToken(transactionId, referenceNumber));
            //Assert test
            Assert.Equal("The given TransactionId or ReferenceNumber or both are incorrect.", actual.Failures.FirstOrDefault()?.Message);
        }

        [Fact]
        public void IsUploadedToAs400_Passes_WhenreRepoHasANUll_Test()
        {
            //Arrange test
            var orderCode = "123";
            _partnerOrderRepositoryMoq.Setup(s => s.IsUploadedToAs400(orderCode)).Returns((bool?)null);

            //Act test
            var actual = _sut.IsUploadedToAs400(orderCode);

            //Assert test
            Assert.Equal(actual, false);
        }

        [Fact]
        public void IsUploadedToAs400_Passes_WhenRepoHasAFalse_Test()
        {
            //Arrange test
            var orderCode = "123";
            _partnerOrderRepositoryMoq.Setup(s => s.IsUploadedToAs400(orderCode)).Returns(false);

            //Act test
            var actual = _sut.IsUploadedToAs400(orderCode);

            //Assert test
            Assert.Equal(actual, false);
        }

        [Fact]
        public void IsUploadedToAs400_Passes_WhenRepoHasTrue_Test()
        {
            //Arrange test
            var orderCode = "123";
            _partnerOrderRepositoryMoq.Setup(s => s.IsUploadedToAs400(orderCode)).Returns(true);

            //Act test
            var actual = _sut.IsUploadedToAs400(orderCode);

            //Assert test
            Assert.Equal(actual, true);
        }

        [Fact]
        public void GetOrderDetails_Passes_WhenNoOrderEntityFound_Test()
        {
            //Arrange test
            var orderCode = "123";
            var sourceCode = "abc";
            _partnerOrderRepositoryMoq.Setup(s => s.GetOrderEntity(orderCode, sourceCode)).Returns((OrderEntity)null);

            //Act test
            var actual = _sut.GetOrderDetails(orderCode, sourceCode);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public void GetOrderDetails_Passes_Test()
        {
            //Arrange test
            var cartId = 555;
            var orderCode = "123";
            var sourceCode = "abc";
            var productId = 123;
            var tocken = 1000;

            OrderEntity orderEntity = MockHelper.MockOrderEntityObject(orderCode);
            orderEntity.CartID = cartId;

            var cartEntity = MockHelper.MockCartEntityObject(cartId);
            var ccEntity = MockHelper.MockCreditCardEntityObject();
            ccEntity.CreditCardTokenID = tocken;
            var expectedList = new List<ProductEntity>() { MockHelper.MockProductEntityObject(productId) };
            var codes = cartEntity.CartItems.Select(li => li.ProductId).Distinct().ToList();

            _partnerOrderRepositoryMoq.Setup(s => s.GetOrderEntity(orderCode, sourceCode)).Returns(orderEntity);
            _partnerOrderRepositoryMoq.Setup(s => s.GetCartEntity(cartId)).Returns(cartEntity);
            _partnerOrderRepositoryMoq.Setup(s => s.GetCreditCardById(tocken)).Returns(ccEntity);
            _partnerOrderRepositoryMoq.Setup(x => x.GetProduct(codes)).Returns(expectedList);

            //Act test
            var actual = _sut.GetOrderDetails(orderCode, sourceCode);

            //Assert test
            Assert.NotNull(actual);
            Assert.Equal(actual.ReferenceNumber, orderEntity.ReferenceNumber);
        }

        [Fact]
        public void GetOrderDetails_ThrowsException_WhenProductsDoNotMatch_Test()
        {
            //Arrange test
            var cartId = 555;
            var orderCode = "123";
            var sourceCode = "abc";
            var productId = 456;
            OrderEntity orderEntity = MockHelper.MockOrderEntityObject(orderCode);
            var cartEntity = MockHelper.MockCartEntityObject(cartId);
            orderEntity.CartID = cartId;

            MockHelper.MockCreditCardEntityObject();
            var expectedList = new List<ProductEntity>() { MockHelper.MockProductEntityObject(productId) };
            var codes = cartEntity.CartItems.Select(li => li.ProductId).Distinct().ToList();

            _partnerOrderRepositoryMoq.Setup(s => s.GetOrderEntity(orderCode, sourceCode)).Returns(orderEntity);
            _partnerOrderRepositoryMoq.Setup(s => s.GetCartEntity(cartId)).Returns(cartEntity);
            _partnerOrderRepositoryMoq.Setup(x => x.GetProduct(codes)).Returns(expectedList);

            //Act test
            var actual = Assert.Throws<KeyNotFoundException>(() => _sut.GetOrderDetails(orderCode, sourceCode));

            //Assert test
            Assert.NotNull(actual);
            Assert.NotNull(actual.Message);
            Assert.StartsWith("The given key was not", actual.Message);
        }

        [Fact]
        public void GetOrderDetails_ThrowsException_WhenNoValidProducts_Test()
        {
            //Arrange test
            var cartId = 123;
            var orderCode = "123";
            var sourceCode = "abc";
            OrderEntity orderEntity = MockHelper.MockOrderEntityObject(orderCode);
            var cartEntity = MockHelper.MockCartEntityObject(cartId);
            orderEntity.CartID = cartId;

            var codes = cartEntity.CartItems.Select(li => li.ProductId).Distinct().ToList();
            _partnerOrderRepositoryMoq.Setup(s => s.GetOrderEntity(orderCode, sourceCode)).Returns(orderEntity);
            _partnerOrderRepositoryMoq.Setup(s => s.GetCartEntity(cartId)).Returns(cartEntity);
            _partnerOrderRepositoryMoq.Setup(x => x.GetProduct(codes)).Returns((List<ProductEntity>)null);

            //Act test
            var actual = Assert.Throws<ArgumentNullException>(() => _sut.GetOrderDetails(orderCode, sourceCode));

            //Assert test
            Assert.NotNull(actual);
            Assert.NotNull(actual.Message);
            Assert.StartsWith("Value cannot be null", actual.Message);
        }
    }
}