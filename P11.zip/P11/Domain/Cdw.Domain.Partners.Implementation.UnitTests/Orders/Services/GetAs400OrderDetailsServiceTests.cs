﻿using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Orders.Infrastructure;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Implementation.UnitTests.MockObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.Services;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class GetAs400OrderDetailsServiceTests
    {
        private readonly GetAs400OrderDetailsService _sut;
        private readonly Mock<IAS400OrderDetails> _as400OrderDetails = new Mock<IAS400OrderDetails>();
        private readonly Mock<IOrdersWebService> _ordersWebService = new Mock<IOrdersWebService>();
        private readonly Mock<ILog> _logger = new Mock<ILog>();
        private readonly Mock<IPartnerOrderService> _partnerOrderService = new Mock<IPartnerOrderService>();

        public GetAs400OrderDetailsServiceTests()
        {
            _sut = new GetAs400OrderDetailsService(_logger.Object, _partnerOrderService.Object, _ordersWebService.Object, _as400OrderDetails.Object);
        }

        [Fact]
        public void GetAs400OrderDetailsService_NotNull_Test()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void Process_Passes_Test()
        {
            //Arrange test
            Order order = new Order().Fake();
            var orderCode = "123";
            IOrderDetail orderDetail = MockHelper.MockOrderDetailObject(orderCode);
            order.OrderNumber = orderCode;
            ITrackingValues trackingValues = new FakeTrackingValues().GetFakeObject();

            _partnerOrderService.Setup(s => s.IsUploadedToAs400(orderCode)).Returns(true);
            _ordersWebService.Setup(s => s.GetOrderDetailByOrderCode(orderCode)).Returns(orderDetail);

            //Act test
            _sut.Process(order, orderCode, trackingValues);

            //Assert test
            Assert.True(true);
        }
    }
}