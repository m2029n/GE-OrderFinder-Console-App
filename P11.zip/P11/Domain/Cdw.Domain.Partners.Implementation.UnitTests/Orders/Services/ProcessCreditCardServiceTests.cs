﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Common.Logging;
using Moq;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class ProcessCreditCardServiceTests
    {
        private readonly ProcessCreditCardService _sut;
        private readonly Mock<ILog> _logMoq = new Mock<ILog>();

        private readonly Mock<ICreditCardServiceDomainManager> _creditCardServiceDomainManagerMoq =
            new Mock<ICreditCardServiceDomainManager>();

        private readonly Mock<IPartnerSettings> _partnerSettingsMoq = new Mock<IPartnerSettings>();

        public ProcessCreditCardServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());

            _sut = new ProcessCreditCardService(_logMoq.Object, _creditCardServiceDomainManagerMoq.Object,
                _partnerSettingsMoq.Object);
        }

        [Fact]
        public void ValidateCreditCard_Passes_Test()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            var cc = request.Billing.Method.CreditCard.Number;
            var key = _partnerSettingsMoq.Object.CreditCardAPIKey;
            _creditCardServiceDomainManagerMoq.Setup(x => x.EncryptAsync(cc, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = true,
                CreditCardToken = Guid.NewGuid().ToString()
            };

            _creditCardServiceDomainManagerMoq.Setup(x => x.AuthorizeAsync(It.IsAny<ICreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            //Act test
            var response = _sut.ProcessAsync(request);

            //Assert test
            Assert.NotNull(response);
        }

        [Fact]
        public async Task ValidateCreditCard_ThrowsException_WhenE1000_Test()
        {
            //Arrange test

            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            var request = FakeHelper.GetFakeRequestorderFakeObject();

            var cc = request.Billing.Method.CreditCard.Number;
            var key = _partnerSettingsMoq.Object.CreditCardAPIKey;
            _creditCardServiceDomainManagerMoq.Setup(x => x.EncryptAsync(cc, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = false,
                CreditCardToken = Guid.NewGuid().ToString(),
                ErrorCode = "E1000",
                ErrorMessage = "invalid Credit Card"
            };
            _creditCardServiceDomainManagerMoq.Setup(x => x.AuthorizeAsync(It.IsAny<ICreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            //Act test
            var ex = await Assert.ThrowsAsync<OrderValidationException>(async () => await _sut.ProcessAsync(request).ConfigureAwait(false));

            //Assert test
            Assert.True(ex.Failures.Any());
            Assert.Equal(ex.Failures.First().Field, "CreditCard");
            Assert.Equal(ex.Failures.First().Message, "invalid Credit Card");
        }

        [Fact]
        public async Task ValidateCreditCard_ThrowsException_WhenE2000_Test()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            var cc = request.Billing.Method.CreditCard.Number;
            var key = _partnerSettingsMoq.Object.CreditCardAPIKey;
            _creditCardServiceDomainManagerMoq.Setup(x => x.EncryptAsync(cc, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = false,
                CreditCardToken = Guid.NewGuid().ToString(),
                ErrorCode = "E2000",
                ErrorMessage = "invalid expiry date"
            };
            _creditCardServiceDomainManagerMoq.Setup(x => x.AuthorizeAsync(It.IsAny<ICreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            //Act test
            var ex = await Assert.ThrowsAsync<OrderValidationException>(async () => await _sut.ProcessAsync(request).ConfigureAwait(false));

            //Assert test
            Assert.True(ex.Failures.Any());
            Assert.Equal(ex.Failures.First().Field, "CreditCard");
            Assert.Equal(ex.Failures.First().Message, "invalid expiry date");
        }

        [Fact]
        public async Task ValidateCreditCard_ThrowsException_WhenApplicationException_Test()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            var cc = request.Billing.Method.CreditCard.Number;
            var key = _partnerSettingsMoq.Object.CreditCardAPIKey;

            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            _creditCardServiceDomainManagerMoq.Setup(x => x.EncryptAsync(cc, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = false,
                CreditCardToken = Guid.NewGuid().ToString(),
                ErrorCode = "ABC",
                ErrorMessage = "ETS Error"
            };
            _creditCardServiceDomainManagerMoq.Setup(x => x.AuthorizeAsync(It.IsAny<ICreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            //Act test
            var ex = await Assert.ThrowsAsync<ApplicationException>(async () => await _sut.ProcessAsync(request).ConfigureAwait(false));

            //Assert test
            Assert.Equal(ex.Message, "CreditCardService Failed with message : ETS Error");
        }

        [Fact]
        public async Task ValidateCreditCard_ThrowsException_WhenCCManagerThrowsException_Test()
        {
            //Arrange test
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            var cc = request.Billing.Method.CreditCard.Number;
            var key = _partnerSettingsMoq.Object.CreditCardAPIKey;

            _creditCardServiceDomainManagerMoq.Setup(x => x.EncryptAsync(cc, key)).Throws(new Exception("CreditCardService Failed"));

            //Act test
            var response = await _sut.ProcessAsync(request).ConfigureAwait(false);

            //Assert test
            Assert.Null(response); // errors are supressed
        }
    }
}