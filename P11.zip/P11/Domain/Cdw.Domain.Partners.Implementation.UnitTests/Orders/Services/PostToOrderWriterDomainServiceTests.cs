﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.OrderWriter;
using Common.Logging;
using Moq;
using Xunit;
using Order = Cdw.Domain.Partners.Orders.Order;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class PostToOrderWriterDomainServiceTests
    {
        private readonly PostToOrderWriterDomainService _sut;
        private readonly Mock<ILog> _logger = new Mock<ILog>();
        private readonly Mock<IOrderWriterDomainManager> _orderWriterDomainManager = new Mock<IOrderWriterDomainManager>();
        private readonly Mock<IPartnerOrderService> _partnerOrderService = new Mock<IPartnerOrderService>();

        public PostToOrderWriterDomainServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());
            _sut = new PostToOrderWriterDomainService(_logger.Object, _orderWriterDomainManager.Object, _partnerOrderService.Object);
        }

        [Fact]
        public void PostToOrderWriterDomainService_NotNull_Test()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void Process_Pass_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var cart = new Cart().Fake(true);
            order.Cart = cart;
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            var terms = "Net30";
            order.Billing.Method.Terms = terms;
            var paymenCode = "123";
            var sourceName = "OrderSourceName1";

            _partnerOrderService.Setup(s => s.GetPaymentCode(sourceName, terms)).Returns(paymenCode);
            _orderWriterDomainManager.Setup(s => s.UploadAsync(It.IsAny<Ecommerce.Domain.OrderWriter.Order>())).Verifiable();

            //Act test
            _sut.Process(order, trackingValues);

            //Assert test
            Assert.True(true); // The sign of a great test!
        }
    }
}