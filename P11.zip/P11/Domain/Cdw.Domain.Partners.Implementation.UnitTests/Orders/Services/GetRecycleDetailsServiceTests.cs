﻿using Cdw.Api.Partners.Model.Recycling;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Partners.Recycling;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class GetRecycleDetailsServiceTests
    {
        private readonly GetRecycleDetailsService _sut;
        private readonly Mock<IRecyclingDomainManager> _recylingDomainManagerMoq = new Mock<IRecyclingDomainManager>();
        private readonly Order _order;

        public GetRecycleDetailsServiceTests()
        {
            _sut = new GetRecycleDetailsService(_recylingDomainManagerMoq.Object);
            _order = new Order().Fake();
        }

        [Fact]
        public void HydrateRecycleDetailsService_NotNull_Test()
        {
            //Assert test
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task GetRecyclingFeeAsync_Passes_WithFees_Test()
        {
            //Arrange test
            var recyclingfee = new List<Api.Partners.Model.Recycling.IRecyclingFeeModel>()
            {
                new RecyclingFeeModel
                {
                    Amount = 1,
                    Code = "10",
                    Description = "Description",
                    ProductCode = "12345"
                }
            };

            _recylingDomainManagerMoq.Setup(s => s.GetRecyclingFeesAsync(It.IsAny<RecyclingFeeRequestModel>())).ReturnsAsync(recyclingfee);
            var expectedResult = 10;

            //Act test
            var result = await _sut.ProcessAsync(_order);

            //Assert test
            Assert.Equal(expectedResult, result);
        }

        [Fact]
        public async Task GetRecyclingFeeAsync_Passes_WithOutFees_Test()
        {
            //Arrange test
            _recylingDomainManagerMoq.Setup(s => s.GetRecyclingFeesAsync(It.IsAny<RecyclingFeeRequestModel>())).ReturnsAsync(null);
            var expectedResult = 0;

            //Act test
            var result = await _sut.ProcessAsync(_order).ConfigureAwait(false);

            //Assert test
            Assert.Equal(expectedResult, result);
        }
    }
}