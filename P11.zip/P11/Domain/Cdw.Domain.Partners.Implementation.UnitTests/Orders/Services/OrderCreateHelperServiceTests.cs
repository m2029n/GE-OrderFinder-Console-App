﻿using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Implementation.UnitTests.MockObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.PartnerOrder;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class OrderCreateHelperServiceTests
    {
        private readonly OrderCreateHelperService _sut;

        private readonly Mock<IPartnerOrderService> _partnerOrderServiceMoq = new Mock<IPartnerOrderService>();

        private readonly Mock<IGetFreightRaterService> _freightRaterServiceMoq = new Mock<IGetFreightRaterService>();

        private readonly Mock<IGetRecycleDetailsService> _recycleDetailsServiceMoq = new Mock<IGetRecycleDetailsService>();

        private readonly Mock<IGetTaxDetailsService> _taxDetailsServiceMoq = new Mock<IGetTaxDetailsService>();

        private readonly Mock<IProcessCreditCardService> _processCreditCardServiceMoq = new Mock<IProcessCreditCardService>();

        private readonly Mock<IPostToOrderWriterDomainService> _orderWriterDomainManagerServiceMoq = new Mock<IPostToOrderWriterDomainService>();

        public OrderCreateHelperServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());

            _sut = new OrderCreateHelperService(
                _partnerOrderServiceMoq.Object,
                _freightRaterServiceMoq.Object,
                _recycleDetailsServiceMoq.Object,
                _taxDetailsServiceMoq.Object,
                _processCreditCardServiceMoq.Object,
                _orderWriterDomainManagerServiceMoq.Object
                );
        }

        [Fact]
        public void OrderCreateHelperService_NotNull_Test()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void GetOrderFromRequest_Passes_Test()
        {
            //Arrange test
            var productEntity = MockHelper.MockProductEntityObject(123);
            _partnerOrderServiceMoq.Setup(x => x.GetProductEntities(It.IsAny<IEnumerable<string>>())).Returns(new List<ProductEntity>() { productEntity });
            var request = FakeHelper.GetFakeRequestorderFakeObject();

            //Act test
            var order = _sut.GetOrderFromRequest(request);

            //Assert test
            Assert.True(order.Cart.Items.Count > 0);
        }

        [Fact]
        public async Task GetShippingInfoAsync_Passes_Test()
        {
            //Arrange test
            var shippingInfo = new ShippingInfo().Fake();
            var order = new Order().Fake();
            var request = FakeHelper.GetFakeRequestorderFakeObject();
            var trackingValues = new FakeTrackingValues().GetFakeObject();

            _freightRaterServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<Order>(), It.IsAny<IRequestOrder>(), It.IsAny<ITrackingValues>())).Returns(Task.FromResult(shippingInfo));

            //Act test
            var actual = await _sut.GetShippingInfoAsync(order, request, trackingValues, null).ConfigureAwait(false);

            //Assert test
            Assert.Equal(actual.Method.Description, order.Shipping.Method.Description);
            Assert.Equal(actual.Method.Rate.ShippingMethodId, order.Shipping.Method.Rate.ShippingMethodId);
        }

        [Fact]
        public async Task GetRecyclingFeeAsync_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            decimal fees = 25;
            _recycleDetailsServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<Order>())).Returns(Task.FromResult(fees));

            //Act test
            var actual = await _sut.GetRecyclingFeeAsync(order, null).ConfigureAwait(false);

            //Assert test
            Assert.Equal(actual, fees);
        }

        [Fact]
        public async Task GetTaxesAsync_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            IEnumerable<Partners.Orders.Tax> taxes = new List<Partners.Orders.Tax>() { new Partners.Orders.Tax().Fake() };

            _taxDetailsServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<Order>(), It.IsAny<ITrackingValues>())).Returns(Task.FromResult(taxes));

            //Act test
            var actual = await _sut.GetTaxesAsync(order, trackingValues, null).ConfigureAwait(false);

            //Assert test
            Assert.NotNull(actual);
            Assert.Equal(actual.Count(), taxes.Count());
        }

        [Fact]
        public void ValidateTerms_Passes_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderNOCCFakeObject();
            request.Billing.Method.Terms = "123";
            _partnerOrderServiceMoq.Setup(x => x.ValidateTerms(It.IsAny<IRequestOrder>())).Returns(true);

            //Act test
            _sut.ValidateTerms(request, null);

            //Assert test
            Assert.True(true);
        }

        [Fact]
        public void CheckUniqueReferenceNumber_Passes_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            _partnerOrderServiceMoq.Setup(x => x.CheckUniqueReferenceNumber(It.IsAny<IRequestOrder>())).Verifiable();

            //Act test
            _sut.CheckUniqueReferenceNumber(request);

            //Assert test
            Assert.True(true);
        }

        [Fact]
        public void InsertCart_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            _partnerOrderServiceMoq.Setup(x => x.InsertCart(It.IsAny<Order>())).Verifiable();

            //Act test
            _sut.InsertCart(order);

            //Assert test
            Assert.True(true);
        }

        [Fact]
        public void InsertPaymentInformation_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var creditCardResponse = new FakeCreditCardAuthorizationResponse();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            string authCreditCardToken = null;

            _partnerOrderServiceMoq.Setup(x => x.InsertPaymentInformation(It.IsAny<Order>(), It.IsAny<ITrackingValues>(), It.IsAny<ICreditCardAuthorizationResponse>(), It.IsAny<string>())).Verifiable();

            //Act test
            _sut.InsertPaymentInformation(order, trackingValues, creditCardResponse, authCreditCardToken);

            //Assert test
            Assert.True(true);
        }

        [Fact]
        public void InsertOrder_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            _partnerOrderServiceMoq.Setup(x => x.InsertOrder(It.IsAny<Order>(), It.IsAny<IRequestOrder>())).Verifiable();

            //Act test
            _sut.InsertOrder(order, request);

            //Assert test
            Assert.True(true);  // The sign of a great test!
        }

        [Fact]
        public async Task GetOrderDetails_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var fees = 25M;
            var orderCode = "123";
            var sourceCode = "abc";
            _partnerOrderServiceMoq.Setup(x => x.GetOrderDetails(orderCode, sourceCode)).Returns(order);
            _recycleDetailsServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<Order>())).Returns(Task.FromResult(fees));

            //Act test
            var actual = await _sut.GetOrderDetails(orderCode, sourceCode).ConfigureAwait(false);

            //Assert test
            Assert.NotNull(actual);
            Assert.Equal(actual.RecyclingFee, fees);
            Assert.Equal(actual.ReferenceNumber, order.ReferenceNumber);
        }

        [Fact]
        public async Task GetOrderDetails_Passes_WhenNull_Test()
        {
            //Arrange test
            var order = new Order().FakeNull();
            var orderCode = "XXXXX";
            var sourceCode = "abc";
            _partnerOrderServiceMoq.Setup(x => x.GetOrderDetails(orderCode, sourceCode)).Returns(order);

            //Act test
            var actual = await _sut.GetOrderDetails(orderCode, sourceCode).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public async Task ProcessCreditCard_Passes_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = true,
                CreditCardToken = Guid.NewGuid().ToString()
            };
            _processCreditCardServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<IRequestOrder>())).ReturnsAsync(ccar);

            //Act test
            var actual = await _sut.ProcessCreditCardAsync(request, null).ConfigureAwait(false);

            //Assert test
            Assert.NotNull(actual);
            Assert.True(actual.IsValid);
            Assert.Equal(actual.CreditCardToken, ccar.CreditCardToken);
        }

        [Fact]
        public async Task ProcessCreditCard_Passes_WhenNull_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            request.Billing.Method.Terms = "123";
            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = true,
                CreditCardToken = Guid.NewGuid().ToString()
            };
            _processCreditCardServiceMoq.Setup(x => x.ProcessAsync(It.IsAny<IRequestOrder>())).ReturnsAsync(ccar);

            //Act test
            var actual = await _sut.ProcessCreditCardAsync(request, null).ConfigureAwait(false);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public void GetAuthCreditCardToken_Passes_Test()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            request.Billing.Method.TransactionId = "70EAB72E-7A92-4DF6-AA33-143719B9BD31";
            request.Billing.Method.ReferenceNumber = "47A2957A-8905-4C02-9526-AAAD9129306C";
            var authCreditCardToken = "89B2957A-8905-5C02-9526-XXAD9129306C";
            _partnerOrderServiceMoq.Setup(x => x.GetAuthCreditCardToken(It.IsAny<string>(), It.IsAny<string>())).Returns(authCreditCardToken);

            //Act test
            var actual = _sut.GetAuthCreditCardToken(request, null);

            //Assert test
            Assert.NotNull(actual);
            Assert.Equal(actual, authCreditCardToken);
        }

        [Fact]
        public void GetAuthCreditCardToken_Passes_WhenNull()
        {
            //Arrange test
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();
            request.Billing.Method.TransactionId = "70EAB72E-7A92-4DF6-AA33-143719B9BD31";
            request.Billing.Method.ReferenceNumber = "47A2957A-8905-4C02-9526-AAAD9129306C";
            _partnerOrderServiceMoq.Setup(x => x.GetAuthCreditCardToken(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((string)null);

            //Act test
            var actual = _sut.GetAuthCreditCardToken(request, null);

            //Assert test
            Assert.Null(actual);
        }

        [Fact]
        public void PostToOrderWriter_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            _orderWriterDomainManagerServiceMoq.Setup(x => x.Process(It.IsAny<Order>(), It.IsAny<ITrackingValues>())).Verifiable();

            //Act test
            _sut.PostToOrderWriterAsync(order, trackingValues);

            //Assert test
            Assert.True(true);  // The sign of a great test!
        }

        [Fact]
        public void RaiseDomainEvents_Passes_Test()
        {
            //Arrange test
            var order = new Order().Fake();
            var trackingValues = new FakeTrackingValues().GetFakeObject();
            IRequestOrder request = FakeHelper.GetFakeRequestorderFakeObject();

            _orderWriterDomainManagerServiceMoq.Setup(x => x.Process(It.IsAny<Order>(), It.IsAny<ITrackingValues>())).Verifiable();

            //Act test
            _sut.RaiseDomainEvents(order, request, trackingValues, null);

            //Assert test
            Assert.True(true); // The sign of a great test!
        }
    }
}