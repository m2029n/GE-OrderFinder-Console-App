﻿using System;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Clients.Freight;
using Cdw.Common;
using Cdw.Domain.Freight;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Security.OAuth2.Client;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Orders.Services
{
    public class GetFreightRaterServiceTests
    {
        private readonly GetFreightRaterService _sut;
        private readonly Order _order;
        private readonly ITrackingValues _trackingValues;
        private readonly IRequestOrder _request;
        private readonly Mock<ILog> _logMoq = new Mock<ILog>();
        private readonly Mock<IPartnerOrderService> _partnerOrderSviceMoq = new Mock<IPartnerOrderService>();
        private readonly Mock<IRatingClientManager> _ratingManagerMoq = new Mock<IRatingClientManager>();

        public GetFreightRaterServiceTests()
        {
            Mapper.AddProfile(new RequestOrdersMappingProfile());

            _sut = new GetFreightRaterService(_logMoq.Object, _partnerOrderSviceMoq.Object, _ratingManagerMoq.Object);
            _order = new Order().Fake();
            _request = FakeHelper.GetFakeRequestorderFakeObject();
            _trackingValues = new FakeTrackingValues().GetFakeObject();
        }

        [Fact]
        public void FreightRaterService_NotNull_Test()
        {
            //Assert test
            Assert.NotNull(_sut);
        }

        [Theory(DisplayName = "GetOrderShippingRatesAsync_HappyPath_BundledProductOrNot_Tests")]
        [InlineData(true)]
        [InlineData(false)]
        public async void GetOrderShippingRatesAsync_Pass_WithBundledProductOrNot_Tests(bool isBundle)
        {
            //Arrange test
            if (isBundle)
            {
                var cart = new Cart();
                _order.Cart = cart.Fake(true);
            }
            var freightCode = _order.Shipping.Method.Id;
            _request.Freight = 1;

            var clientName = "123";
            var shippingMethod = "abc";

            SetupMoqCalls(null, freightCode, clientName, shippingMethod);

            //Act test
            var result = await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false);

            //Assert test
            Assert.NotNull(result);
            Assert.NotNull(result.Method);
            Assert.NotNull(result.Method.Rate);
            Assert.NotNull(result.Method.Rate.ShippingMethodId);
            Assert.Equal(freightCode, result.Method.Rate.ShippingMethodId);
        }

        public async void GetOrderShippingRatesAsync_Passes_WithXeroxData_Test()
        {
            // Arrange
            var freightCode = "Test";
            _request.Freight = 0;
            var shippingMethod = "Test";

            var shippingMethodEntity = new ShippingMethodPropertiesEntity
            {
                FreeShippingMethod = shippingMethod
            };
            var clientName = "123";
            _request.ClientName = clientName;

            SetupMoqCalls(shippingMethodEntity, freightCode, clientName, _order.Shipping.Method.Id);

            // Act
            var result = await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.Method);
            Assert.NotNull(result.Method.Rate);
            Assert.NotNull(result.Method.Rate.ShippingMethodId);
            Assert.Equal(freightCode, result.Method.Rate.ShippingMethodId);
        }

        [Fact]
        public void GetOrderShippingRatesAsync_ThrowsException_WhenXeroxData_HasNoFreeShippingMethod_Test()
        {
            //Arrange test
            var freightCode = "Test";
            _request.Freight = 0;

            var shippingMethodEntity = new ShippingMethodPropertiesEntity
            {
                FreeShippingMethod = null
            };
            var clientName = "123";
            var shippingMethod = "abc";
            SetupMoqCalls(shippingMethodEntity, freightCode, clientName, shippingMethod);

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false));

            //Assert test
            Assert.NotNull(result);
            Assert.NotNull(result.Exception);
        }

        [Fact]
        public void GetOrderShippingRatesAsync_ThrowsException_WhenInStep2RatingManagerHasErrors_Test()
        {
            //Arrange test
            var freightCode = "Test";
            _request.Freight = 1;
            var clientName = "123";
            var shippingMethod = "abc";
            SetupMoqCalls(null, freightCode, clientName, shippingMethod, true);

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false));

            //Assert test

            Assert.NotNull(result);
            Assert.NotNull(result.Exception);
        }

        [Fact]
        public void GetOrderShippingRatesAsync_ThrowsException_WhenInStep2RatingManagerThrowsCDWException_Test()
        {
            //Arrange test
            _request.Freight = 1;

            var exception = FormatterServices.GetUninitializedObject(typeof(CdwHttpException)) as CdwHttpException;
            _ratingManagerMoq.Setup(s => s.RateAsync(It.IsAny<IRatingRequest>())).Throws(exception);

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false));

            //Assert test

            Assert.NotNull(result);
            Assert.NotNull(result.Exception);
        }

        [Fact]
        public void GetOrderShippingRatesAsync_ThrowsException_WhenIntep4ShippingMethodNotFoundById_Test()
        {
            //Arrange test
            _request.Freight = 1;
            SetupMoqCalls(null, null, null, null);

            //Act test
            var result = Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessAsync(_order, _request, _trackingValues).ConfigureAwait(false));

            //Assert test
            Assert.NotNull(result);
            Assert.NotNull(result.Exception);
        }

        private void SetupMoqCalls(ShippingMethodPropertiesEntity shippingMethodEntity, string freightCode, string clientName, string shippingMethod, bool isRateError = false)
        {
            if (shippingMethodEntity != null)
            {
                _partnerOrderSviceMoq.Setup(s => s.GetShippingMethodPropertyAsync(clientName, shippingMethod))
                .Returns(Task.FromResult(shippingMethodEntity));
            }

            string errorMessage = null;
            if (isRateError)
            {
                errorMessage = "error getting rates";
            }
            IRatingResponse freightRaterResponse = new FakeRatingResponse().GetFakeObject(errorMessage, freightCode);

            _ratingManagerMoq.Setup(s => s.RateAsync(It.IsAny<IRatingRequest>()))
                    .Returns(Task.FromResult(freightRaterResponse));
        }
    }
}