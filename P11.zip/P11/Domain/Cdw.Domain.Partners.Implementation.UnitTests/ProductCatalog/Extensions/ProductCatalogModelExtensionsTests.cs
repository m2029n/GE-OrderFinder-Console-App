﻿using System;
using System.Collections.Generic;
using Cdw.Api.Partners.Model.ProductCatalog;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Price.Product;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Extensions
{
    public class ProductCatalogModelExtensionsTests
    {
        [Fact]
        public void ProductCatalogModelExtensions_test_apply_should_pass_with_nulls()
        {
            var item = new ProductCatalogModel();
            item.ApplyCoupon(null);
            Assert.NotNull(item);
        }

        [Fact]
        public void ProductCatalogModelExtensions_test_apply_should_pass_with_values()
        {
            var item = new ProductCatalogModel { ProductCode = "123" };
            var coup = new CouponResponse();
            var list = new List<ICouponItem>();
            list.Add(new CouponItem { ProductCode = "123", CouponValue = 123, CouponCode = "abc" });
            coup.CouponItems = list;
            var list2 = new List<ICouponDetail>();
            list2.Add(new CouponDetail { CouponCode = "abc", EndDate = new DateTime() });
            coup.CouponDetails = list2;
            item.ApplyCoupon(coup);
            Assert.NotNull(item);
        }

        [Fact]
        public void ProductCatalogModelExtensions_test_apply_should_pass_with_some_values()
        {
            var item = new ProductCatalogModel { ProductCode = "123" };
            var coup = new CouponResponse();
            item.ApplyCoupon(coup);
            Assert.NotNull(item);
        }

        [Fact]
        public void GetPriceByCodeTest_should_pass()
        {
            var list = new List<IProductPrices>();
            var priceList = new List<IProductPrice>();
            var prodprice = new ProductPrice { ProductCode = "prod1", Price = 123 };
            priceList.Add(prodprice);
            var price = new ProductPrices { Prices = priceList, ProductCode = "prod1" };
            list.Add(price);
            var actual = "prod1".GetPriceByCode(list);
            Assert.NotNull(actual);
            Assert.Equal(actual, 123);
        }

        [Fact]
        public void GetPriceByCodeZeroTest_should_pass()
        {
            var list = new List<IProductPrices>();
            var actual = "prod1".GetPriceByCode(list);
            Assert.Equal(actual, 0);
        }

        [Fact]
        public void GetPriceByCodeNullTest_should_pass()
        {
            var actual = "prod1".GetPriceByCode(null);
            Assert.Equal(actual, 0);
        }
    }
}