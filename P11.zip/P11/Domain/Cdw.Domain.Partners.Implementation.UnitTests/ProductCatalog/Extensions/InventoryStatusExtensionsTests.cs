﻿using Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions;
using Cdw.Ecommerce.Domain.Product.Models;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Extensions
{
    public class InventoryStatusExtensionsTests
    {
        [Theory]
        [InlineData(InventoryStatusType.ShipWithinNumDays, "1", "Ships in 1")]
        [InlineData(InventoryStatusType.OneToThreeDays, "10", "Ships in 10")]
        [InlineData(InventoryStatusType.ThreeToSixDays, "100", "Ships in 100")]
        [InlineData(InventoryStatusType.NoEta, "", "Call for Availability")]
        [InlineData(InventoryStatusType.InStock, "", "")]
        [InlineData(InventoryStatusType.Limited, "", "")]
        [InlineData(InventoryStatusType.ElectronicDropShip, "", "")]
        [InlineData(InventoryStatusType.AvailableToShipToday, "", "")]
        public void StatusMessage_test_should_pass_when_status_changes(InventoryStatusType statusType, string shortMessage, string expected)
        {
            var sut = new InventoryStatus();
            sut.StatusType = statusType;
            sut.ShortMessage = shortMessage;
            var actual = sut.StatusMessage();
            Assert.Equal(actual, expected);
        }
    }
}