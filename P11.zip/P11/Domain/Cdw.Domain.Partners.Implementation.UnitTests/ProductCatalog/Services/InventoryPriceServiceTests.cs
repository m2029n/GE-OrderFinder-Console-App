﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Price;
using Cdw.Ecommerce.Domain.Price.Product;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class InventoryPriceServiceTests
    {
        private readonly InventoryPriceService _sut;
        private readonly Mock<IProductPriceManager> _productPriceManager;

        public InventoryPriceServiceTests()
        {
            _productPriceManager = new Mock<IProductPriceManager>();
            var log = new Mock<ILog>();
            _sut = new InventoryPriceService(_productPriceManager.Object, log.Object);
        }

        [Fact]
        public void InventoryPriceServiceTest_should_pass_when_created()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task ExecuteAsync_should_pass_one()
        {
            var list = new List<ProductInventory>();
            var partner = new Identity();
            var actual = new List<IProductPrices>();
            var tasks = _sut.GetTasks(list, partner);
            await Task.WhenAll(tasks);
            foreach (var task in tasks)
            {
                actual.AddRange(await task);
            }
            Assert.NotNull(actual);
        }

        [Fact]
        public async Task ExecuteAsync_should_pass_when_null()
        {
            var partner = new Identity();
            var actual = new List<IProductPrices>();
            var tasks = _sut.GetTasks(null, partner);
            await Task.WhenAll(tasks);
            foreach (var task in tasks)
            {
                actual.AddRange(await task);
            }
            Assert.NotNull(actual);
        }

        [Theory]
        [InlineData(1, 1)]
        [InlineData(99, 1)]
        [InlineData(100, 1)]
        [InlineData(101, 2)]
        [InlineData(200, 2)]
        [InlineData(299, 3)]
        [InlineData(300, 3)]
        [InlineData(301, 4)]
        public async Task ExecuteAsyncTasks_should_pass_batches(int batchsize, int expected)
        {
            var list = new List<ProductInventory>();
            for (int j = 0; j < batchsize; j++)
            {
                list.Add(new ProductInventory { ProductCode = j + "_prod_code" });
            }
            var partner = new Identity();

            var list2 = new List<IProductPrices>();
            list2.Add(new FakeProductPrices());
            _productPriceManager.Setup(p => p.GetAsync(It.IsAny<PriceRequest>(), false)).ReturnsAsync(list2.AsQueryable());
            var tasks = _sut.GetTasks(list, partner);
            await Task.WhenAll(tasks);
            var actual = new List<IProductPrices>();

            foreach (var task in tasks.ToArray())
            {
                actual.AddRange(await task);
            }
            Assert.NotNull(actual);
            Assert.Equal(expected, actual.Count);
        }
    }
}