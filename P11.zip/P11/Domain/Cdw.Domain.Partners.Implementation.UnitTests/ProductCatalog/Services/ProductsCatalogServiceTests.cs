﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class ProductsCatalogServiceTests
    {
        private readonly ProductsCatalogService _sut;

        public ProductsCatalogServiceTests()
        {
            var productsearchService = new Mock<ISearchProductService>().Object;
            var batchFactoryService = new Mock<IBatchFactoryService>().Object;
            var bundleManager = new Mock<IBundleItemService>().Object;
            _sut = new ProductsCatalogService(productsearchService, bundleManager, batchFactoryService);
        }

        [Fact]
        public async Task GetAsyncTest_Should_return_null()
        {
            var actual = await _sut.GetAsync(null, 5000, 0).ConfigureAwait(false);
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetAsyncTest_Should_return_null_noProducts()
        {
            var actual = await _sut.GetAsync(new Identity(), 5000, 0).ConfigureAwait(false);
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetAsyncTest_Should_return_null_noPartner()
        {
            var actual = await _sut.GetAsync(null, 5000, 0).ConfigureAwait(false);
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetAsyncTest_Products_should_return_Products()
        {
            var productsearchService = new Mock<ISearchProductService>();
            var bundleManager = new Mock<IBundleItemService>().Object;
            var list = new List<ProductInventory>();
            list.Add(new ProductInventory { ManufactureCode = "code123", ManufacturePartNumber = "part123", ProductCode = "product_code1", PriceAdvertised = (decimal)12.99 });
            list.Add(new ProductInventory { ManufactureCode = "code456", ManufacturePartNumber = "part456", ProductCode = "product_code2", PriceAdvertised = (decimal)13.99 });

            productsearchService.Setup(s => s.GetAsync(It.IsAny<Identity>())).ReturnsAsync(list);
            var list2 = new List<IProductCore>();
            list2.Add(new Ecommerce.Domain.Product.Models.Product { IsBundle = true, ProductCode = "product_code1" });
            list2.Add(new Ecommerce.Domain.Product.Models.Product { IsBundle = true, ProductCode = "product_code2" });
            var statuses = new List<InventoryStatus>();
            statuses.Add(new InventoryStatus { ProductCode = "product_code1", StatusType = InventoryStatusType.ThreeToSixDays });
            statuses.Add(new InventoryStatus { ProductCode = "product_code1", StatusType = InventoryStatusType.NoEta });

            var batchFactoryService = new Mock<IBatchFactoryService>();
            batchFactoryService.Setup(s => s.Statuses).Returns(statuses);
            batchFactoryService.Setup(s => s.ProductItems).Returns(list2);
            batchFactoryService.Setup(s => s.CouponResponse).Returns(new CouponResponse());

            var sut = new ProductsCatalogService(productsearchService.Object, bundleManager, batchFactoryService.Object);

            var actual = await sut.GetAsync(new Identity { ApplyCoupon = true, ShowWeight = true }, 5000, 0).ConfigureAwait(false);
            Assert.Equal(2, actual.Results.Count);
        }
    }
}