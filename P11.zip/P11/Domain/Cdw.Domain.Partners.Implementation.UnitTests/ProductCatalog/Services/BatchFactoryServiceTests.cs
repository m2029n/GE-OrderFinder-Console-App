﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Price.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class BatchFactoryServiceTests
    {
        private readonly Mock<IInventoryStatusService> _statusService = new Mock<IInventoryStatusService>();
        private readonly Mock<IInventoryPriceService> _priceService = new Mock<IInventoryPriceService>();
        private readonly Mock<IProductService> _productService = new Mock<IProductService>();
        private readonly Mock<ICouponService> _couponService = new Mock<ICouponService>();

        [Fact]
        public void BatchFactoryService_should_not_be_null()
        {
            var sut = new BatchFactoryService(_statusService.Object, _priceService.Object, _productService.Object, _couponService.Object);
            Assert.NotNull(sut);
        }

        [Fact]
        public void LoadBatchedCallsDataAsync_should_pass_when_no_results()
        {
            var sut = new BatchFactoryService(_statusService.Object, _priceService.Object, _productService.Object, _couponService.Object);
            List<ProductInventory> list = new List<ProductInventory>();
            list.Add(new ProductInventory { ProductCode = "123" });
            var actual = sut.LoadBatchedCallsDataAsync(new Identity { ApplyCoupon = true }, list);

            Assert.NotNull(actual);
        }

        [Fact]
        public void LoadBatchedCallsDataAsync_should_pass_when_results()
        {
            var sut = new BatchFactoryService(_statusService.Object, _priceService.Object, _productService.Object, _couponService.Object);
            var list = new List<ProductInventory>();
            list.Add(new ProductInventory { ProductCode = "123" });
            var partner = new Identity { ApplyCoupon = true, ProductApiCompany = "comp" };
            var list1 = new List<InventoryStatus>();
            _statusService.Setup(s => s.GetAsync(list, "comp")).ReturnsAsync(list1);
            var list2 = new List<IProductPrices>();
            _priceService.Setup(s => s.GetAsync(list, partner)).ReturnsAsync(list2);
            var list3 = new List<IProductCore>();
            _productService.Setup(s => s.GetAsync(list, partner)).ReturnsAsync(list3);
            ICouponResponse list4 = new CouponResponse();
            _couponService.Setup(s => s.ApplyAsync(list3, list, partner)).ReturnsAsync(list4);

            var actual = sut.LoadBatchedCallsDataAsync(partner, list).ConfigureAwait(false);

            Assert.NotNull(actual);
            Assert.NotNull(sut.Prices);
            Assert.NotNull(sut.CouponResponse);
            Assert.NotNull(sut.ProductItems);
            Assert.NotNull(sut.Statuses);
        }
    }
}