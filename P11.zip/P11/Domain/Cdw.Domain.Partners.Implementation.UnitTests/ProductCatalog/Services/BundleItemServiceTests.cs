﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class BundleItemServiceTests
    {
        private readonly BundleItemService _sut;
        private readonly Mock<IBundleItemsManager> _bndService;

        public BundleItemServiceTests()
        {
            _bndService = new Mock<IBundleItemsManager>();
            _sut = new BundleItemService(_bndService.Object);
        }

        [Fact]
        public void BundleItemServiceTest_should_pass_when_created()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task BundleItemServiceTest_GetStockStatusAsync_should_pass_when_values()
        {
            var actual = await _sut.GetStockStatusAsync("123", "123").ConfigureAwait(false);
            Assert.Equal("", actual);
        }

        [Fact]
        public async Task BundleItemServiceTest_GetStockStatusAsync_should_pass_when_bundles_are_returned()
        {
            _bndService.Setup(b => b.GetBundleItemsWithStockStatusAsync("123", "123")).ReturnsAsync(new ProductBundle { PrimaryProductStatus = new InventoryStatus { StatusType = InventoryStatusType.ShipWithinNumDays } });
            var actual = await _sut.GetStockStatusAsync("123", "123").ConfigureAwait(false);
            Assert.NotNull(actual);
        }
    }
}