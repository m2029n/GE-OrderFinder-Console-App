﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class ProductServiceTests
    {
        private readonly Mock<IProductManager> _productManager;
        private readonly ProductService _sut;

        public ProductServiceTests()
        {
            _productManager = new Mock<IProductManager>();
            _sut = new ProductService(_productManager.Object);
        }

        [Fact]
        public async Task ExecuteAsyncTest_should_pass_execute()
        {
            var list = new List<ProductInventory>();
            list.Add(new ProductInventory());
            Identity partner = new Identity();
            var list2 = new List<IProductCore>();
            list2.Add(new FakeProductCode());
            _productManager.Setup(p => p.GetProductsAsync(It.IsAny<IList<string>>(), It.IsAny<string>())).ReturnsAsync(list2);
            var actual = await _sut.GetAsync(list, partner).ConfigureAwait(false);
            Assert.NotNull(actual);
            Assert.Equal(actual.Count, 1);
        }

        [Theory]
        [InlineData(1, 1)]
        [InlineData(99, 1)]
        [InlineData(100, 1)]
        [InlineData(101, 2)]
        [InlineData(200, 2)]
        [InlineData(299, 3)]
        [InlineData(300, 3)]
        [InlineData(301, 4)]
        public async Task ExecuteAsyncBatchTest_should_pass_execute_batches(int batchsize, int expected)
        {
            var list = new List<ProductInventory>();
            for (int i = 0; i < batchsize; i++)
            {
                list.Add(new ProductInventory { ProductCode = i + "_prod_code" });
            }
            Identity partner = new Identity();
            var list2 = new List<IProductCore>();
            list2.Add(new FakeProductCode());
            _productManager.Setup(p => p.GetProductsAsync(It.IsAny<IList<string>>(), It.IsAny<string>())).ReturnsAsync(list2);
            var actual = await _sut.GetAsync(list, partner).ConfigureAwait(false);
            Assert.NotNull(actual);
            Assert.Equal(expected, actual.Count);
        }

        [Fact]
        public void ProductServiceTest_should_pass_when_created()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public void ProductServiceNullExecuteTest_should_return_null()
        {
            var actual = _sut.GetAsync(null, null);
            Assert.NotNull(actual);
        }
    }
}