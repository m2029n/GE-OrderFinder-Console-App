﻿using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class CouponServiceTests
    {
        private Mock<ICouponDomainManager> _mockCouponDomainManager;
        private Mock<ICouponRequestService> _mockCouponRequestService;
        private CouponService _sut;

        public CouponServiceTests()
        {
            _mockCouponDomainManager = new Mock<ICouponDomainManager>();
            _mockCouponRequestService = new Mock<ICouponRequestService>();
            _sut = new CouponService(_mockCouponDomainManager.Object, _mockCouponRequestService.Object);
        }

        [Fact]
        public async Task ApplyAsync_ShouldNotCallRepoIfZeroProducts()
        {
            //Arrange
            var products = ProductList(0);
            var inventoryList = new List<ProductInventory>();
            var partner = new Identity();

            _mockCouponRequestService.Setup(s => s.BuildCouponRequest(products, inventoryList, partner, It.IsAny<int>(), It.IsAny<int>()))
                .Throws(new Exception("I shoudl NOT be called"));

            //Act
            var actual = await _sut.ApplyAsync(products, inventoryList, partner);

            //Assert
            Assert.Equal(string.Empty, actual.CompanyCode);
            Assert.Equal(string.Empty, actual.CustomerNumber);
            Assert.Equal(0, actual.CouponDetails.Count());
            Assert.Equal(0, actual.CouponItems.Count());
        }

        [Fact]
        public async Task ApplyAsync_ShouldCallRepo3TimesForAProductListOf5000()
        {
            //Arrange
            var products = ProductList(5500);
            var inventoryList = new List<ProductInventory>();
            var partner = new Identity();
            var couponResponse = new FakeCouponResponse().GetFakeObject();
            var couponRequest = new CouponRequest();

            var hitCount = 0;
            _mockCouponRequestService.Setup(s => s.BuildCouponRequest(products, inventoryList, partner, It.IsAny<int>(), It.IsAny<int>()))
                .Returns(couponRequest)
                .Callback<List<IProductCore>, List<ProductInventory>, Identity, int, int>((p1, p2, p3, p4, p5) =>
                {
                    hitCount++;
                    Assert.Equal(products.First().ProductCode, p1.First().ProductCode);
                    Assert.Equal(partner, p3);
                });
            _mockCouponDomainManager.Setup(s => s.ApplyAsync(couponRequest)).ReturnsAsync(couponResponse);

            //Act
            var actual = await _sut.ApplyAsync(products, inventoryList, partner);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(6, hitCount);
            Assert.Equal(couponResponse.CompanyCode, actual.CompanyCode);
            Assert.Equal(couponResponse.CustomerNumber, actual.CustomerNumber);
            Assert.Equal(couponResponse.CouponDetails.ToString(), actual.CouponDetails.ToString());
            Assert.Equal(couponResponse.CouponItems.ToString(), actual.CouponItems.ToString());
        }

        [Fact]
        public async Task ApplyCouponTest_returnsNull()
        {
            //Arrange
            var products = ProductList(2000);
            var inventoryList = new List<ProductInventory>();
            var partner = new Identity();
            ICouponResponse couponResponse = new FakeCouponResponse().GetFakeObject();
            ICouponResponse nullCouponResponse = null;
            var couponRequest = new FakeCouponRequest().GetFakeObject();

            _mockCouponRequestService.Setup(s => s.BuildCouponRequest(products, inventoryList, partner, It.IsAny<int>(), It.IsAny<int>())).Returns(couponRequest);
            _mockCouponDomainManager.SetupSequence(s => s.ApplyAsync(couponRequest))
                        .Returns(Task.FromResult(couponResponse))
                        .Returns(Task.FromResult(nullCouponResponse));

            //Act
            var actual = await _sut.ApplyAsync(products, inventoryList, partner);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(couponResponse.CompanyCode, actual.CompanyCode);
            Assert.Equal(couponResponse.CustomerNumber, actual.CustomerNumber);
            Assert.Equal(couponResponse.CouponDetails.ToString(), actual.CouponDetails.ToString());
            Assert.Equal(couponResponse.CouponItems.ToString(), actual.CouponItems.ToString());
        }

        [Fact]
        public void BuildCouponRequestTest_should_pass()
        {
            //Arrange
            var products = new List<IProductCore>();
            products.Add(new Ecommerce.Domain.Product.Models.Product { IsBundle = true, ProductCode = "product_code1" });
            products.Add(new Ecommerce.Domain.Product.Models.Product { IsBundle = true, ProductCode = "product_code2" });
            var inventoryList = new List<ProductInventory>();
            inventoryList.Add(new ProductInventory { ManufactureCode = "code123", ManufacturePartNumber = "part123", ProductCode = "product_code1", PriceAdvertised = (decimal)12.99 });
            inventoryList.Add(new ProductInventory { ManufactureCode = "code456", ManufacturePartNumber = "part456", ProductCode = "product_code2", PriceAdvertised = (decimal)13.99 });
            var partner = new Identity();
            partner.ApplyCoupon = true;

            //Act
            var couponRequestService = new CouponRequestService();
            var couponRequest = couponRequestService.BuildCouponRequest(products, inventoryList, partner, 1, 0);

            //Assert
            Assert.Equal(1, couponRequest.Products.Count());
            Assert.NotNull(couponRequest);
            Assert.Equal(couponRequest.CompanyCode, "0");
            Assert.Equal(couponRequest.Products.ToList()[0].ProductCode, inventoryList.ToList()[0].ProductCode);
            Assert.Equal(couponRequest.Products.ToList()[0].Pricing.ToList()[0].UnitPrice.ToString(), "12.99");
            Assert.Equal(couponRequest.OrderDate, DateTime.Now.Date);
            Assert.Null(couponRequest.CouponCodes);
        }

        public List<IProductCore> ProductList(int count)
        {
            var products = new List<IProductCore>();
            for (int i = 0; i < count; i++)
            {
                products.Add(new Ecommerce.Domain.Product.Models.Product { IsBundle = true, ProductCode = "product_code" + i.ToString() });
            }
            return products;
        }
    }
}