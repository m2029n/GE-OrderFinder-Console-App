﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Ecommerce.Domain.Search;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class ProductSearchInventoryServiceTests
    {
        private readonly SearchProductService _sut;

        public ProductSearchInventoryServiceTests()
        {
            var searchDomainManager = new Mock<ISearchDomainManager>().Object;
            var log = new Mock<ILog>().Object;
            _sut = new SearchProductService(searchDomainManager, log);
        }

        [Fact]
        public async Task ExecuteAsync_Should_return_null()
        {
            var actual = await _sut.GetAsync(null).ConfigureAwait(false);
            Assert.Null(actual);
        }

        [Fact]
        public async Task ExecuteAsync_Should_return_null_for_queryApi()
        {
            var partner = new Identity();
            var searchMgr = new Mock<ISearchDomainManager>();
            var log = new Mock<ILog>().Object;
            var searchResult = new FakeSearchResult().GetFakeObject();

            searchMgr.Setup(s => s.SearchAsync(It.IsAny<SearchRequest>()))
                .ReturnsAsync(searchResult)
                .Callback<SearchRequest>((p) =>
                {
                    Assert.Equal(partner.SearchApi.QueryUri, p.QueryUri);
                });

            //Act
            var search = new SearchProductService(searchMgr.Object, log);
            var actual = await search.GetAsync(partner).ConfigureAwait(false);

            //Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task ExecuteAsync_ExecuteAsync_Should_return_searchResults()
        {
            //Arange
            var partner = new Identity();
            partner.SearchApi = new SearchApiSettings();
            partner.SearchApi.QueryUri = "b=BBG.BBR.BLA";
            var searchMgr = new Mock<ISearchDomainManager>();
            var log = new Mock<ILog>().Object;
            var searchResult = new FakeSearchResult().GetFakeObject();

            searchMgr.Setup(s => s.SearchAsync(It.IsAny<SearchRequest>()))
                .ReturnsAsync(searchResult)
                .Callback<SearchRequest>((p) =>
               {
                   Assert.StartsWith(partner.SearchApi.QueryUri, p.QueryUri);
               });

            //Act
            var search = new SearchProductService(searchMgr.Object, log);
            var actual = await search.GetAsync(partner).ConfigureAwait(false);

            //Assert
            Assert.Equal(actual.Count, 1);
            Assert.Equal(actual[0].ManufactureCode, "ManufactureCode");
            Assert.Equal(actual[0].ProductCode, "ProductCode");
            Assert.Equal(actual[0].ManufacturePartNumber, "ManufacturePartNumber");
            Assert.Equal(actual[0].PriceAdvertised.ToString(CultureInfo.InvariantCulture), "12.99");
            Assert.NotNull(actual);
        }

        [Fact]
        public void ExecuteAsync_should_fail()
        {
            //Arange
            var partner = new Identity();
            partner.SearchApi = new SearchApiSettings();
            partner.SearchApi.QueryUri = "b=BBG.BBR.BLA";
            var searchMgr = new Mock<ISearchDomainManager>();
            var log = new Mock<ILog>().Object;

            searchMgr.Setup(s => s.SearchAsync(It.IsAny<SearchRequest>())).Throws<Exception>();

            //Act
            var sut = new SearchProductService(searchMgr.Object, log);
            var actual = Assert.ThrowsAsync<Exception>(async () => await sut.GetAsync(partner).ConfigureAwait(false));

            //Assert
            Assert.NotNull(actual);
        }
    }
}