﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.ProductCatalog.Services
{
    public class InventoryStatusServiceTests
    {
        private readonly Mock<IInventoryStatusManager> _inventoryStatusManager;
        private readonly InventoryStatusService _sut;

        public InventoryStatusServiceTests()
        {
            _inventoryStatusManager = new Mock<IInventoryStatusManager>();
            _sut = new InventoryStatusService(_inventoryStatusManager.Object);
        }

        [Fact]
        public void InventoryStatusServiceTest_should_pass_when_created()
        {
            Assert.NotNull(_sut);
        }

        [Theory]
        [InlineData(1, 1)]
        [InlineData(99, 1)]
        [InlineData(100, 1)]
        [InlineData(101, 2)]
        [InlineData(200, 2)]
        [InlineData(299, 3)]
        [InlineData(300, 3)]
        [InlineData(301, 4)]
        public async Task ExecuteAsyncBatchTest_should_pass_execute_batches(int batchsize, int expected)
        {
            var list = new List<ProductInventory>();
            for (int i = 0; i < batchsize; i++)
            {
                list.Add(new ProductInventory { ProductCode = i + "_prod_code" });
            }

            var list2 = new List<InventoryStatus>();
            list2.Add(new InventoryStatus());
            _inventoryStatusManager.Setup(p => p.GetBulkInventoryStatusAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(list2);

            var actual = new List<InventoryStatus>();
            var tasks = _sut.GetTasks(list, "123");
            await Task.WhenAll(tasks);
            foreach (var task in tasks)
            {
                actual.AddRange(await task);
            }
            Assert.NotNull(actual);
            Assert.Equal(expected, actual.Count);
        }
    }
}