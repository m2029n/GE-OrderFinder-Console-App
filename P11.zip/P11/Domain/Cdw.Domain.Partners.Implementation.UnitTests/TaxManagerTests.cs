﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Tax;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Clients.Tax;
using Cdw.Services.Core;
using Cdw.Test.Common.Xunit;
using Common.Logging;
using Moq;
using Xunit;
using TaxPartnerDomain = Cdw.Domain.Partners.Tax;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    [CI]
    public class TaxManagerTests
    {
        private Mock<ILog> _mocklogger;

        private Mock<ITaxRequestClientDomainManager> _mocktaxRequestClientDomainManager;

        private Mock<IHealthCheck> _mockhealthCheck;

        private TaxDomainManager _taxDomainManager;

        public TaxManagerTests()
        {
            _mocklogger = new Mock<ILog>();
            _mocktaxRequestClientDomainManager = new Mock<ITaxRequestClientDomainManager>();
            _mockhealthCheck = new Mock<IHealthCheck>();
            Mapper.AddProfile(new TaxMappingProfile());
            _taxDomainManager = new TaxDomainManager(_mocklogger.Object, _mocktaxRequestClientDomainManager.Object);
        }

        [Fact(DisplayName = "GetTaxLinesAsync")]
        public void GetTaxLinesAsync()
        {
            _mocktaxRequestClientDomainManager.Reset();

            _mocktaxRequestClientDomainManager.Setup(x => x.GetTaxLinesAsync(It.IsAny<ITaxRequest>()))
                .Returns(Task.FromResult(new FakeTaxResponse().GetFakeObject() as ITaxResponse));

            var resultAsync = _taxDomainManager.GetTaxLinesAsync(new FakeTaxRequest().GetFakeObject()).Result;

            Assert.NotNull(resultAsync);
        }

        [Fact(DisplayName = "GetTaxDetailsAsync")]
        public void GetTaxDetailsAsync()
        {
            _mocktaxRequestClientDomainManager.Reset();

            _mocktaxRequestClientDomainManager.Setup(x => x.GetTaxLinesAsync(It.IsAny<ITaxRequest>()))
                .Returns(Task.FromResult(new FakeTaxResponse().GetFakeObject() as ITaxResponse));

            var resultAsync = _taxDomainManager.GetTaxDetailsAsync(new FakeTaxRequest().GetFakeObject()).Result;

            Assert.NotNull(resultAsync);
        }

        [Fact]
        public async Task TaxHealthCheck()
        {
            var expectedResult = new HealthCheckMessage("DoesNotMatter", HealthStatus.Ready);
            _mocktaxRequestClientDomainManager.Setup(x => x.CheckAsync()).ReturnsAsync(expectedResult);

            var actual = await _taxDomainManager.CheckAsync();

            Assert.Equal(expectedResult.Service, actual.Service);
        }
    }

    public class FakeTaxRequest : TaxPartnerDomain.ITaxRequest
    {
        public FakeTaxRequest GetFakeObject()
        {
            return new FakeTaxRequest()
            {
                TrackingValues = new FakeTrackingValues().GetFakeObject(),
                Account = new FakeTaxAccount().GetFakeObject(),
                Address = new FakeTaxAddress().GetFakeObject(),
                Company = 1000,
                Discounts = new List<TaxPartnerDomain.IDiscount>() { new FakeTaxDiscount().GetFakeObject() },
                Freight = Faker.RandomNumber.Next(10),
                Handling = Faker.RandomNumber.Next(10),
                Insurance = Faker.RandomNumber.Next(10),
                LineItems = new List<TaxPartnerDomain.ILineItem>() { new FakeTaxLineItem().GetFakeObject() },
                ProductFees = new List<TaxPartnerDomain.IProductFee>() { new FakeTaxProductFee().GetFakeObject() }
            };
        }

        public TaxPartnerDomain.IAccount Account { get; set; }
        public TaxPartnerDomain.IAddress Address { get; set; }
        public int Company { get; set; }
        public IEnumerable<TaxPartnerDomain.IDiscount> Discounts { get; set; }
        public decimal Freight { get; set; }
        public decimal Handling { get; set; }
        public decimal Insurance { get; set; }
        public IEnumerable<TaxPartnerDomain.ILineItem> LineItems { get; set; }
        public IEnumerable<TaxPartnerDomain.IProductFee> ProductFees { get; set; }
        public ITrackingValues TrackingValues { get; set; }
    }

    public class FakeTaxAccount : TaxPartnerDomain.IAccount
    {
        public string CustomerNumber { get; set; }
        public string EAccount { get; set; }
        public string EmailAddress { get; set; }

        public FakeTaxAccount GetFakeObject()
        {
            return new FakeTaxAccount()
            {
                CustomerNumber = Faker.RandomNumber.Next(10).ToString(),
                EAccount = Faker.Lorem.GetFirstWord(),
                EmailAddress = Faker.Internet.FreeEmail()
            };
        }
    }

    public class FakeTaxAddress : TaxPartnerDomain.IAddress
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
        public string StreetAddress { get; set; }
        public string SecondaryStreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string IsoCountryCode { get; set; }

        public FakeTaxAddress GetFakeObject()
        {
            return new FakeTaxAddress()
            {
                City = Faker.Address.City(),
                StreetAddress = Faker.Address.StreetAddress(),
                FirstName = Faker.Name.First(),
                LastName = Faker.Name.Last(),
                PhoneNumber = Faker.Phone.Number(),
                PostalCode = Faker.Address.ZipCode(),
                SecondaryStreetAddress = Faker.Address.SecondaryAddress(),
                State = Faker.Address.UsState(),
                Company = "Cdw",
                IsoCountryCode = "Us"
            };
        }
    }

    public class FakeTaxDiscount : TaxPartnerDomain.IDiscount
    {
        public string Id { get; set; }
        public int Type { get; set; }
        public decimal Amount { get; set; }

        public FakeTaxDiscount GetFakeObject()
        {
            return new FakeTaxDiscount()
            {
                Id = Faker.Lorem.GetFirstWord(),
                Type = 1,
                Amount = 7
            };
        }
    }

    public class FakeTaxLineItem : TaxPartnerDomain.ILineItem
    {
        public string ProductCode { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public string Status { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LinePrice { get; set; }
        public IEnumerable<TaxPartnerDomain.IDiscount> Discounts { get; set; }
        public IEnumerable<TaxPartnerDomain.ICustomProperty> CustomProperties { get; set; }
        public int? LineNumber { get; set; }

        public FakeTaxLineItem GetFakeObject()
        {
            var fake = new FakeTaxLineItem().AssignFakeValues();
            fake.Quantity = 2;
            fake.Discounts = new List<TaxPartnerDomain.IDiscount>() { new FakeTaxDiscount().GetFakeObject() };
            fake.CustomProperties = new List<TaxPartnerDomain.ICustomProperty>() { new FakeTaxCustomProperty().GetFakeObject() };

            return fake;
        }
    }

    public class FakeTaxCustomProperty : TaxPartnerDomain.ICustomProperty
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public FakeTaxCustomProperty GetFakeObject()
        {
            return new FakeTaxCustomProperty().AssignFakeValues();
        }
    }

    public class FakeTaxProductFee : TaxPartnerDomain.IProductFee
    {
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal FeeUnitPrice { get; set; }
        public int? LineNumber { get; set; }
        public string FeeProductCode { get; set; }

        public FakeTaxProductFee GetFakeObject()
        {
            return new FakeTaxProductFee()
            {
                ProductCode = Faker.Lorem.GetFirstWord(),
                LineNumber = 1,
                FeeProductCode = Faker.Lorem.GetFirstWord(),
                Quantity = 1,
                FeeUnitPrice = Faker.RandomNumber.Next(10)
            };
        }
    }
}