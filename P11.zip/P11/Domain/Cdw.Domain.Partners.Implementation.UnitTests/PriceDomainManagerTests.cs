﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Price;

using Cdw.Ecommerce.Domain.Price;
using Cdw.Ecommerce.Domain.Price.Price;
using Cdw.Ecommerce.Domain.Price.Product;
using Cdw.Test.Common.Xunit;
using Common.Logging;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    [CI]
    public class PriceDomainManagerTests
    {
        private Mock<ILog> _mocklogger;
        private Mock<Cdw.Ecommerce.Domain.Price.IProductPriceManager> _mockpriceRepository;

        private PriceDomainManager _priceDomainManager;

        public PriceDomainManagerTests()
        {
            _mocklogger = new Mock<ILog>();
            _mockpriceRepository = new Mock<IProductPriceManager>();

            _priceDomainManager = new PriceDomainManager(_mocklogger.Object, _mockpriceRepository.Object);
            Mapper.AddProfile(new PriceMappingProfile());
        }

        [Fact(DisplayName = "PriceGetAsync")]
        public void PriceGetAsync()
        {
            var tt =
               new List<Ecommerce.Domain.Price.Product.IProductPrices>() { new FakeProductPrices().GetFakeObject() };

            IQueryable<IProductPrices> aa = new EnumerableQuery<IProductPrices>(tt);

            _mockpriceRepository.Setup(x => x.GetAsync(It.IsAny<IProductPriceRequest>(), false)).Returns(Task.FromResult(aa));

            var result = _priceDomainManager.GetAsync(new FakeProductPriceRequest().GetFakeObject()).Result;

            Assert.NotNull(result);
        }
    }

    public class FakeProductPrices : Ecommerce.Domain.Price.Product.IProductPrices
    {
        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public List<Ecommerce.Domain.Price.Product.IProductPrice> Prices { get; set; }
        public decimal? TotalBidPrice { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public bool IsEDCPurchasableByCustomer { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public FakeProductPrices GetFakeObject()
        {
            return new FakeProductPrices()
            {
                ProductId = 1,
                ProductCode = "abc",
                Prices = new List<Ecommerce.Domain.Price.Product.IProductPrice>() { new FakeProductPrice().GetFakeObject() }
            };
        }
    }

    public class FakeProductPrice : Ecommerce.Domain.Price.Product.IProductPrice
    {
        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public int Id { get; set; }
        public double Price { get; set; }
        public Ecommerce.Domain.Price.Product.IProductPrice BStockOriginalPrice { get; set; }
        public Ecommerce.Domain.Price.Product.IProductPrice ModeMsrp { get; set; }
        public string PriceKey { get; }
        public string CurrencyCode { get; }
        public string PriceFormatted { get; }
        public string PriceFormattedLong { get; }
        public string Name { get; set; }
        public string PriceCode { get; set; }
        public Type PriceType { get; set; }
        public string PricingType { get; set; }
        public bool HasStaticPrice { get; set; }
        public bool IsMandatory { get; }
        public bool IsPriceOverride { get; set; }
        public IList<CdwBidPrice> BidTierPrices { get; set; }
        public string CurrencySign { get; }
        public int ContractId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IList<CdwBidPrice> BidTierPricesInfo { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public CdwPriceMapPromotion MapPrice { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public FakeProductPrice GetFakeObject()
        {
            return new FakeProductPrice()
            {
            };
        }
    }

    public class FakeProductPriceRequest : Cdw.Domain.Partners.Price.IProductPriceRequest
    {
        public List<string> EDC { get; set; }
        public string UserTrackingId { get; set; }
        public string CompanyCode { get; set; }
        public string CustomPageKey { get; set; }
        public string SessionKey { get; set; }
        public List<string> Contracts { get; set; }
        public bool LowestPrice { get; set; }
        public bool IsLoggedIn { get; set; }
        public bool IsTransactiveUser { get; set; }
        public bool IsEProcurementUser { get; set; }
        public bool IsEppUser { get; set; }
        public ITrackingValues TrackingValues { get; set; }

        public FakeProductPriceRequest GetFakeObject()
        {
            return new FakeProductPriceRequest()
            {
                EDC = new List<string>() { "abc" },
                UserTrackingId = Faker.Lorem.GetFirstWord(),
                CompanyCode = "1000",
                CustomPageKey = Faker.Lorem.GetFirstWord(),
                SessionKey = Faker.Lorem.GetFirstWord(),
                Contracts = new List<string>() { "abc" },
                LowestPrice = true,
                IsLoggedIn = true,
                IsTransactiveUser = true,
                IsEProcurementUser = true,
                IsEppUser = true,
                TrackingValues = new FakeTrackingValues().GetFakeObject()
            };
        }
    }
}