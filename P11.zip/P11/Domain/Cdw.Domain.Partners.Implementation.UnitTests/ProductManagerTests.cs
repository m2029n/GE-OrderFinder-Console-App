﻿using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Domain.Partners.Implementation.Product;
using Cdw.Domain.Partners.Product;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Cdw.Services.Core;
using Cdw.Test.Common.Xunit;
using Moq;
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    [CI]
    public class ProductManagerTests
    {
        private readonly Mock<IProductManager> _mockproductManager;
        private readonly Mock<IPartnerConfigurationSettingsManager> _mockConfig;
        private readonly ProductDomainManager _productDomainManager;

        public ProductManagerTests()
        {
            _mockproductManager = new Mock<IProductManager>();
            var mockhealthCheck = new Mock<IHealthCheck>();
            _mockConfig = new Mock<IPartnerConfigurationSettingsManager>();

            Mapper.AddProfile(new ProductMappingProfile());
            _productDomainManager = new ProductDomainManager(_mockproductManager.Object,
                mockhealthCheck.Object, _mockConfig.Object);
        }
        [Fact]
        public void GetProductsAsyncTest()
        {
            var expected = new FakeProductCode().GetFakeObject();
            _mockproductManager.Setup(x => x.GetProductsAsync(It.IsAny<IList<string>>(), It.IsAny<string>())).ReturnsAsync(new List<IProductCore>() { expected });

            _mockConfig.Setup(x => x.GetPartnerConfigurationSettingsByNameAsync("xerox name")).ReturnsAsync(
                  new PartnerConfigurationSettings()
                  {
                      CompanyCode = 1,
                      ClientName = "xerox name",
                      ClientId = 1
                  }

                );

            var actual = _productDomainManager.GetProductAsync(new FakeProductRequest().GetFakeObject()).Result;

            Assert.NotNull(actual);
            Assert.Equal( expected.FriendlyDescription,actual.FriendlyDescription);
            Assert.Equal( expected.FriendlyName,actual.FriendlyName);
        }
    }

    public class FakeProductRequest : IProductRequest
    {
        public IEnumerable<string> ProductCodes { get; set; }
        public string ClientName { get; set; }
        public Partner? PartnerName { get; set; }
        public ITrackingValues TrackingValues { get; set; }

        public FakeProductRequest GetFakeObject()
        {
            return new FakeProductRequest()
            {
                ClientName ="xerox name",
                PartnerName = Partner.XeroxDirect,
                TrackingValues = new FakeTrackingValues().GetFakeObject(),
                ProductCodes = new List<string>() { "abc" }
            };
        }
    }

    public class FakeProductCode : IProductCore
    {
        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public string Name { get; set; }
        public string FriendlyName { get; set; }
        public string Description { get; set; }
        public string FriendlyDescription { get; set; }
        public string ManufacturePartNumber { get; set; }
        public int ManufactureId { get; set; }
        public string UNSPC { get; set; }
        public bool IsSubscription { get; set; }
        public string ShoppingExperienceValueKey { get; set; }
        public string ProductGroup { get; set; }
        public bool IsBundle { get; set; }
        public string ManufactureKey { get; set; }
        public string ManufactureCode { get; set; }
        public string ManufactureName { get; set; }
        public decimal Weight { get; set; }
        public decimal Height { get; set; }
        public decimal ShippingWeight { get; set; }
        public decimal Width { get; set; }
        public decimal Length { get; set; }
        public string LogicalCatalog { get; set; }
        public bool NonReturnable { get; set; }
        public int DropShipOnly { get; set; }
        public DateTime DateSellStart { get; set; }
        public DateTime DateSellStop { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public string ImageEDC { get; set; }
        public string SpinSetName { get; set; }
        public int ReplacementProductId { get; set; }
        public string ProductClass { get; set; }
        public int? SalesRank { get; set; }
        public string StockSource { get; set; }
        public string ProductType { get; set; }
        public bool IsCustomerSpecificEDC { get; set; }
        public string SupplierInventoryTypeCode { get; set; }
        public string WebClassCode { get; set; }
        public string CompanyPartNumber { get; set; }
        public bool IsConfigurable { get; set; }
        public bool IsDiscontinued { get; set; }
        public bool IsPriceOverride { get; set; }
        public ProductDescription ProductOverviewDescription { get; set; }
        public string RootManufactureName { get; set; }
        public string ParentManufactureCode { get; set; }
        public string ParentManufactureName { get; set; }
        public bool ChildMfgLogo { get; set; }

        public FakeProductCode GetFakeObject(string code = "abc")
        {
            return new FakeProductCode()
            {
                ProductCode = code,
                ManufacturePartNumber = Faker.RandomNumber.Next(10).ToString(),
                Description = Faker.Lorem.Sentence(10),
                FriendlyName = Faker.Lorem.Sentence(10),
                FriendlyDescription = Faker.Lorem.Sentence(10),
                Name = Faker.Lorem.GetFirstWord()
            };
        }
    }
}