﻿using System;
using System.IO;
using Cdw.Partners.Utilities;
using log4net.Core;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Utils
{
    public class StackTracePatternConvertorTests : StackTracePatternConvertor
    {
        private bool _wasCalled;

        protected override void Convert(TextWriter writer, object state)
        {
            base.Convert(writer, state);
            _wasCalled = true;
        }

        [Fact]
        public void StackTracePatternConvertorTests_should_behappy_when_haslines()
        {
            try
            {
                throw new Exception("test");
            }
            catch (Exception ex)
            {
                var loggingEvent = new LoggingEvent(GetType(), null, "logger name", Level.Fatal, "test", ex);
                using (var mockWriter = new StringWriter())
                {
                    Convert(mockWriter, loggingEvent);
                    Assert.True(_wasCalled);
                    Assert.StartsWith("\"   at Cdw.Domain.Partners.Implementation.UnitTests.Utils.StackTracePatternConvertorTests.StackTracePatternConvertorTests_should_behappy_when_haslines", mockWriter.ToString().Trim());
                }
            }
        }

        [Fact]
        public void StackTracePatternConvertorTests_should_behappy_when_null_passed()
        {
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, null);
                Assert.True(_wasCalled);
            }
        }

        [Fact]
        public void StackTracePatternConvertorTests_should_behappy_when_nullException_passed()
        {
            var loggingEvent = new LoggingEvent(GetType(), null, "logger name", Level.Fatal, "test", null);
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, loggingEvent);
                Assert.True(_wasCalled);
                Assert.Equal(mockWriter.ToString(), "\"\"");
            }
        }
    }
}