﻿using System;
using System.IO;
using Cdw.Partners.Utilities;
using log4net.Core;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Utils
{
    public class ExceptionMessagePatternConvertorTests : ExceptionMessagePatternConvertor
    {
        private bool _wasCalled;

        protected override void Convert(TextWriter writer, object state)
        {
            base.Convert(writer, state);
            _wasCalled = true;
        }

        [Fact]
        public void ExceptionMessagePatternConvertor_should_behappy_when_string_passed()
        {
            var loggingEvent = new LoggingEvent(GetType(), null, "logger name", Level.Fatal, "test", new Exception("test"));
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, loggingEvent);
                Assert.True(_wasCalled);
                Assert.Equal(mockWriter.ToString(), "\"test\"");
            }
        }

        [Fact]
        public void ExceptionMessagePatternConvertor_should_behappy_when_objects_passed()
        {
            var loggingEvent = new LoggingEvent(GetType(), null, "logger name", Level.Fatal, "test", new Exception("{message= some message}"));
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, loggingEvent);
                Assert.True(_wasCalled);
                Assert.Equal(mockWriter.ToString(), "{message= some message}");
            }
        }

        [Fact]
        public void ExceptionMessagePatternConvertor_should_behappy_when_null_passed()
        {
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, null);
                Assert.True(_wasCalled);
            }
        }

        [Fact]
        public void ExceptionMessagePatternConvertor_should_behappy_when_nullException_passed()
        {
            var loggingEvent = new LoggingEvent(GetType(), null, "logger name", Level.Fatal, "test", null);
            using (var mockWriter = new StringWriter())
            {
                Convert(mockWriter, loggingEvent);
                Assert.True(_wasCalled);
                Assert.Equal(mockWriter.ToString(), "\"\"");
            }
        }
    }
}