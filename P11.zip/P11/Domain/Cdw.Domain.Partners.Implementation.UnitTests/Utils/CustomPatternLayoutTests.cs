﻿using Cdw.Partners.Utilities;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Utils
{
    public class CustomPatternLayoutTests
    {
        [Fact]
        public void CustomPatternLayout_should_pass()
        {
            var sut = new CustomPatternLayout();
            Assert.NotNull(sut);
        }
    }
}