﻿using System;
using System.Collections.Generic;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Tax;
using IAccount = Cdw.Domain.Partners.Orders.IAccount;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    public class FakeTrackingValues : ITrackingValues
    {
        public Guid CorrelationId { get; set; }
        public Guid TrackingId { get; set; }

        public FakeTrackingValues GetFakeObject()
        {
            return new FakeTrackingValues()
            {
                CorrelationId = Guid.NewGuid(),
                TrackingId = Guid.NewGuid()
            };
        }
    }

    public class FakeAccount : IAccount
    {
        public string CustomerNumber { get; set; }
        public string EAccount { get; set; }
        public string EmailAddress { get; set; }

        public FakeAccount GetFakeObject()
        {
            return new FakeAccount()
            {
                CustomerNumber = Faker.RandomNumber.Next(10).ToString(),
                EAccount = Faker.Lorem.GetFirstWord(),
                EmailAddress = Faker.Internet.FreeEmail()
            };
        }
    }

    public class FakeTaxResponse : Cdw.Domain.Tax.ITaxResponse
    {
        public IEnumerable<Domain.Tax.ITax> Headers { get; set; }
        public IEnumerable<Domain.Tax.ITax> LineItems { get; set; }
        public IEnumerable<IProductFeeResponse> ProductFees { get; set; }

        public FakeTaxResponse GetFakeObject()
        {
            return new FakeTaxResponse()
            {
                Headers = new List<Domain.Tax.ITax>() { new FakeTax().GetFakeObject() },
                LineItems = new List<Domain.Tax.ITax>() { new FakeTax().GetFakeObject() },
                ProductFees = new List<Domain.Tax.IProductFeeResponse>() { new FakeProductFeeResponse().GetFakeObject() }
            };
        }
    }
}