﻿using Xunit;

namespace Cdw.Partners.Utilities.Tests
{
    public class CustomPatternLayoutTests
    {
        [Fact()]
        public void CustomPatternLayoutTest()
        {
            var sut = new CustomPatternLayout();
            Assert.NotNull(sut);
        }
    }
}