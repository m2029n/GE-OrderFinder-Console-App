﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Ecommerce.Domain.Order;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;

namespace Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects
{
    public static class FakerOrderDetails
    {
        public static IProductManager MockProductManager()
        {
            var repo = new Mock<IProductManager>();
            repo.Setup(x => x.GetProductsAsync(It.IsAny<List<string>>(), It.IsAny<string>())).
                Returns(Task.FromResult(GetProducts()));
            return repo.Object;
        }

        public static IOrderDomainManager MockOrderManager()
        {
            var repo = new Mock<IOrderDomainManager>();
            repo.Setup(x => x.GetOrderHeaderByPONumber(It.IsAny<string>(), It.IsAny<string>())).
                Returns(Task.FromResult(GetOrderHeader()));
            repo.Setup(x => x.GetOrderDetails(It.IsAny<CompanyCode>(), It.IsAny<string>(), It.IsAny<DataMap>())).
                Returns(Task.FromResult(GetOrderDetails()));
            return repo.Object;
        }

        internal static IEnumerable<IProductCore> GetProducts()
        {
            List<ProductCore> products = new List<ProductCore>();
            products.Add(new ProductCore
            {
                ProductCode = "070807",
                Name = "LEXMARK 6408 RIB BLK 6PK",
                FriendlyDescription = "Compatible with Lexmark 6408",
                FriendlyName = "Lexmark 6408 Black Ribbon (6 pack)",
                ManufacturePartNumber = "1040990",
                ManufactureId = 5544,
                UNSPC = "44103116",
                IsSubscription = false,
                ManufactureKey = "46CAA04437FD11D4B7050008C7C55D36",
                ManufactureCode = "LXX",
                ManufactureName = "Lexmark Supplies",
                Weight = 2.34m,
                Height = 4.4m,
                Width = 7.7m,
                DropShipOnly = 0,
                DateSellStart = DateTime.Now.AddDays(-10),
                DateSellStop = DateTime.Now.AddDays(-8),
                DateCreated = DateTime.Now.AddDays(-6),
                DateModified = DateTime.Now.AddDays(-4),
                ImageEDC = "070807",
                //ReplacementProductId = 0,
                ProductClass = "PU",
                StockSource = "P",
                ProductType = "P",
                IsCustomerSpecificEDC = false,
                IsBundle = false,
                WebClassCode = "P08",
                ProductGroup = "PRB",
                CompanyPartNumber = "LXX-1040990",
                IsConfigurable = false,
            });
            products.Add(new ProductCore
            {
                ProductCode = "075945",
                Name = "BRO LBL TAPE 1/2\" BLK ON CLEAR",
                FriendlyDescription = "Brother 1/2\" Black on Clear Laminated Tape",
                FriendlyName = "Lexmark 6408 Black Ribbon (6 pack)",
                ManufacturePartNumber = "TX1311",
                ManufactureId = 7971,
                UNSPC = "14111506",
                IsSubscription = false,
                ManufactureKey = "69A7C9B109EA415CBED07BB56B6D6DB7",
                ManufactureCode = "BTS",
                ManufactureName = "Brother Supplies",
                Weight = 0.315m,
                Height = 0.315m,
                Width = 1.1m,
                DropShipOnly = 0,
                NonReturnable = true,
                DateSellStart = DateTime.Now.AddDays(-10),
                DateSellStop = DateTime.Now.AddDays(-8),
                DateCreated = DateTime.Now.AddDays(-6),
                DateModified = DateTime.Now.AddDays(-4),
                ImageEDC = "075945",
                // ReplacementProductId = 0,
                ProductClass = "PU",
                StockSource = "P",
                ProductType = "P",
                IsCustomerSpecificEDC = false,
                IsBundle = false,
                WebClassCode = "PD3",
                ProductGroup = "PLA",
                CompanyPartNumber = "BTS-TX1311",
                IsConfigurable = false,
            });
            products.Add(new ProductCore
            {
                ProductCode = "074986",
                Name = "BROTHER THERMAPLUS FAX PAPER 98' 2PK",
                FriendlyDescription = "Compatible with Brother FAX170, 190, 275, 290MC, 375MC, INSTAFAX2100M, 2200M, 600, 610, 615, 620, 625, 635, 640, 650M, 675, 680, 700, 710M, 715M, 720M, 725M, 740M, 780MC, 800M, 810MC, 820MC, 825MC, X875MC, MFC390MC, MFC670, MFC690, MFC695, MFC890MC",
                FriendlyName = "Brother ThermaPlus Paper (98 ft) (2 pack)",
                ManufacturePartNumber = "6890",
                ManufactureId = 7971,
                UNSPC = "14111508",
                IsSubscription = false,
                ManufactureKey = "69A7C9B109EA415CBED07BB56B6D6DB7",
                ManufactureCode = "BTS",
                ManufactureName = "Brother Supplies",
                Weight = 2.58m,
                Height = 2.58m,
                Width = 5.3m,
                DropShipOnly = 0,
                NonReturnable = true,
                DateSellStart = DateTime.Now.AddDays(-10),
                DateSellStop = DateTime.Now.AddDays(-8),
                DateCreated = DateTime.Now.AddDays(-6),
                DateModified = DateTime.Now.AddDays(-4),
                ImageEDC = "074986",
                // ReplacementProductId = 0,
                ProductClass = "PU",
                StockSource = "P",
                ProductType = "P",
                IsCustomerSpecificEDC = false,
                IsBundle = false,
                WebClassCode = "P0H",
                ProductGroup = "FXA",
                CompanyPartNumber = "BTS-6890",
                IsConfigurable = false,
            });
            return products;
        }

        internal static IRecentOrder GetOrderHeader()
        {
            var order = new RecentOrder
            {
                CompanyCode = "01",
                OrderCode = "1BMXLMD",
                CustomerNumber = " 3201028"
            };
            return order;
        }

        internal static IOrderDetails GetOrderDetails()
        {
            var details = new OrderDetails
            {
                Header = new OrderHeader
                {
                    PaymentMethodName = "Net 30 Verbal",
                    PaymentCode = "",
                    IsLease = false,
                    OrderStatus = OrderStatus.Shipped,
                    NumberOfBoxes = 3,
                    PaymentType = "020",
                    FreightTotal = 40.04m,
                    QuoteNumber = "N",
                    OrderValue = 4468,
                    ShippingCarrier = "UPS Ground (2 - 3 day)",
                    ShippingCarrierCode = "CJ",
                    SuspendCode = "DH",
                    StatusCode = "",
                    SubTotal = 0,
                    ContactSequence = 105,
                    PoNumber = "110320",
                    OrderDate = DateTime.Now.AddMonths(-5),
                    OrderCode = "1BMV3FC",
                    CustomerNumber = "0665881",
                    CompanyCode = "01",
                    BillingAddress = new BillingAddress
                    {
                        Phone = "6107756000",
                        PostalCode = "19603-0563",
                        StateProv = "PA",
                        City = "READING",
                        CompanyName = "PENSKE TRUCK LEASING CO, LP",
                        Address2 = "",
                        Address1 = "PO BOX 563",
                        ContactName = "HEATHER BARNES",
                        LastName = "PENSKE TRUCK LE",
                        MiddleInitial = "",
                        FirstName = ""
                    },
                    InvoicedItemCount = 2
                },
                LineItems = new List<OrderLineItem>
                {
                    new OrderLineItem{
                       BackorderedEstShipDate = DateTime.Now.AddMonths(-2),
                       QuantityBackordered = 0,
                       OrderLineStatus = OrderStatus.Shipped,
                       QuantityDespatched = 2,
                       CDWReferenceCode = 20640,
                       ContractName = "PENSKE TRUCK LEASING",
                       PriceListCode = "P8E",
                       TaxAmount = 22.2m,
                       OnBehalfFlag = "N",
                       OrderLineValue = 370,
                       SuspendCode = "DH",
                       QuantityOutstanding = 0,
                       Status= "C",
                       Price = 185,
                       Quantity = 2,
                       ProductCode = "070807",
                       OrderLineNumber= 0
                    },
                    new OrderLineItem
                    {
                      BackorderedEstShipDate = DateTime.Now.AddMonths(-2),
                      QuantityBackordered = 0,
                      OrderLineStatus = OrderStatus.Canceled,
                      QuantityDespatched = 0,
                      CDWReferenceCode = 20640,
                      ContractName = "PENSKE TRUCK LEASING",
                      PriceListCode= "P8E",
                      TaxAmount = 185.4m,
                      OnBehalfFlag = "N",
                      OrderLineValue = 3090,
                      SuspendCode = "DH",
                      QuantityOutstanding = 0,
                      Status = "X",
                      Price = 1545,
                      Quantity = 2,
                      ProductCode = "075945",
                      OrderLineNumber = 0
                    },
                    new OrderLineItem
                    {
                        BackorderedEstShipDate = DateTime.Now.AddMonths(-3),
                        QuantityBackordered = 0,
                        OrderLineStatus = OrderStatus.ProcessingOrder,
                        QuantityDespatched = 0,
                        CDWReferenceCode = 20640,
                        ContractName = "PENSKE TRUCK LEASING",
                        PriceListCode = "P8E",
                        TaxAmount = 9.48m,
                        OnBehalfFlag = "N",
                        OrderLineValue = 158m,
                        SuspendCode = "DH",
                        QuantityOutstanding = 2,
                        Status = "",
                        Price = 79,
                        Quantity = 2,
                        ProductCode = "074986",
                        OrderLineNumber = 0
                    }
                },
                Shipments = new List<ShipmentBox>
                {
                    new ShipmentBox {
                        Weight = 10.79m,
                       TrackingNumber = "P1ZE633380377829364",
                       ShipMethod = "UPS Ground (2 - 3 Day)",
                       ShipDate = DateTime.Now.AddMonths(-2),
                       InvoiceNumber = "CSM3157",
                       CarrierCode = "UPS",
                       Contents = new List<ShipmentBoxContent>
                       {
                           new ShipmentBoxContent {
                              QuantityInBox =1,
                              OrderLineNumber = 4,
                             ManufacturerPartNumber = "40A20170US",
                              EstimatedQuantity = 0,
                              EDC = "3154444",
                             Description = "Lenovo ThinkPad Ultra Dock - port replicator"
                            }
                       }
                   }
                }
            };
            return details;
        }
    }

    internal class OrderDetails : IOrderDetails
    {
        public IOrderHeader Header { get; set; }

        public IEnumerable<IOrderLineItem> LineItems { get; set; }

        public IEnumerable<IShipmentBox> Shipments { get; set; }

        public IEnumerable<IOrderTax> Taxes { get; set; }
    }

    internal class BillingAddress : IBillingAddress
    {
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string LastName { get; set; }
        public string ContactName { get; set; }
        public string AttentionName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string CompanyName { get; set; }
        public string City { get; set; }
        public string StateProv { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
    }

    internal class OrderHeader : IOrderHeader
    {
        public int InvoicedItemCount { get; set; }
        public IBillingAddress BillingAddress { get; set; }
        public IAddress ShippingAddress { get; set; }
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
        public string OrderCode { get; set; }
        public DateTime OrderDate { get; set; }
        public string PoNumber { get; set; }
        public int ContactSequence { get; set; }
        public decimal SubTotal { get; set; }
        public string StatusCode { get; set; }
        public string SuspendCode { get; set; }
        public string ShippingCarrierCode { get; set; }
        public string ShippingCarrier { get; set; }
        public decimal OrderValue { get; set; }
        public string QuoteNumber { get; set; }
        public decimal FreightTotal { get; set; }
        public string PaymentType { get; set; }
        public string PaymentMethodName { get; set; }
        public int NumberOfBoxes { get; set; }
        public bool IsLease { get; set; }

        public OrderStatus OrderStatus { get; set; }

        public string PaymentCode { get; set; }
        public string PurchasedBy { get; set; }
        public DateTime? InvoicedDate { get; set; }
        private string _orderStatusMessage;

        public string OrderStatusMessage
        {
            get
            {
                string returnValue;
                if (StatusCode != null)
                {
                    _orderStatusMessage = StatusCode.Trim().ToUpper();
                }

                var suspendCode = string.Empty;
                if (SuspendCode != null)
                {
                    suspendCode = SuspendCode.Trim().ToUpper();
                }

                var shippingCarrier = string.Empty;
                if (ShippingCarrierCode != null)
                {
                    shippingCarrier = ShippingCarrierCode.Trim().ToUpper();
                }

                if ("C".Equals(_orderStatusMessage))
                {
                    returnValue = "WC".Equals(shippingCarrier) ? "[All Items have been picked up from willcall]" : "[All Items Shipped]";
                }
                else if ("X".Equals(_orderStatusMessage) || "8".Equals(_orderStatusMessage))
                {
                    if (InvoicedItemCount == 0)
                    {
                        returnValue = "[Canceled]";
                    }
                    else
                    {
                        returnValue = "WC".Equals(shippingCarrier) ? "[All Items have been picked up from willcall]" : "[All Items Shipped]";
                    }
                }
                else if ("DW".Equals(suspendCode) || "TW".Equals(suspendCode) || "MW".Equals(suspendCode))
                {
                    returnValue = "[Backordered Item(s)]";
                }
                else if (String.IsNullOrEmpty(_orderStatusMessage) && "WC".Equals(shippingCarrier) && String.IsNullOrEmpty(suspendCode))
                {
                    returnValue = "All items on this order are ready to be picked up in will call";
                }
                else if ("CW".Equals(_orderStatusMessage))
                {
                    returnValue = "Processing Order";
                }
                else
                {
                    returnValue = "Item(s) have not yet shipped";
                }

                return returnValue;
            }

            internal set { _orderStatusMessage = value; }
        }
    }

    internal class RecentOrder : IRecentOrder
    {
        public string CompanyCode { get; set; }

        public string OrderCode { get; set; }

        public string CustomerNumber { get; set; }
    }

    internal class OrderLineItem : IOrderLineItem
    {
        public string CompanyCode { get; set; }
        public string OrderNumber { get; set; }
        public int OrderLineNumber { get; set; }
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
        public int QuantityOutstanding { get; set; }
        public string SuspendCode { get; set; }
        public decimal OrderLineValue { get; set; }
        public string OnBehalfFlag { get; set; }
        public decimal TaxAmount { get; set; }
        public string PriceListCode { get; set; }
        public string ContractName { get; set; }
        public int CDWReferenceCode { get; set; }
        public decimal QuantityDespatched { get; set; }
        public OrderStatus OrderLineStatus { get; set; }

        public int QuantityBackordered { get; set; }
        public DateTime BackorderedEstShipDate { get; set; }
    }

    internal class ShipmentBox : IShipmentBox
    {
        public int BoxNumber { get; set; }
        public string CarrierCode { get; set; }
        public string CarrierCodeType { get; set; }
        public IEnumerable<IShipmentBoxContent> Contents { get; set; }
        public DateTime? EstimatedDeliveryDate { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? ShipDate { get; set; }
        public string ShipMethod { get; set; }
        public ITrackingDetail TrackingDetail { get; set; }
        public string TrackingNumber { get; set; }
        public decimal? Weight { get; set; }
    }

    internal class ShipmentBoxContent : IShipmentBoxContent
    {
        public string Description { get; set; }
        public string EDC { get; set; }
        public int? EstimatedQuantity { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public int? OrderLineNumber { get; set; }
        public int? QuantityInBox { get; set; }
    }
}