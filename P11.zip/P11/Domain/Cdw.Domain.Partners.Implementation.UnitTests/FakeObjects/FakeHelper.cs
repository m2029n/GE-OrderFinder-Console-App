﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects
{
    public static class FakeHelper
    {
        public const string ClientName = "FooBarChooWho?";

        public static RecyclingFee GetRecyclingFeeFakeObject()
        {
            return new RecyclingFee()
            {
                ProductCode = Faker.Lorem.GetFirstWord(),
                Amount = Faker.RandomNumber.Next(10),
                Description = Faker.Lorem.GetFirstWord(),
                Code = Faker.Lorem.GetFirstWord(),
                ProductFeeEDC = Faker.Lorem.GetFirstWord()
            };
        }

        public static LineItem GetFakeLineItemFakeObject()
        {
            var fake = new LineItem().AssignFakeValues();
            fake.Quantity = 2;
            fake.Discounts = new List<Partners.Orders.IDiscount>() { new Discount().AssignFakeValues() };
            fake.CustomProperties = new List<Partners.Orders.ICustomProperty>() { FakeHelper.GetFakeOrderCustomPropertyFakeObject() };

            return fake;
        }

        public static RequestOrder GetFakeRequestorderFakeObject()
        {
            var ro = new RequestOrder()
            {
                Billing = GetFakeBillingInfoFakeObject(),
                TrackingValues = new FakeTrackingValues().GetFakeObject(),
                TransactionDate = DateTime.Now,
                ReferenceNumber = Faker.Lorem.Sentence(10),
                Account = new FakeAccount()
                {
                    EmailAddress = Faker.Internet.FreeEmail(),
                    CustomerNumber = Faker.Lorem.GetFirstWord(),
                    EAccount = Faker.Lorem.GetFirstWord()
                },
                Taxes = null,
                Shipping = new ShippingInfo()
                {
                    Address = FakeHelper.GetFakeOrderAddressFakeObject(),
                    Method = FakeHelper.GetFakeShippingMethodFakeObject()
                },
                Company = 1000,
                Discounts = new List<IDiscount>() { new Discount().AssignFakeValues() },
                CustomProperties = new List<ICustomProperty>() { FakeHelper.GetFakeOrderCustomPropertyFakeObject() },
                LineItems = new List<ILineItem>() { FakeHelper.GetFakeLineItemFakeObject() }
            };

            return ro;
        }

        public static RequestOrder GetFakeRequestorderNOCCFakeObject()
        {
            var ro = new RequestOrder()
            {
                Billing = GetFakeBillingInfoNoCCFakeObject(),
                ClientName = ClientName,
                TrackingValues = new FakeTrackingValues().GetFakeObject(),
                TransactionDate = DateTime.Now,
                ReferenceNumber = Faker.Lorem.Sentence(10),
                Account = new FakeAccount()
                {
                    EmailAddress = Faker.Internet.FreeEmail(),
                    CustomerNumber = Faker.Lorem.GetFirstWord(),
                    EAccount = Faker.Lorem.GetFirstWord()
                },
                Taxes = null,
                Shipping = new ShippingInfo()
                {
                    Address = FakeHelper.GetFakeOrderAddressFakeObject(),
                    Method = FakeHelper.GetFakeShippingMethodFakeObject()
                },
                Company = 1000,
                Discounts = new List<IDiscount>() { new Discount().AssignFakeValues() },
                CustomProperties = new List<ICustomProperty>() { FakeHelper.GetFakeOrderCustomPropertyFakeObject() },
                LineItems = new List<ILineItem>() { FakeHelper.GetFakeLineItemFakeObject() }
            };

            return ro;
        }

        public static BillingInfo GetFakeBillingInfoFakeObject()
        {
            return new BillingInfo()
            {
                Method = FakeHelper.GetFakePaymentMethodFakeObject(),
                Address = FakeHelper.GetFakeOrderAddressFakeObject()
            };
        }

        public static BillingInfo GetFakeBillingInfoNoCCFakeObject()
        {
            return new BillingInfo()
            {
                Method = FakeHelper.GetFakePaymentMethodNoCCFakeObject(),
                Address = FakeHelper.GetFakeOrderAddressFakeObject()
            };
        }

        public static Identity GetFakeIdentityFakeObject()
        {
            var obj = new Identity
            {
                ClientId = 1,
                ClientName = "XeroxUs",
                SourceCode = "XDR",
                Partner = Partners.Common.Partner.XeroxDirect,
                FreightRaterSpecialCode = "A",
            };

            return obj;
        }

        public static CreditCard GetFakeCreditCardFakeObject()
        {
            var bi = new CreditCard()
            {
                Name = Faker.Name.FullName(),
                ExpirationMonth = 12,
                ExpirationYear = 2025,
                Number = "4012000033330011"
            };
            return bi;
        }

        public static PaymentMethod GetFakePaymentMethodFakeObject()
        {
            return new PaymentMethod()
            {
                CreditCard = FakeHelper.GetFakeCreditCardFakeObject()
            };
        }

        public static PaymentMethod GetFakePaymentMethodNoCCFakeObject()
        {
            return new PaymentMethod()
            {
            };
        }

        public static Partners.Orders.Address GetFakeOrderAddressFakeObject()
        {
            return new Partners.Orders.Address()
            {
                City = Faker.Address.City(),
                StreetAddress = Faker.Address.StreetAddress(),
                FirstName = Faker.Name.First(),
                LastName = Faker.Name.Last(),
                PhoneNumber = Faker.Phone.Number(),
                PostalCode = Faker.Address.ZipCode(),
                SecondaryStreetAddress = Faker.Address.SecondaryAddress(),
                State = Faker.Address.UsState(),
                Company = "Cdw",
                IsoCountryCode = "Us"
            };
        }

        public static CustomProperty GetFakeOrderCustomPropertyFakeObject()
        {
            return new CustomProperty().AssignFakeValues();
        }

        public static OrderItemShippingRate GetFakeOrderItemShippingRateFakeObject()
        {
            return new OrderItemShippingRate()
            {
                BoxHandling = Faker.RandomNumber.Next(100),
                CdwCost = Faker.RandomNumber.Next(100),
                Freight = Faker.RandomNumber.Next(100),
                Handling = Faker.RandomNumber.Next(100),
                Insurance = Faker.RandomNumber.Next(100),
                ProductCode = Faker.Lorem.GetFirstWord(),
                Weight = Faker.RandomNumber.Next(100)
            };
        }

        public static OrderShippingRate GetFakeOrderShippingRateFakeObject()
        {
            return new OrderShippingRate()
            {
                ShippingMethodId = Faker.Lorem.GetFirstWord(),
                ShippingMethodDescription = Faker.Lorem.Sentence(10),
                BoxCount = Faker.RandomNumber.Next(10),
                BoxHandlingCharge = Faker.RandomNumber.Next(10),
                FreightCost = Faker.RandomNumber.Next(10),
                Freight = Faker.RandomNumber.Next(10),
                Handling = Faker.RandomNumber.Next(10),
                Insurance = Faker.RandomNumber.Next(10),
                OrderItems = new List<IOrderItemShippingRate>() { FakeHelper.GetFakeOrderItemShippingRateFakeObject() },
                TotalShippingCharge = Faker.RandomNumber.Next(10),
                TotalWeight = Faker.RandomNumber.Next(10),
                TransactionGUID = Guid.NewGuid()
            };
        }

        public static ShippingMethod GetFakeShippingMethodFakeObject()
        {
            return new ShippingMethod()
            {
                Id = Faker.Lorem.GetFirstWord(),
                Description = Faker.Lorem.Sentence(1),
                Rate = FakeHelper.GetFakeOrderShippingRateFakeObject()
            };
        }
    }
}