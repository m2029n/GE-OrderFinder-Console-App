﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Freight;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Ecommerce.Domain.Search;
using Cdw.Ecommerce.Domain.Search.Errors;
using Cdw.Ecommerce.Domain.Search.Filters;
using Cdw.Ecommerce.Domain.Search.HubRefinement;
using Cdw.Ecommerce.Domain.Search.Merchandise;
using Cdw.Ecommerce.Domain.Search.Product;
using Cdw.Ecommerce.Domain.Search.Redirects;

namespace Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects
{
    public class FakeProductFeeResponse : IProductFeeResponse
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
        public decimal OboRate { get; set; }
        public decimal OboAmount { get; set; }
        public string ProductCode { get; set; }
        public int? LineNumber { get; set; }
        public string TaxTypeKey { get; set; }
        public string FeeProductCode { get; set; }

        public FakeProductFeeResponse GetFakeObject()
        {
            return new FakeProductFeeResponse()
            {
                Description = Faker.Lorem.Sentence(10),
                Rate = Faker.RandomNumber.Next(10),
                Amount = Faker.RandomNumber.Next(10),
                OboAmount = Faker.RandomNumber.Next(10),
                OboRate = Faker.RandomNumber.Next(10),
                ProductCode = Faker.Lorem.GetFirstWord(),
                LineNumber = 1,
                TaxTypeKey = Faker.Lorem.GetFirstWord(),
                FeeProductCode = Faker.Lorem.GetFirstWord()
            };
        }
    }

    public class FakeTax : Domain.Tax.ITax
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
        public decimal OboRate { get; set; }
        public decimal OboAmount { get; set; }
        public string ProductCode { get; set; }
        public int? LineNumber { get; set; }
        public string TaxTypeKey { get; set; }

        public FakeTax GetFakeObject()
        {
            return new FakeTax()
            {
                Id = Faker.Lorem.GetFirstWord(),
                Description = Faker.Lorem.Sentence(10),
                Rate = Faker.RandomNumber.Next(10),
                Amount = 7,
                OboRate = Faker.RandomNumber.Next(10),
                OboAmount = Faker.RandomNumber.Next(10),
                ProductCode = Faker.Lorem.GetFirstWord(),
                LineNumber = 1,
                TaxTypeKey = Faker.Lorem.GetFirstWord()
            };
        }
    }

    public class FakeRatingResponse : IRatingResponse
    {
        public string ErrorMessage { get; set; }
        public string TransactionIdentifier { get; set; }
        public int PackageCount { get; set; }
        public IRatedFreight Freight { get; set; }
        public decimal TotalWeight { get; set; }

        public FakeRatingResponse GetFakeObject(string error = null, string freightCode = "YT")
        {
            return new FakeRatingResponse()
            {
                ErrorMessage = error,
                TransactionIdentifier = Guid.NewGuid().ToString(),
                Freight = new FakeRatedFreight().GetFakeObject(freightCode)
            };
        }
    }

    public class FakeRatedFreight : IRatedFreight
    {
        public IEnumerable<IRatedFreightShippingMethod> ShippingMethods { get; set; }
        public IEnumerable<IRatedFreightDetail> Details { get; set; }

        public FakeRatedFreight GetFakeObject(string freightCode = "YT")
        {
            return new FakeRatedFreight()
            {
                ShippingMethods =
                    new List<IRatedFreightShippingMethod>() { new FakeRatedFreightShippingMethod().GetFakeObject(freightCode) },
                Details = new List<IRatedFreightDetail>() { new FakeRatedFreightDetail().GetFakeObject() },
            };
        }
    }

    public class FakeRatedFreightDetail : IRatedFreightDetail
    {
        public string ProductCode { get; set; }
        public int OrderLineNumber { get; set; }
        public decimal Weight { get; set; }
        public IEnumerable<IRatedFreightDetailShippingMethod> ShippingMethods { get; set; }

        public FakeRatedFreightDetail GetFakeObject()
        {
            return new FakeRatedFreightDetail()
            {
                ShippingMethods =
                    new List<IRatedFreightDetailShippingMethod>()
                    {
                        new FakeRatedFreightDetailShippingMethod().GetFakeObject()
                    }
            };
        }
    }

    public class FakeRatedFreightDetailShippingMethod : IRatedFreightDetailShippingMethod
    {
        public string Code { get; set; }
        public string DropShipMethodCode { get; set; }
        public decimal Cost { get; set; }
        public ContractFreightType ContractFreightTypesApplied { get; set; }
        public decimal TotalCharge { get; set; }
        public decimal SaturdayCharge { get; set; }
        public decimal OtherCharge { get; set; }
        public decimal BoxHandlingCharge { get; set; }
        public decimal OrderHandlingCharge { get; set; }
        public decimal InsuranceCharge { get; set; }
        public decimal FreightCharge { get; set; }
        public int ShippingProgramId { get; set; }

        public FakeRatedFreightDetailShippingMethod GetFakeObject()
        {
            return new FakeRatedFreightDetailShippingMethod()
            {
                Code = "YT",
                DropShipMethodCode = Faker.Lorem.GetFirstWord(),
                Cost = Faker.RandomNumber.Next(10),
                ContractFreightTypesApplied = ContractFreightType.Actual,
                TotalCharge = Faker.RandomNumber.Next(10),
                SaturdayCharge = Faker.RandomNumber.Next(10),
                OtherCharge = Faker.RandomNumber.Next(10),
                BoxHandlingCharge = Faker.RandomNumber.Next(10),
                OrderHandlingCharge = Faker.RandomNumber.Next(10),
                InsuranceCharge = Faker.RandomNumber.Next(10),
                FreightCharge = Faker.RandomNumber.Next(10),
                ShippingProgramId = Faker.RandomNumber.Next(10)
            };
        }
    }

    public class FakeRatedFreightShippingMethod : IRatedFreightShippingMethod
    {
        public string Code { get; set; }
        public string SpecialCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string EstimatedArrival { get; set; }
        public bool IsCustomerAccount { get; set; }
        public string WeightType { get; set; }
        public decimal TotalWeight { get; set; }
        public decimal Cost { get; set; }
        public ContractFreightType ContractFreightTypesApplied { get; set; }
        public decimal FreightCharge { get; set; }
        public decimal OtherCharge { get; set; }
        public decimal SaturdayCharge { get; set; }
        public decimal OrderHandlingCharge { get; set; }
        public decimal BoxHandlingCharge { get; set; }
        public decimal InsuranceCharge { get; set; }
        public decimal TotalCharge { get; set; }
        public bool IsChildRateDowngrade { get; set; }
        public bool IsShippingProgramApplied { get; set; }

        public FakeRatedFreightShippingMethod GetFakeObject(string freightCode = "YT")
        {
            return new FakeRatedFreightShippingMethod()
            {
                Code = freightCode,
                Name = Faker.Lorem.GetFirstWord(),
                TotalWeight = Faker.RandomNumber.Next(10),
                Cost = Faker.RandomNumber.Next(10),
                FreightCharge = Faker.RandomNumber.Next(10),
                InsuranceCharge = Faker.RandomNumber.Next(10),
                OrderHandlingCharge = Faker.RandomNumber.Next(10),
                TotalCharge = Faker.RandomNumber.Next(10),
                BoxHandlingCharge = Faker.RandomNumber.Next(10),
            };
        }
    }

    public class FakeCreditCardAuthorizationResponse : ICreditCardAuthorizationResponse
    {
        public bool IsValid { get; set; }
        public string MaskCreditCardNumber { get; set; }
        public string CreditCardToken { get; set; }
        public string ExternalCreditCardToken { get; set; }
        public string CreditCardTokenHandle { get; set; }
        public string ErrorMessage { get; set; }
        public string CreditCardHolderName { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string ErrorCode { get; set; }
        public EErrorServerity ErrorServerity { get; set; }
        public ECreditCardType? CreditCardType { get; set; }
    }

    public class FakeSearchResult : ISearchResult
    {
        public IEnumerable<IProductRecord> Products { get; set; }
        public long ProductsCount { get; set; }
        public IEnumerable<IMerchandiseRecord> Merchandise { get; set; }
        public IEnumerable<IFiltersRecord> Filters { get; set; }
        public IEnumerable<IHubRefinementRecord> HubRefinements { get; set; }
        public INavigationStatus Navigation { get; set; }
        public IDidYouMean DidYouMean { get; set; }
        public IRedirectRecord Redirects { get; set; }
        public IEnumerable<IErrors> Errors { get; set; }

        public FakeSearchResult GetFakeObject()
        {
            return new FakeSearchResult()
            {
                ProductsCount = 100,
                Products = new List<ProductRecord>
                {
                    new ProductRecord()
                    {
                        Rating = "Rating",
                        CoremetricsTag = "CoremetricsTag",
                        FriendlyName = "FriendlyName",
                        ProductId = "ProductId",
                        ProductCode = "ProductCode",
                        As400CategoryCode = "As400CategoryCode",
                        As400CategoryName = "As400CategoryName",
                        WebCategoryCode = "WebCategoryCode",
                        WebCategoryName = "WebCategoryName",
                        FriendlyDescription = "FriendlyDescription",
                        RatingCount = "RatingCount",
                        ManufacturePartNumber = "ManufacturePartNumber",
                        ImageEdc = "ImageEdc",
                        ManufactureCode = "ManufactureCode",
                        ManufacturerName = "ManufacturerName",
                        BrandCode = "BrandCode",
                        BrandName = "BrandName",
                        ShipStatusShort = "ShipStatusShort",
                        ProductPrice = "12.99",
                        ShoppingExperienceValueKey = "ShoppingExperienceValueKey",
                        IsCustomEdc = true,
                        ShipStatusLong = "ShipStatusLong",
                        PriceKey = "PriceKey",
                        IsMembershipShippingEligible = true,
                        CouponCodeList = "CouponCodeList"
                    }
                }
            };
        }
    }

    public class FakeCouponRequest : ICouponRequest
    {
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
        public string OrderNumber { get; set; }
        public IEnumerable<string> CouponCodes { get; set; }
        public int? ContactSequence { get; set; }
        public string OrderStatus { get; set; }
        public EOrderType OrderType { get; set; }
        public string RequestForUser { get; set; }
        public string ShippingMethodCode { get; set; }
        public string DeliverySequence { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal? OrderValue { get; set; }
        public decimal? FreightCharge { get; set; }
        public string TokenCode { get; set; }
        public IEnumerable<IProductLine> Products { get; set; }

        public FakeCouponRequest GetFakeObject()
        {
            return new FakeCouponRequest()
            {
                CompanyCode = "01",
                ContactSequence = 1,
                OrderStatus = "1",
                OrderType = EOrderType.Order,
                RequestForUser = "WEBUSER",
                DeliverySequence = "000",
                OrderDate = DateTime.Now,
                OrderValue = 600,
                TokenCode = "xxxxx",
                Products = new[]
            {
                    new ProductLine()
                    {
                        ProductCode = "2873249",
                        LineNumber = 1,
                        QuantityOrdered = 10,
                        QuantityAllocated = 10,
                        QuantityOutstanding = 0,
                        IsCancelled = false,
                        IsDropShip = false,
                        Pricing = new List<ICouponPrice>
                        {
                            new CouponPrice
                            {
                                UnitPrice = 60,
                                PriceType = EPriceType.Advertised,
                            },
                            new CouponPrice
                            {
                                UnitPrice = 0,
                                PriceType = EPriceType.Extranet,
                            },
                            new CouponPrice
                            {
                                UnitPrice = 60,
                                PriceType = EPriceType.Unit,
                            }
                        }
                    }
                }
            };
        }
    }

    

    public class FakeCouponResponse : ICouponResponse
    {

        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
        public IEnumerable<ICouponItem> CouponItems { get; set; }
        public IEnumerable<ICouponDetail> CouponDetails { get; set; }
        public ICouponError ErrorInfo { get; set; }

        public FakeCouponResponse GetFakeObject()
        {
            return new FakeCouponResponse()
            {
                CompanyCode = "1000",
                CouponDetails = new List<ICouponDetail>()
                {    new CouponDetail()
                    {
                    CouponCode = "17C019",
                    CouponType = ECouponType.FlatAmountOffProduct,
                    CouponDescription = "$150 off Toshiba Notebooks",
                    CouponPercent = 0,
                    CouponValue = 150,
                    EffectiveDate = new DateTime(2017 - 05 - 01),
                    EndDate = new DateTime(2017 - 06 - 30),
                    MaxDollarsPerCustomerLimit = 2250,
                    MaxQtyPerCustomerLimit = 2250,
                    OrderMaxPurchaseLimit = 999999.99m,
                    OrderMinPurchaseLimit = 0,
                    ProductMaxQtyLimit = 15,
                    ProductMinQtyLimit = 1,
                    QuantityAllowed = 15
                    }
                },
                CouponItems = new List<ICouponItem>()
                 {
                     new CouponItem()
                      {
                        ProductCode = "4562743",
                        LineNumber = 1,
                        CouponCode = "17C019",
                        OriginalPrice = 0,
                        DiscountedPrice = 0,
                        CouponValue = 0,
                        QuantityApplied = 0,
                        Disclaimer = "Instant savings of <b>$150 off Toshiba Notebooks</b>;Limit to <b>$2,250.00</b>, or <b>15</b> units per customer;Limit of one coupon per order; savings will be applied once the item is placed in the cart; not valid for quote and leasing options (offer valid through <b>6/30/2017</b> while supplies last); details are subject to change",
                        ErrorInfo = new CouponError()
                        {
                           ReasonCode = "606",
                           ReasonMessage = "Quantity Ordered not allowed for the coupon."
                        }
                  }
                }
            };
        }
    }
}