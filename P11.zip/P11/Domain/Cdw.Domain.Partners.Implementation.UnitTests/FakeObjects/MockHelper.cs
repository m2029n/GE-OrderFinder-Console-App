﻿using System;
using System.Collections.Generic;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Infrastructure.Services;
using Moq;

namespace Cdw.Domain.Partners.Implementation.UnitTests.MockObjects
{
    internal static class MockHelper
    {
        public static IOrderDetail MockOrderDetailObject(string orderCode)
        {
            var te = new Mock<IOrderDetail>();
            var oh = new Mock<IOrderHeader>();
            oh.Setup(x => x.OrderCode).Returns(orderCode);
            oh.Setup(x => x.OrderStatus).Returns("Shipped");
            te.Setup(x => x.OrderHeader).Returns(oh.Object);
            te.Setup(x => x.OrderLines).Returns(new List<IOrderLine>() { MockOrderLineObject(orderCode) });
            return te.Object;
        }

        public static IOrderLine MockOrderLineObject(string orderCode)
        {
            var te = new Mock<IOrderLine>();
            te.Setup(x => x.OrderLineStatus).Returns("status");
            te.Setup(x => x.Price).Returns(Faker.RandomNumber.Next(100));
            te.Setup(x => x.ProductCode).Returns("123");
            return te.Object;
        }

        public static CreditCardEntity MockCreditCardEntityObject()
        {
            var te = new CreditCardEntity()
            {
                CreditCardType = PaymentMethodTypeEntity.Visa,
                CreditCardToken = Faker.Lorem.GetFirstWord(),
                CreditCardExpirationDate = DateTime.Now.AddDays(100),
                CreditCardHolderName = Faker.Name.First(),
                CreditCardNumber = Faker.RandomNumber.Next(100).ToString(),
                CreditCardNumberLastFour = Faker.RandomNumber.Next(10).ToString(),
                CreditCardTokenID = Faker.RandomNumber.Next(10),
                PaymentMethodOptionID = Faker.RandomNumber.Next(10)
            };
            return te;
        }

        public static OrderEntity MockOrderEntityObject(string orderCode)
        {
            var oe = new OrderEntity()
            {
                OrderID = 115936,
                TransactionDate = DateTime.Now,
                Source = "XDR",
                ReferenceNumber = "testdatadcdb2c56",
                Account_CustomerNumber = string.Empty,
                Account_EAccount = String.Empty,
                Account_EmailAddress = Faker.Internet.Email(),
                FreightCost = 5.56M,
                Freight = 0,
                Handling = 0,
                Insurance = 0,
                Billing_FirstName = Faker.Name.First(),
                Billing_LastName = Faker.Name.Last(),
                Billing_PhoneNumber = Faker.Phone.Number(),
                Billing_Company = "CDW Gets IT",
                Billing_StreetAddress = Faker.Address.StreetAddress(),
                Billing_SecondaryStreetAddress = Faker.Address.SecondaryAddress(),
                Billing_City = Faker.Address.City(),
                Billing_State = Faker.Address.UsState(),
                Billing_PostalCode = Faker.Address.ZipCode(),
                Billing_IsoCountryCode = "US",
                Billing_Method_PONumber = "CRE42326",
                Billing_Method_CreditCardTokenID = 3939740,
                Shipping_FirstName = Faker.Name.First(),
                Shipping_LastName = Faker.Name.Last(),
                Shipping_PhoneNumber = Faker.Phone.Number(),
                Shipping_Company = "CDW People Who Get IT",
                Shipping_StreetAddress = Faker.Address.StreetAddress(),
                Shipping_SecondaryStreetAddress = Faker.Address.SecondaryAddress(),
                Shipping_City = Faker.Address.City(),
                Shipping_State = Faker.Address.UsState(),
                Shipping_PostalCode = Faker.Address.ZipCode(),
                Shipping_IsoCountryCode = "US",
                Shipping_Method_Id = "XV",
                Shipping_Method_Description = "CDW Xerox FREE -FedEx Ground",
                CartID = 108322,
                OrderCode = orderCode,
                BoxCount = 1,
                Weight = 11,
                TotalShippingCharge = 0,
                BoxHandlingCharge = 0,
                FreightTransactionID = Guid.NewGuid(),
                IpAddress = "127.0.0.1",
                Geolocation = "chicago",
                UserAgent = "chrome",
                Taxes = new List<TaxEntity>() { MockTaxEntityObject() },
                RecycleFees = new List<RecycleFeeEntity>() { MockRecycleFeeEntityObject() },
                OrderItems = new List<OrderItemShippingRateEntity>() { MockOrderItemShippingRateEntityObject() },
            };

            return oe;
        }

        public static OrderItemShippingRateEntity MockOrderItemShippingRateEntityObject()
        {
            var te = new OrderItemShippingRateEntity()
            {
                ProductCode = Faker.Lorem.GetFirstWord(),
                OrderID = 115936,
                BoxHandling = Faker.RandomNumber.Next(10),
                CdwCost = Faker.RandomNumber.Next(10),
                Freight = Faker.RandomNumber.Next(10),
                Handling = Faker.RandomNumber.Next(10),
                Insurance = Faker.RandomNumber.Next(10),
                Weight = Faker.RandomNumber.Next(10)
            };
            return te;
        }

        public static RecycleFeeEntity MockRecycleFeeEntityObject()
        {
            var te = new RecycleFeeEntity()
            {
                Amount = Faker.RandomNumber.Next(100),
                Description = Faker.Lorem.Sentence(20),
                Code = Faker.Lorem.GetFirstWord(),
                OrderId = 115936,
                ProductCode = Faker.Lorem.GetFirstWord()
            };
            return te;
        }

        public static TaxEntity MockTaxEntityObject()
        {
            var te = new TaxEntity()
            {
                Amount = Faker.RandomNumber.Next(100),
                Description = Faker.Lorem.Sentence(20),
                Id = "id",
                OrderID = 115936,
                OrderTaxID = Faker.RandomNumber.Next(10000),
                Rate = Faker.RandomNumber.Next(10)
            };

            return te;
        }

        public static CartEntity MockCartEntityObject(int cartId)
        {
            var te = new CartEntity()
            {
                CartID = cartId,
                CartItems = new List<CartItemEntity>() { MockCartItemEntityObject() },
                CustomProperties = new List<CustomPropertyEntity>() { MockCustomPropertyEntityObject() },
                DateCreated = DateTime.Now,
                Discounts = MockCartDiscountsEntityObject(),
                Company = 1,
                DiscountValue = Faker.RandomNumber.Next(100),
                Subtotal = Faker.RandomNumber.Next(100)
            };

            return te;
        }

        public static CartDiscountsEntity MockCartDiscountsEntityObject()
        {
            var te = new CartDiscountsEntity()
            {
                FixedAmountDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() },
                PercentOffDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() },
            };

            return te;
        }

        public static CartItemEntity MockCartItemEntityObject()
        {
            var te = new CartItemEntity()
            {
                CartItemID = Faker.RandomNumber.Next(1000),
                CustomProperties = new List<CustomPropertyEntity>() { MockCustomPropertyEntityObject() },
                DiscountedLinePrice = Faker.RandomNumber.Next(1000),
                DiscountedUnitPrice = Faker.RandomNumber.Next(1000),
                Discounts = MockCartItemDiscountsEntityObject(),
                LinePrice = Faker.RandomNumber.Next(1000),
                Product = MockProductEntityObject(123),
                ProductId = 123,
                Quantity = Faker.RandomNumber.Next(100),
                Status = CartItemStatus.Shipped,
                UnitPrice = Faker.RandomNumber.Next(100)
            };

            return te;
        }

        public static CustomPropertyEntity MockCustomPropertyEntityObject()
        {
            var te = new CustomPropertyEntity()
            {
                Name = Faker.Lorem.GetFirstWord(),
                Value = Faker.Lorem.GetFirstWord(),
                CustomPropertyID = Faker.RandomNumber.Next(10),
            };

            return te;
        }

        public static CartItemDiscountsEntity MockCartItemDiscountsEntityObject()
        {
            var te = new CartItemDiscountsEntity()
            {
                FixedLinePriceDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() },
                FixedUnitPriceDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() },
                PercentOffLinePriceDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() },
                PercentOffUnitPriceDiscounts = new List<DiscountEntity>() { MockDiscountEntityObject() }
            };

            return te;
        }

        public static DiscountEntity MockDiscountEntityObject()
        {
            var te = new DiscountEntity()
            {
                Type = 1,
                Id = "5",
                Amount = Faker.RandomNumber.Next(100),
                DiscountId = 2
            };

            return te;
        }

        public static ProductEntity MockProductEntityObject(int productId)
        {
            var te = new ProductEntity()
            {
                ProductID = productId,
                Name = Faker.Lorem.GetFirstWord(),
                BundledProducts = new List<BundleProductEntity>() { MockBundleProductEntityObject() },
                ProductCode = Faker.Lorem.GetFirstWord(),
                Weight = Faker.RandomNumber.Next(100),
                Description = Faker.Lorem.Sentence(10),
                Length = Faker.RandomNumber.Next(100),
                CompanyPartNumber = Faker.Lorem.GetFirstWord(),
                CustomerSpecificEDC = true,
                DateCreated = DateTime.Now,
                DateModified = DateTime.Now,
                DateSellStart = DateTime.Now,
                DateSellStop = DateTime.Now,
                DropShipOnly = true,
                FriendlyDescription = Faker.Lorem.Sentence(10),
                FriendlyName = Faker.Lorem.GetFirstWord(),
                Height = Faker.RandomNumber.Next(100),
                ImageEDC = Faker.Lorem.GetFirstWord(),
                IsBundle = false,
                ManufactureCode = Faker.Lorem.GetFirstWord(),
                ManufactureID = "100",
                ManufactureKey = Faker.Lorem.GetFirstWord(),
                ManufactureName = Faker.Lorem.GetFirstWord(),
                ManufacturePartNumber = Faker.Lorem.GetFirstWord(),
                NonReturnable = true,
                ParentManufactureID = Faker.RandomNumber.Next(10),
                ProductClass = Faker.Lorem.GetFirstWord(),
                ProductGroup = Faker.Lorem.GetFirstWord(),

                ProductKey = Faker.Lorem.GetFirstWord(),
                ProductType = Faker.Lorem.GetFirstWord(),
                SpinSetName = Faker.Lorem.GetFirstWord(),
                StockSource = Faker.Lorem.GetFirstWord(),
                Width = Faker.RandomNumber.Next(10)
            };

            return te;
        }

        public static BundleProductEntity MockBundleProductEntityObject()
        {
            var id = Faker.RandomNumber.Next(100);
            var te1 = new ProductEntity()
            {
                ProductID = 12,
                Name = Faker.Lorem.GetFirstWord(),

                ProductCode = Faker.Lorem.GetFirstWord(),
                Weight = Faker.RandomNumber.Next(100),
                Description = Faker.Lorem.Sentence(10),
                Length = Faker.RandomNumber.Next(100),
                CompanyPartNumber = Faker.Lorem.GetFirstWord(),
                CustomerSpecificEDC = true,
                DateCreated = DateTime.Now,
                DateModified = DateTime.Now,
                DateSellStart = DateTime.Now,
                DateSellStop = DateTime.Now,
                DropShipOnly = true,
                FriendlyDescription = Faker.Lorem.Sentence(10),
                FriendlyName = Faker.Lorem.GetFirstWord(),
                Height = Faker.RandomNumber.Next(100),
                ImageEDC = Faker.Lorem.GetFirstWord(),
                IsBundle = false,
                ManufactureCode = Faker.Lorem.GetFirstWord(),
                ManufactureID = "100",
                ManufactureKey = Faker.Lorem.GetFirstWord(),
                ManufactureName = Faker.Lorem.GetFirstWord(),
                ManufacturePartNumber = Faker.Lorem.GetFirstWord(),
                NonReturnable = true,
                ParentManufactureID = Faker.RandomNumber.Next(10),
                ProductClass = Faker.Lorem.GetFirstWord(),
                ProductGroup = Faker.Lorem.GetFirstWord(),

                ProductKey = Faker.Lorem.GetFirstWord(),
                ProductType = Faker.Lorem.GetFirstWord(),
                SpinSetName = Faker.Lorem.GetFirstWord(),
                StockSource = Faker.Lorem.GetFirstWord(),
                Width = Faker.RandomNumber.Next(10)
            };
            var te = new BundleProductEntity(new BundleChildProductEntity()
            {
                Product = te1,
                ProductID = id,
                ProductChildQuantity = id
            });

            return te;
        }
    }
}