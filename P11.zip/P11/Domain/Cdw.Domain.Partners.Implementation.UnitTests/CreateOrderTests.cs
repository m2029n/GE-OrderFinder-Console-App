﻿using System;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Partners.Utilities;
using Cdw.Test.Common.Xunit;
using Moq;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    [CI]
    public class CreateOrderTests
    {
        public CreateOrderTests()
        {
            var mockpartnerSettings = new Mock<IPartnerSettings>();
            mockpartnerSettings.Setup(x => x.CreditCardAPIKey).Returns("key");

            var mockTrackingValues = new Mock<ITrackingValues>();
            mockTrackingValues.Setup(x => x.CorrelationId).Returns(Guid.NewGuid());
            mockTrackingValues.Setup(x => x.TrackingId).Returns(Guid.NewGuid());

            Mapper.AddProfile(new RequestOrdersMappingProfile());

            //_orderManager = new OrderManager(_mockLogger.Object,
            //    _mockPartnerOrderRepository.Object,
            //    _mockRatingManager.Object,
            //    _mocktaxRequestDomainManager.Object,
            //    _mockrecyclingDomainManager.Object,
            //    _mockorderWriterDomainManager.Object,
            //    _mockordersWebService.Object,
            //    _mockorderStatusClient.Object,
            //    _mockcreditCardServiceDomainManager.Object,
            //    _mockpartnerSettings.Object, _mockOrderDomainManager.Object,_mockProductManager.Object);
        }

        //[Fact(DisplayName = "GetPartnerIdentityTest")]
        //public void GetPartnerIdentityTest()
        //{
        //    var entity = MockIdentityEntity();
        //    _mockPartnerOrderRepository.Setup(x => x.GetIdentityDetails(It.IsAny<string>())).Returns(entity);

        //    var input = FakeHelper.GetFakeIdentityFakeObject();
        //    //override
        //    input.SourceCode = "XDR";
        //    input.ClientId = 0;

        //    _orderManager.GetPartnerIdentity(input);

        //    Assert.Equal(input.SourceCode, entity.SourceCode);
        //    Assert.Equal(input.ClientId, entity.ClientId);
        //}

        //[Fact(DisplayName = "CreateOrder_domain_test")]
        //public async void CreateOrder_domain_test()
        //{
        //    _mockpartnerSettings.Setup(x => x.CreditCardAPIKey).Returns("creditcardapikey");
        //    var er = new Mock<IEncryptedResult>();
        //    er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
        //    _mockcreditCardServiceDomainManager.Setup(x => x.Encrypt(It.IsAny<string>(), It.IsAny<string>()))
        //        .Returns(er.Object);

        //    var requestobj = FakeHelper.GetFakeRequestorderFakeObject();
        //    var ccar = new FakeCreditCardAuthorizationResponse()
        //    {
        //        IsValid = true,
        //        CreditCardToken = Guid.NewGuid().ToString()
        //    };
        //    _mockcreditCardServiceDomainManager.Setup(x => x.Authorize(It.IsAny<CreditCardAuthorizationRequest>()))
        //        .Returns(ccar);
        //    _mockPartnerOrderRepository.Setup(x => x.GetIdentityDetails("XeroxUs")).Returns(MockIdentityEntity());
        //    _mockPartnerOrderRepository.Setup(x => x.UniqueReferenceNumber(It.IsAny<string>(), It.IsAny<string>()))
        //        .Returns(true);

        //    var productEntity = MockHelper.MockProductEntityObject(123);
        //    _mockPartnerOrderRepository.Setup(x => x.GetProduct(It.IsAny<IEnumerable<string>>()))
        //        .Returns(new List<ProductEntity>() {productEntity});
        //    _mockPartnerOrderRepository.Setup(x => x.GetProduct(It.IsAny<IEnumerable<int>>()))
        //        .Returns(new List<ProductEntity>() { productEntity });
        //    _mockPartnerOrderRepository.Setup(x => x.InsertApiCarts(It.IsAny<CartEntity>()))
        //        .Returns(It.IsAny<CartEntity>());
        //    _mockPartnerOrderRepository.Setup(x => x.GetCreditCardByToken(It.IsAny<string>()))
        //        .Returns(MockHelper.MockCreditCardEntityObject());
        //    _mockRatingManager.Setup(x => x.RateAsync(It.IsAny<IRatingRequest>()))
        //        .Returns(Task.FromResult((new FakeRatingResponse().GetFakeObject() as IRatingResponse)));

        //    _mockrecyclingDomainManager.Setup(x => x.GetRecyclingFeesAsync(It.IsAny<IRecyclingFeeRequest>()))
        //        .Returns(
        //            Task.FromResult(
        //                new List<Cdw.Domain.Partners.Recycling.IRecyclingFee>() {FakeHelper.GetRecyclingFeeFakeObject()}
        //                    as IEnumerable<Cdw.Domain.Partners.Recycling.IRecyclingFee>));

        //    _mocktaxRequestDomainManager.Setup(x => x.GetTaxLinesAsync(It.IsAny<ITaxRequest>()))
        //        .Returns(Task.FromResult(new FakeTaxResponse().GetFakeObject() as ITaxResponse));

        //    _mockPartnerOrderRepository.Setup(x => x.Create(It.IsAny<OrderEntity>())).Returns(new OrderEntity()
        //    {
        //        OrderCode = "neworder"
        //    });

        //    _mockPartnerOrderRepository.Setup(x => x.GetShippingMethodProperty(It.IsAny<string>(), It.IsAny<string>()))
        //        .ReturnsAsync(new ShippingMethodPropertiesEntity()
        //        {
        //            FreeShippingMethod = "YT"
        //        });

        //    var orderEntity = new OrderEntity().AssignFakeValues();
        //    var orderitems = new OrderItemShippingRateEntity().AssignFakeValues();
        //    var ordertaxes = new TaxEntity().AssignFakeValues();

        //    orderEntity.OrderItems = new List<OrderItemShippingRateEntity>() {orderitems};
        //    orderEntity.Taxes = new List<TaxEntity>() {ordertaxes};
        //    _mockPartnerOrderRepository.Setup(x => x.GetOrderEntity(It.IsAny<string>(), It.IsAny<string>())).Returns(orderEntity);

        //    var cart = new CartEntity().AssignFakeValues();
        //    cart.CustomProperties = new List<CustomPropertyEntity>() {new CustomPropertyEntity().AssignFakeValues()};
        //    cart.Discounts = new CartDiscountsEntity()
        //    {
        //        FixedAmountDiscounts = new List<DiscountEntity>() {new DiscountEntity().AssignFakeValues()},
        //        PercentOffDiscounts = new List<DiscountEntity>() {new DiscountEntity().AssignFakeValues()}
        //    };
        //    var cartitems = new CartItemEntity().AssignFakeValues();
        //    cartitems.Discounts = new CartItemDiscountsEntity()
        //    {
        //        FixedLinePriceDiscounts = new List<DiscountEntity>() { new DiscountEntity().AssignFakeValues() },
        //        FixedUnitPriceDiscounts = new List<DiscountEntity>() { new DiscountEntity().AssignFakeValues() },
        //        PercentOffLinePriceDiscounts = new List<DiscountEntity>() { new DiscountEntity().AssignFakeValues() },
        //        PercentOffUnitPriceDiscounts = new List<DiscountEntity>() { new DiscountEntity().AssignFakeValues() }
        //    };
        //    cartitems.CustomProperties= new List<CustomPropertyEntity>() { new CustomPropertyEntity().AssignFakeValues() };
        //    cartitems.Product = new ProductEntity().AssignFakeValues();
        //    cartitems.ProductId = 123;
        //    cart.CartItems = new List<CartItemEntity>() { cartitems };
        //    _mockPartnerOrderRepository.Setup(x => x.GetCartEntity(It.IsAny<int>())).Returns(cart);
        //    _mockPartnerOrderRepository.Setup(x => x.GetCreditCardById(It.IsAny<int>()))
        //        .Returns(new CreditCardEntity().AssignFakeValues());

        //    _mockPartnerOrderRepository.Setup(x => x.IsUploadedToAs400(It.IsAny<string>())).Returns(false);

        //    var order = await _orderManager.CreateOrderAsync(requestobj).ConfigureAwait(false);

        //    Assert.NotNull(order);
        //}
    }
}