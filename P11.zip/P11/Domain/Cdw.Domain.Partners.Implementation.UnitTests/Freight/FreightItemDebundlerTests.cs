﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Domain.Partners.Implementation.Freight;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Freight
{
    public class FreightItemDebundlerTests
    {
        private Mock<IBundleItemsManager> _mockBundleItemsManager;
        private Mock<IProductManager> _mockProductManager;

        private FreightItemDebundler _sut;

        public FreightItemDebundlerTests()
        {
            _mockBundleItemsManager = new Mock<IBundleItemsManager>();
            _mockProductManager = new Mock<IProductManager>();

            _sut = new FreightItemDebundler(_mockBundleItemsManager.Object, _mockProductManager.Object);
        }

        [Fact]
        public async Task DeBundleFreightItemsAsync_ShouldReturnEmptyListWhenNoProductsAreFound()
        {
            // Arrange
            var model = new RatingRequestModel
            {
                CompanyCode = "CC",
                ItemsToShip = new List<RatingRequestFreightItemModel>
                {
                    new RatingRequestFreightItemModel { ProductCode = "1" },
                    new RatingRequestFreightItemModel { ProductCode = "2" }
                }.ToArray()
            };
            _mockProductManager.Setup(x => x.GetBulkProductsAsync("1,2", "CC")).ReturnsAsync(null);

            // Act
            var actual = await _sut.GetDeBundledFreightItemsAsync(model);

            // Assert
            Assert.Equal(0, actual.Count());
        }

        [Fact]
        public async Task DeBundleFreightItemsAsync_ShouldReturnSameCountWhenNoBundlesFound()
        {
            // Arrange
            var model = new RatingRequestModel
            {
                CompanyCode = "CC",
                ItemsToShip = new List<RatingRequestFreightItemModel>
                {
                    new RatingRequestFreightItemModel { ProductCode = "1", UnitPrice = 1.11m, Quantity = 11 },
                    new RatingRequestFreightItemModel { ProductCode = "2", UnitPrice = 2.22m, Quantity = 22 }
                }.ToArray()
            };

            var products = new List<IProductCore>
            {
                new FakeProductCode { IsBundle = false, ProductCode = "1" },
                new FakeProductCode { IsBundle = false, ProductCode = "2" },
            };

            _mockProductManager.Setup(x => x.GetBulkProductsAsync("1,2", "CC")).ReturnsAsync(products);

            // Act
            var actual = await _sut.GetDeBundledFreightItemsAsync(model);

            // Assert
            Assert.Equal(2, actual.Count());

            var firstActual = actual.First();
            var expected = model.ItemsToShip.First();
            Assert.Null(firstActual.ContractReferenceNumber);
            Assert.Equal(1, firstActual.OrderLineNumber);
            Assert.Equal(expected.ProductCode, firstActual.ProductCode);
            Assert.Equal(expected.Quantity, firstActual.Quantity);
            Assert.Equal(expected.UnitPrice, firstActual.UnitPrice);
            
            Assert.Equal(2, actual.Last().OrderLineNumber);
        }

        [Fact]
        public async Task DeBundleFreightItemsAsync_ShouldReturnItemForEachBundledProduct()
        {
            // Arrange
            var model = new RatingRequestModel
            {
                CompanyCode = "CC",
                ItemsToShip = new List<RatingRequestFreightItemModel>
                {
                    new RatingRequestFreightItemModel { ProductCode = "1", UnitPrice = 1.11m, Quantity = 11 },
                }.ToArray()
            };

            var products = new List<IProductCore>
            {
                new FakeProductCode { IsBundle = true, ProductCode = "1" }
            };

            _mockProductManager.Setup(x => x.GetBulkProductsAsync("1", "CC")).ReturnsAsync(products);

            var bundledItems = new List<MyUnncessaryImplmentationOfBundleItemButSomeoneLovesInterfacesThatExposeBothGettersAndSetterWhichDefeatsThePurpose>
            {
                new MyUnncessaryImplmentationOfBundleItemButSomeoneLovesInterfacesThatExposeBothGettersAndSetterWhichDefeatsThePurpose { ProductCode = "1-1" },
                new MyUnncessaryImplmentationOfBundleItemButSomeoneLovesInterfacesThatExposeBothGettersAndSetterWhichDefeatsThePurpose { ProductCode = "1-2" }
            };
            _mockBundleItemsManager.Setup(x => x.GetAsync("1")).ReturnsAsync(bundledItems);

            // Act
            var actual = await _sut.GetDeBundledFreightItemsAsync(model);

            // Assert
            Assert.Equal(2, actual.Count());

            var firstActual = actual.First();
            var expected = model.ItemsToShip.First();
            Assert.Null(firstActual.ContractReferenceNumber);
            Assert.Equal(1, firstActual.OrderLineNumber);
            Assert.Equal(bundledItems.First().ProductCode, firstActual.ProductCode);
            Assert.Equal(expected.Quantity, firstActual.Quantity);
            Assert.Equal(expected.UnitPrice, firstActual.UnitPrice);

            Assert.Equal(2, actual.Last().OrderLineNumber);
        }

        private class MyUnncessaryImplmentationOfBundleItemButSomeoneLovesInterfacesThatExposeBothGettersAndSetterWhichDefeatsThePurpose : IBundleItem
        {
            public string ProductCode { get; set; }
            public string Name { get; set; }
            public string FriendlyName { get; set; }
            public string ImageEDC { get; set; }
            public string Description { get; set; }
            public string FriendlyDescription { get; set; }
            public string ManufacturerPartNumber { get; set; }
            public string ParentProductCode { get; set; }
            public int Quantity { get; set; }
            public decimal ShippingWeight { get; set; }
            public string InventoryStatusMessage { get; set; }
        }
    }
}