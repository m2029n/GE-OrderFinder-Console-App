﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Domain.Freight;
using Cdw.Domain.Partners.Implementation.Freight;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Infrastructure.PartnerOrder;
using Common.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Freight
{
    public class FreightDomainMapperTests
    {
        private Mock<ILog> _mockILog;
        private FreightDomainMapper _sut;

        public FreightDomainMapperTests()
        {
            _mockILog = new Mock<ILog>();
            _sut = new FreightDomainMapper(_mockILog.Object);
        }

        [Fact]
        public void ToRatingRequest_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequestModel model = null;

            // Act
            var actual = _sut.ToRatingRequest(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToRatingRequest_ShouldMapProperties()
        {
            // Arrange
            var model = new RatingRequestModel
            {
                CompanyCode = "CC",
                OrderReferenceNumber = "ORN",
                ItemsToShip = new List<RatingRequestFreightItemModel>().ToArray(),
                Options = new RatingRequestOptionsModel(),
                Requester = new RatingRequesterModel(),
                SalesChannel = new RatingRequestSalesChannelModel { ShipMethodFilter = "1" },
                ShipTo = new RatingRequestShippingAddressModel()
            };

            // Act
            var actual = _sut.ToRatingRequest(model);

            // Assert
            Assert.Equal(model.CompanyCode, actual.CompanyCode);
            Assert.Equal(model.OrderReferenceNumber, actual.OrderReferenceNumber);

            Assert.NotNull(actual.ItemsToShip);
            Assert.NotNull(actual.Options);
            Assert.NotNull(actual.Requester);
            Assert.NotNull(actual.SalesChannel);
            Assert.NotNull(actual.ShipTo);
        }

        [Fact]
        public void ToRatingRequest_ShouldLogModelOnException()
        {
            // Arrange
            var loggedMessage = "Has to be a string because you can't use var without a initial typing... so not just use string... because that would mean I have to type more and you should not be reading this anyways!";
            var exceptionWasThown = false;

            try
            {
                var model = new RatingRequestModel
                {
                    CompanyCode = "SomeCodeToCheckForInJson",
                    SalesChannel = new RatingRequestSalesChannelModel() // Not setting ShipMethodFilter casues an errro
                };

                _mockILog.Setup(x => x.Error(It.IsAny<object>(), It.IsAny<Exception>()))
                        .Callback<object, Exception>((message, ex) =>
                        {
                            loggedMessage = message.ToString();
                        });

                // Act
                var actual = _sut.ToRatingRequest(model);
            }
            catch (Exception)
            {
                exceptionWasThown = true;
            }

            // Assert
            Assert.True(exceptionWasThown);
            Assert.True(loggedMessage.Contains("FreightDomainMapper.ToRatingRequest failed"));
            Assert.True(loggedMessage.Contains("SomeCodeToCheckForInJson"));
        }

        [Fact]
        public void ToIRatingRequestFreightItem_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequestFreightItemModel model = null;

            // Act
            var actual = _sut.ToIRatingRequestFreightItem(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToIRatingRequestFreightItem_ShouldStraightMappAllProperties()
        {
            // Arrange
            var model = new RatingRequestFreightItemModel
            {
                ContractReferenceNumber = "CRN",
                OrderLineNumber = 1,
                ParentOrderLineNumber = 2,
                ProductCode = "PC",
                Quantity = 3,
                UnitPrice = 1.23m
            };

            // Act
            var actual = _sut.ToIRatingRequestFreightItem(model);

            // Assert
            Assert.Equal(model.ContractReferenceNumber, actual.ContractReferenceNumber);
            Assert.Equal(model.OrderLineNumber, actual.OrderLineNumber);
            Assert.Equal(model.ParentOrderLineNumber, actual.ParentOrderLineNumber);
            Assert.Equal(model.ProductCode, actual.ProductCode);
            Assert.Equal(model.Quantity, actual.Quantity);
            Assert.Equal(model.UnitPrice, actual.UnitPrice);
        }

        [Fact]
        public void ToIRatingRequestOptions_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequestOptionsModel model = null;

            // Act
            var actual = _sut.ToIRatingRequestOptions(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToIRatingRequestOptions_ShouldStraightMappAllProperties()
        {
            // Arrange
            var model = new RatingRequestOptionsModel
            {
                Debug = true,
                ExcludeExtendedInfo = true,
                ExcludePackages = true,
                ExcludeRates = true,
                IncludeFreightDetails = true,
                IncludeUnavailableRates = true,
                IsCod = true,
                IsDropShip = true,
                IsFree = true
            };

            // Act
            var actual = _sut.ToIRatingRequestOptions(model);

            // Assert
            Assert.Equal(model.Debug, actual.Debug);
            Assert.Equal(model.ExcludeExtendedInfo, actual.ExcludeExtendedInfo);
            Assert.Equal(model.ExcludePackages, actual.ExcludePackages);
            Assert.Equal(model.ExcludeRates, actual.ExcludeRates);
            Assert.Equal(model.IncludeFreightDetails, actual.IncludeFreightDetails);
            Assert.Equal(model.IncludeUnavailableRates, actual.IncludeUnavailableRates);
            Assert.Equal(model.IsCod, actual.IsCod);
            Assert.Equal(model.IsDropShip, actual.IsDropShip);
            Assert.Equal(model.IsFree, actual.IsFree);
        }

        [Fact]
        public void ToIRatingRequester_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequesterModel model = null;

            // Act
            var actual = _sut.ToIRatingRequester(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToIRatingRequester_ShouldStraightMappAllProperties()
        {
            // Arrange
            var model = new RatingRequesterModel
            {
                ApplicationName = "AN",
                HostName = "HN",
                JobName = "JN",
                Platform = "P"
            };

            // Act
            var actual = _sut.ToIRatingRequester(model);

            // Assert
            Assert.Equal(model.ApplicationName, actual.ApplicationName);
            Assert.Equal(model.HostName, actual.HostName);
            Assert.Equal(model.JobName, actual.JobName);
            Assert.Equal(model.Platform, actual.Platform);
        }

        [Fact]
        public void ToRatingRequestSalesChannel_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequestSalesChannelModel model = null;

            // Act
            var actual = _sut.ToRatingRequestSalesChannel(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToRatingRequestSalesChannel_ShouldStraightMappAllProperties()
        {
            var shippingMethodFilter = SalesChannelShipMethodFilter.SpecialsOnly;

            // Arrange
            var model = new RatingRequestSalesChannelModel
            {
                Code = "C",
                ShipMethodFilter = ((int)shippingMethodFilter).ToString()
            };

            // Act
            var actual = _sut.ToRatingRequestSalesChannel(model);

            // Assert
            Assert.Equal(model.Code, actual.Code);
            Assert.Equal(shippingMethodFilter, actual.ShipMethodFilter);
        }

        [Fact]
        public void ToRatingRequestShippingAddress_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            RatingRequestShippingAddressModel model = null;

            // Act
            var actual = _sut.ToRatingRequestShippingAddress(model);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToRatingRequestShippingAddress_ShouldStraightMappAllProperties()
        {
            // Arrange
            var model = new RatingRequestShippingAddressModel
            {
                City = "C",
                CompanyName = "CN",
                Country = "CTR",
                FirstName = "F",
                IsResidence = true,
                LastName = "L",
                Line1 = "L1",
                Line2 = "L2",
                PostalCode = "PO",
                State = "S"
            };

            // Act
            var actual = _sut.ToRatingRequestShippingAddress(model);

            // Assert
            Assert.Equal(model.City, actual.City);
            Assert.Equal(model.CompanyName, actual.CompanyName);
            Assert.Equal(model.Country, actual.Country);
            Assert.Equal(model.FirstName, actual.FirstName);
            Assert.Equal(model.IsResidence, actual.IsResidence);
            Assert.Equal(model.LastName, actual.LastName);
            Assert.Equal(model.Line1, actual.Line1);
            Assert.Equal(model.Line2, actual.Line2);
            Assert.Equal(model.PostalCode, actual.PostalCode);
            Assert.Equal(model.State, actual.State);
        }

        [Fact]
        public void ToRatingResponsePartner_ShouldHandlesNullFreightDetailsAndFreightShippingMethods()
        {
            // Arrange
            var input = new FakeRatingResponse
            {
                ErrorMessage = "EM",
                Freight = new FakeRatedFreight(),
                PackageCount = 987,
                TransactionIdentifier = "TI"
            };

            // Act
            var actual = _sut.ToRatingResponsePartner(input, null);

            // Assert
            Assert.Equal(input.ErrorMessage, actual.ErrorMessage);
            Assert.Equal(input.PackageCount, actual.PackageCount);
            Assert.Equal(input.TransactionIdentifier, actual.TransactionIdentifier);
            Assert.NotNull(actual.Freight);
        }

        [Fact]
        public void ToRatingResponsePartner_ShouldHandleShippingMethodsBeingNull()
        {
            // Arrange
            var input = new FakeRatingResponse
            {
                Freight = new FakeRatedFreight
                {
                    ShippingMethods = new List<FakeRatedFreightShippingMethod>
                    {
                        new FakeRatedFreightShippingMethod { Code = "AAA" },
                        new FakeRatedFreightShippingMethod { Code = "BBB" }
                    }
                }
            };

            // Act
            var actual = _sut.ToRatingResponsePartner(input, null);

            // Assert
            Assert.NotNull(actual.Freight.ShippingMethods);
            Assert.Equal(2, actual.Freight.ShippingMethods.Count());
        }

        [Fact]
        public void ToRatingResponsePartner_ShouldLogModelOnException()
        {
            // Arrange
            var loggedMessage = "Fluffy chickens.";
            var msgToCheckFor = "SomeCodeToCheckForInJson";
            var msgToCheckFor2 = "SomeOtherStringToCheckForInJson";
            var exceptionWasThown = false;

            try
            {
                var model = new FakeRatingResponse { ErrorMessage = msgToCheckFor };

                var shippingMethods = new List<ShippingMethodPropertiesEntity>
                {
                    new ShippingMethodPropertiesEntity { FreeShippingMethod = msgToCheckFor2 }
                };

                _mockILog.Setup(x => x.Error(It.IsAny<object>(), It.IsAny<Exception>()))
                        .Callback<object, Exception>((message, ex) =>
                        {
                            loggedMessage = message.ToString();
                        });

                // Act
                var actual = _sut.ToRatingResponsePartner(model, shippingMethods);
            }
            catch (Exception)
            {
                exceptionWasThown = true;
            }

            // Assert
            Assert.True(exceptionWasThown);
            Assert.True(loggedMessage.Contains("FreightDomainMapper.ToRatingResponsePartner failed"));
            Assert.True(loggedMessage.Contains(msgToCheckFor));
            Assert.True(loggedMessage.Contains(msgToCheckFor2));
        }

        [Fact]
        public void ToRatingResponsePartner_ShouldRemovesSuppressedShippingMethods()
        {
            // Arrange
            var shippingMethods = new List<ShippingMethodPropertiesEntity>
            {
                new ShippingMethodPropertiesEntity { IsSuppressed = false, ShippingMethod = "AAA" },
                new ShippingMethodPropertiesEntity { IsSuppressed = true, ShippingMethod = "IamSuppressed" }
            };

            var input = new FakeRatingResponse
            {
                ErrorMessage = "EM",
                Freight = new FakeRatedFreight
                {
                    ShippingMethods = new List<FakeRatedFreightShippingMethod>
                    {
                        new FakeRatedFreightShippingMethod { Code = "AAA" },
                        new FakeRatedFreightShippingMethod { Code = "IamSuppressed" }
                    }
                },
                PackageCount = 987,
                TransactionIdentifier = "TI"
            };

            // Act
            var actual = _sut.ToRatingResponsePartner(input, shippingMethods);

            // Assert
            Assert.NotNull(actual.Freight.ShippingMethods);
            Assert.Equal(1, actual.Freight.ShippingMethods.Count());
            Assert.Equal("AAA", actual.Freight.ShippingMethods.First().Code);
        }

        [Fact]
        public void ToIRatedFreightShippingMethod_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            FakeRatedFreightShippingMethod source = null;

            // Act
            var actual = _sut.ToIRatedFreightShippingMethod(source, null);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToIRatedFreightShippingMethod_ShouldSetTransitBusinessDaysToNAWhenShippingMethodPropertiesIsNull()
        {
            // Arrange
            var source = new FakeRatedFreightShippingMethod
            {
                BoxHandlingCharge = 123.33m,
                Code = "C",
                ContractFreightTypesApplied = ContractFreightType.FreeWithDifference,
                Cost = 12345.5m,
                Description = "D",
                EstimatedArrival = "EA",
                FreightCharge = 334.4m,
                InsuranceCharge = 33.3m,
                IsCustomerAccount = true,
                Name = "N",
                OrderHandlingCharge = 3311.24m,
                OtherCharge = 8.8m,
                SaturdayCharge = 7.7m,
                SpecialCode = "SC",
                TotalCharge = 5533.32m,
                TotalWeight = 1.2m,
                WeightType = "WT"
            };

            // Act
            var actual = _sut.ToIRatedFreightShippingMethod(source, null);

            // Assert
            Assert.Equal(source.BoxHandlingCharge, actual.BoxHandlingCharge);
            Assert.Equal(source.Code, actual.Code);
            Assert.Equal((int)source.ContractFreightTypesApplied, (int)actual.ContractFreightTypesApplied);
            Assert.Equal(source.Cost, actual.Cost);
            Assert.Equal(source.Description, actual.Description);

            Assert.Equal(source.EstimatedArrival, actual.EstimatedArrival);
            Assert.Equal(source.FreightCharge, actual.FreightCharge);
            Assert.Equal(source.InsuranceCharge, actual.InsuranceCharge);
            Assert.Equal(source.IsCustomerAccount, actual.IsCustomerAccount);
            Assert.Equal(source.Name, actual.Name);

            Assert.Equal(source.OrderHandlingCharge, actual.OrderHandlingCharge);
            Assert.Equal(source.OtherCharge, actual.OtherCharge);
            Assert.Equal(source.SaturdayCharge, actual.SaturdayCharge);
            Assert.Equal(source.SpecialCode, actual.SpecialCode);
            Assert.Equal(source.TotalCharge, actual.TotalCharge);

            Assert.Equal(source.TotalWeight, actual.TotalWeight);
            Assert.Equal("NA", actual.TransitBusinessDays);
            Assert.Equal(source.WeightType, actual.WeightType);
        }

        [Fact]
        public void ToIRatedFreightShippingMethod_ShouldSetTransitBusinessDaysToMatchingShippingMethodTransitBusinessDays()
        {
            // Arrange
            const string code = "Because shipping method = code makes sense.. on backward Tuesdays";
            const string transitBusinessDays = "SWH";
            var source = new FakeRatedFreightShippingMethod { Code = code };

            var shippingMethods = new List<ShippingMethodPropertiesEntity>
            {
                new ShippingMethodPropertiesEntity { ShippingMethod = code, TransitBusinessDays = transitBusinessDays }
            };

            // Act
            var actual = _sut.ToIRatedFreightShippingMethod(source, shippingMethods);

            // Assert
            Assert.Equal(transitBusinessDays, actual.TransitBusinessDays);
        }

        [Fact]
        public void ToRatedFreightDetailPartner_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            FakeRatedFreightDetail source = null;

            // Act
            var actual = _sut.ToRatedFreightDetailPartner(source, null);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToRatedFreightDetailPartner_ShouldHandleSuppressedItemsBeingNull()
        {
            // Arrange
            var source = new FakeRatedFreightDetail
            {
                OrderLineNumber = 1,
                ProductCode = "PC",
                ShippingMethods = new List<FakeRatedFreightDetailShippingMethod>
                {
                    new FakeRatedFreightDetailShippingMethod { Code = "AAA" },
                    new FakeRatedFreightDetailShippingMethod { Code = "BBB" }
                },
                Weight = 123.45m
            };

            // Act
            var actual = _sut.ToRatedFreightDetailPartner(source, null);

            // Assert
            Assert.Equal(source.OrderLineNumber, actual.OrderLineNumber);
            Assert.Equal(source.ProductCode, actual.ProductCode);
            Assert.Equal(source.ShippingMethods.Count(), actual.ShippingMethods.Count());
            Assert.Equal(source.Weight, actual.Weight);
        }

        [Fact]
        public void ToRatedFreightDetailPartner_ShouldHandleSuppressedItems()
        {
            // Arrange
            const string codeIShouldFind = "Does it really matter what this says...";
            var source = new FakeRatedFreightDetail
            {
                OrderLineNumber = 1,
                ProductCode = "PC",
                ShippingMethods = new List<FakeRatedFreightDetailShippingMethod>
                {
                    new FakeRatedFreightDetailShippingMethod { Code = codeIShouldFind },
                    new FakeRatedFreightDetailShippingMethod { Code = "IamSuppressed" }
                },
                Weight = 123.45m
            };

            var suppresssedItems = new List<ShippingMethodPropertiesEntity>
            {
                new ShippingMethodPropertiesEntity { ShippingMethod = "IamSuppressed" }
            };

            // Act
            var actual = _sut.ToRatedFreightDetailPartner(source, suppresssedItems);

            // Assert
            Assert.Equal(source.OrderLineNumber, actual.OrderLineNumber);
            Assert.Equal(source.ProductCode, actual.ProductCode);
            Assert.Equal(1, actual.ShippingMethods.Count());
            Assert.Equal(codeIShouldFind, actual.ShippingMethods.First().Code);
            Assert.Equal(source.Weight, actual.Weight);
        }

        [Fact]
        public void ToRatedFreightDetailShippingMethod_ShouldReturnNullWhenNullPassedIn()
        {
            // Arrange
            FakeRatedFreightDetailShippingMethod source = null;

            // Act
            var actual = _sut.ToRatedFreightDetailShippingMethod(source);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public void ToRatedFreightDetailShippingMethod_ShouldStraightMappAllProperties()
        {
            // Arrange
            var source = new FakeRatedFreightDetailShippingMethod
            {
                BoxHandlingCharge = 123.33m,
                Code = "C",
                ContractFreightTypesApplied = ContractFreightType.FreeWithDifference,
                Cost = 12345.5m,
                DropShipMethodCode = "DSC",
                FreightCharge = 334.4m,
                InsuranceCharge = 33.3m,
                OrderHandlingCharge = 3311.24m,
                OtherCharge = 8.8m,
                SaturdayCharge = 7.7m,
                ShippingProgramId = 856,
                TotalCharge = 5533.32m
            };

            // Act
            var actual = _sut.ToRatedFreightDetailShippingMethod(source);

            // Assert
            Assert.Equal(source.BoxHandlingCharge, actual.BoxHandlingCharge);
            Assert.Equal(source.Code, actual.Code);
            Assert.Equal((int)source.ContractFreightTypesApplied, (int)actual.ContractFreightTypesApplied);
            Assert.Equal(source.Cost, actual.Cost);
            Assert.Equal(source.DropShipMethodCode, actual.DropShipMethodCode);
            Assert.Equal(source.FreightCharge, actual.FreightCharge);
            Assert.Equal(source.InsuranceCharge, actual.InsuranceCharge);
            Assert.Equal(source.OrderHandlingCharge, actual.OrderHandlingCharge);
            Assert.Equal(source.OtherCharge, actual.OtherCharge);
            Assert.Equal(source.SaturdayCharge, actual.SaturdayCharge);
            Assert.Equal(source.TotalCharge, actual.TotalCharge);
        }
    }
}