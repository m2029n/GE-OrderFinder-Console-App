﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Clients.Freight;
using Cdw.Domain.Partners.Freight;
using Cdw.Domain.Partners.Implementation.Freight;
using Cdw.Domain.Partners.Implementation.Freight.FreightDomain;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Services.Core;
using Common.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Freight
{
    public class FreightDomainManagerTests
    {
        private readonly Mock<IFreightDomainMapper> _mockFreightDomainMapper;
        private readonly Mock<IFreightItemDebundler> _mockFreightItemDebundler;
        private readonly Mock<ILog> _mockLogger;
        private readonly Mock<IPartnerOrderRepository> _mockPartnerOrderRepository;
        private readonly Mock<IRatingClientManager> _mockRatingClientManager;

        private FreightDomainManager _sut;

        public FreightDomainManagerTests()
        {
            _mockFreightDomainMapper = new Mock<IFreightDomainMapper>();
            _mockFreightItemDebundler = new Mock<IFreightItemDebundler>();
            _mockLogger = new Mock<ILog>();
            _mockPartnerOrderRepository = new Mock<IPartnerOrderRepository>();
            _mockRatingClientManager = new Mock<IRatingClientManager>();

            _sut = new FreightDomainManager(_mockFreightDomainMapper.Object, _mockFreightItemDebundler.Object, _mockLogger.Object, _mockPartnerOrderRepository.Object, _mockRatingClientManager.Object);
        }

        [Fact]
        public async Task CheckAsync_ReturnsHealthCheckResults()
        {
            var expectedResult = new HealthCheckMessage("DoesNotMatter", HealthStatus.Ready);
            _mockRatingClientManager.Setup(x => x.CheckAsync()).ReturnsAsync(expectedResult);

            var actual = await _sut.CheckAsync();

            Assert.Equal(expectedResult.Service, actual.Service);
        }

        [Fact]
        public async Task RateAsync_OrchestratesAllDepenendencies()
        {
            // Arrange
            const string clientName = "FooBarChooHoo";
            var loggerCallCount = 0;
            var model = new RatingRequestModel();
            var ratingRequest = new RatingRequest();
            var ratingResponse = new FakeRatingResponse();
            var shippingMethodProperties = new List<ShippingMethodPropertiesEntity>();
            var ratingResponsePartner = new RatingResponsePartner();

            _mockLogger.Setup(x => x.Debug(It.IsAny<object>())).Callback<object>((obj) =>
            {
                loggerCallCount += 1;
            });

            _mockFreightItemDebundler.Setup(x => x.GetDeBundledFreightItemsAsync(model)).ReturnsAsync(new RatingRequestFreightItemModel[0]);
            _mockFreightDomainMapper.Setup(x => x.ToRatingRequest(model)).Returns(ratingRequest);
            _mockRatingClientManager.Setup(x => x.RateAsync(ratingRequest)).ReturnsAsync(ratingResponse);
            _mockPartnerOrderRepository.Setup(x => x.GetShippingMethodPropertiesAsync(clientName)).ReturnsAsync(shippingMethodProperties);
            _mockFreightDomainMapper.Setup(x => x.ToRatingResponsePartner(ratingResponse, shippingMethodProperties)).Returns(ratingResponsePartner);

            // Act
            var actual = await _sut.RateAsync(clientName, model, null);

            // Assert
            // Assert.Equal(4, loggerCallCount);  // This should be 4 but given that the _logger.Debug extension method uses TaskRun the 4th callback is not guaranteed to finish by the time this assert executes.
            Assert.Equal(0, model.ItemsToShip.Count());
            Assert.Equal(ratingResponsePartner, actual);
        }
    }
}