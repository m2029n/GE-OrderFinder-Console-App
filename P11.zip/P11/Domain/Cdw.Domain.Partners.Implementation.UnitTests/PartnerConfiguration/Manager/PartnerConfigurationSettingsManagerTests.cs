﻿using Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.PartnerConfiguration.Manager
{
    public class PartnerConfigurationSettingsManagerTests
    {
        [Fact]
        public void GetPartnerConfigurationSettingsByName_null_when_no_settings()
        {
            //Arrange
            var repo = new Mock<IConfigurationSettingsRepository>();
            //ACT
            var sut = new PartnerConfigurationSettingsManager(repo.Object);
            var actual = sut.GetPartnerConfigurationSettingsByNameAsync("Black Box").Result;
            //Asert
            Assert.NotNull(sut);
            Assert.Null(actual);
        }

        [Fact]
        public void GetPartnerConfigurationSettingsByName_should_pass()
        {
            //Arrange
            var partner = new PartnerConfigurationSettings
            {
                ClientId = 20,
                ClientName = "Black Box"
            };
            var repo = new Mock<IConfigurationSettingsRepository>();
            repo.Setup(r => r.GetPartnerConfigurationSettingsByNameAsync("Black Box")).ReturnsAsync(partner);
            var sut = new PartnerConfigurationSettingsManager(repo.Object);
            //ACT
            var actual = sut.GetPartnerConfigurationSettingsByNameAsync("Black Box").Result;
            //Asert
            Assert.NotNull(actual);
            Assert.Equal(20, actual.ClientId);
        }
    }
}