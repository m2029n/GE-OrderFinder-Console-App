﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Core.Data.DbClient;
using Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Infrastructure.PartnerOrder;
using Moq;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.PartnerConfiguration.DB
{
    public class ConfigurationSettingsRepositoryTests
    {
        [Fact]
        public async Task InitAsyncTest()
        {
            //Arrange
            var dbInstance = new Mock<IDbClient>();
            dbInstance.Name = "Kate";
            dbInstance.Setup(f => f.SetProcedureName(It.IsAny<string>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(dbInstance.Object);
            var list1 = new List<OrderManagerSettings>();
            dbInstance.Setup(f => f.ExecuteFetch<OrderManagerSettings>()).Returns(list1);
            var list2 = new List<ShippingMethodPropertiesEntity>();
            dbInstance.Setup(f => f.ExecuteFetch<ShippingMethodPropertiesEntity>()).Returns(list2);
            IDbClient DbFunc() => dbInstance.Object;
            var sut = new ConfigurationSettingsRepository(DbFunc);
            //Act
            await sut.InitAsync().ConfigureAwait(false);
            var actualy = await sut.GetPartnerConfigurationSettingsByNameAsync("Black Box").ConfigureAwait(false);
            //Assert
            Assert.NotNull(actualy);
            Assert.Equal("Black Box", actualy.ClientName);
        }
    }
}