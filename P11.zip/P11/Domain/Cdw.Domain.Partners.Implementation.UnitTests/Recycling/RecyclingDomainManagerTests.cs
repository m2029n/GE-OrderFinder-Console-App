﻿using Cdw.Api.Partners.Model.Recycling;
using Cdw.Domain.Partners.Implementation.Recycling;
using Cdw.Infrastructure.Recycling;
using Cdw.Infrastructure.Recycling.DB;
using Cdw.Services.Core;
using Common.Logging;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Recycling
{
    public class RecyclingDomainManagerTests
    {
        private readonly Mock<ILog> _mockLogger;
        private readonly Mock<IRecyclingRepository> _mockRecyclingRepository;

        private readonly RecyclingDomainManager _sut;
        private RecyclingFeeRequestModel _defaultRecyclingFeeRequestModel;

        public RecyclingDomainManagerTests()
        {
            _mockLogger = new Mock<ILog>();
            _mockRecyclingRepository = new Mock<IRecyclingRepository>();
            _sut = new RecyclingDomainManager(_mockLogger.Object, _mockRecyclingRepository.Object);

            _defaultRecyclingFeeRequestModel = new RecyclingFeeRequestModel
            {
                ProductCodes = "DoesNotMatter",
                State = "DoesNotMatterEitherOrShouldItBeToo"
            };
        }

        [Fact]
        public async Task CheckAsync_ShouldReturnAHardCodedHealthCheckMessage()
        {
            // Act
            var actual = await _sut.CheckAsync();

            // Assert
            Assert.Equal("Recycling Service", actual.Service);
            Assert.Equal(HealthStatus.Ready, actual.Status);
        }

        [Fact]
        public async Task GetRecyclingFeesAsync_ShouldReturnNullWhenRepoReturnsNull()
        {
            // Arrange
            List<RecyclingFeeEntity> repoResults = null;
            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes)).ReturnsAsync(repoResults);

            // Act
            var actual = await _sut.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetRecyclingFeesAsync_ShouldReturnNullWhenRepoReturnsEmptyList()
        {
            // Arrange
            var emptyRepoResults = new List<IRecyclingFeeEntity>();
            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes))
                    .ReturnsAsync(emptyRepoResults);

            // Act
            var actual = await _sut.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetRecyclingFeesAsync_ShouldCallRepoAndMapResults()
        {
            // Arrange
            var repoResults = GetRecyclingFeeEntities(1);

            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes)).ReturnsAsync(repoResults);

            // Act
            var actual = await _sut.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            var expectedFirst = repoResults.First();
            var actualFirst = actual.First();
            Assert.Equal(expectedFirst.UnitFeeAmount, actualFirst.Amount);
            Assert.Equal(expectedFirst.FeeEDCName, actualFirst.Code);
            Assert.Equal(expectedFirst.FeeClassName, actualFirst.Description);
            Assert.Equal(expectedFirst.ProductCode, actualFirst.ProductCode);
            Assert.Equal(expectedFirst.ProductFeeEDC, actualFirst.ProductFeeEDC);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryAsync_ShouldReturnNullWhenGetRecyclingFeesAsyncReturnsNull()
        {
            // Arrange
            List<IRecyclingFeeEntity> nullRepoResults = null;
            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes))
                    .ReturnsAsync(nullRepoResults);

            // Act
            var actual = await _sut.GetRecyclingFeeSummaryAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryAsync_ShouldReturnNullWhenGetRecyclingFeesAsyncReturnsEmptyList()
        {
            // Arrange
            var emptyRepoResults = new List<IRecyclingFeeEntity>();
            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes))
                    .ReturnsAsync(emptyRepoResults);

            // Act
            var actual = await _sut.GetRecyclingFeeSummaryAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryAsync_ShouldSumAmountFieldAndJoinProductCodes()
        {
            // Arrange
            var emptyRepoResults = GetRecyclingFeeEntities(5);
            _mockRecyclingRepository.Setup(x => x.GetRecyclingFeesAsync(_defaultRecyclingFeeRequestModel.State, _defaultRecyclingFeeRequestModel.ProductCodes))
                    .ReturnsAsync(emptyRepoResults);

            // Act
            var actual = await _sut.GetRecyclingFeeSummaryAsync(_defaultRecyclingFeeRequestModel);

            // Assert
            Assert.Equal(5, actual.Amount);
            Assert.Equal(5, actual.ProductCodes.Split(',').Count());
        }

        private List<RecyclingFeeEntity> GetRecyclingFeeEntities(int count)
        {
            var results = new List<RecyclingFeeEntity>();

            for (int i = 0; i < count; i++)
            {
                results.Add(new RecyclingFeeEntity
                {
                    UnitFeeAmount = 1.0m,
                    FeeEDCName = $"FeeEDCName {i + 1}",
                    FeeClassName = $"FeeClassName {i + 1}",
                    ProductCode = $"ProductCode {i + 1}",
                    ProductFeeEDC = $"ProductFeeEDC {i + 1}"
                });
            }

            return results;
        }
    }
}