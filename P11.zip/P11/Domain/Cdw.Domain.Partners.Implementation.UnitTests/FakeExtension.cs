﻿using System;

namespace Cdw.Domain.Partners.Implementation.UnitTests
{
    public static class FakeExtension
    {
        public static T AssignFakeValues<T>(this T obj)
        {
            foreach (var prop in obj.GetType().GetProperties())
            {
                switch (prop.PropertyType.FullName)
                {
                    case "System.String":
                        {
                            prop.SetValue(obj, Faker.Lorem.GetFirstWord());
                        }
                        break;

                    case "System.Decimal":
                        {
                            prop.SetValue(obj, 10m);
                        }
                        break;

                    case "System.Int32":
                        {
                            prop.SetValue(obj, Faker.RandomNumber.Next(10));
                        }
                        break;

                    case "System.Boolean":
                        {
                            prop.SetValue(obj, true);
                        }
                        break;

                    case "System.DateTime":
                        {
                            prop.SetValue(obj, DateTime.Now);
                        }
                        break;
                }
            }
            return obj;
        }
    }
}