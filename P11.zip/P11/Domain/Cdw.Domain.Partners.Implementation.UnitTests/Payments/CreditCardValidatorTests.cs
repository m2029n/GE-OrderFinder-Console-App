﻿using System.Linq;
using Cdw.Api.Partners.Model.Payment;
using Cdw.Partners.Validation.Payments;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Payments
{
    public class CreditCardValidatorTests
    {
        [Fact]
        public void ValidateTest()
        {
            var sut = new CreditCardValidator();
            var result = sut.Validate(new CreditCardModel()).ToList();

            Assert.NotNull(result);
            Assert.NotNull(result.FirstOrDefault(f => f.Field == "CreditCard.Number"));
            Assert.NotNull(result.FirstOrDefault(f => f.Field == "CreditCard.ExpirationMonth"));
            Assert.NotNull(result.FirstOrDefault(f => f.Field == "CreditCard.ExpirationYear"));
        }

        [Fact]
        public void ValidateNullTest()
        {
            var sut = new CreditCardValidator();
            var result = sut.Validate(null);

            Assert.NotNull(result);
            Assert.NotNull(result.FirstOrDefault(f => f.Field == "Credit Card"));
        }
    }
}