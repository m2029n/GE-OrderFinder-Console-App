﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Payments;
using Cdw.Domain.Partners.Implementation.UnitTests.FakeObjects;
using Cdw.Domain.Partners.Payments;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.Payments;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Common.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.Payments
{
    public class PaymentDomainManagerTests
    {
        private readonly Mock<ILog> _logger = new Mock<ILog>();
        private readonly Mock<ICreditCardServiceDomainManager> _creditCardServiceDomainManager = new Mock<ICreditCardServiceDomainManager>();
        private readonly Mock<IPartnerSettings> _partnerSettings = new Mock<IPartnerSettings>();
        private readonly Mock<IPaymentRepository> _paymentRepository = new Mock<IPaymentRepository>();
        private readonly PaymentDomainManager _sut;
        private readonly PaymentRequest _paymentRequestModel = new PaymentRequest();

        public PaymentDomainManagerTests()
        {
            Mapper.AddProfile(new PaymentsMappingProfile());

            _sut = new PaymentDomainManager(_logger.Object, _creditCardServiceDomainManager.Object,
                _paymentRepository.Object, _partnerSettings.Object);
            _paymentRequestModel.CreditCard = new CreditCard
            {
                Number = "411111111111111111",
                Name = "Name LastName",
                CVV = "123",
                ExpirationMonth = 12,
                ExpirationYear = 2025
            };
            _paymentRequestModel.TransactionId = Guid.NewGuid().ToString();
        }

        [Fact]
        public async Task Should_Pass_AuthorizeTests()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));

            var key = _partnerSettings.Object.CreditCardAPIKey;
            _creditCardServiceDomainManager.Setup(x => x.EncryptAsync(_paymentRequestModel.CreditCard.Number, key)).ReturnsAsync(er.Object);
            _creditCardServiceDomainManager.Setup(x => x.EncryptAsync(_paymentRequestModel.CreditCard.Number, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = true,
                CreditCardToken = Guid.NewGuid().ToString()
            };

            _creditCardServiceDomainManager.Setup(x => x.AuthorizeAsync(It.IsAny<Implementation.Payments.CreditCardService.CreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            var actual = await _sut.AuthorizeAsync(_paymentRequestModel).ConfigureAwait(false);
            Assert.NotNull(actual);
            Assert.Equal(actual.TransactionId, _paymentRequestModel.TransactionId);
        }

        [Fact]
        public void Should_Fail_IFNotValid_AuthorizeTests()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            var key = _partnerSettings.Object.CreditCardAPIKey;
            _creditCardServiceDomainManager.Setup(x => x.EncryptAsync(_paymentRequestModel.CreditCard.Number, key)).ReturnsAsync(er.Object);
            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = false,
                CreditCardToken = Guid.NewGuid().ToString()
            };
            _creditCardServiceDomainManager.Setup(x => x.AuthorizeAsync(It.IsAny<CreditCardAuthorizationRequest>())).ReturnsAsync(ccar);

            var actual = Assert.ThrowsAsync<PaymentValidationException>(() => _sut.AuthorizeAsync(_paymentRequestModel));

            Assert.NotNull(actual);
        }

        [Fact]
        public void Should_Fail_IFCouldNotEncrypt_AuthorizeTests()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));
            var key = _partnerSettings.Object.CreditCardAPIKey;
            _creditCardServiceDomainManager.Setup(x => x.EncryptAsync(_paymentRequestModel.CreditCard.Number, key)).Throws(new Exception("errror"));
            var actual = Assert.ThrowsAsync<Exception>(() => _sut.AuthorizeAsync(_paymentRequestModel));

            Assert.NotNull(actual);
        }

        [Fact]
        public void Should_Fail_IFCouldNotSave_AuthorizeTests()
        {
            //Arrange test
            var er = new Mock<IEncryptedResult>();
            er.Setup(x => x.EncryptedInfo).Returns(Faker.Lorem.Sentence(30));

            var key = _partnerSettings.Object.CreditCardAPIKey;
            _creditCardServiceDomainManager.Setup(x => x.EncryptAsync(_paymentRequestModel.CreditCard.Number, key)).ReturnsAsync(er.Object);

            var ccar = new FakeCreditCardAuthorizationResponse()
            {
                IsValid = true,
                CreditCardToken = Guid.NewGuid().ToString()
            };
            _creditCardServiceDomainManager.Setup(x => x.AuthorizeAsync(It.IsAny<CreditCardAuthorizationRequest>())).ReturnsAsync(ccar);
            _paymentRepository.Setup(x => x.AddPaymentTokensMapping(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Throws(new Exception());

            var actual = Assert.ThrowsAsync<Exception>(() => _sut.AuthorizeAsync(_paymentRequestModel));

            Assert.NotNull(actual);
        }
    }
}