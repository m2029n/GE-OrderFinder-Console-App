﻿using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Domain.Partners.Implementation.DataAccess.APILogging;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Domain.Partners.Implementation.UnitTests.APILogging.Manager
{
    public class LogRequestResponseManagerTests
    {
        private readonly Mock<ILogRequestResponseRepository> _repository = new Mock<ILogRequestResponseRepository>();

        [Fact]
        public async Task InsertRequestResponseLogAsyncTest()
        {
            //Arrange
            var model = new RequestResponseLog
            {
                PartnerName = "Test",
            };
            var expected = new RequestResponseLog
            {
                PartnerName = "Test",
                Id = 123,
                MessageType = "Post"
            };
            _repository.Setup(i => i.InsertRequestResponseLogAsync(model)).ReturnsAsync(expected);
            var sut = new LogRequestResponseManager(_repository.Object);

            //Act
            var actual = await sut.InsertRequestResponseLogAsync(model).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(expected.Id, actual.Id);
            Assert.Equal(expected.MessageType, actual.MessageType);
        }

        [Fact]
        public async Task SearchLogsByClientNameAsyncTest()
        {
            //Arrange
            var model = new
            {
                clientName = "Test",
                startDate = DateTime.Now,
                endDate = DateTime.Now,
                method = "post",
                resultCode = 200,
                requestPath =""
            };
            var expected = new RequestResponseLog
            {
                PartnerName = "Test",
                Id = 123,
                MessageType = "Post"
            };
            List<RequestResponseLog> expectedList = new List<RequestResponseLog>();
            expectedList.Add(expected);
            _repository.Setup(i => i.SearchLogsByClientNameAsync(model.clientName, model.startDate, model.endDate, model.method,model.requestPath, model.resultCode)).ReturnsAsync(expectedList);
            var sut = new LogRequestResponseManager(_repository.Object);

            //Act
            var actual = await sut.SearchLogsByClientNameAsync(model.clientName, model.startDate, model.endDate, model.method,model.requestPath, model.resultCode).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(expectedList.Count, actual.ResultCount);
        }

        [Fact]
        public async Task GetLogsByIdAsyncTest()
        {
            //Arrange
            var id = 12;
            var expected = new RequestResponseLog
            {
                PartnerName = "Test",
                Id = id,
                MessageType = "Post",
                RequestPath = "/order"
            };

            _repository.Setup(i => i.GetRequestResponseLogsByIdAndClientNameAsync("Test", id)).ReturnsAsync(expected);
            var sut = new LogRequestResponseManager(_repository.Object);

            //Act
            var actual = await sut.GetLogsByIdAsync("Test", id).ConfigureAwait(false);

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(expected.Id, actual.Id);
            Assert.Equal(expected.RequestPath, actual.RequestPath);
        }
    }
}