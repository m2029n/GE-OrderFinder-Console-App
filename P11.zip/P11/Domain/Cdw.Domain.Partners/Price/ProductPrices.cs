﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Price
{
    internal class ProductPrices : IProductPrices
    {
        public ProductPrices()
        {
            this.Prices = new List<IProductPrice>();
        }

        public List<IProductPrice> Prices { get; set; }

        public string ProductCode { get; set; }

        public int ProductId { get; set; }
    }
}