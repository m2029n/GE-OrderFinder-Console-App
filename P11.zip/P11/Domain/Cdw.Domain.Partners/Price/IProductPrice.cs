﻿using System;

namespace Cdw.Domain.Partners.Price
{
    /// <summary>
    /// Interface to describe a CDW Price
    /// </summary>
    public interface IProductPrice
    {
        /// <summary>
        /// defines ProductId
        /// </summary>
        int ProductId { get; set; }

        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// Property to describe the Price Identifier
        /// </summary>
        Int32 Id { set; get; }

        /// <summary>
        /// Property to describe the Price Amount
        /// </summary>
        double Price { get; set; }

        /// <summary>
        /// Property to describe the original price of a B-stock product
        /// </summary>
        IProductPrice BStockOriginalPrice { get; set; }

        /// <summary>
        /// Property to describe the Mode MSRP
        /// </summary>
        IProductPrice ModeMsrp { get; set; }

        /// <summary>
        /// Read-only property to the expose the price key (internally generated).
        /// </summary>
        string PriceKey { get; }

        /// <summary>
        /// Read-only property to describe the display ready formatted price
        /// </summary>
        string PriceFormatted { get; }

        /// <summary>
        /// Read-only property to describe the display ready formatted price long version.
        /// </summary>
        string PriceFormattedLong { get; }

        /// <summary>
        /// Property to describe the Price Name
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Property to describe the Price Code
        /// </summary>
        string PriceCode { get; set; }

        /// <summary>
        /// Property to describe the Pricing Type for the current price
        /// </summary>
        string PricingType { get; set; }

        /// <summary>
        /// Property to expose if the current price represents a stored price (static).
        /// </summary>
        bool HasStaticPrice { get; set; }

        /// <summary>
        /// Property to expose if the current price is a mandatory price.
        /// </summary>
        bool IsMandatory { get; }
    }
}