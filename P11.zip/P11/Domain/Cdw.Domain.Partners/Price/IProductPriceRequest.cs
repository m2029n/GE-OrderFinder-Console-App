﻿using System;
using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.Price
{
    /// <summary>
    /// defines IProductPriceRequest
    /// </summary>
    public interface IProductPriceRequest
    {
        /// <summary>
        /// defines EDC
        /// </summary>
        List<string> EDC { get; set; }

        /// <summary>
        /// defines UserTrackingId
        /// </summary>
        string UserTrackingId { get; set; }

        /// <summary>
        /// defines CompanyCode
        /// </summary>
        string CompanyCode { get; set; }

        /// <summary>
        /// defines CustomPageKey
        /// </summary>
        string CustomPageKey { get; set; }

        /// <summary>
        /// defines SessionKey
        /// </summary>
        string SessionKey { get; set; }

        //string SessionType { get; set; }
        /// <summary>
        /// defines Contracts
        /// </summary>
        List<String> Contracts { get; set; }

        /// <summary>
        /// defines LowestPrice
        /// </summary>
        bool LowestPrice { get; set; }

        /// <summary>
        /// defines IsLoggedIn
        /// </summary>
        bool IsLoggedIn { get; set; }

        /// <summary>
        /// defines IsTransactiveUser
        /// </summary>
        bool IsTransactiveUser { get; set; }

        /// <summary>
        /// defines IsEProcurementUser
        /// </summary>
        bool IsEProcurementUser { get; set; }

        /// <summary>
        /// defines IsEppUser
        /// </summary>
        bool IsEppUser { get; set; }

        /// <summary>
        /// defines TrackingValues
        /// </summary>
        ITrackingValues TrackingValues { get; set; }
    }
}