﻿using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.Price
{
    /// <summary>
    /// implements ProductPriceRequest
    /// </summary>
    public class ProductPriceRequest : IProductPriceRequest
    {
        /// <summary>
        /// ctor ProductPriceRequest
        /// </summary>
        public ProductPriceRequest()
        {
            EDC = new List<string>();
            Contracts = new List<string>();
        }

        /// <summary>
        /// holds EDC
        /// </summary>
        public List<string> EDC { get; set; }

        /// <summary>
        /// holds UserTrackingId
        /// </summary>
        public string UserTrackingId { get; set; }

        /// <summary>
        /// holds CompanyCode
        /// </summary>
        public string CompanyCode { get; set; }

        /// <summary>
        /// holds IsLoggedIn
        /// </summary>
        public bool IsLoggedIn { get; set; }

        /// <summary>
        /// holds CustomPageKey
        /// </summary>
        public string CustomPageKey { get; set; }

        /// <summary>
        /// holds IsClosedLoop
        /// </summary>
        public bool IsClosedLoop { get; set; }

        /// <summary>
        /// holds SessionKey
        /// </summary>
        public string SessionKey { get; set; }

        /// <summary>
        /// holds Contracts
        /// </summary>
        public List<string> Contracts { get; set; }

        /// <summary>
        /// holds IsEppUser
        /// </summary>
        public bool IsEppUser { get; set; }

        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }

        /// <summary>
        /// holds LowestPrice
        /// </summary>
        public bool LowestPrice { get; set; }

        /// <summary>
        /// holds ShowRestricted
        /// </summary>
        public bool ShowRestricted { get; set; }

        /// <summary>
        /// holds IsTransactiveUser
        /// </summary>
        public bool IsTransactiveUser { get; set; }

        /// <summary>
        /// holds IsEProcurementUser
        /// </summary>
        public bool IsEProcurementUser { get; set; }
    }
}