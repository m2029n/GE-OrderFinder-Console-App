﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Price
{
    /// <summary>
    /// defines IPriceDomainManager
    /// </summary>
    public interface IPriceDomainManager
    {
        /// <summary>
        /// Obsolete
        /// </summary>
        /// <param name="pricingRequest"></param>
        /// <returns></returns>
        [Obsolete("Use Async version instead.")]
        IQueryable<IProductPrices> Get(IProductPriceRequest pricingRequest);

        /// <summary>
        /// defines GetAsync
        /// </summary>
        /// <param name="pricingRequest"></param>
        /// <returns></returns>
        Task<IQueryable<IProductPrices>> GetAsync(IProductPriceRequest pricingRequest);
    }
}