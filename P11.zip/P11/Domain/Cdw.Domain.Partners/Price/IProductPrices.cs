﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Price
{
    /// <summary>
    /// defines IProductPrices
    /// </summary>
    public interface IProductPrices
    {
        /// <summary>
        /// Public property to expose the current product identifier associated with the current
        /// pricing type.
        /// </summary>
		Int32 ProductId { get; set; }

        /// <summary>
        /// Public property to expose the current product code associated with the current pricing type.
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// defines Prices
        /// </summary>
        List<IProductPrice> Prices { get; set; }
    }
}