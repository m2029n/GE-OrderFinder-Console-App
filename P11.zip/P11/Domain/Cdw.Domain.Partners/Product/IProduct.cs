﻿namespace Cdw.Domain.Partners.Product
{
    /// <summary>
    /// The product object represents the details of a product,
    /// </summary>
    public interface IProduct
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }
        /// <summary>
        /// defines Description
        /// </summary>
        string Description { get; }
        /// <summary>
        /// defines FriendlyName
        /// </summary>
        string FriendlyName { get; }
        /// <summary>
        /// defines FriendlyDescription
        /// </summary>
        string FriendlyDescription { get; }
        /// <summary>
        /// defines ManufacturerPartNumber
        /// </summary>
        string ManufacturerPartNumber { get; }
    }
}