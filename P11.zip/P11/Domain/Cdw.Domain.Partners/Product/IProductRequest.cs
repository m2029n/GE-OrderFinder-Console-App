﻿using Cdw.Common;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Product
{
    /// <summary>
    /// defines IProductRequest
    /// </summary>
    public interface IProductRequest
    {
        /// <summary>
        /// defines ProductCodes
        /// </summary>
        IEnumerable<string> ProductCodes { get; }

        /// <summary>
        /// defines ClientName
        /// </summary>
        string ClientName { get; set; }

        /// <summary>
        /// defines TrackingValues
        /// </summary>
        ITrackingValues TrackingValues { get; }
    }
}