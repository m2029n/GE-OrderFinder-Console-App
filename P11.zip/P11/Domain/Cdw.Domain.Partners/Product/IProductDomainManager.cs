﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Services.Core;

namespace Cdw.Domain.Partners.Product
{
    /// <summary>
    /// extends IHealthCheck for Product Manager
    /// </summary>
    public interface IProductDomainManager : IHealthCheck
    {
        /// <summary>
        /// Obsolete
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Obsolete("Use Async version instead.")]
        IProduct GetProduct(IProductRequest request);

        /// <summary>
        /// Obsolete
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Obsolete("Use Async version instead.")]
        IEnumerable<IProduct> GetProducts(IProductRequest request);

        /// <summary>
        /// defines GetProductAsync
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<IProduct> GetProductAsync(IProductRequest request);

        /// <summary>
        /// defines GetProductsAsync
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<IEnumerable<IProduct>> GetProductsAsync(IProductRequest request);
    }
}