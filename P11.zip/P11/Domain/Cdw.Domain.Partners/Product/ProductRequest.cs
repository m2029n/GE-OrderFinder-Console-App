﻿using Cdw.Common;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Product
{
    /// <summary>
    /// implements ProductRequest
    /// </summary>
    public class ProductRequest : IProductRequest
    {
        /// <summary>
        /// holds ProductCodes
        /// </summary>
        public IEnumerable<string> ProductCodes { get; set; }

        /// <summary>
        /// holds ClientName
        /// </summary>
        public string ClientName { get; set; }

        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }
    }
}