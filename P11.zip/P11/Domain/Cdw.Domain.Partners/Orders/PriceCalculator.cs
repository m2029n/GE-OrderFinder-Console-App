using System;
using System.Collections.Generic;
using System.Linq;

namespace Cdw.Domain.Partners.Orders
{
    internal static class PriceCalculator
    {
        public static decimal CalculateUnitPriceAfterDiscounts(CartItem cartItem)
        {
            return ApplyPercentageDiscounts(
                cartItem.Discounts.PercentOffUnitPriceDiscounts,
                ApplyFixedDiscounts(
                    cartItem.Discounts.FixedUnitPriceDiscounts,
                    cartItem.UnitPrice));
        }

        public static decimal CalculateLinePriceAfterDiscounts(CartItem cartItem)
        {
            return CalculatedDiscountedLinePrice(
                cartItem.Discounts,
                CalculateUnitPriceAfterDiscounts(cartItem) * cartItem.Quantity);
        }

        public static decimal CalculateLinePriceBeforeDiscounts(CartItem cartItem)
        {
            return cartItem.UnitPrice * cartItem.Quantity;
        }

        private static decimal CalculatedDiscountedLinePrice(
            ICartItemDiscounts discounts,
            decimal linePrice)
        {
            return ApplyPercentageDiscounts(
                discounts.PercentOffLinePriceDiscounts,
                ApplyFixedDiscounts(
                    discounts.FixedLinePriceDiscounts,
                    linePrice));
        }

        private static decimal ApplyFixedDiscounts(
            IList<IDiscount> discounts,
            decimal price)
        {
            return Math.Max(0, price - discounts.Sum(d => d.Amount));
        }

        private static decimal ApplyPercentageDiscounts(
            IList<IDiscount> discounts,
            decimal price)
        {
            return Math.Round(
                Math.Max(0, price - discounts.Sum(d => (d.Amount / 100m) * price)),
                2);
        }
    }
}