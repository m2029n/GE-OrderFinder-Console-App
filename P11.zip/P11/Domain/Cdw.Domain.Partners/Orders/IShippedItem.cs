﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ShippingItems
    /// </summary>
    public interface IShippedItem
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; }

        /// <summary>
        /// defines ManufacturerPartNumber
        /// </summary>
        string ManufacturerPartNumber { get; }
    }

    /// <summary>
    /// imlements ShippedItem
    /// </summary>
    public class ShippedItem : IShippedItem
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }
    }
}