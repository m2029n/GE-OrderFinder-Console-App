﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICreditCardType
    /// </summary>
    public interface ICreditCardType
    {
        /// <summary>
        /// defines Type
        /// </summary>
        PaymentMethodType Type { get; }

        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }

        /// <summary>
        /// defines AlternateNames
        /// </summary>
        IEnumerable<string> AlternateNames { get; }

        /// <summary>
        /// defines CardNumberLength
        /// </summary>
        int CardNumberLength { get; }

        /// <summary>
        /// defines NumberMatchesCardTypePattern
        /// </summary>
        bool NumberMatchesCardTypePattern(string cardNumber);
    }

    /// <summary>
    /// implements ICreditCardType
    /// </summary>
    public class CreditCardType : ICreditCardType
    {
        /// <summary>
        /// not implemented method
        /// </summary>
        /// <param name="cardNumber"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public bool NumberMatchesCardTypePattern(string cardNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// holds Type
        /// </summary>
        public PaymentMethodType Type { get; set; }

        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// holds AlternateNames
        /// </summary>
        public IEnumerable<string> AlternateNames { get; set; }

        /// <summary>
        /// holds CardNumberLength
        /// </summary>
        public int CardNumberLength { get; set; }
    }
}