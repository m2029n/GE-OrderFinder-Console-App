﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// enum for Shipping Status
    /// </summary>
    public enum OrderShippingStatus
    {
        /// <summary>
        /// Unknown Shipping Status
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Canceled Shipping Status
        /// </summary>
        Canceled = 1,

        /// <summary>
        /// BackOrdered Shipping Status
        /// </summary>
        BackOrdered = 2,

        /// <summary>
        /// ShippedFromWillCall Shipping Status
        /// </summary>
        ShippedFromWillCall = 4,

        /// <summary>
        /// Shipped Shipping Status
        /// </summary>
        Shipped = 8,

        /// <summary>
        /// WaitingForPickup Shipping Status
        /// </summary>
        WaitingForPickup = 16,

        /// <summary>
        /// ProcessingOrder Shipping Status
        /// </summary>
        ProcessingOrder = 32,

        /// <summary>
        /// NotShipped Shipping Status
        /// </summary>
        NotShipped = 64
    }
}