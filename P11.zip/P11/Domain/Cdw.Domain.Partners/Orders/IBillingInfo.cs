﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IBillingInfo
    /// </summary>
    public interface IBillingInfo
    {
        /// <summary>
        /// defines Address
        /// </summary>
        IAddress Address { get; }

        /// <summary>
        /// defines Method
        /// </summary>
        IPaymentMethod Method { get; }
    }

    /// <summary>
    /// implements IBillingInfo
    /// </summary>
    public class BillingInfo : IBillingInfo
    {
        /// <summary>
        /// holds Address
        /// </summary>
        public IAddress Address { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public IPaymentMethod Method { get; set; }
    }
}