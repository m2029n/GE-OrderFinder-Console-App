﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// enum for OrderStatus
    /// </summary>
    public enum OrderStatus
    {
        /// <summary>
        /// processing status
        /// </summary>
        Processing = 1,

        /// <summary>
        /// BackorderedItems status
        /// </summary>
        BackorderedItems = 2,

        /// <summary>
        /// PartiallyShipped status
        /// </summary>
        PartiallyShipped = 3,

        /// <summary>
        /// Shipped status
        /// </summary>
        Shipped = 4,

        /// <summary>
        /// Canceled status
        /// </summary>
        Canceled = 5
    }
}