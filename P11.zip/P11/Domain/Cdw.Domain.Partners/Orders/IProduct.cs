﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IProduct
    /// </summary>
    public interface IProduct
    {
        /// <summary>
        /// defines ProductKey
        /// </summary>
        string ProductKey { get; set; }

        /// <summary>
        /// defines ProductID
        /// </summary>
        int ProductID { get; set; }

        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; set; }
        /// <summary>
        /// defines FriendlyName
        /// </summary>
        string FriendlyName { get; set; }
        /// <summary>
        /// defines Description
        /// </summary>
        string Description { get; set; }
        /// <summary>
        /// defines FriendlyDescription
        /// </summary>
        string FriendlyDescription { get; set; }
        /// <summary>
        /// defines CompanyPartNumber
        /// </summary>
        string CompanyPartNumber { get; set; }
        /// <summary>
        /// defines ParentManufactureID
        /// </summary>
        int ParentManufactureID { get; set; }
        /// <summary>
        /// defines ManufactureID
        /// </summary>
        string ManufactureID { get; set; }
        /// <summary>
        /// defines ManufactureKey
        /// </summary>
        string ManufactureKey { get; set; }
        /// <summary>
        /// defines ManufactureCode
        /// </summary>
        string ManufactureCode { get; set; }
        /// <summary>
        /// defines ManufactureName
        /// </summary>
        string ManufactureName { get; set; }
        /// <summary>
        /// defines ManufacturePartNumber
        /// </summary>
        string ManufacturePartNumber { get; set; }
        /// <summary>
        /// defines Weight
        /// </summary>
        decimal Weight { get; set; }
        /// <summary>
        /// defines Height
        /// </summary>
        decimal Height { get; set; }
        /// <summary>
        /// defines Width
        /// </summary>
        decimal Width { get; set; }
        /// <summary>
        /// defines Length
        /// </summary>
        decimal Length { get; set; }
        /// <summary>
        /// defines NonReturnable
        /// </summary>
        bool NonReturnable { get; set; }
        /// <summary>
        /// defines DropShipOnly
        /// </summary>
        bool DropShipOnly { get; set; }
        /// <summary>
        /// defines DateSellStart
        /// </summary>
        DateTime DateSellStart { get; set; }
        /// <summary>
        /// defines DateSellStop
        /// </summary>
        DateTime DateSellStop { get; set; }
        /// <summary>
        /// defines DateCreated
        /// </summary>
        DateTime DateCreated { get; set; }
        /// <summary>
        /// defines DateModified
        /// </summary>
        DateTime DateModified { get; set; }
        /// <summary>
        /// defines ImageEDC
        /// </summary>
        string ImageEDC { get; set; }
        /// <summary>
        /// defines SpinSetName
        /// </summary>
        string SpinSetName { get; set; }
        /// <summary>
        /// defines StockSource
        /// </summary>
        string StockSource { get; set; }
        /// <summary>
        /// defines ProductClass
        /// </summary>
        string ProductClass { get; set; }
        /// <summary>
        /// defines ProductGroup
        /// </summary>
        string ProductGroup { get; set; }
        /// <summary>
        /// defines IsBundle
        /// </summary>
        bool IsBundle { get; set; }
        /// <summary>
        /// defines ProductType
        /// </summary>
        string ProductType { get; set; }
        /// <summary>
        /// defines CustomerSpecificEDC
        /// </summary>
        bool CustomerSpecificEDC { get; set; }
        /// <summary>
        /// defines BundledProducts
        /// </summary>
        IEnumerable<IBundleProduct> BundledProducts { get; set; }
    }

    /// <summary>
    /// implements Product
    /// </summary>
    public class Product : IProduct
    {
        /// <summary>
        /// holds ProductKey
        /// </summary>
        public string ProductKey { get; set; }
        /// <summary>
        /// holds ProductID
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// holds FriendlyName
        /// </summary>
        public string FriendlyName { get; set; }
        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// holds FriendlyDescription
        /// </summary>
        public string FriendlyDescription { get; set; }
        /// <summary>
        /// holds CompanyPartNumber
        /// </summary>
        public string CompanyPartNumber { get; set; }
        /// <summary>
        /// holds ParentManufactureID
        /// </summary>
        public int ParentManufactureID { get; set; }
        /// <summary>
        /// holds ManufactureID
        /// </summary>
        public string ManufactureID { get; set; }
        /// <summary>
        /// holds ManufactureKey
        /// </summary>
        public string ManufactureKey { get; set; }
        /// <summary>
        /// holds ProdManufactureCodeuctKey
        /// </summary>
        public string ManufactureCode { get; set; }
        /// <summary>
        /// holds ManufactureName
        /// </summary>
        public string ManufactureName { get; set; }
        /// <summary>
        /// holds ManufacturePartNumber
        /// </summary>
        public string ManufacturePartNumber { get; set; }
        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }
        /// <summary>
        /// holds Height
        /// </summary>
        public decimal Height { get; set; }
        /// <summary>
        /// holds Width
        /// </summary>
        public decimal Width { get; set; }
        /// <summary>
        /// holds Length
        /// </summary>
        public decimal Length { get; set; }
        /// <summary>
        /// holds NonReturnable
        /// </summary>
        public bool NonReturnable { get; set; }
        /// <summary>
        /// holds DropShipOnly
        /// </summary>
        public bool DropShipOnly { get; set; }
        /// <summary>
        /// holds DateSellStart
        /// </summary>
        public DateTime DateSellStart { get; set; }
        /// <summary>
        /// holds DateSellStop
        /// </summary>
        public DateTime DateSellStop { get; set; }
        /// <summary>
        /// holds DateCreated
        /// </summary>
        public DateTime DateCreated { get; set; }
        /// <summary>
        /// holds DateModified
        /// </summary>
        public DateTime DateModified { get; set; }
        /// <summary>
        /// holds ImageEDC
        /// </summary>
        public string ImageEDC { get; set; }
        /// <summary>
        /// holds SpinSetName
        /// </summary>
        public string SpinSetName { get; set; }
        /// <summary>
        /// holds StockSource
        /// </summary>
        public string StockSource { get; set; }
        /// <summary>
        /// holds ProductClass
        /// </summary>
        public string ProductClass { get; set; }
        /// <summary>
        /// holds ProductGroup
        /// </summary>
        public string ProductGroup { get; set; }
        /// <summary>
        /// holds IsBundle
        /// </summary>
        public bool IsBundle { get; set; }
        /// <summary>
        /// holds ProductType
        /// </summary>
        public string ProductType { get; set; }
        /// <summary>
        /// holds CustomerSpecificEDC
        /// </summary>
        public bool CustomerSpecificEDC { get; set; }
        /// <summary>
        /// holds BundledProducts
        /// </summary>
        public IEnumerable<IBundleProduct> BundledProducts { get; set; }
    }
}