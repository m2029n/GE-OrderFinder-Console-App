﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IResponseCreditCard
    /// </summary>
    public interface IResponseCreditCard
    {
        /// <summary>
        /// defines Type
        /// </summary>
        string Type { get; set; }

        /// <summary>
        /// defines Number
        /// </summary>
        string Number { get; set; }
    }
}