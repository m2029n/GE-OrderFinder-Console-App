﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICartItemDiscounts
    /// </summary>
    public interface ICartItemDiscounts
    {
        /// <summary>
        /// defines FixedLinePriceDiscounts
        /// </summary>
        IList<IDiscount> FixedLinePriceDiscounts { get; }

        /// <summary>
        /// defines FixedUnitPriceDiscounts
        /// </summary>
        IList<IDiscount> FixedUnitPriceDiscounts { get; }

        /// <summary>
        /// defines PercentOffLinePriceDiscounts
        /// </summary>
        IList<IDiscount> PercentOffLinePriceDiscounts { get; }

        /// <summary>
        /// defines PercentOffUnitPriceDiscounts
        /// </summary>
        IList<IDiscount> PercentOffUnitPriceDiscounts { get; }
    }

    /// <summary>
    /// implements v
    /// </summary>
    public class CartItemDiscounts : ICartItemDiscounts
    {
        /// <summary>
        /// holds FixedLinePriceDiscounts
        /// </summary>
        public IList<IDiscount> FixedLinePriceDiscounts { get; set; }

        /// <summary>
        /// holds FixedUnitPriceDiscounts
        /// </summary>
        public IList<IDiscount> FixedUnitPriceDiscounts { get; set; }

        /// <summary>
        /// holds PercentOffLinePriceDiscounts
        /// </summary>
        public IList<IDiscount> PercentOffLinePriceDiscounts { get; set; }

        /// <summary>
        /// holds PercentOffUnitPriceDiscounts
        /// </summary>
        public IList<IDiscount> PercentOffUnitPriceDiscounts { get; set; }
    }
}