﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICartItem
    /// </summary>
    public interface ICartItem
    {
        /// <summary>
        /// defines Id
        /// </summary>
        int Id { get; }

        /// <summary>
        /// defines Status
        /// </summary>
        CartItemStatus Status { get; }

        /// <summary>
        /// defines CustomProperties
        /// </summary>
        IList<ICustomProperty> CustomProperties { get; }

        /// <summary>
        /// defines Discounts
        /// </summary>
        ICartItemDiscounts Discounts { get; }

        /// <summary>
        /// defines UnitPrice
        /// </summary>
        decimal UnitPrice { get; }

        /// <summary>
        /// defines DiscountedUnitPrice
        /// </summary>
        decimal DiscountedUnitPrice { get; }

        /// <summary>
        /// defines LinePrice
        /// </summary>
        decimal LinePrice { get; }

        /// <summary>
        /// defines DiscountedLinePrice
        /// </summary>
        decimal DiscountedLinePrice { get; }

        /// <summary>
        /// defines Product
        /// </summary>
        IProduct Product { get; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        uint Quantity { get; }
    }

    /// <summary>
    /// implements ICartItem
    /// </summary>
    public class CartItem : ICartItem
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// holds Status
        /// </summary>
        public CartItemStatus Status { get; set; }

        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public IList<ICustomProperty> CustomProperties { get; set; }

        /// <summary>
        /// holds Discounts
        /// </summary>
        public ICartItemDiscounts Discounts { get; set; }

        /// <summary>
        /// holds UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// holds Product
        /// </summary>
        public IProduct Product { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public uint Quantity { get; set; }

        /// <summary>
        /// holds DiscountedUnitPrice
        /// </summary>
        public decimal DiscountedUnitPrice => PriceCalculator.CalculateUnitPriceAfterDiscounts(this);

        /// <summary>
        /// holds LinePrice
        /// </summary>
        public decimal LinePrice => PriceCalculator.CalculateLinePriceBeforeDiscounts(this);

        /// <summary>
        /// return Line Price
        /// </summary>
        public decimal DiscountedLinePrice => PriceCalculator.CalculateLinePriceAfterDiscounts(this);
    }

    public class AS400CartItem : ICartItem
    {
        public int Id { get; set; }
        public CartItemStatus Status { get; set; }
        public IList<ICustomProperty> CustomProperties { get; set; }
        public ICartItemDiscounts Discounts { get; set; }
        public decimal UnitPrice { get; set; }

        public IProduct Product { get; set; }
        public uint Quantity { get; set; }

        public decimal DiscountedUnitPrice { get; set; }

        public decimal LinePrice { get; set; }

        public decimal DiscountedLinePrice { get; set; }
    }
}