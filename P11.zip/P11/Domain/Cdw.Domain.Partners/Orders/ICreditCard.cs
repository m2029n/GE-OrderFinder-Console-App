﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICreditCard
    /// </summary>
    public interface ICreditCard
    {
        /// <summary>
        /// defines Id
        /// </summary>
        int Id { get; }
        /// <summary>
        /// defines Token
        /// </summary>
        string Token { get; }
        /// <summary>
        /// defines Type
        /// </summary>
        ICreditCardType Type { get; }
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }
        /// <summary>
        /// defines Number
        /// </summary>
        string Number { get; }
        /// <summary>
        /// defines ExpirationMonth
        /// </summary>
        int ExpirationMonth { get; }
        /// <summary>
        /// defines ExpirationYear
        /// </summary>
        int ExpirationYear { get; }
    }

    /// <summary>
    /// impelements ICreditCard
    /// </summary>
    public class CreditCard : ICreditCard
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// holds Token
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// holds Type
        /// </summary>
        public ICreditCardType Type { get; set; }
        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// holds Number
        /// </summary>
        public string Number { get; set; }
        /// <summary>
        /// holds ExpirationMonth
        /// </summary>
        public int ExpirationMonth { get; set; }
        /// <summary>
        /// holds ExpirationYear
        /// </summary>
        public int ExpirationYear { get; set; }
    }
}