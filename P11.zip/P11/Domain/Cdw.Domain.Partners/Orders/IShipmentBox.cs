﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IShipmentBox
    /// </summary>
    public interface IShipmentBox
    {
        /// <summary>
        /// defines BoxNumber
        /// </summary>
        int BoxNumber { get; set; }

        /// <summary>
        /// defines CarrierCode
        /// </summary>
        string CarrierCode { get; set; }

        /// <summary>
        /// defines CarrierCodeType
        /// </summary>
        string CarrierCodeType { get; set; }

        /// <summary>
        /// defines Contents
        /// </summary>
        IEnumerable<IShipmentBoxContent> Contents { get; set; }

        /// <summary>
        /// defines EstimatedDeliveryDate
        /// </summary>
        DateTime? EstimatedDeliveryDate { get; set; }

        /// <summary>
        /// defines InvoiceNumber
        /// </summary>
        string InvoiceNumber { get; set; }

        /// <summary>
        /// defines ShipDate
        /// </summary>
        DateTime? ShipDate { get; set; }

        /// <summary>
        /// defines ShipMethod
        /// </summary>
        string ShipMethod { get; set; }

        /// <summary>
        /// defines TrackingNumber
        /// </summary>
        string TrackingNumber { get; set; }

        /// <summary>
        /// defines Weight
        /// </summary>
        decimal? Weight { get; set; }
    }

    /// <summary>
    /// implements ShipmentBox
    /// </summary>
    public class ShipmentBox : IShipmentBox
    {
        /// <summary>
        /// holds BoxNumber
        /// </summary>
        public int BoxNumber { get; set; }

        /// <summary>
        /// holds CarrierCode
        /// </summary>
        public string CarrierCode { get; set; }

        /// <summary>
        /// holds CarrierCodeType
        /// </summary>
        public string CarrierCodeType { get; set; }

        /// <summary>
        /// holds Contents
        /// </summary>
        public IEnumerable<IShipmentBoxContent> Contents { get; set; }

        /// <summary>
        /// holds EstimatedDeliveryDate
        /// </summary>
        public DateTime? EstimatedDeliveryDate { get; set; }

        /// <summary>
        /// holds InvoiceNumber
        /// </summary>
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// holds ShipDate
        /// </summary>
        public DateTime? ShipDate { get; set; }

        /// <summary>
        /// holds ShipMethod
        /// </summary>
        public string ShipMethod { get; set; }

        /// <summary>
        /// holds TrackingNumber
        /// </summary>
        public string TrackingNumber { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal? Weight { get; set; }
    }
}