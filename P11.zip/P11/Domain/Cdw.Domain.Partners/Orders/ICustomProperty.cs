﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICustomProperty
    /// </summary>
    public interface ICustomProperty
    {
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }
        /// <summary>
        /// defines Value
        /// </summary>
        string Value { get; }
    }

    /// <summary>
    /// implements ICustomProperty
    /// </summary>
    public class CustomProperty : ICustomProperty
    {
        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// holds Value
        /// </summary>
        public string Value { get; set; }
    }
}