﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderLineItem
    /// </summary>
    public interface IOrderLineItem
    {
        /// <summary>
        /// defines CompanyCode
        /// </summary>
        string CompanyCode { get; }

        /// <summary>
        /// defines OrderNumber
        /// </summary>
        string OrderNumber { get; }

        /// <summary>
        /// defines OrderLineNumber
        /// </summary>
        int OrderLineNumber { get; }

        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; set; }

        /// <summary>
        /// defines Price
        /// </summary>
        decimal Price { get; set; }

        /// <summary>
        /// defines Status
        /// </summary>
        string Status { get; set; }

        /// <summary>
        /// defines QuantityOutstanding
        /// </summary>
        int QuantityOutstanding { get; set; }

        /// <summary>
        /// defines SuspendCode
        /// </summary>
        string SuspendCode { get; set; }

        /// <summary>
        /// defines OrderLineValue
        /// </summary>
        decimal OrderLineValue { get; set; }

        /// <summary>
        /// defines OnBehalfFlag
        /// </summary>
        string OnBehalfFlag { get; set; }

        /// <summary>
        /// defines TaxAmount
        /// </summary>
        decimal TaxAmount { get; set; }

        /// <summary>
        /// defines PriceListCode
        /// </summary>
        string PriceListCode { get; set; }

        /// <summary>
        /// defines ContractName
        /// </summary>
        string ContractName { get; set; }

        /// <summary>
        /// defines CDWReferenceCode
        /// </summary>
        int CDWReferenceCode { get; set; }

        /// <summary>
        /// defines QuantityDespatched
        /// </summary>
        decimal QuantityDespatched { get; set; }

        /// <summary>
        /// defines OrderLineStatus
        /// </summary>
        OrderShippingStatus OrderLineStatus { get; set; }

        /// <summary>
        /// defines QuantityBackordered
        /// </summary>
        int QuantityBackordered { get; set; }

        /// <summary>
        /// defines BackorderedEstShipDate
        /// </summary>
        DateTime BackorderedEstShipDate { get; set; }

        /// <summary>
        /// defines FriendlyName
        /// </summary>
        string FriendlyName { get; set; }

        /// <summary>
        /// defines FriendlyDescription
        /// </summary>
        string FriendlyDescription { get; set; }

        /// <summary>
        /// defines ManuFacturePartNumber
        /// </summary>
        string ManuFacturePartNumber { get; set; }
    }

    /// <summary>
    /// implements OrderLineItem
    /// </summary>
    public class OrderLineItem : IOrderLineItem
    {
        /// <summary>
        /// holds CompanyCode
        /// </summary>
        public string CompanyCode { get; }

        /// <summary>
        /// holds OrderNumber
        /// </summary>
        public string OrderNumber { get; }

        /// <summary>
        /// holds OrderLineNumber
        /// </summary>
        public int OrderLineNumber { get; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// holds Price
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// holds Status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// holds QuantityOutstanding
        /// </summary>
        public int QuantityOutstanding { get; set; }

        /// <summary>
        /// holds SuspendCode
        /// </summary>
        public string SuspendCode { get; set; }

        /// <summary>
        /// holds OrderLineValue
        /// </summary>
        public decimal OrderLineValue { get; set; }

        /// <summary>
        /// holds OnBehalfFlag
        /// </summary>
        public string OnBehalfFlag { get; set; }

        /// <summary>
        /// holds TaxAmount
        /// </summary>
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// holds PriceListCode
        /// </summary>
        public string PriceListCode { get; set; }

        /// <summary>
        /// holds ContractName
        /// </summary>
        public string ContractName { get; set; }

        /// <summary>
        /// holds CDWReferenceCode
        /// </summary>
        public int CDWReferenceCode { get; set; }

        /// <summary>
        /// holds QuantityDespatched
        /// </summary>
        public decimal QuantityDespatched { get; set; }

        /// <summary>
        /// holds OrderLineStatus
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public OrderShippingStatus OrderLineStatus { get; set; }

        /// <summary>
        /// holds QuantityBackordered
        /// </summary>
        public int QuantityBackordered { get; set; }

        /// <summary>
        /// holds BackorderedEstShipDate
        /// </summary>
        public DateTime BackorderedEstShipDate { get; set; }

        /// <summary>
        /// holds FriendlyName
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// holds FriendlyDescription
        /// </summary>
        public string FriendlyDescription { get; set; }

        /// <summary>
        /// holds ManuFacturePartNumber
        /// </summary>
        public string ManuFacturePartNumber { get; set; }
    }
}