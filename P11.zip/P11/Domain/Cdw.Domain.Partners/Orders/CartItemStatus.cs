﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines enums CartItemStatus
    /// </summary>
    public enum CartItemStatus
    {
        /// <summary>
        /// defines Pending Status
        /// </summary>
        Pending,
        /// <summary>
        /// defines Partial Status
        /// </summary>
        Partial,
        /// <summary>
        /// defines Shipped Status
        /// </summary>
        Shipped,
        /// <summary>
        /// defines Backordered Status
        /// </summary>
        Backordered,
        /// <summary>
        /// defines Canceled Status
        /// </summary>
        Canceled
    }
}