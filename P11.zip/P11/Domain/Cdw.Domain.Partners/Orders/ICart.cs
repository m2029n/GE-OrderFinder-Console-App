﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Domain.Partners.Common;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICart
    /// </summary>
    public interface ICart
    {
        /// <summary>
        /// defines Id
        /// </summary>
        int Id { get; }

        /// <summary>
        /// defines Company
        /// </summary>
        CdwCompany Company { get; }

        /// <summary>
        /// defines Subtotal
        /// </summary>
        decimal Subtotal { get; }

        /// <summary>
        /// defines DiscountValue
        /// </summary>
        decimal DiscountValue { get; }

        /// <summary>
        /// defines DiscountedSubtotal
        /// </summary>
        decimal DiscountedSubtotal { get; }

        /// <summary>
        /// defines Discounts
        /// </summary>
        ICartDiscounts Discounts { get; }

        /// <summary>
        /// defines Items
        /// </summary>
        IList<ICartItem> Items { get; }

        /// <summary>
        /// defines CustomProperties
        /// </summary>
        IList<ICustomProperty> CustomProperties { get; }
    }

    /// <summary>
    /// impements ICart
    /// </summary>
    public class Cart : ICart
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// holds Company
        /// </summary>
        public CdwCompany Company { get; set; }

        /// <summary>
        /// calculates Subtotal
        /// </summary>
        public decimal Subtotal
        {
            get { return Items.Sum(i => i.DiscountedLinePrice); }
        }

        /// <summary>
        /// calculates DiscountValue
        /// </summary>
        public decimal DiscountValue => DiscountCalculator.CalculateDiscountValue(this);

        /// <summary>
        /// culculates DiscountedSubtotal
        /// </summary>
        public decimal DiscountedSubtotal => Subtotal;

        /// <summary>
        /// holds Discounts
        /// </summary>
        public ICartDiscounts Discounts { get; set; }

        /// <summary>
        /// holds Items
        /// </summary>
        public IList<ICartItem> Items { get; set; }

        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public IList<ICustomProperty> CustomProperties { get; set; }
    }
}