﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderValidationFailure
    /// </summary>
    public interface IOrderValidationFailure
    {
        /// <summary>
        /// defines Field
        /// </summary>
        string Field { get; }

        /// <summary>
        /// defines Message
        /// </summary>
        string Message { get; }
    }
}