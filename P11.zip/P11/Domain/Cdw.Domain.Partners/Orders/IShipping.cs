namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines Shipping
    /// </summary>
    public interface IShipping
    {
        /// <summary>
        /// defines address for shipping
        /// </summary>
        IAddress Address { get; set; }

        /// <summary>
        /// defines Method for shipping
        /// </summary>
        IShippingMethod Method { get; set; }
    }

    /// <summary>
    /// implements shipping
    /// </summary>
    public class Shipping : IShipping
    {
        /// <summary>
        /// holds address
        /// </summary>
        public IAddress Address { get; set; }

        /// <summary>
        /// holds method
        /// </summary>
        public IShippingMethod Method { get; set; }
    }
}