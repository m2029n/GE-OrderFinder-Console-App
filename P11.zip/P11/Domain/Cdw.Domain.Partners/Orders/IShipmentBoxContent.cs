﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IShipmentBoxContent
    /// </summary>
    public interface IShipmentBoxContent
    {
        /// <summary>
        /// defines Description
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// defines EDC
        /// </summary>
        string EDC { get; set; }

        /// <summary>
        /// defines EstimatedQuantity
        /// </summary>
        int? EstimatedQuantity { get; set; }

        /// <summary>
        /// defines ManufacturerPartNumber
        /// </summary>
        string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// defines OrderLineNumber
        /// </summary>
        int? OrderLineNumber { get; set; }

        /// <summary>
        /// defines QuantityInBox
        /// </summary>
        int? QuantityInBox { get; set; }
    }

    /// <summary>
    /// implements ShipmentBoxContent
    /// </summary>
    public class ShipmentBoxContent : IShipmentBoxContent
    {
        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds EDC
        /// </summary>
        public string EDC { get; set; }

        /// <summary>
        /// holds EstimatedQuantity
        /// </summary>
        public int? EstimatedQuantity { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// holds OrderLineNumber
        /// </summary>
        public int? OrderLineNumber { get; set; }

        /// <summary>
        /// holds QuantityInBox
        /// </summary>
        public int? QuantityInBox { get; set; }
    }
}