﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IShipment
    /// </summary>
    public interface IShipment
    {
        /// <summary>
        /// defines InvoiceNumber
        /// </summary>
        string InvoiceNumber { get; }

        /// <summary>
        /// defines Box
        /// </summary>
        int Box { get; }

        /// <summary>
        /// defines ShippedDate
        /// </summary>
        DateTime ShippedDate { get; }

        /// <summary>
        /// defines ShippingMethod
        /// </summary>
        IShippingMethod ShippingMethod { get; }

        /// <summary>
        /// defines TrackingNumber
        /// </summary>
        string TrackingNumber { get; }

        /// <summary>
        /// defines TrackingUrl
        /// </summary>
        string TrackingUrl { get; }

        /// <summary>
        /// defines Weight
        /// </summary>
        decimal Weight { get; }

        /// <summary>
        /// defines Contents
        /// </summary>
        IEnumerable<IShippedItem> Contents { get; }
    }

    /// <summary>
    /// implements Shipment
    /// </summary>
    public class Shipment : IShipment
    {
        /// <summary>
        /// holds Box
        /// </summary>
        public int Box { get; set; }

        /// <summary>
        /// holds Contents
        /// </summary>
        public IEnumerable<IShippedItem> Contents { get; set; }

        /// <summary>
        /// holds InvoiceNumber
        /// </summary>
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// holds ShippedDate
        /// </summary>
        public DateTime ShippedDate { get; set; }

        /// <summary>
        /// holds ShippingMethod
        /// </summary>
        public IShippingMethod ShippingMethod { get; set; }

        /// <summary>
        /// holds TrackingNumber
        /// </summary>
        public string TrackingNumber { get; set; }

        /// <summary>
        /// holds TrackingUrl
        /// </summary>
        public string TrackingUrl { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }
    }
}