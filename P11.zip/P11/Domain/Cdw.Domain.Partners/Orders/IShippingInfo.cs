﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IShippingInfo
    /// </summary>
    public interface IShippingInfo
    {
        /// <summary>
        /// defines Address
        /// </summary>
        IAddress Address { get; }

        /// <summary>
        /// defines Method
        /// </summary>
        IShippingMethod Method { get; }
    }

    /// <summary>
    /// holds ShippingInfo
    /// </summary>
    public class ShippingInfo : IShippingInfo
    {
        /// <summary>
        /// holds Address
        /// </summary>
        public IAddress Address { get; set; }

        /// <summary>
        /// holds Method
        /// </summary>
        public IShippingMethod Method { get; set; }
    }
}