﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ILineItem
    /// </summary>
    public interface ILineItem
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// defines Status
        /// </summary>
        string Status { get; set; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        uint Quantity { get; set; }

        /// <summary>
        /// defines UnitPrice
        /// </summary>
        decimal UnitPrice { get; set; }

        /// <summary>
        /// defines LinePrice
        /// </summary>
        decimal LinePrice { get; set; }

        /// <summary>
        /// defines Discounts
        /// </summary>
        IEnumerable<IDiscount> Discounts { get; set; }

        /// <summary>
        /// defines CustomProperties
        /// </summary>
        IEnumerable<ICustomProperty> CustomProperties { get; set; }

        /// <summary>
        /// defines Shipments
        /// </summary>
        IEnumerable<IShipment> Shipments { get; set; }
    }

    /// <summary>
    /// implements ILineItem
    /// </summary>
    public class LineItem : ILineItem
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
        /// <summary>
        /// holds Status
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// holds Quantity
        /// </summary>
        public uint Quantity { get; set; }
        /// <summary>
        /// holds UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }
        /// <summary>
        /// holds LinePrice
        /// </summary>
        public decimal LinePrice { get; set; }
        /// <summary>
        /// holds Discounts
        /// </summary>
        public IEnumerable<IDiscount> Discounts { get; set; }
        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }
        /// <summary>
        /// holds Shipments
        /// </summary>
        public IEnumerable<IShipment> Shipments { get; set; }
    }
}