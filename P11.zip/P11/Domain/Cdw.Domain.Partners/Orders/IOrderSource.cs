﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderSource
    /// </summary>
    public interface IOrderSource
    {
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }

        /// <summary>
        /// defines FreightRaterSpecialCode
        /// </summary>
        string FreightRaterSpecialCode { get; }
    }

    /// <summary>
    /// implements IOrderSource
    /// </summary>
    public class OrderSource : IOrderSource
    {
        /// <summary>
        /// hold Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// hold FreightRaterSpecialCode
        /// </summary>
        public string FreightRaterSpecialCode { get; set; }
    }
}