﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IResponseBilling
    /// </summary>
    public interface IResponseBilling
    {
        /// <summary>
        /// defines Address
        /// </summary>
        IAddress Address { get; set; }

        /// <summary>
        /// defines Method
        /// </summary>
        IResponsePaymentMethod Method { get; set; }
    }
}