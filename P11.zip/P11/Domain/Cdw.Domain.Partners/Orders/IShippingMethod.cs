﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// interface for ShippingMethod
    /// </summary>
    public interface IShippingMethod
    {
        /// <summary>
        /// for Description
        /// </summary>
        string Description { get; }

        /// <summary>
        /// for Id
        /// </summary>
        string Id { get; }

        /// <summary>
        /// for Rate
        /// </summary>
        IOrderShippingRate Rate { get; }
    }

    /// <summary>
    /// implements IShippingMethod
    /// </summary>
    public class ShippingMethod : IShippingMethod
    {
        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// holds Rate
        /// </summary>
        public IOrderShippingRate Rate { get; set; }
    }
}