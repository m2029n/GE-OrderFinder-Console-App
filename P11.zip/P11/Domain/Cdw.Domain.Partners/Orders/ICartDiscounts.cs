﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines ICartDiscounts
    /// </summary>
    public interface ICartDiscounts
    {
        /// <summary>
        /// defines FixedAmountDiscounts
        /// </summary>
        IList<IDiscount> FixedAmountDiscounts { get; }

        /// <summary>
        /// defines PercentOffDiscounts
        /// </summary>
        IList<IDiscount> PercentOffDiscounts { get; }
    }

    /// <summary>
    /// impelements ICartDiscounts
    /// </summary>
    public class CartDiscounts : ICartDiscounts
    {
        /// <summary>
        /// holds FixedAmountDiscounts
        /// </summary>
        public IList<IDiscount> FixedAmountDiscounts { get; set; }

        /// <summary>
        /// holds PercentOffDiscounts
        /// </summary>
        public IList<IDiscount> PercentOffDiscounts { get; set; }
    }
}