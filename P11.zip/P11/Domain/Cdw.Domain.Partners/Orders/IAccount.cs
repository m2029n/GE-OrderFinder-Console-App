﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IAccount
    /// </summary>
    public interface IAccount
    {
        /// <summary>
        /// defines CustomerNumber
        /// </summary>
        string CustomerNumber { get; }
        /// <summary>
        /// defines EAccount
        /// </summary>
        string EAccount { get; }
        /// <summary>
        /// defines EmailAddress
        /// </summary>
        string EmailAddress { get; }
    }

    /// <summary>
    /// used to identify account sent to order create
    /// </summary>
    public class Account : IAccount
    {
        /// <summary>
        /// used to identify customer by number
        /// </summary>
        public string CustomerNumber { get; set; }
        /// <summary>
        /// electronic account
        /// </summary>
        public string EAccount { get; set; }
        /// <summary>
        /// email address of the account
        /// </summary>
        public string EmailAddress { get; set; }
    }
}