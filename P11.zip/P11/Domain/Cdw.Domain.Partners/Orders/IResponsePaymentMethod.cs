﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IResponsePaymentMethod
    /// </summary>
    public interface IResponsePaymentMethod
    {
        /// <summary>
        /// defines PONumber
        /// </summary>
        string PONumber { get; set; }

        /// <summary>
        /// defines CreditCard
        /// </summary>
        IResponseCreditCard CreditCard { get; set; }
    }
}