﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderItemShippingRate
    /// </summary>
    public interface IOrderItemShippingRate
    {
        /// <summary>
        /// defines BoxHandling
        /// </summary>
        decimal BoxHandling { get; }

        /// <summary>
        /// defines CdwCost
        /// </summary>
        decimal CdwCost { get; }

        /// <summary>
        /// defines Freight
        /// </summary>
        decimal Freight { get; }

        /// <summary>
        /// defines Handling
        /// </summary>
        decimal Handling { get; }

        /// <summary>
        /// defines Insurance
        /// </summary>
        decimal Insurance { get; }

        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// defines Weight
        /// </summary>
        decimal Weight { get; }
    }

    /// <summary>
    /// implements OrderItemShippingRate
    /// </summary>
    public class OrderItemShippingRate : IOrderItemShippingRate
    {
        /// <summary>
        /// holds BoxHandling
        /// </summary>
        public decimal BoxHandling { get; set; }

        /// <summary>
        /// holds BoxHandling
        /// </summary>
        public decimal CdwCost { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }
    }
}