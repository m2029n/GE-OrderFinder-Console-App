﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Common;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrder
    /// </summary>
    public interface IOrder
    {
        /// <summary>
        /// defines Account
        /// </summary>
        IAccount Account { get; }

        /// <summary>
        /// defines Billing
        /// </summary>
        IBillingInfo Billing { get; }

        /// <summary>
        /// defines Cart
        /// </summary>
        ICart Cart { get; }

        /// <summary>
        /// defines Tax
        /// </summary>
        decimal Tax { get; }

        /// <summary>
        /// defines Total
        /// </summary>
        decimal Total { get; }

        /// <summary>
        /// defines OrderNumber
        /// </summary>
        string OrderNumber { get; }

        /// <summary>
        /// defines ReferenceNumber
        /// </summary>
        string ReferenceNumber { get; }

        /// <summary>
        /// defines Shipments
        /// </summary>
        IEnumerable<IShipment> Shipments { get; }

        /// <summary>
        /// defines Shipping
        /// </summary>
        IShippingInfo Shipping { get; }

        /// <summary>
        /// defines Source
        /// </summary>
        IOrderSource Source { get; }

        /// <summary>
        /// defines Status
        /// </summary>
        OrderStatus Status { get; }

        /// <summary>
        /// defines Taxes
        /// </summary>
        IEnumerable<ITax> Taxes { get; }

        /// <summary>
        /// defines RecyclingFees
        /// </summary>
        IEnumerable<IRecyclingFee> RecyclingFees { get; }

        /// <summary>
        /// defines RecyclingFee
        /// </summary>
        decimal RecyclingFee { get; }

        /// <summary>
        /// defines TransactionDate
        /// </summary>
        DateTime TransactionDate { get; }

        /// <summary>
        /// defines TrackingValues
        /// </summary>
        ITrackingValues TrackingValues { get; }

        /// <summary>
        /// defines Company to be used for the order
        /// </summary>
        int Company { get; set; }
    }

    /// <summary>
    /// implements IOrder
    /// </summary>
    public class Order : IOrder
    {
        /// <summary>
        /// holds Account
        /// </summary>
        public IAccount Account { get; set; }

        /// <summary>
        /// holds Billing
        /// </summary>
        public IBillingInfo Billing { get; set; }

        /// <summary>
        /// holds Cart
        /// </summary>
        public ICart Cart { get; set; }

        /// <summary>
        /// culculates Tax
        /// </summary>
        public decimal Tax
        {
            get { return Math.Max(0, Taxes.Sum(t => t.Amount)); }
        }

        /// <summary>
        /// holds Total
        /// </summary>
        public decimal Total { get; set; }

        /// <summary>
        /// holds OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// holds ReferenceNumber
        /// </summary>
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// holds Shipments
        /// </summary>
        public IEnumerable<IShipment> Shipments { get; set; }

        /// <summary>
        /// holds Shipping
        /// </summary>
        public IShippingInfo Shipping { get; set; }

        /// <summary>
        /// holds Source
        /// </summary>
        public IOrderSource Source { get; set; }

        /// <summary>
        /// holds Status
        /// </summary>
        public OrderStatus Status { get; set; }

        /// <summary>
        /// holds Taxes
        /// </summary>
        public IEnumerable<ITax> Taxes { get; set; }

        /// <summary>
        /// holds RecyclingFees
        /// </summary>
        public IEnumerable<IRecyclingFee> RecyclingFees { get; set; }

        /// <summary>
        /// holds RecyclingFee
        /// </summary>
        public decimal RecyclingFee { get; set; }

        /// <summary>
        /// holds TransactionDate
        /// </summary>
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }

        /// <summary>
        /// holds Company from partner settings
        /// </summary>
        public int Company { get; set; }
    }
}