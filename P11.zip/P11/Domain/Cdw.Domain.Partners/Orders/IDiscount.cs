﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IDiscount
    /// </summary>
    public interface IDiscount
    {
        /// <summary>
        /// defines Id
        /// </summary>
        string Id { get; }
        /// <summary>
        /// defines Type
        /// </summary>
        int Type { get; set; }
        /// <summary>
        /// defines Amount
        /// </summary>
        decimal Amount { get; }
    }

    /// <summary>
    /// implements IDiscount
    /// </summary>
    public class Discount : IDiscount
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// holds Type
        /// </summary>
        public int Type { get; set; }
    }
}