﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// Payment Method interface.
    /// </summary>
    public interface IPaymentMethod
    {
        /// <summary>
        /// Encrypted Credit Card string provided by Partner.
        /// </summary>
        string EncryptedCreditCard { get; set; }

        /// <summary>
        /// Credit Card object.
        /// </summary>
        ICreditCard CreditCard { get; }

        /// <summary>
        /// PO Number provided by Partner.
        /// </summary>
        string PONumber { get; }

        /// <summary>
        /// Payment Terms provided by eligible Partner.
        /// </summary>
        string Terms { get; set; }

        /// <summary>
        /// Transaction Id provided by Partner during _authorize credit card workflow.
        /// </summary>
        string TransactionId { get; set; }

        /// <summary>
        /// Reference Number provided to Partner - associated with internal credit card mapping.
        /// </summary>
        string ReferenceNumber { get; set; }
    }

    /// <summary>
    /// Payment Method implementaion.
    /// </summary>
    public class PaymentMethod : IPaymentMethod
    {
        /// <summary>
        /// Encrypted Credit Card string provided by Partner.
        /// </summary>
        public string EncryptedCreditCard { get; set; }

        /// <summary>
        /// Credit Card object.
        /// </summary>
        public ICreditCard CreditCard { get; set; }

        /// <summary>
        /// PO Number provided by Partner.
        /// </summary>
        public string PONumber { get; set; }

        /// <summary>
        /// Payment Terms provided by eligible Partner.
        /// </summary>
        public string Terms { get; set; }

        /// <summary>
        /// Transaction Id provided by Partner during _authorize credit card workflow.
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// Reference Number provided to Partner - associated with internal credit card mapping.
        /// </summary>
        public string ReferenceNumber { get; set; }
    }
}