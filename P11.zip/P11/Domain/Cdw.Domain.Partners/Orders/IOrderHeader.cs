﻿using System;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderHeader
    /// </summary>
    public interface IOrderHeader
    {
        /// <summary>
        /// defines InvoicedItemCount
        /// </summary>
        int InvoicedItemCount { get; set; }
        /// <summary>
        /// defines BillingAddress
        /// </summary>
        IAddress BillingAddress { get; set; }
        /// <summary>
        /// defines ShippingAddress
        /// </summary>
        IAddress ShippingAddress { get; set; }
        /// <summary>
        /// defines CompanyCode
        /// </summary>
        string CompanyCode { get; set; }
        /// <summary>
        /// defines CustomerNumber
        /// </summary>
        string CustomerNumber { get; set; }
        /// <summary>
        /// defines OrderCode
        /// </summary>
        string OrderCode { get; set; }
        /// <summary>
        /// defines OrderDate
        /// </summary>
        DateTime OrderDate { get; set; }
        /// <summary>
        /// defines PoNumber
        /// </summary>
        string PoNumber { get; set; }
        /// <summary>
        /// defines ContactSequence
        /// </summary>
        int ContactSequence { get; set; }
        /// <summary>
        /// defines SubTotal
        /// </summary>
        decimal SubTotal { get; set; }
        /// <summary>
        /// defines StatusCode
        /// </summary>
        string StatusCode { get; set; }
        /// <summary>
        /// defines SuspendCode
        /// </summary>
        string SuspendCode { get; set; }
        /// <summary>
        /// defines ShippingCarrierCode
        /// </summary>
        string ShippingCarrierCode { get; set; }
        /// <summary>
        /// defines ShippingCarrier
        /// </summary>
        string ShippingCarrier { get; set; }
        /// <summary>
        /// defines OrderValue
        /// </summary>
        decimal OrderValue { get; set; }
        /// <summary>
        /// defines QuoteNumber
        /// </summary>
        string QuoteNumber { get; set; }
        /// <summary>
        /// defines FreightTotal
        /// </summary>
        decimal FreightTotal { get; set; }
        /// <summary>
        /// defines PaymentType
        /// </summary>
        string PaymentType { get; set; }
        /// <summary>
        /// defines NumberOfBoxes
        /// </summary>
        int NumberOfBoxes { get; set; }
        /// <summary>
        /// defines IsLease
        /// </summary>
        bool IsLease { get; set; }
        /// <summary>
        /// defines IOrderHeader
        /// </summary>
        OrderStatus OrderStatus { get; set; }
        /// <summary>
        /// defines PaymentCode
        /// </summary>
        string PaymentCode { get; set; }
        /// <summary>
        /// defines PaymentMethodName
        /// </summary>
        string PaymentMethodName { get; set; }
    }

    /// <summary>
    /// implements OrderHeader
    /// </summary>
    public class OrderHeader : IOrderHeader
    {
        /// <summary>
        /// holds InvoicedItemCount
        /// </summary>
        public int InvoicedItemCount { get; set; }
        /// <summary>
        /// holds BillingAddress
        /// </summary>
        public IAddress BillingAddress { get; set; }
        /// <summary>
        /// holds ShippingAddress
        /// </summary>
        public IAddress ShippingAddress { get; set; }
        /// <summary>
        /// holds CompanyCode
        /// </summary>
        public string CompanyCode { get; set; }
        /// <summary>
        /// holds CustomerNumber
        /// </summary>
        public string CustomerNumber { get; set; }
        /// <summary>
        /// holds OrderCode
        /// </summary>
        public string OrderCode { get; set; }
        /// <summary>
        /// holds OrderDate
        /// </summary>
        public DateTime OrderDate { get; set; }
        /// <summary>
        /// holds PoNumber
        /// </summary>
        public string PoNumber { get; set; }
        /// <summary>
        /// holds ContactSequence
        /// </summary>
        public int ContactSequence { get; set; }
        /// <summary>
        /// holds SubTotal
        /// </summary>
        public decimal SubTotal { get; set; }
        /// <summary>
        /// holds StatusCode
        /// </summary>
        public string StatusCode { get; set; }
        /// <summary>
        /// holds SuspendCode
        /// </summary>
        public string SuspendCode { get; set; }
        /// <summary>
        /// holds ShippingCarrierCode
        /// </summary>
        public string ShippingCarrierCode { get; set; }
        /// <summary>
        /// holds ShippingCarrier
        /// </summary>
        public string ShippingCarrier { get; set; }
        /// <summary>
        /// holds OrderValue
        /// </summary>
        public decimal OrderValue { get; set; }
        /// <summary>
        /// holds QuoteNumber
        /// </summary>
        public string QuoteNumber { get; set; }
        /// <summary>
        /// holds FreightTotal
        /// </summary>
        public decimal FreightTotal { get; set; }
        /// <summary>
        /// holds PaymentType
        /// </summary>
        public string PaymentType { get; set; }
        /// <summary>
        /// holds NumberOfBoxes
        /// </summary>
        public int NumberOfBoxes { get; set; }
        /// <summary>
        /// holds IsLease
        /// </summary>
        public bool IsLease { get; set; }
        /// <summary>
        /// holds OrderStatus
        /// </summary>
        public OrderStatus OrderStatus { get; set; }
        /// <summary>
        /// holds PaymentCode
        /// </summary>
        public string PaymentCode { get; set; }
        /// <summary>
        /// holds PaymentMethodName
        /// </summary>
        public string PaymentMethodName { get; set; }
    }
}