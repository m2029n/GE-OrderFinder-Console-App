﻿using Cdw.Domain.Partners.Common;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IIdentity
    /// </summary>
    public interface IIdentity
    {
        /// <summary>
        /// defines ClientId
        /// </summary>
        int ClientId { get; set; }

        /// <summary>
        /// defines ClientName
        /// </summary>
        string ClientName { get; set; }

        /// <summary>
        /// defines SourceCode
        /// </summary>
        string SourceCode { get; set; }

        /// <summary>
        /// defines FreightRaterSpecialCode
        /// </summary>
        string FreightRaterSpecialCode { get; set; }

        /// <summary>
        /// defines Partner
        /// </summary>
        Partner? Partner { get; set; }

        /// <summary>
        /// defines CompanyCode
        /// </summary>
        int CompanyCode { get; set; }
    }
}