﻿using System.Threading.Tasks;
using Cdw.Common;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderManager
    /// </summary>
    public interface IOrderManager
    {
        /// <summary>
        /// defines GetOrderAsync
        /// </summary>
        /// <param name="code"></param>
        /// <param name="trackingValues"></param>
        /// <param name="clientName"></param>
        /// <returns></returns>
        Task<IOrder> GetOrderAsync(string code, ITrackingValues trackingValues, string clientName);

        /// <summary>
        /// defines CreateOrderAsync
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<IOrder> CreateOrderAsync(IRequestOrder model);

        /// <summary>
        /// defines SearchOrderAsync
        /// </summary>
        /// <param name="customerNumber"></param>
        /// <param name="poNumber"></param>
        /// <param name="trackingValues"></param>
        /// <returns></returns>
        Task<IOrderDetails> SearchOrderAsync(string customerNumber, string poNumber, ITrackingValues trackingValues);
    }
}