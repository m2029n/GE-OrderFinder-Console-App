﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IRecyclingFee
    /// </summary>
    public interface IRecyclingFee
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }
        /// <summary>
        /// defines Amount
        /// </summary>
        decimal Amount { get; }
        /// <summary>
        /// defines Description
        /// </summary>
        string Description { get; }
        /// <summary>
        /// defines Code
        /// </summary>
        string Code { get; }
        /// <summary>
        /// defines ProductFeeEDC
        /// </summary>
        string ProductFeeEDC { get; }
    }

    /// <summary>
    /// implements RecyclingFee
    /// </summary>
    public class RecyclingFee : IRecyclingFee
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// holds Code
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// holds ProductFeeEDC
        /// </summary>
        public string ProductFeeEDC { get; set; }
    }
}