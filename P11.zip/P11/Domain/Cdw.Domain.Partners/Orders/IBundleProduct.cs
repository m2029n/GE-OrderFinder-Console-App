﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IBundleProduct
    /// </summary>
    public interface IBundleProduct
    {
        /// <summary>
        /// defines Product
        /// </summary>
        IProduct Product { get; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; }
    }

    /// <summary>
    /// implements IBundleProduct
    /// </summary>
    public class BundleProduct : IBundleProduct
    {
        /// <summary>
        /// holds Product
        /// </summary>
        public IProduct Product { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }
    }
}