﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderDetails
    /// </summary>
    public interface IOrderDetails
    {
        /// <summary>
        /// defines Header
        /// </summary>
        IOrderHeader Header { get; }

        /// <summary>
        /// defines LineItems
        /// </summary>
        IEnumerable<IOrderLineItem> LineItems { get; }

        /// <summary>
        /// defines Shipments
        /// </summary>
        IEnumerable<IShipmentBox> Shipments { get; }
    }

    /// <summary>
    /// implements OrderDetails
    /// </summary>
    public class OrderDetails : IOrderDetails
    {
        /// <summary>
        /// holds Header
        /// </summary>
        public IOrderHeader Header { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public IEnumerable<IOrderLineItem> LineItems { get; set; }

        /// <summary>
        /// holds Shipments
        /// </summary>
        public IEnumerable<IShipmentBox> Shipments { get; set; }
    }
}