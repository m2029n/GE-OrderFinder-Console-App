﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IResponseOrder
    /// </summary>
    public interface IResponseOrder
    {
        /// <summary>
        /// defines OrderNumber
        /// </summary>
        string OrderNumber { get; set; }

        /// <summary>
        /// defines Status
        /// </summary>
        string Status { get; set; }

        /// <summary>
        /// defines TransactionDate
        /// </summary>
        DateTime TransactionDate { get; set; }

        /// <summary>
        /// defines Company
        /// </summary>
        int Company { get; set; }

        /// <summary>
        /// defines ReferenceNumber
        /// </summary>
        string ReferenceNumber { get; set; }

        /// <summary>
        /// defines Account
        /// </summary>
        IAccount Account { get; set; }

        /// <summary>
        /// defines Subtotal
        /// </summary>
        decimal Subtotal { get; set; }

        /// <summary>
        /// defines Discount
        /// </summary>
        decimal Discount { get; set; }

        /// <summary>
        /// defines Taxes
        /// </summary>
        IEnumerable<ITax> Taxes { get; set; }

        /// <summary>
        /// defines Freight
        /// </summary>
        decimal Freight { get; set; }

        /// <summary>
        /// defines Handling
        /// </summary>
        decimal Handling { get; set; }

        /// <summary>
        /// defines Insurance
        /// </summary>
        decimal Insurance { get; set; }

        /// <summary>
        /// defines Tax
        /// </summary>
        decimal Tax { get; set; }

        /// <summary>
        /// defines Total
        /// </summary>
        decimal Total { get; set; }

        /// <summary>
        /// defines Discounts
        /// </summary>
        IEnumerable<IDiscount> Discounts { get; set; }

        /// <summary>
        /// defines Billing
        /// </summary>
        IResponseBilling Billing { get; set; }

        /// <summary>
        /// defines Shipping
        /// </summary>
        IShipping Shipping { get; set; }

        /// <summary>
        /// defines LineItems
        /// </summary>
        IEnumerable<ILineItem> LineItems { get; set; }

        /// <summary>
        /// defines CustomProperties
        /// </summary>
        IEnumerable<ICustomProperty> CustomProperties { get; set; }
    }

    /// <summary>
    /// implements ResponseOrder
    /// </summary>
    public class ResponseOrder : IResponseOrder
    {
        /// <summary>
        /// holds Company
        /// </summary>
        public int Company { get; set; }

        /// <summary>
        /// hold Subtotal
        /// </summary>
        public decimal Subtotal { get; set; }

        /// <summary>
        /// holds Discount
        /// </summary>
        public decimal Discount { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds Discounts
        /// </summary>
        public IEnumerable<IDiscount> Discounts { get; set; }

        /// <summary>
        /// holds Billing
        /// </summary>
        public IResponseBilling Billing { get; set; }

        /// <summary>
        /// holds Shipping
        /// </summary>
        public IShipping Shipping { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public IEnumerable<ILineItem> LineItems { get; set; }

        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }

        /// <summary>
        /// holds OrderNumber
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// holds Status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// holds TransactionDate
        /// </summary>
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// holds ReferenceNumber
        /// </summary>
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// holds Account
        /// </summary>
        public IAccount Account { get; set; }

        /// <summary>
        /// holds Taxes
        /// </summary>
        public IEnumerable<ITax> Taxes { get; set; }

        /// <summary>
        /// holds Tax
        /// </summary>
        public decimal Tax { get; set; }

        /// <summary>
        /// holds Total
        /// </summary>
        public decimal Total { get; set; }
    }
}