﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// enum for payment mathods
    /// </summary>
    public enum PaymentMethodType
    {
        /// <summary>
        /// when not used
        /// </summary>
        Unknown = 1,

        /// <summary>
        /// AX
        /// </summary>
        AmericanExpress = 1001,

        /// <summary>
        /// Disc
        /// </summary>
        DiscoverNetwork = 1002,

        /// <summary>
        /// VISA
        /// </summary>
        Visa = 1003,

        /// <summary>
        /// MC
        /// </summary>
        MasterCard = 1004,

        /// <summary>
        /// Dinner Club
        /// </summary>
        DinersClub = 1011
    }
}