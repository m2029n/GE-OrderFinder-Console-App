﻿namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IAddress
    /// </summary>
    public interface IAddress
    {
        /// <summary>
        /// defines MiddleInitial
        /// </summary>
        string MiddleInitial { get; set; }
        /// <summary>
        /// defines ContactName
        /// </summary>
        string ContactName { get; set; }
        /// <summary>
        /// defines AttentionName
        /// </summary>
        string AttentionName { get; set; }
        /// <summary>
        /// defines FirstName
        /// </summary>
        string FirstName { get; set; }
        /// <summary>
        /// defines LastName
        /// </summary>
        string LastName { get; set; }
        /// <summary>
        /// defines PhoneNumber
        /// </summary>
        string PhoneNumber { get; set; }
        /// <summary>
        /// defines Company
        /// </summary>
        string Company { get; set; }
        /// <summary>
        /// defines StreetAddress
        /// </summary>
        string StreetAddress { get; set; }
        /// <summary>
        /// defines SecondaryStreetAddress
        /// </summary>
        string SecondaryStreetAddress { get; set; }
        /// <summary>
        /// defines City
        /// </summary>
        string City { get; set; }
        /// <summary>
        /// defines State
        /// </summary>
        string State { get; set; }
        /// <summary>
        /// defines PostalCode
        /// </summary>
        string PostalCode { get; set; }
        /// <summary>
        /// defines IsoCountryCode
        /// </summary>
        string IsoCountryCode { get; set; }
    }
    /// <summary>
    /// used to send address
    /// </summary>
    public class Address : IAddress
    {
        /// <summary>
        /// holds MiddleInitial
        /// </summary>
        public string MiddleInitial { get; set; }
        /// <summary>
        /// holds ContactName
        /// </summary>
        public string ContactName { get; set; }
        /// <summary>
        /// holds AttentionName
        /// </summary>
        public string AttentionName { get; set; }
        /// <summary>
        /// holds FirstName
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// holds LastName
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// holds PhoneNumber
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// holds Company
        /// </summary>
        public string Company { get; set; }
        /// <summary>
        /// holds StreetAddress
        /// </summary>
        public string StreetAddress { get; set; }
        /// <summary>
        /// holds SecondaryStreetAddress
        /// </summary>
        public string SecondaryStreetAddress { get; set; }
        /// <summary>
        /// holds City
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// holds State
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// holds PostalCode
        /// </summary>
        public string PostalCode { get; set; }
        /// <summary>
        /// holds IsoCountryCode
        /// </summary>
        public string IsoCountryCode { get; set; }
    }
}