﻿using System;
using System.Collections.Generic;

namespace Cdw.Domain.Partners.Orders
{
    /// <summary>
    /// defines IOrderShippingRate
    /// </summary>
    public interface IOrderShippingRate
    {
        /// <summary>
        /// defines ShippingMethodId
        /// </summary>
        string ShippingMethodId { get; }

        /// <summary>
        /// defines ShippingMethodDescription
        /// </summary>
        string ShippingMethodDescription { get; }

        /// <summary>
        /// defines BoxCount
        /// </summary>
        int BoxCount { get; }

        /// <summary>
        /// defines BoxHandlingCharge
        /// </summary>
        decimal BoxHandlingCharge { get; }

        /// <summary>
        /// defines FreightCost
        /// </summary>
        decimal FreightCost { get; }

        /// <summary>
        /// defines Freight
        /// </summary>
        decimal Freight { get; }

        /// <summary>
        /// defines Handling
        /// </summary>
        decimal Handling { get; }

        /// <summary>
        /// defines Insurance
        /// </summary>
        decimal Insurance { get; }

        /// <summary>
        /// defines OrderItems
        /// </summary>
        IEnumerable<IOrderItemShippingRate> OrderItems { get; }

        /// <summary>
        /// defines TotalShippingCharge
        /// </summary>
        decimal TotalShippingCharge { get; }

        /// <summary>
        /// defines TotalWeight
        /// </summary>
        decimal TotalWeight { get; }

        /// <summary>
        /// defines TransactionGUID
        /// </summary>
        Guid TransactionGUID { get; }
    }

    /// <summary>
    /// implements IOrderShippingRate
    /// </summary>
    public class OrderShippingRate : IOrderShippingRate
    {
        /// <summary>
        /// holds ShippingMethodId
        /// </summary>
        public string ShippingMethodId { get; set; }

        /// <summary>
        /// holds ShippingMethodDescription
        /// </summary>
        public string ShippingMethodDescription { get; set; }

        /// <summary>
        /// holds BoxCount
        /// </summary>
        public int BoxCount { get; set; }

        /// <summary>
        /// holds BoxHandlingCharge
        /// </summary>
        public decimal BoxHandlingCharge { get; set; }

        /// <summary>
        /// holds FreightCost
        /// </summary>
        public decimal FreightCost { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }

        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }

        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }

        /// <summary>
        /// holds OrderItems
        /// </summary>
        public IEnumerable<IOrderItemShippingRate> OrderItems { get; set; }

        /// <summary>
        /// holds TotalShippingCharge
        /// </summary>
        public decimal TotalShippingCharge { get; set; }

        /// <summary>
        /// holds TotalWeight
        /// </summary>
        public decimal TotalWeight { get; set; }

        /// <summary>
        /// holds TransactionGUID
        /// </summary>
        public Guid TransactionGUID { get; set; }
    }
}