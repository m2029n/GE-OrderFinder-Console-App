﻿using System;
using System.Threading.Tasks;
using Cdw.Services.Core;

namespace Cdw.Domain.Partners.PartnerCart
{
    /// <summary>
    /// extends IHealthCheck for IPartnerCartRequestDomainManager
    /// </summary>
    public interface IPartnerCartRequestDomainManager : IHealthCheck
    {
        /// <summary>
        /// Obsolete
        /// </summary>
        /// <param name="partnerCartRequest"></param>
        /// <returns></returns>
        [Obsolete("Use Async version instead.")]
        IPartnerCartRequest Create(IPartnerCartRequest partnerCartRequest);

        /// <summary>
        /// defines CreateAsync
        /// </summary>
        /// <param name="partnerCartRequest"></param>
        /// <returns></returns>
        Task<IPartnerCartRequest> CreateAsync(IPartnerCartRequest partnerCartRequest);
    }
}