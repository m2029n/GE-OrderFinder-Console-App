﻿using System;
using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.PartnerCart
{
    /// <summary>
    /// defines IPartnerCartRequest
    /// </summary>
    public interface IPartnerCartRequest
    {
        /// <summary>
        /// defines Id
        /// </summary>
        int Id { get; }

        /// <summary>
        /// defines Source
        /// </summary>
        string Source { get; }

        /// <summary>
        /// defines CorrelationId
        /// </summary>
        string CorrelationId { get; }

        /// <summary>
        /// defines CartUrl
        /// </summary>
        string CartUrl { get; }

        /// <summary>
        /// defines WebSiteId
        /// </summary>
        int WebSiteId { get; }

        /// <summary>
        /// defines Created
        /// </summary>
        DateTime Created { get; }

        /// <summary>
        /// defines LineItems
        /// </summary>
        IEnumerable<IPartnerCartRequestItem> LineItems { get; }

        /// <summary>
        /// defines TrackingValues
        /// </summary>
        ITrackingValues TrackingValues { get; }
    }
}