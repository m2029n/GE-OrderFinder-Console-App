﻿namespace Cdw.Domain.Partners.PartnerCart
{
    /// <summary>
    /// implements PartnerCartRequestItem
    /// </summary>
    public class PartnerCartRequestItem : IPartnerCartRequestItem
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// holds Manufacturer
        /// </summary>
        public string Manufacturer { get; set; }

        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }
    }
}