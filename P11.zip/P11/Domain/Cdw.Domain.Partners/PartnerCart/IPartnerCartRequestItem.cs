﻿namespace Cdw.Domain.Partners.PartnerCart
{
    /// <summary>
    /// defines IPartnerCartRequestItem
    /// </summary>
    public interface IPartnerCartRequestItem
    {
        /// <summary>
        /// defines Id
        /// </summary>
        int Id { get; }

        /// <summary>
        /// defines Manufacturer
        /// </summary>
        string Manufacturer { get; }

        /// <summary>
        /// defines ManufacturerPartNumber
        /// </summary>
        string ManufacturerPartNumber { get; }

        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; }
    }
}