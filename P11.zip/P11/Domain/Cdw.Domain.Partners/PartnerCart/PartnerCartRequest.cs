using System;
using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.PartnerCart
{
    /// <summary>
    /// implements PartnerCartRequest
    /// </summary>
    public class PartnerCartRequest : IPartnerCartRequest
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// holds Source
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// holds CorrelationId
        /// </summary>
        public string CorrelationId { get; set; }

        /// <summary>
        /// holds CartUrl
        /// </summary>
        public string CartUrl { get; set; }

        /// <summary>
        /// holds WebSiteId
        /// </summary>
        public int WebSiteId { get; set; }

        /// <summary>
        /// holds Created
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public IEnumerable<IPartnerCartRequestItem> LineItems { get; set; }

        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }
    }
}