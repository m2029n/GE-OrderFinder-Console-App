﻿using System.ComponentModel;

namespace Cdw.Domain.Partners.Common
{
    /// <summary>
    /// Partner Enums
    /// TODO: Start using the settings file
    /// </summary>
    public enum Partner
    {
        /// <summary>
        /// Def Partner
        /// </summary>
        [Description("Default Partner")]
        DefaultPartner,

        /// <summary>
        /// XeroxDirect
        /// </summary>
        [Description("Xerox Direct")]
        XeroxDirect,

        /// <summary>
        /// XeroxCanada
        /// </summary>
        [Description("Xerox Canada")]
        XeroxCanada,

        /// <summary>
        /// Adobe
        /// </summary>
        [Description("Adobe")]
        Adobe,

        /// <summary>
        /// BlackBox
        /// </summary>
        [Description("Black Box")]
        BlackBox
    }

    /// <summary>
    /// used to hold partners data
    /// </summary>
    public class XeroxDirect
    {
        /// <summary>
        /// holds ClientName
        /// </summary>
        public string ClientName => "Xerox Direct";

        /// <summary>
        /// patner object
        /// </summary>
        public Partner Partner => Partner.XeroxDirect;

        /// <summary>
        /// prtners companyCode
        /// </summary>
        public int CompanyCode => (int)CdwCompany.CDW;

        /// <summary>
        /// holds SourceCode
        /// </summary>
        public string SourceCode => "XDR";

        /// <summary>
        /// holds clientId
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// holds FreightRaterSpecialCode
        /// </summary>
        public string FreightRaterSpecialCode { get; set; }
    }
}