﻿using System.ComponentModel;

namespace Cdw.Domain.Partners.Common
{
    /// <summary>
    /// CDW Internal Company Codes
    /// </summary>
    public enum CdwCompany
    {
        /// <summary>
        /// CDW US.  Used for cdw.com
        /// </summary>
        [Description("01")]
        CDW = 1000,

        /// <summary>
        /// CDW Government.  Used for cdwg.com
        /// </summary>
        [Description("02")]
        CDWG = 1006,

        /// <summary>
        /// CDW Canada.  Used for cdw.ca
        /// </summary>
        [Description("17")]
        CDWCa = 1012
    }
}