﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Api.Partners.Model.Recycling;
using Cdw.Services.Core;

namespace Cdw.Domain.Partners.Recycling
{
    /// <summary>
    /// implements IHealthCheck
    /// </summary>
    public interface IRecyclingDomainManager : IHealthCheck
    {
        /// <summary>
        /// defines GetRecyclingFeesAsync
        /// </summary>
        /// <param name="recycleFeeRequest"></param>
        /// <returns></returns>
        Task<IEnumerable<IRecyclingFeeModel>> GetRecyclingFeesAsync(RecyclingFeeRequestModel recycleFeeRequest);

        /// <summary>
        /// defines GetRecyclingFeeSummaryAsync
        /// </summary>
        /// <param name="recycleFeeRequest"></param>
        /// <returns></returns>
        Task<IRecyclingFeeSummaryModel> GetRecyclingFeeSummaryAsync(RecyclingFeeRequestModel recycleFeeRequest);
    }
}