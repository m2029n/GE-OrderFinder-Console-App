﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// A collection of shipping methods with details
    /// </summary>
    public interface IRatedFreightDetail
    {
        /// <summary>
        /// The CDW product code uniquely identifying a product for which freight has been requested
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// Item line number order Eg: 1 for first product 2 for second product
        /// </summary>
        int OrderLineNumber { get; }

        /// <summary>
        /// Weight of product???
        /// </summary>
        decimal Weight { get; }

        /// <summary>
        /// A collection of shipping method details
        /// </summary>
        IEnumerable<IRatedFreightDetailShippingMethod> ShippingMethods { get; }
    }
}