﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// enumb for SalesChannelShipMethodFilter
    /// </summary>
    public enum SalesChannelShipMethodFilter
    {
        /// <summary>
        /// defines all methods
        /// </summary>
        All,

        /// <summary>
        /// defines SpecialsOnly
        /// </summary>
        SpecialsOnly
    }
}