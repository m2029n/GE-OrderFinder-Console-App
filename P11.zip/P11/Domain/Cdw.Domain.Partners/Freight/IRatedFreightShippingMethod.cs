﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// A Collection of shipping methods
    /// </summary>
    public interface IRatedFreightShippingMethod
    {
        /// <summary>
        /// Code that identifies the shipping method
        /// </summary>
        string Code { get; }

        /// <summary>
        ///
        /// </summary>
        string SpecialCode { get; }

        /// <summary>
        /// Name of shipping method returned
        /// </summary>
        string Name { get; }

        /// <summary>
        /// A description or title of the shipping method
        /// </summary>
        string Description { get; }

        /// <summary>
        ///
        /// </summary>
        string EstimatedArrival { get; }

        /// <summary>
        ///
        /// </summary>
        bool IsCustomerAccount { get; }

        /// <summary>
        ///
        /// </summary>
        string WeightType { get; }

        /// <summary>
        /// Total weight of product???
        /// </summary>
        decimal TotalWeight { get; }

        /// <summary>
        ///
        /// </summary>
        decimal Cost { get; }

        /// <summary>
        ///
        /// </summary>
        ContractFreightType ContractFreightTypesApplied { get; }

        /// <summary>
        ///
        /// </summary>
        decimal FreightCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal OtherCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal SaturdayCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal OrderHandlingCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal BoxHandlingCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal InsuranceCharge { get; }

        /// <summary>
        /// Combined dollar amount of all the charges included
        /// </summary>
        decimal TotalCharge { get; }

        /// <summary>
        ///
        /// </summary>
        string TransitBusinessDays { get; }
    }
}