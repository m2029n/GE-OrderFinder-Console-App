﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// A collection of shipping method details
    /// </summary>
    public interface IRatedFreightDetailShippingMethod
    {
        /// <summary>
        /// Code that identifies the shipping method
        /// </summary>
        string Code { get; }

        /// <summary>
        ///
        /// </summary>
        string DropShipMethodCode { get; }

        /// <summary>
        ///
        /// </summary>
        decimal Cost { get; }

        /// <summary>
        ///
        /// </summary>
        ContractFreightType ContractFreightTypesApplied { get; }

        /// <summary>
        ///
        /// </summary>
        decimal TotalCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal SaturdayCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal OtherCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal BoxHandlingCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal OrderHandlingCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal InsuranceCharge { get; }

        /// <summary>
        ///
        /// </summary>
        decimal FreightCharge { get; }
    }
}