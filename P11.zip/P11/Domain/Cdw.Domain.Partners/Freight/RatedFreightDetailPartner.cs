﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// implements RatedFreightDetailPartner
    /// </summary>
    public class RatedFreightDetailPartner : IRatedFreightDetail
    {
        /// <summary>
        /// holds OrderLineNumber
        /// </summary>
        public int OrderLineNumber { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds ShippingMethods
        /// </summary>
        public IEnumerable<IRatedFreightDetailShippingMethod> ShippingMethods { get; set; }

        /// <summary>
        /// holds Weight
        /// </summary>
        public decimal Weight { get; set; }
    }
}