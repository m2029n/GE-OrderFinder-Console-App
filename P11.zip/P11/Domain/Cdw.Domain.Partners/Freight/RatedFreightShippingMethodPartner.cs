﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// implements RatedFreightShippingMethodPartner
    /// </summary>
    public class RatedFreightShippingMethodPartner : IRatedFreightShippingMethod
    {
        /// <summary>
        /// holds BoxHandlingCharge
        /// </summary>
        public decimal BoxHandlingCharge { get; set; }

        /// <summary>
        /// holds Code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// holds ContractFreightTypesApplied
        /// </summary>
        public ContractFreightType ContractFreightTypesApplied { get; set; }

        /// <summary>
        /// holds Cost
        /// </summary>
        public decimal Cost { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds EstimatedArrival
        /// </summary>
        public string EstimatedArrival { get; set; }

        /// <summary>
        /// holds FreightCharge
        /// </summary>
        public decimal FreightCharge { get; set; }

        /// <summary>
        /// holds InsuranceCharge
        /// </summary>
        public decimal InsuranceCharge { get; set; }

        /// <summary>
        /// holds IsCustomerAccount
        /// </summary>
        public bool IsCustomerAccount { get; set; }

        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// holds OrderHandlingCharge
        /// </summary>
        public decimal OrderHandlingCharge { get; set; }

        /// <summary>
        /// holds OtherCharge
        /// </summary>
        public decimal OtherCharge { get; set; }

        /// <summary>
        /// holds SaturdayCharge
        /// </summary>
        public decimal SaturdayCharge { get; set; }

        /// <summary>
        /// holds SpecialCode
        /// </summary>
        public string SpecialCode { get; set; }

        /// <summary>
        /// holds TotalCharge
        /// </summary>
        public decimal TotalCharge { get; set; }

        /// <summary>
        /// holds TransitBusinessDays
        /// </summary>
        public string TransitBusinessDays { get; set; }

        /// <summary>
        /// holds TotalWeight
        /// </summary>
        public decimal TotalWeight { get; set; }

        /// <summary>
        /// holds WeightType
        /// </summary>
        public string WeightType { get; set; }

        /// <summary>
        /// holds DropShipMethodCode
        /// </summary>
        public string DropShipMethodCode { get; set; }  // TODO: SMM 3/19 - this property has no source 
    }
}