﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// Freight response object
    /// </summary>
    public interface IRatingResponse
    {
        /// <summary>
        /// The error message, if any, for the request
        /// </summary>
        string ErrorMessage { get; }

        /// <summary>
        ///
        /// </summary>
        string TransactionIdentifier { get; }

        /// <summary>
        ///
        /// </summary>
        int PackageCount { get; }

        /// <summary>
        /// Freight response object with shipping methods
        /// </summary>
        IRatedFreight Freight { get; }
    }
}