﻿using System;
using System.Threading.Tasks;
using Cdw.Api.Partners.Model.Freight;
using Cdw.Common;
using Cdw.Services.Core;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// extends IHealthCheck
    /// </summary>
    public interface IFreightDomainManager : IHealthCheck
    {
        /// <summary>
        /// defines RateAsync
        /// </summary>
        /// <param name="clientName">The name of the client making the request</param>
        /// <param name="request"></param>
        /// <param name="trackingValues"></param>
        /// <returns></returns>
        Task<IRatingResponse> RateAsync(string clientName, RatingRequestModel request, ITrackingValues trackingValues);
    }
}