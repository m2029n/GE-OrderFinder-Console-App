﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// implements RatingResponsePartner
    /// </summary>
    public class RatingResponsePartner : IRatingResponse
    {
        /// <summary>
        /// holds ErrorMessage
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// holds Freight
        /// </summary>
        public IRatedFreight Freight { get; set; }

        /// <summary>
        /// holds PackageCount
        /// </summary>
        public int PackageCount { get; set; }

        /// <summary>
        /// holds TransactionIdentifier
        /// </summary>
        public string TransactionIdentifier { get; set; }
    }
}