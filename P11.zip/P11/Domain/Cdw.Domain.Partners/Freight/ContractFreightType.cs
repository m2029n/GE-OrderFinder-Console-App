﻿using System;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// enum defines ContractFreightType
    /// </summary>
    [Flags]
    public enum ContractFreightType
    {
        /// <summary>
        /// not set
        /// </summary>
        None = 0,

        /// <summary>
        /// defines Actual Type
        /// </summary>
        Actual = 1,

        /// <summary>
        /// defines Free Type
        /// </summary>
        Free = 2,

        /// <summary>
        /// defines FreeWithDifference Type
        /// </summary>
        FreeWithDifference = 4,

        /// <summary>
        /// defines Custom Type
        /// </summary>
        Custom = 8
    }
}