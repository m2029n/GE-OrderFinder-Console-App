﻿namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// implements RatedFreightDetailShippingMethod
    /// </summary>
    public class RatedFreightDetailShippingMethod : IRatedFreightDetailShippingMethod
    {
        /// <summary>
        /// holds BoxHandlingCharge
        /// </summary>
        public decimal BoxHandlingCharge { get; set; }

        /// <summary>
        /// holds Code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// holds ContractFreightTypesApplied
        /// </summary>
        public ContractFreightType ContractFreightTypesApplied { get; set; }

        /// <summary>
        /// holds Cost
        /// </summary>
        public decimal Cost { get; set; }

        /// <summary>
        /// holds DropShipMethodCode
        /// </summary>
        public string DropShipMethodCode { get; set; }

        /// <summary>
        /// holds FreightCharge
        /// </summary>
        public decimal FreightCharge { get; set; }

        /// <summary>
        /// holds InsuranceCharge
        /// </summary>
        public decimal InsuranceCharge { get; set; }

        /// <summary>
        /// holds OrderHandlingCharge
        /// </summary>
        public decimal OrderHandlingCharge { get; set; }

        /// <summary>
        /// holds OtherCharge
        /// </summary>
        public decimal OtherCharge { get; set; }

        /// <summary>
        /// holds SaturdayCharge
        /// </summary>
        public decimal SaturdayCharge { get; set; }

        /// <summary>
        /// holds TotalCharge
        /// </summary>
        public decimal TotalCharge { get; set; }
    }
}