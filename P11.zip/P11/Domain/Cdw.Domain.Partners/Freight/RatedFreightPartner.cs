﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// implements RatedFreightPartner
    /// </summary>
    public class RatedFreightPartner : IRatedFreight
    {
        /// <summary>
        /// holds Details
        /// </summary>
        public IEnumerable<IRatedFreightDetail> Details { get; set; }

        /// <summary>
        /// holds ShippingMethods
        /// </summary>
        public IEnumerable<IRatedFreightShippingMethod> ShippingMethods { get; set; }
    }
}