﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Freight
{
    /// <summary>
    /// Freight response object with shipping methods
    /// </summary>
    public interface IRatedFreight
    {
        /// <summary>
        /// A collection of shipping methods returned
        /// </summary>
        IEnumerable<IRatedFreightShippingMethod> ShippingMethods { get; set; }

        /// <summary>
        /// A collection of shipping methods with details
        /// </summary>
        IEnumerable<IRatedFreightDetail> Details { get; }
    }
}