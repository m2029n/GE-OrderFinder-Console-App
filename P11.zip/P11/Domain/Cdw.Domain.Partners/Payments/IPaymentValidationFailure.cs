﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// defines IPaymentValidationFailure
    /// </summary>
    public interface IPaymentValidationFailure
    {
        /// <summary>
        /// defines Field
        /// </summary>
        string Field { get; }

        /// <summary>
        /// defines Message
        /// </summary>
        string Message { get; }
    }
}