﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// defines ICreditCard
    /// </summary>
    public interface ICreditCard
    {
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; set; }
        /// <summary>
        /// defines Number
        /// </summary>
        string Number { get; set; }
        /// <summary>
        /// defines ExpirationMonth
        /// </summary>
        int ExpirationMonth { get; set; }
        /// <summary>
        /// defines ExpirationYear
        /// </summary>
        int ExpirationYear { get; set; }
        /// <summary>
        /// defines CVV
        /// </summary>
        string CVV { get; set; }
    }
}