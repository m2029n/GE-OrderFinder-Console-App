﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// implements IAuthResponse
    /// </summary>
    public class AuthResponse : IAuthResponse
    {
        /// <summary>
        /// holds IAuthResponse
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// holds ReferenceNumber
        /// </summary>
        public string ReferenceNumber { get; set; }
    }
}