﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// defines IAuthResponse
    /// </summary>
    public interface IAuthResponse
    {
        /// <summary>
        /// defines TransactionId
        /// </summary>
        string TransactionId { get; }

        /// <summary>
        /// defines ReferenceNumber
        /// </summary>
        string ReferenceNumber { get; }
    }
}