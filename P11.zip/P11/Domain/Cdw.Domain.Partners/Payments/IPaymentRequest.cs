﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// defines IPaymentRequest
    /// </summary>
    public interface IPaymentRequest
    {
        /// <summary>
        /// defines TransactionId
        /// </summary>
        string TransactionId { get; set; }

        /// <summary>
        /// defines CreditCard
        /// </summary>
        ICreditCard CreditCard { get; set; }

        /// <summary>
        /// defines IpAddress
        /// </summary>
        string IpAddress { get; set; }

        /// <summary>
        /// defines GeoLocation
        /// </summary>
        string GeoLocation { get; set; }

        /// <summary>
        /// defines UserAgent
        /// </summary>
        string UserAgent { get; set; }
    }
}