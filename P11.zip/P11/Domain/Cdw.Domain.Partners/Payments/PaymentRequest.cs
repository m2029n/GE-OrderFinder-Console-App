﻿namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// implements PaymentRequest
    /// </summary>
    public class PaymentRequest : IPaymentRequest
    {
        /// <summary>
        /// holds TransactionId
        /// </summary>
        public string TransactionId { get; set; }

        /// <summary>
        /// holds CreditCard
        /// </summary>
        public ICreditCard CreditCard { get; set; }

        /// <summary>
        /// holds IpAddress
        /// </summary>
        public string IpAddress { get; set; }

        /// <summary>
        /// holds GeoLocation
        /// </summary>
        public string GeoLocation { get; set; }

        /// <summary>
        /// holds UserAgent
        /// </summary>
        public string UserAgent { get; set; }
    }
}