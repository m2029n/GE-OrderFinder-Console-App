﻿using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Payments
{
    /// <summary>
    /// defines IPaymentDomainManager
    /// </summary>
    public interface IPaymentDomainManager
    {
        /// <summary>
        /// defines Authorize
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<IAuthResponse> AuthorizeAsync(IPaymentRequest request);
    }
}