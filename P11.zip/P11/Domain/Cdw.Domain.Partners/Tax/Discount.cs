﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements IDiscount
    /// </summary>
    public class Discount : IDiscount
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// holds Type
        /// </summary>
        public int Type { get; set; }
    }
}