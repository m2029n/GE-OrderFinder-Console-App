﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines ITaxDetailResponse
    /// </summary>
    public interface ITaxDetailResponse
    {
        /// <summary>
        /// defines Headers
        /// </summary>
        IEnumerable<ITaxHeader> Headers { get; set; }

        /// <summary>
        /// defines LineItems
        /// </summary>
        IEnumerable<ITaxLineItem> LineItems { get; set; }
    }
}