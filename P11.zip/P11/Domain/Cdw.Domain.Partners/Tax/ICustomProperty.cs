﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines ICustomProperty
    /// </summary>
    public interface ICustomProperty
    {
        /// <summary>
        /// defines Name
        /// </summary>
        string Name { get; }
        /// <summary>
        /// defines Value
        /// </summary>
        string Value { get; }
    }
}