﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// used to identify account sent to order create
    /// </summary>
    public class Account : IAccount
    {
        /// <summary>
        /// used to identify customer by number
        /// </summary>
        public string CustomerNumber { get; set; }
        /// <summary>
        /// electronic account
        /// </summary>
        public string EAccount { get; set; }
        /// <summary>
        /// email address of the account
        /// </summary>
        public string EmailAddress { get; set; }
    }
}