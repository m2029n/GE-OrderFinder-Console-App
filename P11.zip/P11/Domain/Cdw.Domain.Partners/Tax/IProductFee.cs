﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines IProductFee
    /// </summary>
    public interface IProductFee
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; set; }

        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; set; }

        /// <summary>
        /// defines FeeUnitPrice
        /// </summary>
        decimal FeeUnitPrice { get; set; }

        /// <summary>
        /// defines LineNumber
        /// </summary>
        int? LineNumber { get; set; }

        /// <summary>
        /// defines FeeProductCode
        /// </summary>
        string FeeProductCode { get; set; }
    }
}