﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines IAccount
    /// </summary>
    public interface IAccount
    {
        /// <summary>
        /// defines CustomerNumber
        /// </summary>
        string CustomerNumber { get; }
        /// <summary>
        /// defines EAccount
        /// </summary>
        string EAccount { get; }
        /// <summary>
        /// defines EmailAddress
        /// </summary>
        string EmailAddress { get; }
    }
}