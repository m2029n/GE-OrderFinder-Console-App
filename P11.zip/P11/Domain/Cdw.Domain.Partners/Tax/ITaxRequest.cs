﻿using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines ITaxRequest
    /// </summary>
    public interface ITaxRequest
    {
        /// <summary>
        /// defines Account
        /// </summary>
        IAccount Account { get; }

        /// <summary>
        /// defines Address
        /// </summary>
        IAddress Address { get; }

        /// <summary>
        /// defines Company
        /// </summary>
        int Company { get; }

        /// <summary>
        /// defines Discounts
        /// </summary>
        IEnumerable<IDiscount> Discounts { get; }

        /// <summary>
        /// defines Freight
        /// </summary>
        decimal Freight { get; }

        /// <summary>
        /// defines Handling
        /// </summary>
        decimal Handling { get; }

        /// <summary>
        /// defines Insurance
        /// </summary>
        decimal Insurance { get; }

        /// <summary>
        /// defines LineItems
        /// </summary>
        IEnumerable<ILineItem> LineItems { get; }

        /// <summary>
        /// defines ProductFees
        /// </summary>
        IEnumerable<IProductFee> ProductFees { get; set; }

        /// <summary>
        /// defines TrackingValues
        /// </summary>
        ITrackingValues TrackingValues { get; }
    }
}