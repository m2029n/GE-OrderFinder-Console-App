﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines IAddress
    /// </summary>
    public interface IAddress
    {
        /// <summary>
        /// defines FirstName
        /// </summary>
        string FirstName { get; }
        /// <summary>
        /// defines LastName
        /// </summary>
        string LastName { get; }
        /// <summary>
        /// defines PhoneNumber
        /// </summary>
        string PhoneNumber { get; }
        /// <summary>
        /// defines Company
        /// </summary>
        string Company { get; }
        /// <summary>
        /// defines StreetAddress
        /// </summary>
        string StreetAddress { get; }
        /// <summary>
        /// defines SecondaryStreetAddress
        /// </summary>
        string SecondaryStreetAddress { get; }
        /// <summary>
        /// defines City
        /// </summary>
        string City { get; }
        /// <summary>
        /// defines State
        /// </summary>
        string State { get; }
        /// <summary>
        /// defines PostalCode
        /// </summary>
        string PostalCode { get; }
        /// <summary>
        /// defines IsoCountryCode
        /// </summary>
        string IsoCountryCode { get; }
    }
}