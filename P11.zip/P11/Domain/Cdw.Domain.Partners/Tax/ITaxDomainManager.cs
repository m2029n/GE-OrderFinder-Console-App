﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Services.Core;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements IHealthCheck
    /// </summary>
    public interface ITaxDomainManager : IHealthCheck
    {
        /// <summary>
        /// defines GetTaxLinesAsync
        /// </summary>
        /// <param name="taxRequest"></param>
        /// <returns></returns>
        Task<IEnumerable<ITax>> GetTaxLinesAsync(ITaxRequest taxRequest);

        /// <summary>
        /// defines GetTaxDetailsAsync
        /// </summary>
        /// <param name="taxRequest"></param>
        /// <returns></returns>
        Task<ITaxDetailResponse> GetTaxDetailsAsync(ITaxRequest taxRequest);
    }
}