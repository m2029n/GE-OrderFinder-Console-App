﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines IDiscount
    /// </summary>
    public interface IDiscount
    {
        /// <summary>
        /// defines Id
        /// </summary>
        string Id { get; }
        /// <summary>
        /// defines Type
        /// </summary>
        int Type { get; }
        /// <summary>
        /// defines Amount
        /// </summary>
        decimal Amount { get; }
    }
}