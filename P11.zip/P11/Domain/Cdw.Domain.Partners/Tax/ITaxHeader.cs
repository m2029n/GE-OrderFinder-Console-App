﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// extends ITAX
    /// </summary>
    public interface ITaxHeader : ITax
    {
        /// <summary>
        /// defines TaxTypeKey
        /// </summary>
        string TaxTypeKey { get; }
    }
}