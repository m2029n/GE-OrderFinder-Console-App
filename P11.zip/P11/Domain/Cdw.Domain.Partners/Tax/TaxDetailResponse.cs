﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// holds TaxDetailResponse
    /// </summary>
    public class TaxDetailResponse : ITaxDetailResponse
    {
        /// <summary>
        /// holds Headers
        /// </summary>
        public IEnumerable<ITaxHeader> Headers { get; set; }

        /// <summary>
        /// holds LineItems
        /// </summary>
        public IEnumerable<ITaxLineItem> LineItems { get; set; }
    }
}