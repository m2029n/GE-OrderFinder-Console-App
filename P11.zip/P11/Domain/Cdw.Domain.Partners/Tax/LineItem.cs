﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// Implements LineItem
    /// </summary>
    public class LineItem : ILineItem
    {
        /// <summary>
        /// holds CustomProperties
        /// </summary>
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }
        /// <summary>
        /// holds Discounts
        /// </summary>
        public IEnumerable<IDiscount> Discounts { get; set; }
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
        /// <summary>
        /// holds ManufacturerPartNumber
        /// </summary>
        public string ManufacturerPartNumber { get; set; }
        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// holds UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }
        /// <summary>
        /// holds LineNumber
        /// </summary>
        public int? LineNumber { get; set; }
    }
}