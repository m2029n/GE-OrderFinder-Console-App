﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// holds Tax
    /// </summary>
    public class Tax : ITax
    {
        /// <summary>
        /// holds Id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// holds Rate
        /// </summary>
        public decimal Rate { get; set; }
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }
    }
}