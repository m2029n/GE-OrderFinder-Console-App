﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements ProductFee
    /// </summary>
    public class ProductFee : IProductFee
    {
        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }
        /// <summary>
        /// holds Quantity
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// holds FeeUnitPrice
        /// </summary>
        public decimal FeeUnitPrice { get; set; }
        /// <summary>
        /// holds LineNumber
        /// </summary>
        public int? LineNumber { get; set; }
        /// <summary>
        /// holds FeeProductCode
        /// </summary>
        public string FeeProductCode { get; set; }
    }
}