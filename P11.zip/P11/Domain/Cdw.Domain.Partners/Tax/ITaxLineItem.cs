﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// extends ITax
    /// </summary>
    public interface ITaxLineItem : ITax
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }

        /// <summary>
        /// defines LineNumber
        /// </summary>
        string LineNumber { get; }

        /// <summary>
        /// defines TaxTypeKey
        /// </summary>
        string TaxTypeKey { get; }
    }
}