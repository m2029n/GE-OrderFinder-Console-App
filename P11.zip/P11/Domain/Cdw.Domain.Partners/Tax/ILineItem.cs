﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// defines ILineItem
    /// </summary>
    public interface ILineItem
    {
        /// <summary>
        /// defines ProductCode
        /// </summary>
        string ProductCode { get; }
        /// <summary>
        /// defines ManufacturerPartNumber
        /// </summary>
        string ManufacturerPartNumber { get; }
        /// <summary>
        /// defines Quantity
        /// </summary>
        int Quantity { get; }
        /// <summary>
        /// defines UnitPrice
        /// </summary>
        decimal UnitPrice { get; }
        /// <summary>
        /// defines Discounts
        /// </summary>
        IEnumerable<IDiscount> Discounts { get; }
        /// <summary>
        /// defines CustomProperties
        /// </summary>
        IEnumerable<ICustomProperty> CustomProperties { get; }
        /// <summary>
        /// defines LineNumber
        /// </summary>
        int? LineNumber { get; set; }
    }
}