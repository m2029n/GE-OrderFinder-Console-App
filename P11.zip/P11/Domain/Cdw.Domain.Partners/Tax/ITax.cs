﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// Tax response Object
    /// </summary>
    public interface ITax
    {
        /// <summary>
        /// A unique identifier of the type of tax levied
        /// </summary>
        string Id { get; }

        /// <summary>
        /// A description of the type of tax levied
        /// </summary>
        string Description { get; }

        /// <summary>
        /// The tax rate expressed as a percentage. Percentage values are indicated on a scale of 0.00 – 100.00, e.g. 25.00 = 25%.
        /// </summary>
        decimal Rate { get; }

        /// <summary>
        /// The dollar amount of the calculated tax owed.
        /// </summary>
        decimal Amount { get; }
    }
}