﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements CustomProperty
    /// </summary>
    public class CustomProperty : ICustomProperty
    {
        /// <summary>
        /// holds Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// holds Value
        /// </summary>
        public string Value { get; set; }
    }
}