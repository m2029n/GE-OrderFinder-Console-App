﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// holds TaxLineItem
    /// </summary>
    public class TaxLineItem : ITaxLineItem
    {
        /// <summary>
        /// holds Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// holds Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// holds id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// holds LineNumber
        /// </summary>
        public string LineNumber { get; set; }

        /// <summary>
        /// holds ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// holds Rate
        /// </summary>
        public decimal Rate { get; set; }

        /// <summary>
        /// holds TaxTypeKey
        /// </summary>
        public string TaxTypeKey { get; set; }
    }
}