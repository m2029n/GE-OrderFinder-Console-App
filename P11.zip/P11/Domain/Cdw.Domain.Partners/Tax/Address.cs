﻿namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements Address
    /// </summary>
    public class Address : IAddress
    {
        /// <summary>
        /// holds FirstName
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// holds LastName
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// holds PhoneNumber
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// holds Company
        /// </summary>
        public string Company { get; set; }
        /// <summary>
        /// holds StreetAddress
        /// </summary>
        public string StreetAddress { get; set; }
        /// <summary>
        /// holds SecondaryStreetAddress
        /// </summary>
        public string SecondaryStreetAddress { get; set; }
        /// <summary>
        /// holds City
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// holds State
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// holds PostalCode
        /// </summary>
        public string PostalCode { get; set; }
        /// <summary>
        /// holds IsoCountryCode
        /// </summary>
        public string IsoCountryCode { get; set; }
    }
}