﻿using System.Collections.Generic;
using Cdw.Common;

namespace Cdw.Domain.Partners.Tax
{
    /// <summary>
    /// implements ITaxRequest
    /// </summary>
    public class TaxRequest : ITaxRequest
    {
        /// <summary>
        /// holds Account
        /// </summary>
        public IAccount Account { get; set; }
        /// <summary>
        /// holds Address
        /// </summary>
        public IAddress Address { get; set; }
        /// <summary>
        /// holds Company
        /// </summary>
        public int Company { get; set; }
        /// <summary>
        /// holds Discounts
        /// </summary>
        public IEnumerable<IDiscount> Discounts { get; set; }
        /// <summary>
        /// holds Freight
        /// </summary>
        public decimal Freight { get; set; }
        /// <summary>
        /// holds Handling
        /// </summary>
        public decimal Handling { get; set; }
        /// <summary>
        /// holds Insurance
        /// </summary>
        public decimal Insurance { get; set; }
        /// <summary>
        /// holds LineItems
        /// </summary>
        public IEnumerable<ILineItem> LineItems { get; set; }
        /// <summary>
        /// holds ProductFees
        /// </summary>
        public IEnumerable<IProductFee> ProductFees { get; set; }
        /// <summary>
        /// holds TrackingValues
        /// </summary>
        public ITrackingValues TrackingValues { get; set; }
    }
}