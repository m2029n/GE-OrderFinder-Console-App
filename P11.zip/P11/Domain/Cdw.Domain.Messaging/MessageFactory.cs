﻿using System.Collections.Generic;
using Cdw.Infrastructure.Data.Messaging;

namespace Cdw.Domain.Messaging
{
    public class MessageFactory : IMessageFactory
    {
        public Message Create(MessageEntity entity)
        {
            var message = new Message(entity.Body)
            {
                MessageId = entity.MessageId,
                State = (MessageState)entity.State
            };

            return AttachHeaders(message, entity.Headers);
        }

        private Message AttachHeaders(Message message, IEnumerable<MessageHeaderEntity> headerEntities)
        {
            foreach (var entity in headerEntities)
            {
                message.AddHeader(entity.Key, entity.Value);
            }

            return message;
        }
    }
}