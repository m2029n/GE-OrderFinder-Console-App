﻿namespace Cdw.Domain.Messaging
{
    public interface IMessageHandler
    {
        bool CanHandle(IMessage message);

        void Handle(IMessage message);
    }
}