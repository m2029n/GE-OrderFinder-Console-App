﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Infrastructure.Data.Messaging;

namespace Cdw.Domain.Messaging
{
    public class MessageEntityFactory : IMessageEntityFactory
    {
        public MessageEntity Create(IMessage message)
        {
            var entity = new MessageEntity
            {
                MessageId = message.MessageId,
                Headers = CreateHeaders(message.Headers).ToArray(),
                Body = message.Body,
                State = (short)message.State
            };

            return entity;
        }

        private IEnumerable<MessageHeaderEntity> CreateHeaders(IEnumerable<IMessageHeader> headers)
        {
            foreach (var header in headers)
            {
                yield return new MessageHeaderEntity
                {
                    Key = header.Key,
                    Value = header.Value
                };
            }
        }
    }
}