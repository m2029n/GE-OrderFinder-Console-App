﻿using Cdw.Infrastructure.Data.Messaging;

namespace Cdw.Domain.Messaging
{
    public interface IMessageEntityFactory
    {
        MessageEntity Create(IMessage message);
    }
}