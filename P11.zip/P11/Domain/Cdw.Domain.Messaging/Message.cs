﻿using System.Collections.Generic;

namespace Cdw.Domain.Messaging
{
    public class Message : IMessage
    {
        public int MessageId { get; internal set; }

        private readonly List<IMessageHeader> headers;

        public IEnumerable<IMessageHeader> Headers
        {
            get
            {
                return headers;
            }
        }

        public string Body { get; internal set; }

        public MessageState State { get; internal set; }

        public Message(string body)
        {
            Body = body;
            State = MessageState.New;
            headers = new List<IMessageHeader>();
        }

        internal Message(int messageId, IEnumerable<IMessageHeader> messageHeaders, string body, MessageState state)
        {
            MessageId = messageId;
            headers = new List<IMessageHeader>(messageHeaders);
            Body = body;
            State = state;
        }

        public void AddHeader(string key, string value)
        {
            headers.Add(new MessageHeader(key, value));
        }

        public void Complete()
        {
            State = MessageState.Delivered;
        }
    }
}