﻿namespace Cdw.Domain.Messaging
{
    public interface IMessageHeader
    {
        string Key { get; }
        string Value { get; }
    }
}