﻿using Cdw.Infrastructure.Data.Messaging;

namespace Cdw.Domain.Messaging
{
    public class MessagingDomainManager : IMessagingDomainManager
    {
        private readonly IMessageEntityFactory _entityFactory;
        private readonly IMessageFactory _domainFactory;
        private readonly IMessagingRepository _repository;

        public MessagingDomainManager(IMessageEntityFactory entityFactory, IMessageFactory domainFactory, IMessagingRepository repository)
        {
            _entityFactory = entityFactory;
            _domainFactory = domainFactory;
            _repository = repository;
        }

        public IMessage Enqueue(IMessage message)
        {
            var entity = _entityFactory.Create(message);

            var persistedEntity = _repository.Create(entity);

            return _domainFactory.Create(persistedEntity);
        }

        public IMessage Dequeue()
        {
            var entity = _repository.GetFirstUnprocessed();
            if (entity == null)
            {
                return null;
            }

            return _domainFactory.Create(entity);
        }

        public void Complete(IMessage message)
        {
            message.Complete();
            var entity = _entityFactory.Create(message);
            var persistedEntity = _repository.Update(entity);
        }
    }
}