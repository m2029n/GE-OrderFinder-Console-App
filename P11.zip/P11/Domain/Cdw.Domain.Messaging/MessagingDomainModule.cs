﻿using Autofac;

namespace Cdw.Domain.Messaging
{
    public class MessagingDomainModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterType<MessagingDomainManager>()
                .AsImplementedInterfaces();

            builder.RegisterType<MessageFactory>()
                .As<IMessageFactory>();

            builder.RegisterType<MessageEntityFactory>()
                .As<IMessageEntityFactory>();
        }
    }
}