﻿namespace Cdw.Domain.Messaging
{
    public class MessageHeader : IMessageHeader
    {
        public string Key { get; private set; }

        public string Value { get; private set; }

        internal MessageHeader(string key, string value)
        {
            Key = key;
            Value = value;
        }
    }
}