﻿using Cdw.Infrastructure.Data.Messaging;

namespace Cdw.Domain.Messaging
{
    public interface IMessageFactory
    {
        Message Create(MessageEntity entity);
    }
}