﻿using System.Collections.Generic;

namespace Cdw.Domain.Messaging
{
    public interface IMessage
    {
        int MessageId { get; }
        IEnumerable<IMessageHeader> Headers { get; }
        string Body { get; }
        MessageState State { get; }

        void AddHeader(string key, string value);

        void Complete();
    }
}