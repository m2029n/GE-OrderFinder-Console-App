﻿namespace Cdw.Domain.Messaging
{
    public interface IMessagingDomainManager
    {
        IMessage Enqueue(IMessage message);

        IMessage Dequeue();

        void Complete(IMessage message);
    }
}