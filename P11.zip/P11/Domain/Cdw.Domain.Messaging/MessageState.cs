﻿namespace Cdw.Domain.Messaging
{
    public enum MessageState : short
    {
        New,
        Processing,
        Delivered
    }
}