﻿using System.Collections.Generic;
using AutoMapper;
using Cdw.Domain.Partners.Tax;
using Cdw.Domain.Tax;
using Account = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Account;
using Address = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Address;
using CustomProperty = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.CustomProperty;
using Discount = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Discount;
using ILineItem = Cdw.Domain.Partners.Tax.ILineItem;
using ITax = Cdw.Domain.Tax.ITax;
using ITaxRequest = Cdw.Domain.Partners.Tax.ITaxRequest;
using LineItem = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.LineItem;
using ProductFee = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.ProductFee;
using TaxRequest = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.TaxRequest;

namespace Cdw.Domain.Partners.Implementation.Tax
{
    internal class TaxConverter : TypeConverter<ITaxRequest, TaxRequest>
    {
        protected override TaxRequest ConvertCore(ITaxRequest source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new TaxRequest
            {
                Account = Mapper.Map<Account>(source.Account),
                Address = Mapper.Map<Address>(source.Address),
                Company = GetCDWCompanyCode(source.Company),
                Discounts = Mapper.Map<Discount[]>(source.Discounts),
                Freight = source.Freight,
                Handling = source.Handling,
                Insurance = source.Insurance,
                LineItems = Mapper.Map<LineItem[]>(source.LineItems),
                ProductFees = Mapper.Map<ProductFee[]>(source.ProductFees)
            };

            return result;
        }

        private string GetCDWCompanyCode(int companycode)
        {
            switch (companycode)
            {
                case 1000:
                    return "01";

                case 1001:
                    return "02";

                case 1002:
                    return "11";

                case 1003:
                    return "05";

                case 1004:
                    return "00";

                case 1005:
                    return "10";

                case 1006:
                    return "15";

                case 1007:
                    return "16";

                case 1008:
                    return "12";

                case 1009:
                case 1010:
                case 1011:
                    return null;

                case 1012:
                    return "17";

                case 1013:
                    return "03";

                default:
                    return null;
            }
        }
    }

    internal class LineItemConverter : TypeConverter<ILineItem, LineItem>
    {
        protected override LineItem ConvertCore(ILineItem source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new LineItem
            {
                ProductCode = source.ProductCode,
                ManufacturerPartNumber = source.ManufacturerPartNumber,
                Quantity = source.Quantity,
                UnitPrice = source.UnitPrice,
                CustomProperties = Mapper.Map<CustomProperty[]>(source.CustomProperties),
                Discounts = Mapper.Map<Discount[]>(source.Discounts),
                LineNumber = source.LineNumber
            };

            return result;
        }
    }

    internal class TaxHeaderConverter : TypeConverter<ITax, TaxHeader>
    {
        protected override TaxHeader ConvertCore(ITax source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new TaxHeader
            {
                Amount = source.Amount,
                Description = source.Description,
                Id = source.Id,
                Rate = source.Rate,
                TaxTypeKey = source.TaxTypeKey
            };

            return result;
        }
    }

    internal class TaxLineItemConverter : TypeConverter<ITax, TaxLineItem>
    {
        protected override TaxLineItem ConvertCore(ITax source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new TaxLineItem
            {
                Amount = source.Amount,
                Description = source.Description,
                Id = source.Id,
                Rate = source.Rate,
                TaxTypeKey = source.TaxTypeKey,
                LineNumber = source.LineNumber.ToString(),
                ProductCode = source.ProductCode
            };

            return result;
        }
    }

    internal class TaxDetailResponseConverter : TypeConverter<ITaxResponse, TaxDetailResponse>
    {
        protected override TaxDetailResponse ConvertCore(ITaxResponse source)
        {
            if (source == null)
            {
                return null;
            }

            var headers = new List<ITaxHeader>();
            var lineItems = new List<ITaxLineItem>();

            foreach (var header in source.Headers)
            {
                headers.Add(Mapper.Map<TaxHeader>(header)); // map Cdw.Domain.Tax.ITax to ITaxHeader
            }

            foreach (var lineItem in source.LineItems)
            {
                lineItems.Add(Mapper.Map<TaxLineItem>(lineItem)); // map Cdw.Domain.Tax.ITax to ITaxLineItem
            }

            var result = new TaxDetailResponse
            {
                Headers = headers,
                LineItems = lineItems
            };

            return result;
        }
    }
}