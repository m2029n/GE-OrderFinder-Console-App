﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Tax.TaxDomain;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Clients.Tax;
using Cdw.Partners.Utilities;
using Cdw.Security.OAuth2.Client;
using Cdw.Services.Core;
using Common.Logging;
using TaxPartnerDomain = Cdw.Domain.Partners.Tax;
using TaxRequest = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.TaxRequest;

namespace Cdw.Domain.Partners.Implementation.Tax
{
    public class TaxDomainManager : TaxPartnerDomain.ITaxDomainManager
    {
        private readonly ILog _logger;

        private readonly ITaxRequestDomainManager _taxRequestDomainManager;

        private readonly IHealthCheck _healthCheck;

        public TaxDomainManager(ILog logger, ITaxRequestClientDomainManager taxRequestDomainManager)
        {
            _logger = logger;
            _taxRequestDomainManager = taxRequestDomainManager;
            _healthCheck = taxRequestDomainManager;
        }

        public async Task<IEnumerable<TaxPartnerDomain.ITax>> GetTaxLinesAsync(TaxPartnerDomain.ITaxRequest taxRequest)
        {
            var trackingValues = taxRequest.TrackingValues;
            var trackingValuesForTax= new TrackingValues(trackingValues.TrackingId,Guid.NewGuid());
         
            _logger.Debug(" Step 1: Tax Mapping", trackingValues);
            var taxrequest = Mapper.Map<TaxRequest>(taxRequest);

            _logger.Debug(" Step 2: AssignLineNumber", trackingValues);
            AssignLineNumbers(taxrequest);

            _logger.Debug(" Step 3: Calling Tax Client", trackingValues);
            var itaxentity = await _taxRequestDomainManager.WithTracking(trackingValuesForTax).GetTaxLinesAsync(taxrequest).ConfigureAwait(false);

            _logger.Debug(" Step 4: union tax header and line item", trackingValues);
            //Note: we are not using productfee section from the tax api output beacuse in the xerox code there was no implemenation of that but we need to consider that for future.
            var query =
                (from h in itaxentity.Headers where h.Amount != 0 select h).Union
                (from l in itaxentity.LineItems where l.Amount != 0 select l);

            _logger.Debug(" Step 5: tax combine query", trackingValues);
            var querycombined = query.GroupBy(t => new { t.Id, t.Rate })
                .Select(at => new TaxPartnerDomain.TaxPartner
                {
                    Id = at.Key.Id,
                    Rate = at.Key.Rate,
                    Description = at.First().Description,
                    Amount = Math.Max(0, at.Sum(f => f.Amount))
                });
            _logger.Debug(" Step 6: Tax Ended", trackingValues);
            return querycombined.ToArray();
        }

        public async Task<TaxPartnerDomain.ITaxDetailResponse> GetTaxDetailsAsync(TaxPartnerDomain.ITaxRequest taxRequest)
        {
            var trackingValues = taxRequest.TrackingValues;

            _logger.Debug(" Step 1: Tax Detail Mapping", trackingValues);
            var taxrequest = Mapper.Map<TaxRequest>(taxRequest);

            _logger.Debug(" Step 2: AssignLineNumber", trackingValues);
            AssignLineNumbers(taxrequest);
            
            _logger.Debug(" Step 3: Calling Tax Client", trackingValues);         
            var itaxentity = await _taxRequestDomainManager.GetTaxLinesAsync(taxrequest).ConfigureAwait(false);

            _logger.Debug(" Step 4: Mapping", trackingValues);
            var taxDetailResponse = Mapper.Map<TaxPartnerDomain.TaxDetailResponse>(itaxentity);

            _logger.Debug(" Step 5: GetTaxDetails Return", trackingValues);
            return taxDetailResponse;
        }

        /// <summary>
        /// Adds line number to line item if empty for backward compatibility to xerox.
        /// </summary>
        /// <param name="taxrequest"></param>
        private void AssignLineNumbers(TaxRequest taxrequest)
        {
            if (taxrequest == null)
            {
                return;
            }

            var i = 0;
            foreach (var lineItem in taxrequest.LineItems)
            {
                if (!lineItem.LineNumber.HasValue)
                {
                    lineItem.LineNumber = i;
                }

                i++;
            }
        }

        public async Task<IHealthCheckMessage> CheckAsync()
        {
            return await _healthCheck.CheckAsync().ConfigureAwait(false);
        }
    }
}