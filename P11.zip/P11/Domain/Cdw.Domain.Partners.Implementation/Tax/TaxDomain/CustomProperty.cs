﻿using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class CustomProperty : ICustomProperty
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}