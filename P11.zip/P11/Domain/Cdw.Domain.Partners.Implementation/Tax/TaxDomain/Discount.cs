﻿using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class Discount : IDiscount
    {
        public decimal Amount { get; set; }
        public string Id { get; set; }
        public int Type { get; set; }
    }
}