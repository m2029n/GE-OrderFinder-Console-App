﻿using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class Account : IAccount
    {
        public string CustomerNumber { get; set; }
        public string EAccount { get; set; }
        public string EmailAddress { get; set; }
    }
}