﻿using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class ProductFee : IProductFee
    {
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal FeeUnitPrice { get; set; }
        public int? LineNumber { get; set; }
        public string FeeProductCode { get; set; }
    }
}