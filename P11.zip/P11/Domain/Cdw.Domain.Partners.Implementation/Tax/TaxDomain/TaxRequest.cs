﻿using System.Collections.Generic;
using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class TaxRequest : ITaxRequest
    {
        public IAccount Account { get; set; }
        public IAddress Address { get; set; }
        public string Company { get; set; }
        public IEnumerable<IDiscount> Discounts { get; set; }
        public decimal Freight { get; set; }
        public decimal Handling { get; set; }
        public decimal Insurance { get; set; }
        public IEnumerable<ILineItem> LineItems { get; set; }
        public IEnumerable<IProductFee> ProductFees { get; set; }
    }
}