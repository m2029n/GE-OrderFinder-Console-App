﻿using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class Tax : ITax
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
        public decimal OboRate { get; set; }
        public decimal OboAmount { get; set; }
        public string ProductCode { get; set; }
        public int? LineNumber { get; set; }
        public string TaxTypeKey { get; set; }
    }
}