﻿using System.Collections.Generic;
using Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax.TaxDomain
{
    internal class LineItem : ILineItem
    {
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }
        public int? LineNumber { get; set; }
        public decimal Rate { get; set; }
        public IEnumerable<IDiscount> Discounts { get; set; }
        public string ProductCode { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }
}