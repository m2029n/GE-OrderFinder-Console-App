﻿using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Partners.Utilities;

namespace Cdw.Domain.Partners.Implementation.Common
{
    public class PartnerDetails : IPartnerDetails
    {
        private static IPartnerOrderRepository _partnerOrderRepository;

        public PartnerDetails(IPartnerOrderRepository partnerOrderRepository)
        {
            _partnerOrderRepository = partnerOrderRepository;
        }

        public IIdentity GetPartnerSourceCode(Partner partner)
        {
            var identityEntity = _partnerOrderRepository.GetIdentityDetails(partner.Description());

            //return identityEntity?.SourceCode;

            return new Identity
            {
                Partner = partner,
                ClientId = identityEntity.ClientId,
                SourceCode = identityEntity.SourceCode,
                ClientName = identityEntity.ClientName,
                FreightRaterSpecialCode = identityEntity.FreightRaterSpecialCode
            };
        }

        public IIdentity GetPartnersIdenity(PartnerInfo partner)
        {
            var identityEntity = _partnerOrderRepository.GetIdentityDetails(partner.ClientId);

            //return identityEntity?.SourceCode;

            return new Identity
            {
                CompanyCode = partner.CompanyCode,
                ClientId = identityEntity.ClientId,
                SourceCode = identityEntity.SourceCode,
                ClientName = identityEntity.ClientName,
                FreightRaterSpecialCode = identityEntity.FreightRaterSpecialCode,
                ApplyCoupon = partner.ApplyCoupon,
                SearchApi = partner.SearchApi,
                ProductApiCompany = partner.ProductApiCompany,
                PriceCompanyCode = partner.PriceCompanyCode,
                ShowWeight = partner.ShowWeight
            };
        }
    }
}