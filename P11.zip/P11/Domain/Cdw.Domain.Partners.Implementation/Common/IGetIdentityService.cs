﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Common
{
    public interface IGetIdentityService
    {
        IIdentity GetPartnersIdentity(string userName);
    }
}