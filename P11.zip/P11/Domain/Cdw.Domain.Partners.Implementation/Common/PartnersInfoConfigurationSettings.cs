﻿namespace Cdw.Domain.Partners.Implementation.Common
{
    public class PartnersInfoConfigurationSettings
    {
        public PartnersInfo PartnersInfo { get; set; }
    }
}