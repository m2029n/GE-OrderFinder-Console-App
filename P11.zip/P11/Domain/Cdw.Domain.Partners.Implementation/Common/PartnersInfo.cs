﻿using System.Collections.Generic;

namespace Cdw.Domain.Partners.Implementation.Common
{
    public class PartnersInfo
    {
        public List<PartnerInfo> Partners { get; set; }
    }
}