﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners
{
    public class Identity : IIdentity
    {
        /// <summary>
        /// corresponds to an id in the Clients  table
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// partner's name
        /// </summary>
        public string ClientName { get; set; }

        /// <summary>
        /// source code from OrderUploadSourceCodes
        /// </summary>
        public string SourceCode { get; set; }

        /// <summary>
        /// Code from Orders_FreightRaterSpecialCodeByOrderSource
        /// </summary>
        public string FreightRaterSpecialCode { get; set; }

        /// <summary>
        /// Object to be Obsolete
        /// </summary>
        public Partner? Partner { get; set; }

        /// <summary>
        /// CDW code for filtering products
        /// </summary>
        public int CompanyCode { get; set; }

        /// <summary>
        /// used to add coupon data to the product catalog
        /// </summary>
        public bool ApplyCoupon { get; set; }

        public IEnumerable<string> CouponPromotionCodes { get; set; }

        /// <summary>
        /// used if UseSearchApi is true
        /// </summary>
        public SearchApiSettings SearchApi { get; set; }

        public string ProductApiCompany { get; set; }
        public string PriceCompanyCode { get; set; }
        public bool ShowWeight { get; set; }
    }
}