﻿namespace Cdw.Domain.Partners
{
    /// <summary>
    /// used if UseSearchApi is true in Identity
    /// </summary>
    public class SearchApiSettings
    {
        /// <summary>
        /// value passed to search API
        /// </summary>
        public string QueryUri { get; set; }

        /// <summary>
        /// value passed to search API
        /// </summary>
        public int Catalog { get; set; }
    }
}