﻿using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Common
{
    public interface IPartnerDetails
    {
        IIdentity GetPartnerSourceCode(Partner partner);

        IIdentity GetPartnersIdenity(PartnerInfo partner);
    }
}