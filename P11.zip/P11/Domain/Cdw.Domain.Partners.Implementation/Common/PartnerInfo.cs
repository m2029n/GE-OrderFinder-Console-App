﻿namespace Cdw.Domain.Partners.Implementation.Common
{
    public class PartnerInfo
    {
        public string Name { get; set; }
        public int CompanyCode { get; set; }
        public int ClientId { get; set; }
        public bool ApplyCoupon { get; set; }

        /// <summary>
        /// used to select products from the search api for product catalog
        /// </summary>
        public bool UseSearchApi { get; set; }

        /// <summary>
        /// used if UseSearchApi is true
        /// </summary>
        public SearchApiSettings SearchApi { get; set; }

        public string ProductApiCompany { get; set; }
        public string PriceCompanyCode { get; set; }
        public bool ShowWeight { get; set; }
    }
}