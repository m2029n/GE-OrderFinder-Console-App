﻿using System;
using System.Linq;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Common
{
    public class GetIdentityService : IGetIdentityService
    {
        private readonly PartnersInfoConfigurationSettings _config;
        private readonly IPartnerDetails _partnerDetails;

        public GetIdentityService(PartnersInfoConfigurationSettings config, IPartnerDetails partnerDetails)
        {
            _config = config;
            _partnerDetails = partnerDetails;
        }

        /// <summary>
        /// new method to get Identity of the caller Partners
        /// </summary>
        /// <returns></returns>
        public IIdentity GetPartnersIdentity(string userName)
        {
            var partner = _config.PartnersInfo.Partners.FirstOrDefault(p => p.Name == userName);
            if (partner == null)
            {
                throw new Exception($"partner: {userName} is not found in config settings");
            }
            var partnerIdentity = _partnerDetails.GetPartnersIdenity(partner);
            return partnerIdentity;
        }
    }
}