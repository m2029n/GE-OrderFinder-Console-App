﻿using Cdw.Services.Core;

namespace Cdw.Domain.Partners.Implementation.Common
{
    //TODO: Temporary stub
    internal class HealthCheckMessage : IHealthCheckMessage
    {
        public string Service { get; set; }
        public HealthStatus Status { get; set; }
    }
}