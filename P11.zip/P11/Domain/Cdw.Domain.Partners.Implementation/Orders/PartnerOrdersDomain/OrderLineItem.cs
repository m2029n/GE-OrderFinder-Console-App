﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    public class OrderLineItem : IOrderLineItem
    {
        public string CompanyCode { get; }
        public string OrderNumber { get; }
        public int OrderLineNumber { get; }
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
        public int QuantityOutstanding { get; set; }
        public string SuspendCode { get; set; }
        public decimal OrderLineValue { get; set; }
        public string OnBehalfFlag { get; set; }
        public decimal TaxAmount { get; set; }
        public string PriceListCode { get; set; }
        public string ContractName { get; set; }
        public int CDWReferenceCode { get; set; }
        public decimal QuantityDespatched { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public OrderShippingStatus OrderLineStatus { get; set; }
        public int QuantityBackordered { get; set; }
        public DateTime BackorderedEstShipDate { get; set; }
        public string FriendlyName { get; set; }
        public string FriendlyDescription { get; set; }
        public string ManuFacturePartNumber { get; set; }



    }
}
