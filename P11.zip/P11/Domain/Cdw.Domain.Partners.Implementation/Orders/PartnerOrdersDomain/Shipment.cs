﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Shipment : IShipment
    {
        public int Box { get; set; }
        public IEnumerable<IShippedItem> Contents { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime ShippedDate { get; set; }
        public IShippingMethod ShippingMethod { get; set; }
        public string TrackingNumber { get; set; }
        public string TrackingUrl { get; set; }
        public decimal Weight { get; set; }
    }
}
