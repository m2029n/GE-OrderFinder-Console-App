﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class ShippingInfo : IShippingInfo
    {
        public IAddress Address { get; set; }
        public IShippingMethod Method { get; set; }
    }
}
