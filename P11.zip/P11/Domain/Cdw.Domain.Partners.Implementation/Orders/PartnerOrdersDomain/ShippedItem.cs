﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class ShippedItem : IShippedItem
    {
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public string ManufacturerPartNumber { get; set; }
    }
}
