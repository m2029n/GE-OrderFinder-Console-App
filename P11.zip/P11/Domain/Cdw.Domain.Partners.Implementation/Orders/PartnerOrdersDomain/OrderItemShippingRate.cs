﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class OrderItemShippingRate:IOrderItemShippingRate
    {
        public decimal BoxHandling { get;  set; }
        public decimal CdwCost { get;  set; }
        public decimal Freight { get;  set; }
        public decimal Handling { get;  set; }
        public decimal Insurance { get;  set; }
        public string ProductCode { get;  set; }
        public decimal Weight { get;  set; }
    }
}