﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class CartItemDiscounts : ICartItemDiscounts
    {
        public IList<IDiscount> FixedLinePriceDiscounts { get; set; }
        public IList<IDiscount> FixedUnitPriceDiscounts { get; set; }
        public IList<IDiscount> PercentOffLinePriceDiscounts { get; set; }
        public IList<IDiscount> PercentOffUnitPriceDiscounts { get; set; }
    }
}
