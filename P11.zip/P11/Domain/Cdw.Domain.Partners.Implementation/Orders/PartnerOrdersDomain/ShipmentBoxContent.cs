﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    public class ShipmentBoxContent : IShipmentBoxContent
    {
        public string Description { get; set; }
        public string EDC { get; set; }
        public int? EstimatedQuantity { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public int? OrderLineNumber { get; set; }
        public int? QuantityInBox { get; set; }
    }
}
