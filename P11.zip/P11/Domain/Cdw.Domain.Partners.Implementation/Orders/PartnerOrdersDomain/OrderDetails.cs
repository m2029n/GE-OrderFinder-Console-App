﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;
using Newtonsoft.Json;


namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    public class OrderDetails :IOrderDetails
    {
        public IOrderHeader Header { get; set; }
        public IEnumerable<IOrderLineItem> LineItems { get; set; }
        public IEnumerable<IShipmentBox> Shipments { get; set; }
    }

}
