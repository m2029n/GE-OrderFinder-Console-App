﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class RecyclingFee: IRecyclingFee
    {
        public string ProductCode { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
        public string Code { get; set; }
        public string ProductFeeEDC { get; set; }
    }
}
