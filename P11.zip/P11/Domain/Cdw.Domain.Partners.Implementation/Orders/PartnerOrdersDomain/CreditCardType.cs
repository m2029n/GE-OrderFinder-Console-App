﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class CreditCardType : ICreditCardType
    {
        public bool NumberMatchesCardTypePattern(string cardNumber)
        {
            throw new NotImplementedException();
        }

        public PaymentMethodType Type { get; set; }
        public string Name { get; set; }
        public IEnumerable<string> AlternateNames { get; set; }
        public int CardNumberLength { get; set; }
    }
}
