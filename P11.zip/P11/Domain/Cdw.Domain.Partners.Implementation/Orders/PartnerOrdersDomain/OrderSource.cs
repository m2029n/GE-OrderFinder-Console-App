using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class OrderSource:IOrderSource
    {
        public string Name { get;  set; }
        public string FreightRaterSpecialCode { get;  set; }
    }
}