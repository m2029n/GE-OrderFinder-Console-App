﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class LineItem : ILineItem
    {
        public string ProductCode { get; set; }
        public string Status { get; set; }
        public uint Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LinePrice { get; set; }
        public IEnumerable<IDiscount> Discounts { get; set; }
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }
        public IEnumerable<IShipment> Shipments { get; set; }
    }
}