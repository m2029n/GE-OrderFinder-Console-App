﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class ShippingMethod : IShippingMethod
    {
        public string Description { get; set; }
        public string Id { get; set; }
        public IOrderShippingRate Rate { get; set; }
    }
}
