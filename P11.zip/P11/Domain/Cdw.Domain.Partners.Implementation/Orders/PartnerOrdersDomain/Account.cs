﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Account : IAccount
    {
        public string CustomerNumber { get; set; }
        public string EAccount { get; set; }
        public string EmailAddress { get; set; }
    }

     internal class ResponseBilling : IResponseBilling
     {
         public IAddress Address { get; set; }
         public IResponsePaymentMethod Method { get; set; }
     }

    internal class ResponsePaymentMethod:IResponsePaymentMethod
    {
        public string PONumber { get; set; }
        public IResponseCreditCard CreditCard { get; set; }
    }
    internal class ResponseCreditCard:IResponseCreditCard
    {
        public string Type { get; set; }
        public string Number { get; set; }
    }
}
