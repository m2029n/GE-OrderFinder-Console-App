﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Implementation.Orders.Infrastructure;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Cart : ICart
    {
        public int Id { get; set; }
        public CdwCompany Company { get; set; }
        public decimal Subtotal
        {
            get { return Items.Sum(i => i.DiscountedLinePrice); }
        }
        public decimal DiscountValue => DiscountCalculator.CalculateDiscountValue(this);
        public decimal DiscountedSubtotal => Subtotal - DiscountValue;
        public ICartDiscounts Discounts { get; set; }
        public IList<ICartItem> Items { get; set; }
        public IList<ICustomProperty> CustomProperties { get; set; }
    }
}
