﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Tax : ITax
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
    }
}
