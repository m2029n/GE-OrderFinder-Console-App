﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.Orders.Infrastructure;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class CartItem : ICartItem
    {
        public int Id { get; set; }
        public CartItemStatus Status { get; set; }
        public IList<ICustomProperty> CustomProperties { get; set; }
        public ICartItemDiscounts Discounts { get; set; }
        public decimal UnitPrice { get; set; }

        public IProduct Product { get; set; }
        public uint Quantity { get; set; }

        public decimal DiscountedUnitPrice
        {
            get { return PriceCalculator.CalculateUnitPriceAfterDiscounts(this); }
        }

        public decimal LinePrice
        {
            get { return PriceCalculator.CalculateLinePriceBeforeDiscounts(this); }
        }

        public decimal DiscountedLinePrice
        {
            get { return PriceCalculator.CalculateLinePriceAfterDiscounts(this); }
        }
    }
}
