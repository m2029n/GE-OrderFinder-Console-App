﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class ResponseOrder : IResponseOrder
    {
        public int Company { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Discount { get; set; }
        public decimal Freight { get; set; }
        public decimal Handling { get; set; }
        public decimal Insurance { get; set; }
        public IEnumerable<IDiscount> Discounts { get; set; }
        public IResponseBilling Billing { get; set; }
        public IShipping Shipping { get; set; }
        public IEnumerable<ILineItem> LineItems { get; set; }
        public IEnumerable<ICustomProperty> CustomProperties { get; set; }
        public string OrderNumber { get; set; }
        public string Status { get; set; }
        public DateTime TransactionDate { get; set; }
        public string ReferenceNumber { get; set; }
        public IAccount Account { get; set; }
        public IEnumerable<ITax> Taxes { get; set; }
        public decimal Tax { get; set; }
        public decimal Total { get; set; }
    }
}
