﻿using System;
using System.Collections.Generic;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class OrderShippingRate:IOrderShippingRate
    {
        public string ShippingMethodId { get; set; }
        public string ShippingMethodDescription { get; set; }
        public int BoxCount { get;  set; }
        public decimal BoxHandlingCharge { get;  set; }
        public decimal FreightCost { get;  set; }
        public decimal Freight { get;  set; }
        public decimal Handling { get;  set; }
        public decimal Insurance { get;  set; }
        public IEnumerable<IOrderItemShippingRate> OrderItems { get;  set; }
        public decimal TotalShippingCharge { get;  set; }
        public decimal TotalWeight { get;  set; }
        public Guid TransactionGUID { get;  set; }
    }
}