﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class BillingInfo : IBillingInfo
    {
        public IAddress Address { get; set; }
        public IPaymentMethod Method { get; set; }
    }
}
