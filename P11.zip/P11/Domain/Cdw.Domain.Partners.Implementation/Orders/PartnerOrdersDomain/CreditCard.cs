﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class CreditCard : ICreditCard
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public ICreditCardType Type { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public int ExpirationMonth { get; set; }
        public int ExpirationYear { get; set; }
    }
}
