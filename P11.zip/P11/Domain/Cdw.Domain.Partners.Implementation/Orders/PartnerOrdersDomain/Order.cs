﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Order : IOrder
    {
        public IAccount Account { get; set; }
        public IBillingInfo Billing { get; set; }
        public ICart Cart { get; set; }

        public decimal Tax
        {
            get { return Math.Max(0, Taxes.Sum(t => t.Amount)); }
        }

        public decimal Total { get; set; }
        public string OrderNumber { get; set; }
        public string ReferenceNumber { get; set; }
        public IEnumerable<IShipment> Shipments { get; set; }
        public IShippingInfo Shipping { get; set; }
        public IOrderSource Source { get; set; }
        public OrderStatus Status { get; set; }
        public IEnumerable<ITax> Taxes { get; set; }
        public IEnumerable<IRecyclingFee> RecyclingFees { get; set; }
        public decimal RecyclingFee { get; set; }
        public DateTime TransactionDate { get; set; }
        public ITrackingValues TrackingValues { get; set; }
    }
}
