﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    public class OrderHeader : IOrderHeader
    {
        public int InvoicedItemCount { get; set; }
        public IAddress BillingAddress { get; set; }
        public IAddress ShippingAddress { get; set; }
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
        public string OrderCode { get; set; }
        public DateTime OrderDate { get; set; }
        public string PoNumber { get; set; }
        public int ContactSequence { get; set; }
        public decimal SubTotal { get; set; }
        public string StatusCode { get; set; }
        public string SuspendCode { get; set; }
        public string ShippingCarrierCode { get; set; }
        public string ShippingCarrier { get; set; }
        public decimal OrderValue { get; set; }
        public string QuoteNumber { get; set; }
        public decimal FreightTotal { get; set; }
        public string PaymentType { get; set; }
        public int NumberOfBoxes { get; set; }
        public bool IsLease { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string PaymentCode { get; set; }
        public string PaymentMethodName { get; set; }
    }
}
