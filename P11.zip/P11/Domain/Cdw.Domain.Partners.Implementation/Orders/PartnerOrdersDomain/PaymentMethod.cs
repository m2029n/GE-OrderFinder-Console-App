﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class PaymentMethod : IPaymentMethod
    {
        public string EncryptedCreditCard { get; set; }
        public ICreditCard CreditCard { get; set; }
        public string PONumber { get; set; }
    }
}
