﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Discount : IDiscount
    {
        public decimal Amount { get; set; }
        public string Id { get; set; }
        public int Type { get; set; }
    }
}
