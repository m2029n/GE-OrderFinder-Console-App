﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class CartDiscounts : ICartDiscounts
    {
        public IList<IDiscount> FixedAmountDiscounts { get; set; }
        public IList<IDiscount> PercentOffDiscounts { get; set; }
    }
}
