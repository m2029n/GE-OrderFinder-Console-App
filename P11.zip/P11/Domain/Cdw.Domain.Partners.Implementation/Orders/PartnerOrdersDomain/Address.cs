﻿using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    public class Address:IAddress
    {
        public string MiddleInitial { get; set; }
        public string ContactName { get; set; }
        public string AttentionName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
        public string StreetAddress { get; set; }
        public string SecondaryStreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string IsoCountryCode { get; set; }
    }
}
