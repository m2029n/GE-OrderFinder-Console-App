﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.PartnerOrdersDomain
{
    internal class Identity:IIdentity
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string SourceCode { get; set; }
        public string FreightRaterSpecialCode { get; set; }
        public Partner? Partner { get; set; }
        public int CompanyCode { get; set; }
    }
}