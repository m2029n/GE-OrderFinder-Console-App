﻿using System;
using Cdw.Ecommerce.Domain.CreditCardService;

namespace Cdw.Domain.Partners.Implementation.Orders.CreditCardService
{
    internal class CreditCardAuthorizationRequest : ICreditCardAuthorizationRequest
    {
        public string EncryptedCreditCardText { get; set; }
        public ECreditCardType? CreditCardType { get; set; }
        public DateTime ExpirationDate { get; set; }
        public bool IsAuthorizedToSave { get; set; }
        public string CardVerificationValue { get; set; }
        public bool UseAsyncProcessing { get; set; }
        public string CreditCardHolderName { get; set; }
    }
}