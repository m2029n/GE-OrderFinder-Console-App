﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Messaging;
using Cdw.Domain.Partners.Implementation.Helpers;
using Cdw.Ecommerce.Email;
using Cdw.Infrastructure.Events;
using Cdw.Partners.Utilities;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Orders
{
    public class OrderCreatedHandler : IDomainEventHandler<OrderCreatedEvent>
    {
        private readonly IMessagingDomainManager _messagingManager;
        private readonly IEmailDomainManager _emailDomainManager;
        private readonly ILog _log;

        public OrderCreatedHandler(IMessagingDomainManager messagingManager, IEmailDomainManager emailDomainManager, ILog log)
        {
            _messagingManager = messagingManager;
            _emailDomainManager = emailDomainManager;
            _log = log;
        }

        public void Handle(OrderCreatedEvent orderCreatedEvent)
        {
            var soureName = orderCreatedEvent.Order.Source.Name.ToUpper();

            //Email Api to GlobalDB Message Queue
            if (soureName != "XDR" && soureName != "XEC")
            {
                if (!SendWebOrderConfirmationEmail(orderCreatedEvent).Result)
                {
                    _log.Error(string.Format("Source Code {0}'s email cannot be sent", soureName));
                }
            }
            //Message Enque to WebDB Message Queue
            else
            {
                var message = new Message(orderCreatedEvent.Order.OrderNumber);
                message.AddHeader("Source", soureName);
                message.AddHeader("Type", orderCreatedEvent.EventName);

                foreach (var prop in orderCreatedEvent.Order.Cart.CustomProperties)
                {
                    message.AddHeader(prop.Name, prop.Value);
                }
                _messagingManager.Enqueue(message);
            }
        }

        private async Task<bool> SendWebOrderConfirmationEmail(OrderCreatedEvent orderCreatedEvent)
        {
            try
            {
                var request = new OrderConfirmationRequest()
                {
                    EmailHeader = new EmailHeader()
                    {
                        CompanyCode = orderCreatedEvent.Order.Cart.Company.Description(),
                        EmailFromAddress = "no-reply@cdwemail.com",
                        //just trying to dianogse the issue
                        ExternalEmailTransactionId =
                            string.Format("{0}{1}", "WEB" /*orderCreatedEvent.Order.Source.Name*/, Guid.NewGuid()),
                        FirstName = orderCreatedEvent.Order.Shipping.Address.FirstName,
                        LastName = orderCreatedEvent.Order.Shipping.Address.LastName,
                        EmailAddress = orderCreatedEvent.Order.Account.EmailAddress,
                        CustomerId = orderCreatedEvent.Order.Account.CustomerNumber,
                        //just trying to dianogse the issue
                        SystemOrigin = "WEB", //orderCreatedEvent.Order.Source.Name;
                        EmailType = "PSCCWebOrderConfirmation"
                    },

                    OrderNumber = orderCreatedEvent.Order.OrderNumber,
                    Source = orderCreatedEvent.Order.Source.Name,
                    BillingStreetAddressA = orderCreatedEvent.Order.Billing.Address.StreetAddress,
                    BillingCity = orderCreatedEvent.Order.Billing.Address.City,
                    BillingState = orderCreatedEvent.Order.Billing.Address.State,
                    BillingZipCode = orderCreatedEvent.Order.Billing.Address.PostalCode,
                    BillingCompanyName = orderCreatedEvent.Order.Billing.Address.Company,
                    //BillingDisplayName = orderCreatedEvent.Order.Billing.Address.FirstName + " " + orderCreatedEvent.Order.Billing.Address.LastName,
                    CustPhoneNumber = orderCreatedEvent.Order.Billing.Address.PhoneNumber,
                    ShippingMethod = orderCreatedEvent.Order.Shipping.Method.Rate.ShippingMethodDescription,
                    ShippingCost = orderCreatedEvent.Order.Shipping.Method.Rate.TotalShippingCharge.ToString("$#,###.00"),
                    CustUserName = orderCreatedEvent.Order.Billing.Address.FirstName + " " +
                                   orderCreatedEvent.Order.Billing.Address.LastName,
                    CustomerName = orderCreatedEvent.Order.Shipping.Address.FirstName + " " +
                                   orderCreatedEvent.Order.Shipping.Address.LastName,
                    DeliverFirstName = orderCreatedEvent.Order.Shipping.Address.FirstName,
                    DeliverLastName = orderCreatedEvent.Order.Shipping.Address.LastName,
                    DeliveryStreetAddressA = orderCreatedEvent.Order.Shipping.Address.StreetAddress,
                    DeliveryStreetAddressB = orderCreatedEvent.Order.Shipping.Address.SecondaryStreetAddress,
                    DeliveryCity = orderCreatedEvent.Order.Shipping.Address.City,
                    DeliveryState = orderCreatedEvent.Order.Shipping.Address.State,
                    DeliveryZipCode = orderCreatedEvent.Order.Shipping.Address.PostalCode,
                };

                decimal grandTotal = 0, subTotal = 0;
                //Add Cart Items
                var orderLines = new List<IOrderLine>();
                if (orderCreatedEvent.Order.Cart.Items != null)
                {
                    foreach (var item in orderCreatedEvent.Order.Cart.Items)
                    {
                        subTotal += item.UnitPrice * item.Quantity;

                        orderLines.Add(new OrderLine()
                        {
                            CdwPartNumber = GetManuPartNumIfNonSKUdProduct(item, item.Product.ProductCode),
                            ManufacturerPartNumber = GetManuPartNumIfNonSKUdProduct(item, item.Product.ManufacturePartNumber),
                            ProductName = GetManuPartNumIfNonSKUdProduct(item, item.Product.FriendlyName),
                            Quantity = item.Quantity.ToString(),
                            ItemPrice = item.UnitPrice.ToString("$#,###.00"),
                            ExtendedPrice = (item.UnitPrice * item.Quantity).ToString("$#,###.00"),
                            LinkToProduct = UrlLookups.GetSiteName(orderCreatedEvent.Order.Cart.Company, item.Product.ProductCode)
                        });
                    }
                }

                request.Subtotal = subTotal.ToString("$#,###.00");
                grandTotal = orderCreatedEvent.Order.Shipping.Method.Rate.TotalShippingCharge + subTotal;
                request.RequestedDate = GetDateTimeWithTimeZone(DateTime.Now, null);

                request.OrderLines = orderLines;
                //Add Recylcing Fees
                var fees = new List<IRecyclingFeeLine>();
                if (orderCreatedEvent.Order.RecyclingFees != null)
                {
                    foreach (var fee in orderCreatedEvent.Order.RecyclingFees)
                    {
                        fees.Add(new RecyclingFeeLine() { Name = fee.Code, Amount = fee.Amount.ToString("$#,###.00") });
                        grandTotal += fee.Amount;
                    }
                }

                request.RecyclingFees = fees;

                //Add Tax Lines
                decimal totalTax = 0;
                var taxLines = new List<ITaxLine>();
                if (orderCreatedEvent.Order.Taxes != null)
                {
                    foreach (var taxLine in orderCreatedEvent.Order.Taxes)
                    {
                        totalTax += taxLine.Amount;
                    }
                    taxLines.Add(new TaxLine() { Name = "SALES TAX", Amount = totalTax.ToString("$#,###.00") });
                }
                grandTotal += totalTax;
                request.GrandTotal = grandTotal.ToString("$#,###.00");
                request.TaxLines = taxLines;
                await _emailDomainManager.SendWebOrderConfirmationEmailAsync(request).ConfigureAwait(false);
                return true;
            }
            catch (Exception ex)
            {
                _log.Error(string.Format("Email API cannot be sent. Error message: {0}", ex.Message));
                return false;
            }
        }

        private string GetManuPartNumIfNonSKUdProduct(Partners.Orders.ICartItem item, string nonSkuLiteral)
        {
            var displayLiteral = nonSkuLiteral;
            if (item.Product.ProductCode != "NEW-ITEM")
            {
                return displayLiteral;
            }

            var manufacturerPartNumber = item.CustomProperties.First(p => p.Name == "ManufacturerPartNumber").Value;
            if (!string.IsNullOrEmpty(manufacturerPartNumber))
            {
                displayLiteral = manufacturerPartNumber;
            }

            return displayLiteral;
        }

        private string GetDateTimeWithTimeZone(DateTime dateTime, string format)
        {
            string sName = TimeZone.CurrentTimeZone.IsDaylightSavingTime(dateTime)
                ? TimeZone.CurrentTimeZone.DaylightName
                : TimeZone.CurrentTimeZone.StandardName;
            string[] sSplit = sName.Split(new[] { ' ' });
            var timeZone = sSplit.Where(s => s.Length >= 1).Aggregate("", (current, s) => current + s.Substring(0, 1));
            return string.Format("{0} {1}", dateTime.ToString(format), timeZone);
        }
    }
}