﻿using System.Linq;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.Extensions
{
    public static class OrderExtensions
    {
        public static decimal Quantity(this Order order, string productCode, decimal amount)
        {
            var quantity = (from i in order.Cart.Items
                            where i.Product.ProductCode == productCode
                            select i.Quantity).ToList();

            if (quantity.Any())
            {
                return ((int)quantity[0]) * amount;
            }

            return 0;
        }
    }
}