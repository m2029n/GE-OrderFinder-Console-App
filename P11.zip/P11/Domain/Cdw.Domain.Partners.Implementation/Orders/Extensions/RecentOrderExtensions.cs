﻿using Cdw.Ecommerce.Domain.Order;

namespace Cdw.Domain.Partners.Implementation.Orders.Extensions
{
    public static class RecentOrderExtensions
    {
        public static CompanyCode CompanyCodeEnum(this IRecentOrder order)
        {
            switch (order.CompanyCode)
            {
                case "01":
                    return CompanyCode.Cdw;

                case "02":
                    return CompanyCode.CdwG;

                case "17":
                    return CompanyCode.CdwCa;

                default:
                    return CompanyCode.Cdw;
            }
        }
    }
}