﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Orders.Extensions;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.Order;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Partners.Utilities;
using Common.Logging;
using CdwCompany = Cdw.Domain.Partners.Common.CdwCompany;
using IOrder = Cdw.Domain.Partners.Orders.IOrder;
using IOrderDetails = Cdw.Domain.Partners.Orders.IOrderDetails;

namespace Cdw.Domain.Partners.Implementation.Orders
{
    public class OrderManager : IOrderManager
    {
        private readonly ILog _logger;

        private readonly IOrderDomainManager _orderDomainManager;

        private readonly IProductManager _productManager;

        private readonly IOrderCreateHelperService _orderCreateHelperService;

        private readonly IGetAs400OrderDetailsService _as400OrderDetailsService;
        private readonly IPartnerConfigurationSettingsManager _configurationSettings;

        public OrderManager(
            ILog logger,
            IOrderDomainManager orderDomainManager,
            IProductManager productManager,
            IOrderCreateHelperService orderCreateHelperService,
            IGetAs400OrderDetailsService as400OrderDetailsService,
            IPartnerConfigurationSettingsManager configurationSettings)
        {
            _logger = logger;
            _orderDomainManager = orderDomainManager;
            _productManager = productManager;
            _orderCreateHelperService = orderCreateHelperService;
            _as400OrderDetailsService = as400OrderDetailsService;
            _configurationSettings = configurationSettings;
        }

        public async Task<IOrder> GetOrderAsync(string orderCode, ITrackingValues trackingValues, string clientName)
        {
            _logger.Debug("Get Order: Start", trackingValues);

            _logger.Debug("Step 1: GetOrderDetails", trackingValues);
            var partnerSettings = await _configurationSettings.GetPartnerConfigurationSettingsByNameAsync(clientName).ConfigureAwait(false);
            var order = await _orderCreateHelperService.GetOrderDetails(orderCode, partnerSettings.OrderManagerSettings.SourceCode).ConfigureAwait(false);
            if (order == null)
            {
                _logger.Debug("Step 1.1: No Order Found", trackingValues);
                return null;
            }
            _logger.Debug("Step 2: IsUploadedToAs400", trackingValues);
            _as400OrderDetailsService.Process(order, orderCode, trackingValues);//TODO: needs improvement

            ////Calcuate the other charges by adding on for Total Shipping Charges for only Black Box
            ////Total Shipping Charge = Freight + Insurance + Handling + OtherCharges
            //if (order.Source.Name.ToUpper() != "XDR" && order.Source.Name.ToUpper() != "XEC")
            order.Total = order.Cart.DiscountedSubtotal
                          + order.Tax
                          + order.Shipping.Method.Rate.TotalShippingCharge
                          + order.RecyclingFee;
            //else
            //        order.Total = order.Cart.DiscountedSubtotal
            //              + order.Tax
            //              + order.Shipping.Method.Rate.Freight
            //              + order.Shipping.Method.Rate.Insurance
            //              + order.Shipping.Method.Rate.Handling
            //              + order.RecyclingFee;

            _logger.Debug("Get Order: End", trackingValues);
            order.Company = partnerSettings.CompanyCode;
            return order;
        }

        public async Task<IOrder> CreateOrderAsync(IRequestOrder request)
        {
            if (request == null)
            {
                _logger.Debug("CreateOrderAsync failed: request is null");
                return null;
            }

            var partnerConfigurationSettings = await _configurationSettings.GetPartnerConfigurationSettingsByNameAsync(request.ClientName);
            request.PartnerSourceCode = partnerConfigurationSettings.OrderManagerSettings.SourceCode;
            request.PartnerFreightRaterSpecialCode = partnerConfigurationSettings.OrderManagerSettings.FreightRaterSpecialCode;

            // Validate company code with the key passed by the partner
            if (partnerConfigurationSettings.CompanyCode != request.Company)
            {
                throw new ApplicationException("Invalid Company Details");
            }

            AddOrderSourceCustomProperty(request, partnerConfigurationSettings.OrderManagerSettings.SourceCode);

            var trackingValues = request.TrackingValues;

            var creditCardResponse = await _orderCreateHelperService.ProcessCreditCardAsync(request,
                   () => _logger.Debug("Step 1: ValidateCreditCard", trackingValues)).ConfigureAwait(false);

            _orderCreateHelperService.ValidateTerms(request,
                () => _logger.Debug("Step 1.1: ValidateTerms", trackingValues));

            var authCreditCardToken = _orderCreateHelperService.GetAuthCreditCardToken(
                request,
                () => _logger.Debug("Step 1.2: Validate/Obtain Auth Credit Card Token", trackingValues));

            _logger.Debug("Step 2: CheckUniqueReferenceNumber", trackingValues);
            _orderCreateHelperService.CheckUniqueReferenceNumber(request);

            _logger.Debug("Step 3: HydrateOrder", trackingValues);
            var order = _orderCreateHelperService.GetOrderFromRequest(request);

            if (order == null)
            {
                _logger.Debug("CreateOrderAsync failed: order is null");
                return null;
            }

            _logger.Debug("Step 4: InsertCart", trackingValues);
            _orderCreateHelperService.InsertCart(order);

            _logger.Debug("Step 5: InsertPaymentInformation", trackingValues);
            _orderCreateHelperService.InsertPaymentInformation(order, trackingValues, creditCardResponse, authCreditCardToken);

            var step6 = _orderCreateHelperService.GetShippingInfoAsync(order, request, trackingValues,
                () => _logger.Debug("Step 6: GetShippingInfo", trackingValues));
            var step7 = _orderCreateHelperService.GetRecyclingFeeAsync(order,
                () => _logger.Debug("Step 7: GetRecyclingFee", trackingValues));

            await Task.WhenAll(step7, step6).ConfigureAwait(false);
            order.Shipping = await step6;
            order.RecyclingFee = await step7;

            order.Taxes = await _orderCreateHelperService.GetTaxesAsync(order, trackingValues, () => _logger.Debug("Step 8: GetTaxes", trackingValues)).ConfigureAwait(false);

            if (order.Shipping == null)
            {
                _logger.Debug("CreateOrderAsync failed: ShippingInfo object is null");
                return null;
            } // ks: added, call fails if no shipping is found
            if (order.Taxes == null)
            {
                _logger.Debug("CreateOrderAsync failed: Taxes object is null");
                return null;
            } // ks: added, call fails if no taxes are found

            _logger.Debug("Step 9: InsertOrder", trackingValues);
            order.OrderNumber = _orderCreateHelperService.InsertOrder(order, request);

            _logger.Debug("Step 10: PostToOrderWriter", trackingValues);
            await _orderCreateHelperService.PostToOrderWriterAsync(order, trackingValues).ConfigureAwait(false); // TODO: doesnt work if no Bundled products are there investigate

            _orderCreateHelperService.RaiseDomainEvents(order, request, trackingValues,
                () => _logger.Debug("Step 11: DomainEvents", trackingValues));

            _logger.Debug("Step 12: GetOrder", trackingValues);
            return await GetOrderSafeAsync(order, trackingValues, request.ClientName).ConfigureAwait(false);
        }

        private async Task<IOrder> GetOrderSafeAsync(IOrder order, ITrackingValues trackingValues, string requestClientName)
        {
            
            try
            {
                return await GetOrderAsync(order.OrderNumber, trackingValues, requestClientName).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.Error($"Create order / get for {requestClientName} failed with error ", ex, trackingValues);
                return order;
            }
        }

        public async Task<IOrderDetails> SearchOrderAsync(string customerNumber, string poNumber, ITrackingValues trackingValues)
        {
            var orders = await _orderDomainManager.GetOrderHeaderByPONumber(customerNumber, poNumber).ConfigureAwait(false);
            if (orders == null)
            {
                return null;
            }

            var result = await _orderDomainManager.GetOrderDetails(orders.CompanyCodeEnum(), orders.OrderCode, DataMap.Light).ConfigureAwait(false);
            var orderDetails = Mapper.Map<OrderDetails>(result);
            if (orderDetails == null)
            {
                return null;
            }
            var productCodes = orderDetails.LineItems.Select(x => x.ProductCode).ToList();

            //currently only adobe uses it and its company code is always cdw or 01
            var companyCode = CdwCompany.CDW.Description();

            var products = await _productManager.GetProductsAsync(productCodes, companyCode).ConfigureAwait(false);
            foreach (var o in orderDetails.LineItems)
            {
                foreach (var p in products.Where(p => p.ProductCode == o.ProductCode))
                {
                    o.FriendlyName = p.FriendlyName;
                    o.FriendlyDescription = p.FriendlyDescription;
                    o.ManuFacturePartNumber = p.ManufacturePartNumber;
                }
            }

            return orderDetails;
        }

        private void AddOrderSourceCustomProperty(IRequestOrder requestOrder, string sourceCode)
        {
            var orderSource = new CustomProperty() { Name = "OrderSource", Value = sourceCode };
            if (requestOrder.CustomProperties == null)
            {
                requestOrder.CustomProperties = new CustomProperty[] { };
            }

            requestOrder.CustomProperties = requestOrder.CustomProperties.Concat(new[] { orderSource }).ToArray();
        }
    }
}