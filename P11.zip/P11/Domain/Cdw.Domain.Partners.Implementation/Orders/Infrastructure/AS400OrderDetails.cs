﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Infrastructure.Services;
using Cdw.Services.OrderStatus.Client;
using Cdw.Services.OrderStatus.Client.Models;
using Common.Logging;
using CartItemStatus = Cdw.Domain.Partners.Orders.CartItemStatus;
using Order = Cdw.Domain.Partners.Orders.Order;

namespace Cdw.Domain.Partners.Implementation.Orders.Infrastructure
{
    internal class AS400OrderDetails : IAS400OrderDetails
    {
        private readonly IOrderStatusClient _orderStatusClient;
        private readonly IOrdersWebService _ordersWebService;
        private readonly ILog _logger;
        private readonly IPartnerOrderRepository _partnerOrderRepository;

        private readonly Dictionary<string, CartItemStatus> _cartItemStatuses =
            new Dictionary<string, CartItemStatus>
            {
                {"BackOrdered", CartItemStatus.Backordered},
                {"Backordered", CartItemStatus.Backordered},
                {"C", CartItemStatus.Shipped},
                {"X", CartItemStatus.Canceled},
                {"Complete", CartItemStatus.Shipped},
                {"Canceled", CartItemStatus.Canceled},
                {"Not Shipped", CartItemStatus.Pending},
                {"WaitingForPickup", CartItemStatus.Pending},
                {"ShippedFromWillCall", CartItemStatus.Shipped},
                {"Shipped", CartItemStatus.Shipped},
                {"Partial", CartItemStatus.Partial}
            };

        private readonly Dictionary<string, OrderStatus> _orderStatuses =
            new Dictionary<string, OrderStatus>
            {
                {"BackOrdered", OrderStatus.BackorderedItems},
                {"Shipped", OrderStatus.Shipped},
                {"Canceled", OrderStatus.Canceled},
                {"Not Shipped", OrderStatus.Processing},
                {"WaitingForPickup", OrderStatus.Processing},
                {"ShippedFromWillCall", OrderStatus.Shipped}
            };

        public AS400OrderDetails(
            ILog logger,
            IOrderStatusClient orderStatusClient,
            IOrdersWebService ordersWebService,
            IPartnerOrderRepository partnerOrderRepository)
        {
            _orderStatusClient = orderStatusClient;
            _ordersWebService = ordersWebService;
            _logger = logger;
            _partnerOrderRepository = partnerOrderRepository;
        }

        public void HydrateOrder(Order order, IOrderDetail orderDetail)
        {
            var boxes = GetOrderBoxes(order.OrderNumber);

            //As as400 lineitem contacts recycling fee productcode as well, we are ignoring it using this query
            //Reason being we have a seperate recycling fee collection now, we don't want to use recycling fee from
            //as400.
            IList<IOrderLine> as400OrderLines = new List<IOrderLine>();
            if (order.RecyclingFees != null)
            {
                foreach (var od in orderDetail.OrderLines)
                {
                    var rc = order.RecyclingFees.Where(r => r.ProductFeeEDC != od.ProductCode);
                    if (rc.Any())
                    {
                        as400OrderLines.Add(od);
                    }
                }
            }
            else
            {
                as400OrderLines = orderDetail.OrderLines.ToList();
            }

            var cart = GetAs400Cart(order.Cart, as400OrderLines);

            order.Status = GetOrderStatus(orderDetail.OrderHeader.OrderStatus,
                as400OrderLines,
                orderDetail.OrderHeader.SuspendCode);
            order.Shipments = CreateShipments(boxes, orderDetail.OrderHeader.ShippingCarrier);
            order.Cart = cart;
        }

        private IEnumerable<IShipment> CreateShipments(IEnumerable<Box> boxes, string shipMethodId)
        {
            if (boxes == null)
            {
                return Enumerable.Empty<IShipment>();
            }

            foreach (var box in boxes)
            {
                box.LoadTrackingDetail();
            }

            var shipments = boxes.Select(
                b => new Shipment
                {
                    InvoiceNumber = b.InvoiceNumber,
                    Box = b.BoxNumber,
                    ShippedDate = b.ShipDate ?? DateTime.MinValue,
                    ShippingMethod = new ShippingMethod { Id = shipMethodId, Description = b.ShipMethod },
                    TrackingNumber = b.TrackingNumber,
                    TrackingUrl = b.TrackingDetail != null ? b.TrackingDetail.TrackingUrl : string.Empty,
                    Weight = b.Weight ?? 0.0M,
                    Contents =
                        b.Contents.Select(c => new ShippedItem
                        {
                            ProductCode = c.EDC,
                            Quantity = c.QuantityInBox ?? 0,
                            ManufacturerPartNumber = c.ManufacturerPartNumber
                        })
                });

            return shipments;
        }

        private OrderStatus GetOrderStatus(string orderStatus, IEnumerable<IOrderLine> orderLines, string suspendCode)
        {
            OrderStatus retrievedStatus;
            const string backOrderSuspendCode = "WX";

            var status = _orderStatuses.TryGetValue(orderStatus, out retrievedStatus)
                             ? retrievedStatus
                             : OrderStatus.Processing;
            if (status == OrderStatus.BackorderedItems || status == OrderStatus.Processing)
            {
                var enumerable = orderLines as IList<IOrderLine> ?? orderLines.ToList();

                var partiallyShippedItems = from p in enumerable
                                            where enumerable.Any(val => val.QuantityOutstanding > 0)
                                            where enumerable.Any(val => val.QuantityDispatched > 0)
                                            select p;

                if (partiallyShippedItems.Any())
                {
                    status = OrderStatus.PartiallyShipped;
                }

                if (backOrderSuspendCode.Equals(suspendCode, StringComparison.Ordinal))
                {
                    status = OrderStatus.BackorderedItems;
                }
            }
            return status;
        }

        private ICart GetAs400Cart(ICart cart, IEnumerable<IOrderLine> orderLines)
        {
            var cartT = (Cart)cart;
            var activeCartItems = GetActiveCartItems(cartT.Items, orderLines);
            cartT.Items.Clear();
            cartT.Items = activeCartItems.ToList();
            return cart;
        }

        private IEnumerable<ICartItem> GetActiveCartItems(IList<ICartItem> cartItems, IEnumerable<IOrderLine> orderLines)
        {
            var enumerable = orderLines as IList<IOrderLine> ?? orderLines.ToList();

            List<ICartItem> cartItemsInCartAndOnOrder;

            //Compare additionally with Price and Quantity in case of generic non-SKU item per discussion with Scott.T
            //Restrict additional comparison to only orders with non-SKU item.
            if (enumerable.Any(x => x.ProductCode == "NEW-ITEM"))
            {
                cartItemsInCartAndOnOrder =
                (from orderLine in enumerable
                 from cartItem in cartItems
                 where orderLine.ProductCode == cartItem.Product.ProductCode
                 where orderLine.Price == cartItem.DiscountedUnitPrice
                 where orderLine.Quantity == cartItem.Quantity
                 select CreateCartItem(orderLine, cartItem)).ToList();
            }
            else
            {
                cartItemsInCartAndOnOrder =
                    (from orderLine in enumerable
                     from cartItem in cartItems
                     where orderLine.ProductCode == cartItem.Product.ProductCode
                     select CreateCartItem(orderLine, cartItem)).ToList();
            }

            var productsByCode = _partnerOrderRepository
                .GetProduct(enumerable.Select(c => c.ProductCode).Distinct())
                .ToDictionary(p => p.ProductCode);

            var cartItemsNotInOriginalCart = enumerable
                .Where(orderLine => cartItems.All(c => c.Product.ProductCode != orderLine.ProductCode))
                .Select(orderLine => CreateCartItem(orderLine, productsByCode));

            return cartItemsInCartAndOnOrder
                .Union(cartItemsNotInOriginalCart)
                .ToList();
        }

        private ICartItem CreateCartItem(
          IOrderLine orderLine,
          IDictionary<string, ProductEntity> productsByCode)
        {
            var orderLineStatus = orderLine.OrderLineStatus;

            if (orderLine.QuantityDispatched > 0 && orderLine.QuantityOutstanding > 0)
            {
                orderLineStatus = "Partial";
            }

            var cartItem = new CartItem
            {
                Product = Mapper.Map<IProduct>(productsByCode[orderLine.ProductCode]),
                Quantity = (uint)orderLine.Quantity,
                UnitPrice = orderLine.Price,
                Status = GetCartItemStatus(orderLineStatus),
                Discounts = new CartItemDiscounts
                {
                    FixedLinePriceDiscounts = new List<IDiscount>(),
                    FixedUnitPriceDiscounts = new List<IDiscount>(),
                    PercentOffLinePriceDiscounts = new List<IDiscount>(),
                    PercentOffUnitPriceDiscounts = new List<IDiscount>()
                }
            };
            return cartItem;
        }

        private ICartItem CreateCartItem(IOrderLine orderLine, ICartItem originalCartItem)
        {
            var orderLineStatus = orderLine.OrderLineStatus.Trim();
            if (orderLine.QuantityDispatched > 0 && orderLine.QuantityOutstanding > 0)
            {
                orderLineStatus = "Partial";
            }

            var cartItem = new AS400CartItem
            {
                Product = originalCartItem.Product,
                Quantity = (uint)orderLine.Quantity,
                UnitPrice = orderLine.Price,
                Status = GetCartItemStatus(orderLineStatus),
                Discounts = originalCartItem.Discounts,
                CustomProperties = originalCartItem.CustomProperties,
                DiscountedLinePrice = orderLine.Price * orderLine.Quantity,
                LinePrice = originalCartItem.LinePrice
            };

            return cartItem;
        }

        private CartItemStatus GetCartItemStatus(string cartItemStatus)
        {
            if (cartItemStatus == null)
            {
                return CartItemStatus.Pending;
            }
            CartItemStatus retrievedStatus;
            var status = _cartItemStatuses.TryGetValue(cartItemStatus, out retrievedStatus)
                            ? retrievedStatus
                            : CartItemStatus.Pending;
            return status;
        }

        private IEnumerable<Box> GetOrderBoxes(string orderCode)
        {
            _logger.DebugFormat("Retrieving boxes for order {0}", orderCode);
            try
            {
                var client = _orderStatusClient;

                var order = client.GetOrder(orderCode);

                if (order != null)
                {
                    _logger.DebugFormat(
                        "Retrieved {0} boxes for order {1}",
                        order.Boxes.Count(),
                        orderCode);
                    return order.Boxes;
                }

                _logger.Debug("Retrieved order from OrderStatusClient was null");
                return null;
            }
            catch
            {
                return null;
            }
        }
    }
}