﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//
//using Cdw.Domain.Partners.Orders;

//namespace Cdw.Domain.Partners.Implementation.Orders.Infrastructure
//{
//   internal static class DiscountCalculator
//    {
//        public static decimal CalculateDiscountValue(ICart cart)
//        {
//            var cartSubtotal = cart.Subtotal;

//            var totalDiscount = CalculateTotalFixedDiscount(cart)
//                + CalculateTotalPercentDiscount(cart);

//            return Math.Min(cart.Subtotal, totalDiscount);
//        }

//        private static decimal CalculateTotalPercentDiscount(ICart cart)
//        {
//            return Math.Round(cart.Discounts.PercentOffDiscounts
//                    .Select(d => (d.Amount / 100m) * cart.Subtotal)
//                    .Sum(), 2);
//        }

//        private static decimal CalculateTotalFixedDiscount(ICart cart)
//        {
//            return cart.Discounts.FixedAmountDiscounts.Sum(d => d.Amount);
//        }

//        public static void AddDiscountsToCartItem(
//             ICartItem cartItem,
//             IEnumerable<IDiscount> lineItemDiscounts)
//        {
//           var itemDiscounts = lineItemDiscounts as IDiscount[] ?? lineItemDiscounts.ToArray();

//           AddDiscounts(
//                cartItem,
//                CreateFixedAmountOffUnitPriceDiscounts(itemDiscounts),
//                d => d.FixedUnitPriceDiscounts);
//            AddDiscounts(
//                cartItem,
//                CreatePercentOffUnitPriceDiscounts(itemDiscounts),
//                d => d.PercentOffUnitPriceDiscounts);
//            AddDiscounts(
//                cartItem,
//                CreateFixedAmountOffLinePriceDiscounts(itemDiscounts),
//                d => d.FixedLinePriceDiscounts);
//            AddDiscounts(
//                cartItem,
//                CreatePercentOffLinePriceDiscounts(itemDiscounts),
//                d => d.PercentOffUnitPriceDiscounts);
//        }
//        private static void AddDiscounts(
//           Cdw.Domain.Partners.Orders.ICartItem cartItem,
//           IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> discounts,
//           Func<Cdw.Domain.Partners.Orders.ICartItemDiscounts, IList<Cdw.Domain.Partners.Orders.IDiscount>> listSelector)
//        {
//            foreach (var discount in discounts)
//            {
//                listSelector(cartItem.Discounts).Add(discount);
//            }
//        }

//       private static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreateDiscounts(
//          IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models,
//          int discountType)
//       {
//           return models
//               .Where(d => d.Type == discountType)
//               .Select(d => new Discount() { Id = d.Id, Amount = d.Amount, Type = discountType });
//       }

//        public static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreateFixedAmountOffOrderDiscounts(
//          IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1000);
//        }

//        public static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreatePercentOffOrderDiscounts(
//            IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1001);
//        }

//       private static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreatePercentOffLinePriceDiscounts(
//          IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1005);
//        }
//       private static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreateFixedAmountOffUnitPriceDiscounts(
//            IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1002);
//        }

//       private static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreatePercentOffUnitPriceDiscounts(
//            IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1003);
//        }

//       private static IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> CreateFixedAmountOffLinePriceDiscounts(
//            IEnumerable<Cdw.Domain.Partners.Orders.IDiscount> models)
//        {
//            return CreateDiscounts(models, 1004);
//        }
//    }
//}