﻿using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.Services;

namespace Cdw.Domain.Partners.Implementation.Orders.Infrastructure
{
    public interface IAS400OrderDetails
    {
        void HydrateOrder(Order order, IOrderDetail orderDetail);
    }
}