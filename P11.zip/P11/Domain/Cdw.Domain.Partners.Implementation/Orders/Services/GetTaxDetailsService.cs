﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Clients.Tax;
using Cdw.Partners.Utilities;
using Cdw.Security.OAuth2.Client;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class GetTaxDetailsService : IGetTaxDetailsService
    {
        private readonly ILog _logger;
        private readonly ITaxRequestClientDomainManager _taxRequestDomainManager;

        public GetTaxDetailsService(ILog logger, ITaxRequestClientDomainManager taxRequestDomainManager)
        {
            _logger = logger;
            _taxRequestDomainManager = taxRequestDomainManager;
        }

        public async Task<IEnumerable<Partners.Orders.Tax>> ProcessAsync(Order order, ITrackingValues trackingValues)
        {
            var tax = Mapper.Map<ITaxRequest>(order);
            try
            {
                _logger.Debug(tax, "tax input", trackingValues);
                var itaxentity = await _taxRequestDomainManager.WithTracking(trackingValues).GetTaxLinesAsync(tax).ConfigureAwait(false);
                _logger.Debug(itaxentity, "tax output", trackingValues);

                var query =
                    (from h in itaxentity.Headers where h.Amount != 0 select h).Union
                    (from l in itaxentity.LineItems where l.Amount != 0 select l);

                var querycombined = query.GroupBy(t => new { t.Id, t.Rate })
                    .Select(at => new Partners.Orders.Tax
                    {
                        Id = at.Key.Id,
                        Rate = at.Key.Rate,
                        Description = at.First().Description,
                        Amount = Math.Max(0, at.Sum(f => f.Amount))
                    });
                return querycombined.ToList();
            }
            catch (CdwHttpException ex)
            {
                _logger.Error("Tax Failed: Type CdwHttpException", ex, trackingValues, tax);
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error("Tax Failed: Type Exception", ex, trackingValues, tax);
                throw;
            }
        }
    }
}