﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Partners.Validation;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.Events;
using Cdw.Partners.Validation;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class OrderCreateHelperService : IOrderCreateHelperService
    {
        private readonly IPartnerOrderService _partnerOrderService;

        private readonly IGetFreightRaterService _freightRaterService;

        private readonly IGetRecycleDetailsService _recycleDetailsService;

        private readonly IGetTaxDetailsService _taxDetailsService;

        private readonly IProcessCreditCardService _processCreditCardService;

        private readonly IPostToOrderWriterDomainService _orderWriterDomainManagerService;

        public OrderCreateHelperService(IPartnerOrderService partnerOrderService,
            IGetFreightRaterService freightRaterService,
            IGetRecycleDetailsService recycleDetailsService,
            IGetTaxDetailsService taxDetailsService,
            IProcessCreditCardService processCreditCardService,
            IPostToOrderWriterDomainService orderWriterDomainManagerService

           )
        {
            _partnerOrderService = partnerOrderService;
            _freightRaterService = freightRaterService;
            _recycleDetailsService = recycleDetailsService;
            _taxDetailsService = taxDetailsService;
            _processCreditCardService = processCreditCardService;
            _orderWriterDomainManagerService = orderWriterDomainManagerService;
        }

        public Order GetOrderFromRequest(IRequestOrder request)
        {
            //TODO: dictionary improve
            var iOrder = Mapper.Map<Order>(request);

            var productMatches = _partnerOrderService.GetProductEntities(request.LineItems.Select(li => li.ProductCode).Distinct().ToList()).ToDictionary(p => p.ProductCode);

            //todo: get bundle logic for products , currently product api does not support bundle logic.
            var failures =
                from p in productMatches
                where p.Value == null
                select
                    new FailedRequestValidationResult("ProductCode", $"Product with code '{p.Key}' could not be found");

            var orderValidationFailures = failures as FailedRequestValidationResult[] ?? failures.ToArray();

            if (orderValidationFailures.Any())
            {
                throw new OrderValidationException(orderValidationFailures);
            }

            foreach (var lineItem in request.LineItems)
            {
                var product = Mapper.Map<IProduct>(productMatches[lineItem.ProductCode.Trim()]);
                var cartItem = Mapper.Map<ILineItem, CartItem>(lineItem);
                cartItem.Product = product;
                iOrder.Cart.Items.Add(cartItem);
            }

            return iOrder;
        }

        public Task<ShippingInfo> GetShippingInfoAsync(Order order, IRequestOrder request, ITrackingValues trackingValues, Action loggerAction)
        {
            loggerAction?.Invoke();
            return _freightRaterService.ProcessAsync(order, request, trackingValues);
        }

        public Task<decimal> GetRecyclingFeeAsync(Order order, Action loggerAction)
        {
            loggerAction?.Invoke();
            return _recycleDetailsService.ProcessAsync(order);
        }

        public Task<IEnumerable<Partners.Orders.Tax>> GetTaxesAsync(Order order, ITrackingValues trackingValues, Action loggerAction)
        {
            loggerAction?.Invoke();
            return _taxDetailsService.ProcessAsync(order, trackingValues);
        }

        public void ValidateTerms(IRequestOrder request, Action loggerAction)
        {
            if (!string.IsNullOrEmpty(request.Billing.Method.Terms) && request.Billing.Method.CreditCard == null)
            {
                loggerAction?.Invoke();
                _partnerOrderService.ValidateTerms(request);
            }
        }

        public void CheckUniqueReferenceNumber(IRequestOrder request)
        {
            _partnerOrderService.CheckUniqueReferenceNumber(request);
        }

        public void InsertCart(Order order)
        {
            _partnerOrderService.InsertCart(order);
        }

        public void InsertPaymentInformation(Order order, ITrackingValues trackingValues, ICreditCardAuthorizationResponse creditCardResponse, string authCreditCardToken)
        {
            _partnerOrderService.InsertPaymentInformation(order, trackingValues, creditCardResponse, authCreditCardToken);
        }

        public string GetAuthCreditCardToken(IRequestOrder request, Action loggerAction)
        {
            loggerAction?.Invoke();
            return _partnerOrderService.GetAuthCreditCardToken(request.Billing.Method.TransactionId, request.Billing.Method.ReferenceNumber);
        }

        public string InsertOrder(Order order, IRequestOrder request)
        {
            return _partnerOrderService.InsertOrder(order, request);
        }

        public async Task<Order> GetOrderDetails(string orderCode, string sourceCode)
        {
            var order = _partnerOrderService.GetOrderDetails(orderCode, sourceCode);
            if (order == null)
            {
                return null;
            }
            order.RecyclingFee = await _recycleDetailsService.ProcessAsync(order).ConfigureAwait(false);
            return order;
        }

        public async Task<ICreditCardAuthorizationResponse> ProcessCreditCardAsync(IRequestOrder request, Action loggerAction)
        {
            if (request.Billing.Method.CreditCard != null && string.IsNullOrEmpty(request.Billing.Method.Terms)
                && string.IsNullOrEmpty(request.Billing.Method.TransactionId))
            {
                loggerAction?.Invoke();
                return await _processCreditCardService.ProcessAsync(request).ConfigureAwait(false);
            }
            return null;
        }

        public async Task PostToOrderWriterAsync(Order order, ITrackingValues trackingValues)
        {
           await  _orderWriterDomainManagerService.Process(order, trackingValues).ConfigureAwait(false);
        }

        public void RaiseDomainEvents(Order order, IRequestOrder request, ITrackingValues trackingValues, Action loggerAction)
        {
            loggerAction?.Invoke();
            DomainEvents.Raise(new OrderCreatedEvent(order));
        }
    }
}