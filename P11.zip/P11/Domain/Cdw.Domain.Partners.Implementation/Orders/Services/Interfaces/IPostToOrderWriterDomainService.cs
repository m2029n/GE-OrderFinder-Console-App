﻿using System.Threading.Tasks;
using Cdw.Common;
using Order = Cdw.Domain.Partners.Orders.Order;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IPostToOrderWriterDomainService
    {
        Task Process(Order order, ITrackingValues trackingValues);
    }
}