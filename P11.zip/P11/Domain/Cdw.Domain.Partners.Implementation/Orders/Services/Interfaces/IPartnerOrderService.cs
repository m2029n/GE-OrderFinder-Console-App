﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.PartnerOrder;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IPartnerOrderService
    {
        void CheckUniqueReferenceNumber(IRequestOrder request);

        bool ValidateTerms(IRequestOrder request);

        IEnumerable<ProductEntity> GetProductEntities(IEnumerable<string> productCodes);

        Task<ShippingMethodPropertiesEntity> GetShippingMethodPropertyAsync(string clientName, string shippingMethod);

        void InsertCart(Order order);

        void InsertPaymentInformation(Order order, ITrackingValues trackingValues
                                        , ICreditCardAuthorizationResponse creditCardResponse
                                        , string authCreditCardToken);

        string InsertOrder(Order order, IRequestOrder request);

        string GetPaymentCode(string sourceName, string methodTerms);

        Order GetOrderDetails(string orderCode, string sourceCode);

        bool IsUploadedToAs400(string orderCode);

        string GetAuthCreditCardToken(string transactionId, string referenceNumber);
    }
}