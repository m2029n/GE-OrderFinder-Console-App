﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IGetTaxDetailsService
    {
        Task<IEnumerable<Partners.Orders.Tax>> ProcessAsync(Order order, ITrackingValues trackingValues);
    }
}