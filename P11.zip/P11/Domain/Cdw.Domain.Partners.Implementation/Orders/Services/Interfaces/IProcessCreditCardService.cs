﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IProcessCreditCardService
    {
        Task<ICreditCardAuthorizationResponse> ProcessAsync(IRequestOrder request);
    }
}