﻿using System.Threading.Tasks;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IGetFreightRaterService
    {
        Task<ShippingInfo> ProcessAsync(Order order, IRequestOrder request, ITrackingValues trackingValues);
    }
}