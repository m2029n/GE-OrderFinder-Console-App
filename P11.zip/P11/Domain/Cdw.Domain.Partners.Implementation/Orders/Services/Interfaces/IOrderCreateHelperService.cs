﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Common;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IOrderCreateHelperService
    {
        Order GetOrderFromRequest(IRequestOrder request);

        Task<ShippingInfo> GetShippingInfoAsync(Order order, IRequestOrder request, ITrackingValues trackingValues, Action loggerAction);

        Task<decimal> GetRecyclingFeeAsync(Order order, Action loggerAction);

        Task<IEnumerable<Partners.Orders.Tax>> GetTaxesAsync(Order order, ITrackingValues trackingValues, Action loggerAction);

        void ValidateTerms(IRequestOrder request, Action loggerAction);

        void CheckUniqueReferenceNumber(IRequestOrder request);

        void InsertCart(Order order);

        void InsertPaymentInformation(Order order, ITrackingValues trackingValues,
                                      ICreditCardAuthorizationResponse creditCardResponse,
                                      string authCreditCardToken);

        string InsertOrder(Order order, IRequestOrder request);

        Task<Order> GetOrderDetails(string orderCode, string sourceCode);

        Task<ICreditCardAuthorizationResponse> ProcessCreditCardAsync(IRequestOrder request, Action loggerFunc);

        Task PostToOrderWriterAsync(Order order, ITrackingValues trackingValues);

        void RaiseDomainEvents(Order order, IRequestOrder request, ITrackingValues trackingValues, Action action);

        string GetAuthCreditCardToken(IRequestOrder request, Action loggerAction);
    }
}