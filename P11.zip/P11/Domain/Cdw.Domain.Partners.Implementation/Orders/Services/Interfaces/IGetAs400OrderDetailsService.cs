﻿using Cdw.Common;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IGetAs400OrderDetailsService
    {
        void Process(Order order, string orderCode, ITrackingValues trackingValues);
    }
}