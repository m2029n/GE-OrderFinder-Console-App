﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public interface IGetRecycleDetailsService
    {
        Task<decimal> ProcessAsync(Order order);
    }
}