﻿using System.Linq;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Orders.Infrastructure;
using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.Services;
using Cdw.Partners.Utilities;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class GetAs400OrderDetailsService : IGetAs400OrderDetailsService
    {
        private readonly IAS400OrderDetails _as400OrderDetails;
        private readonly IOrdersWebService _ordersWebService;
        private readonly ILog _logger;
        private readonly IPartnerOrderService _partnerOrderService;

        public GetAs400OrderDetailsService(
            ILog logger,
            IPartnerOrderService partnerOrderService,
            IOrdersWebService ordersWebService,
            IAS400OrderDetails as400OrderDetails)
        {
            _logger = logger;
            _partnerOrderService = partnerOrderService;
            _ordersWebService = ordersWebService;
            _as400OrderDetails = as400OrderDetails;
        }

        public void Process(Order order, string orderCode, ITrackingValues trackingValues)
        {
            var isUploadedAs400 = _partnerOrderService.IsUploadedToAs400(orderCode);

            if (isUploadedAs400)
            {
                _logger.Debug($"Step 2.1: Check if order {orderCode} is uploaded in As400", trackingValues);
                IOrderDetail orderDetail = _ordersWebService.GetOrderDetailByOrderCode(order.OrderNumber);

                if (orderDetail.OrderHeader.OrderCode != null && orderDetail.OrderLines.ToList().Any())
                {
                    _logger.Debug($"Step 2.2: Retrieving order {orderCode} from AS400", trackingValues);
                    //Step 3: if yes Hydrate order details from AS400
                    // var as400 = new AS400OrderDetails(_logger, _orderStatusClient, _ordersWebService, _partnerOrderRepository);
                    _as400OrderDetails.HydrateOrder(order, orderDetail);
                    _logger.Debug("Step 3: HydrateOrder", trackingValues);
                }
            }
        }
    }
}