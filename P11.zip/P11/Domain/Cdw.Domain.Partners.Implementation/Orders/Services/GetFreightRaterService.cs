using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Partners.Validation;
using Cdw.Clients.Freight;
using Cdw.Common;
using Cdw.Domain.Partners.Implementation.Freight.FreightDomain;
using Cdw.Domain.Partners.Implementation.Orders.Enterprise;
using Cdw.Domain.Partners.Orders;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Cdw.Security.OAuth2.Client;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class GetFreightRaterService : IGetFreightRaterService
    {
        private readonly ILog _logger;
        private readonly IRatingClientManager _ratingManager;
        private readonly IPartnerOrderService _partnerOrderService;

        public GetFreightRaterService(ILog logger, IPartnerOrderService partnerOrderService, IRatingClientManager ratingManager)
        {
            _logger = logger;
            _ratingManager = ratingManager;
            _partnerOrderService = partnerOrderService;
        }

        public async Task<ShippingInfo> ProcessAsync(Order order, IRequestOrder request, ITrackingValues trackingValues)
        {
            var orderValidationFailures = new List<IOrderValidationFailure>
            {
                new FailedRequestValidationResult("Method.Id",
                    "Requested shipping method is not available due to location or product constraints. Please contact CDW to place the order."
                    )
            };

            var products = order.Cart.Items
                      .SelectMany(ci =>
                {
                    return ci.Product.IsBundle
                        ? ci.Product.BundledProducts
                            .Select(bp => new CartItem { Product = bp.Product, Quantity = (uint)bp.Quantity })
                        : new[]
                            {new CartItem {Product = ci.Product, Quantity = ci.Quantity, UnitPrice = ci.UnitPrice}};
                }).ToList();

            var ratingRequest = Mapper.Map<RatingRequest>(order);
            ratingRequest.ItemsToShip = products.Select((x, index) => new RatingRequestFreightItem
            {
                ContractReferenceNumber = null,
                OrderLineNumber = index + 1,
                ProductCode = x.Product.ProductCode,
                UnitPrice = x.UnitPrice,
                Quantity = (int)x.Quantity
            });

            try
            {
                var shippingMethodOverride = new ShippingMethod
                {
                    Id = order.Shipping.Method.Id,
                    Description = order.Shipping.Method.Description,
                    Rate = order.Shipping.Method.Rate
                };

                //Step 1 is a very xerox specific logic.
                //step 1:
                //Free shipping method logic, when freight is 0 consider given shipping method to be of type free.
                //and if free shipping map is not found in "webdbo.dbo.API_Orders_ShippingMethodProperties" table throw error.
                if (request.Freight == 0)
                {
                    var shippingMethodEntity =
                        await _partnerOrderService.GetShippingMethodPropertyAsync(request.ClientName,
                            shippingMethodOverride.Id).ConfigureAwait(false);

                    if (shippingMethodEntity?.FreeShippingMethod != null)
                    {
                        shippingMethodOverride.Id = shippingMethodEntity.FreeShippingMethod;
                    }
                    else
                    {
                        throw new OrderValidationException(orderValidationFailures);
                    }
                }

                //step 2:
                //if we have the shipping method either free from the table "API_Orders_ShippingMethodProperties" or directly from the payload with freight greater than 0
                // make a call to freight api with that shipping method
                _logger.Debug(ratingRequest, "Freight input", trackingValues);
                var freightRaterResponse = await _ratingManager.WithTracking(trackingValues).RateAsync(ratingRequest)
                    .ConfigureAwait(false);
                _logger.Debug(freightRaterResponse, "Freight output", trackingValues);

                //step 3:
                //validate if there was any error in freight call or no shipping methods were found
                //if yes , throw an error.
                if (!string.IsNullOrEmpty(freightRaterResponse.ErrorMessage) ||
                    !freightRaterResponse.Freight.ShippingMethods.Any())
                {
                    throw new ApplicationException(
                        "Unable to process this order through the API. Please contact CDW to place the order.");
                }

                //step 4: no error in freight call
                //but the corresponding map shipping method from "API_Orders_ShippingMethodProperties" was not found in the freight output throw an error.
                var shippingMethod = freightRaterResponse.Freight.ShippingMethods.FirstOrDefault(x =>
                    string.Equals(x.Code, shippingMethodOverride.Id, StringComparison.CurrentCultureIgnoreCase));
                if (shippingMethod == null)
                {
                    throw new OrderValidationException(orderValidationFailures);
                }

                IOrderShippingRate shippingRate = ShippingRateConverter.Convert(shippingMethodOverride.Id, freightRaterResponse);

                var address = order.Shipping.Address;
                var shippingInfoResult = new ShippingInfo
                {
                    Address = address,
                    Method = new ShippingMethod
                    {
                        Id = shippingRate.ShippingMethodId,
                        Description = shippingRate.ShippingMethodDescription,
                        Rate = shippingRate
                    }
                };
                return shippingInfoResult;
            }
            catch (CdwHttpException ex)
            {
                _logger.Error("Freight Failed: CdwHttpException", ex, trackingValues, ratingRequest);
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error("Freight Failed: Type Exception", ex, trackingValues, ratingRequest);
                throw;
            }
        }
    }
}