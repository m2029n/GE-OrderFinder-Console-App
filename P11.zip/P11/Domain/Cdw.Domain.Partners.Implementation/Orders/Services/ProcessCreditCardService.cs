﻿using AutoMapper;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Common.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CreditCardAuthorizationRequest = Cdw.Domain.Partners.Implementation.Orders.CreditCardService.CreditCardAuthorizationRequest;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class ProcessCreditCardService : IProcessCreditCardService
    {
        private readonly ICreditCardServiceDomainManager _creditCardServiceDomainManager;
        private readonly IPartnerSettings _partnerSettings;
        private readonly ILog _logger;

        public ProcessCreditCardService(ILog logger, ICreditCardServiceDomainManager creditCardServiceDomainManager, IPartnerSettings partnerSettings)
        {
            _logger = logger;
            _creditCardServiceDomainManager = creditCardServiceDomainManager;
            _partnerSettings = partnerSettings;
        }

        public async Task<ICreditCardAuthorizationResponse> ProcessAsync(IRequestOrder request)
        {
            ICreditCardAuthorizationResponse creditCardResponse;

            try
            {
                var result = await _creditCardServiceDomainManager.EncryptAsync(request.Billing.Method.CreditCard.Number,
                        _partnerSettings.CreditCardAPIKey).ConfigureAwait(false);
                var ccRequest = Mapper.Map<CreditCardAuthorizationRequest>(request.Billing.Method.CreditCard);

                ccRequest.EncryptedCreditCardText = result.EncryptedInfo;

                creditCardResponse = await _creditCardServiceDomainManager.AuthorizeAsync(ccRequest).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                //supress any hard exception which we will get if ETS is down and process order with blank Credit Card Details.
                _logger.Error("CreditCardService Failed", ex);
                return null;
            }

            if (!creditCardResponse.IsValid)
            {
                // If ETS gives us any exception other than E1000 or E2000, which are invalid card and invalid expiry date
                // throw a new exception which will be caught in controller logged and api would return "Order could not be created" message.
                if (creditCardResponse.ErrorCode == "E1000" || creditCardResponse.ErrorCode == "E2000")
                {
                    var validationmessage = new List<IOrderValidationFailure>
                    {
                        new FailedRequestValidationResult("CreditCard", creditCardResponse.ErrorMessage)
                    };
                    throw new OrderValidationException(validationmessage);
                }
                throw new ApplicationException($"CreditCardService Failed with message : {creditCardResponse.ErrorMessage}");
            }

            return creditCardResponse;
        }
    }
}