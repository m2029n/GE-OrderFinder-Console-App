using Cdw.Api.Partners.Model.Recycling;
using Cdw.Domain.Partners.Implementation.Orders.Extensions;
using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Partners.Recycling;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class GetRecycleDetailsService : IGetRecycleDetailsService
    {
        private readonly IRecyclingDomainManager _recyclingDomainManager;

        public GetRecycleDetailsService(IRecyclingDomainManager recyclingDomainManager)
        {
            _recyclingDomainManager = recyclingDomainManager;
        }

        public async Task<decimal> ProcessAsync(Order order)
        {
            var codes = String.Join(",", order.Cart.Items.Select(p => p.Product.ProductCode).ToList());
            var recyclingfee = await _recyclingDomainManager.GetRecyclingFeesAsync(new RecyclingFeeRequestModel { ProductCodes = codes, State = order.Shipping.Address.State }).ConfigureAwait(false);

            if (recyclingfee != null)
            {
                order.RecyclingFees = recyclingfee.Select(e => new RecyclingFee
                {
                    ProductCode = e.ProductCode,
                    Amount = order.Quantity(e.ProductCode, e.Amount),
                    Code = e.Code,
                    Description = e.Description,
                    ProductFeeEDC = e.ProductFeeEDC
                });

                var query = from item in order.Cart.Items
                            join recycle in order.RecyclingFees
                                on item.Product.ProductCode equals recycle.ProductCode
                            select new { RecycleFee = recycle.Amount };
                var total = query.ToList().Sum(a => a.RecycleFee);

                return total;
            }
            return 0;
        }
    }
}