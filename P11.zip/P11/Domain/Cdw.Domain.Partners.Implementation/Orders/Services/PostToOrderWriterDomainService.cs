﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Common;
using Cdw.Common.Extensions;
using Cdw.Ecommerce.Domain.OrderWriter;
using Cdw.Partners.Utilities;
using Cdw.Security.OAuth2.Client;
using Common.Logging;
using Order = Cdw.Domain.Partners.Orders.Order;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class PostToOrderWriterDomainService : IPostToOrderWriterDomainService
    {
        private readonly ILog _logger;
        private readonly IOrderWriterDomainManager _orderWriterDomainManager;
        private readonly IPartnerOrderService _partnerOrderService;

        public PostToOrderWriterDomainService(ILog logger, IOrderWriterDomainManager orderWriterDomainManager, IPartnerOrderService partnerOrderService)
        {
            _logger = logger;
            _orderWriterDomainManager = orderWriterDomainManager;
            _partnerOrderService = partnerOrderService;
        }

        public async Task Process(Order order, ITrackingValues trackingValues)
        {
            if (!string.IsNullOrEmpty(order.Billing.Method.Terms))
            {
                order.Billing.Method.Terms = _partnerOrderService.GetPaymentCode(order.Source.Name, order.Billing.Method.Terms);
            }

            var orderWriterObject = Mapper.Map<Ecommerce.Domain.OrderWriter.Order>(order);
            try
            {
                //WB: stand for web order which is the valid code
                orderWriterObject.ApprovalCode = "WB";
                await _orderWriterDomainManager.WithTracking(trackingValues).UploadAsync(orderWriterObject).ConfigureAwait(false);
            }
            catch (AggregateException ex)
            {
                var error = ex.Unroll();
                _logger.Error("OrderWriter Failed:Type AggregateException", error.SourceException, trackingValues, orderWriterObject);
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error("OrderWriter Failed:Type Exception", ex, trackingValues, orderWriterObject);
                throw;
            }
        }
    }
}