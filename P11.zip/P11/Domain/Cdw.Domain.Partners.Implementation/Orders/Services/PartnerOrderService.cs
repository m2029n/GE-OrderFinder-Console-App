﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Api.Partners.Validation;
using Cdw.Common;
using Cdw.Common.Extensions;
using Cdw.Domain.Partners.Orders;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Orders.Services
{
    public class PartnerOrderService : IPartnerOrderService
    {
        private readonly IPartnerOrderRepository _partnerOrderRepository;
        private readonly ILog _logger;

        public PartnerOrderService(IPartnerOrderRepository partnerOrderRepository, ILog logger)
        {
            _partnerOrderRepository = partnerOrderRepository;
            _logger = logger;
        }

        public void CheckUniqueReferenceNumber(IRequestOrder request)
        {
            if (!_partnerOrderRepository.UniqueReferenceNumber(request.PartnerSourceCode, request.ReferenceNumber))
            {
                throw new OrderValidationException(new List<IOrderValidationFailure>
                {
                    new FailedRequestValidationResult("ReferenceNumber","An order with this reference number already exists")
                });
            }
        }

        public bool ValidateTerms(IRequestOrder request)
        {
            var isTermsAllowed = _partnerOrderRepository.IsTermsAllowed(request.PartnerSourceCode, request.Billing.Method.Terms);
            if (!isTermsAllowed)
            {
                var validationmessage = new List<IOrderValidationFailure>
                {
                    new FailedRequestValidationResult("Billing.Method", "Billing Method details should be defined correctly." )
                };
                throw new OrderValidationException(validationmessage);
            }
            return true;
        }

        public IEnumerable<ProductEntity> GetProductEntities(IEnumerable<string> productCodes)
        {
            return _partnerOrderRepository.GetProduct(productCodes);
        }

        public async Task<ShippingMethodPropertiesEntity> GetShippingMethodPropertyAsync(string clientName, string shippingMethod)
        {
            return await _partnerOrderRepository.GetShippingMethodProperty(clientName, shippingMethod);
        }

        public void InsertCart(Order order)
        {
            var cartEntity = Mapper.Map<CartEntity>(order.Cart);
            cartEntity = _partnerOrderRepository.InsertApiCarts(cartEntity);
            Mapper.Map(cartEntity, (Cart)order.Cart);
        }

        public void InsertPaymentInformation(Order order, ITrackingValues trackingValues,
            ICreditCardAuthorizationResponse creditCardResponse, string authCreditCardToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(authCreditCardToken))
                {
                    var authCreditCardDb = _partnerOrderRepository.GetCreditCardByToken(authCreditCardToken);

                    var payment = new PaymentMethod()
                    {
                        CreditCard = new CreditCard()
                        {
                            ExpirationMonth = authCreditCardDb.CreditCardExpirationDate.Month,
                            ExpirationYear = authCreditCardDb.CreditCardExpirationDate.Year,
                            Id = authCreditCardDb.CreditCardTokenID,
                            Token = authCreditCardDb.CreditCardToken,
                            Number = "************" + authCreditCardDb.CreditCardNumberLastFour
                        }
                    };

                    ((BillingInfo)(order.Billing)).Method = payment;
                }
                else
                {
                    if (creditCardResponse == null)
                    {
                        return;
                    }

                    var creditCardDb = _partnerOrderRepository.GetCreditCardByToken(creditCardResponse.CreditCardToken);
                    Mapper.Map(creditCardDb, order.Billing.Method.CreditCard);
                }
            }
            catch (AggregateException ex)
            {
                _logger.Error("CreditCard Failed: AggregateException", ex.Unroll().SourceException, trackingValues);
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error("CreditCard Failed: Type Exception", ex, trackingValues);
                throw;
            }
        }

        public string InsertOrder(Order order, IRequestOrder request)
        {
            var orderEntity = Mapper.Map<OrderEntity>(order);
            orderEntity.IpAddress = request.IpAddress;
            orderEntity.Geolocation = request.Geolocation;
            orderEntity.UserAgent = request.UserAgent;
            orderEntity = _partnerOrderRepository.Create(orderEntity);
            return orderEntity.OrderCode;
        }

        public string GetPaymentCode(string orderSource, string paymentMethod)
        {
            var paymentCode = "";
            var paymentDetails = _partnerOrderRepository.GetPaymentMethodDetails(orderSource, paymentMethod);
            if (paymentDetails != null)
            {
                paymentCode = paymentDetails.PaymentCode;
            }
            return paymentCode;
        }

        public string GetAuthCreditCardToken(string transactionId, string referenceNumber)
        {
            string authCreditCardToken = null;

            if (!string.IsNullOrEmpty(transactionId) && !string.IsNullOrEmpty(referenceNumber))
            {
                authCreditCardToken =
                    _partnerOrderRepository.GetAuthCreditCardToken(transactionId, referenceNumber);
                if (string.IsNullOrEmpty(authCreditCardToken))
                {
                    throw new OrderValidationException(new List<IOrderValidationFailure>
                    {
                        new FailedRequestValidationResult("Billing.Method",
                            "The given TransactionId or ReferenceNumber or both are incorrect.")
                    });
                }
            }

            return authCreditCardToken;
        }

        public bool IsUploadedToAs400(string orderCode)
        {
            var isUploadedAs400 = _partnerOrderRepository.IsUploadedToAs400(orderCode);
            return (isUploadedAs400.HasValue && isUploadedAs400.Value);
        }

        public Order GetOrderDetails(string orderCode, string sourceCode)
        {
            var orderEntity = _partnerOrderRepository.GetOrderEntity(orderCode, sourceCode);
            if (orderEntity == null)
            {
                return null;
            }

            var order = Mapper.Map<Order>(orderEntity);

            //Get Valid Products
            var cartEntity = _partnerOrderRepository.GetCartEntity(order.Cart.Id);

            try
            {
                var codes = cartEntity.CartItems.Select(li => li.ProductId).Distinct().ToList();
                var productMatches = _partnerOrderRepository.GetProduct(codes).ToList().ToDictionary(p => p.ProductID);
                foreach (var lineItem in cartEntity.CartItems)
                {
                    var product = productMatches[lineItem.ProductId];//(KS) needs to be handled better: this will fail the job if product is not found??? Added try/catch
                    lineItem.Product = product;
                }
            }
            catch (Exception ex)
            {
                _logger.Error("GetOrderDetails Failed: No Valid productMatches are found in this Cart", ex);
                throw;
            }

            //Map Cart
            order.Cart = Mapper.Map<ICart>(cartEntity);

            //Map Paymentinfo
            var payment = _partnerOrderRepository.GetCreditCardById(order.Billing.Method.CreditCard.Id);
            var cc = (CreditCard)order.Billing.Method.CreditCard;
            if (payment != null)
            {
                cc.ExpirationYear = payment.CreditCardExpirationDate.Year;
                cc.ExpirationMonth = payment.CreditCardExpirationDate.Month;
                cc.Name = payment.CreditCardHolderName;
                cc.Number = payment.CreditCardNumberLastFour;
                cc.Type = new CreditCardType
                {
                    Type = (PaymentMethodType)payment.PaymentMethodOptionID
                };
            }

            return order;
        }
    }
}