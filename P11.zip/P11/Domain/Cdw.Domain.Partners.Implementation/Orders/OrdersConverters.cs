﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using AutoMapper;
using Cdw.Domain.Freight;
using Cdw.Domain.Partners.Implementation.Freight.FreightDomain;
using Cdw.Domain.Partners.Implementation.Orders.CreditCardService;
using Cdw.Domain.Partners.Implementation.Tax.TaxDomain;
using Cdw.Domain.Partners.Orders;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Domain.Order;
using Cdw.Ecommerce.Domain.OrderWriter;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Partners.Utilities;
using Account = Cdw.Domain.Partners.Orders.Account;
using Address = Cdw.Domain.Partners.Orders.Address;
using CartItemStatus = Cdw.Domain.Partners.Orders.CartItemStatus;
using CdwCompany = Cdw.Domain.Partners.Common.CdwCompany;
using CustomProperty = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.CustomProperty;
using Discount = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Discount;
using IAddress = Cdw.Domain.Partners.Orders.IAddress;
using ICustomProperty = Cdw.Domain.Partners.Orders.ICustomProperty;
using IDiscount = Cdw.Domain.Partners.Orders.IDiscount;
using ILineItem = Cdw.Domain.Partners.Orders.ILineItem;
using IOrder = Cdw.Domain.Partners.Orders.IOrder;
using IPaymentMethod = Cdw.Domain.Partners.Orders.IPaymentMethod;
using IShippingAddress = Cdw.Ecommerce.Domain.Order.IAddress;
using ITax = Cdw.Domain.Partners.Orders.ITax;
using LineItem = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.LineItem;
using Order = Cdw.Domain.Partners.Orders.Order;
using OrderStatus = Cdw.Domain.Partners.Orders.OrderStatus;
using PaymentMethod = Cdw.Domain.Partners.Orders.PaymentMethod;
using ShippingMethod = Cdw.Domain.Partners.Orders.ShippingMethod;

namespace Cdw.Domain.Partners.Implementation.Orders.RequestToDomain
{
    internal class OrderConverter : TypeConverter<IRequestOrder, Order>
    {
        protected override Order ConvertCore(IRequestOrder source)
        {
            var result = new Order
            {
                OrderNumber = string.Empty,
                Status = OrderStatus.Processing,
                TransactionDate = source.TransactionDate,
                ReferenceNumber = source.ReferenceNumber,
                Account = new Account
                {
                    EmailAddress = source.Account.EmailAddress,
                    CustomerNumber = source.Account.CustomerNumber,
                    EAccount = source.Account.EAccount
                },
                Taxes = source.Taxes ?? Enumerable.Empty<ITax>(),
                Billing = new BillingInfo
                {
                    Address = Mapper.Map<Address>(source.Billing.Address),
                    Method = Mapper.Map<PaymentMethod>(source.Billing.Method)
                },
                Shipping = new ShippingInfo
                {
                    Address = Mapper.Map<Address>(source.Shipping.Address),
                    Method = new ShippingMethod
                    {
                        Description = source.Shipping.Method.Description,
                        Id = source.Shipping.Method.Id,
                        Rate = new OrderShippingRate()
                    }
                },
                Shipments = Enumerable.Empty<IShipment>(),
                Cart = Mapper.Map<ICart>(source),
                Source = new OrderSource
                {
                    Name = source.PartnerSourceCode,
                    FreightRaterSpecialCode = source.PartnerFreightRaterSpecialCode
                },
                TrackingValues = source.TrackingValues
            };

            return result;
        }
    }

    internal class PaymentMethodConverter : TypeConverter<IPaymentMethod, PaymentMethod>
    {
        protected override PaymentMethod ConvertCore(IPaymentMethod source)
        {
            var result = new PaymentMethod
            {
                PONumber = source.PONumber,
                CreditCard = Mapper.Map<CreditCard>(source.CreditCard),
                Terms = source.Terms
            };

            return result;
        }
    }

    internal class BillingAddressConverter : TypeConverter<IBillingAddress, IAddress>
    {
        protected override IAddress ConvertCore(IBillingAddress source)
        {
            if (source != null)
            {
                var result = new Address
                {
                    FirstName = source.FirstName,
                    LastName = source.LastName,
                    MiddleInitial = source.MiddleInitial,
                    Company = source.CompanyName,
                    PostalCode = source.PostalCode,
                    PhoneNumber = source.Phone,
                    State = source.StateProv,
                    StreetAddress = source.Address1,
                    SecondaryStreetAddress = source.Address2,
                    AttentionName = source.AttentionName
                };

                return result;
            }
            return new Address();
        }
    }

    internal class ShippingAddressConverter : TypeConverter<IShippingAddress, IAddress>
    {
        protected override IAddress ConvertCore(IShippingAddress source)
        {
            if (source != null)
            {
                var result = new Address
                {
                    Company = source.CompanyName,
                    PostalCode = source.PostalCode,
                    PhoneNumber = source.Phone,
                    State = source.StateProv,
                    StreetAddress = source.Address1,
                    SecondaryStreetAddress = source.Address2,
                    AttentionName = source.AttentionName
                };
                return result;
            }
            return new Address();
        }
    }

    internal class CartItemConverter : TypeConverter<ILineItem, CartItem>
    {
        protected override CartItem ConvertCore(ILineItem source)
        {
            var result = new CartItem
            {
                Quantity = source.Quantity,
                UnitPrice = source.UnitPrice,
                CustomProperties = source.CustomProperties.ToList(),
                Discounts =
                    new CartItemDiscounts
                    {
                        FixedLinePriceDiscounts = new List<IDiscount>(),
                        PercentOffUnitPriceDiscounts = new List<IDiscount>(),
                        FixedUnitPriceDiscounts = new List<IDiscount>(),
                        PercentOffLinePriceDiscounts = new List<IDiscount>()
                    }
            };
            DiscountCalculator.AddDiscountsToCartItem(result, source.Discounts);
            return result;
        }
    }

    internal class CartConverter : TypeConverter<IRequestOrder, ICart>
    {
        protected override ICart ConvertCore(IRequestOrder source)
        {
            var result = new Cart
            {
                Company = ((CdwCompany)source.Company),
                Items = new List<ICartItem>(),
                Discounts = new CartDiscounts
                {
                    FixedAmountDiscounts = DiscountCalculator.CreateFixedAmountOffOrderDiscounts(source.Discounts).ToList(),
                    PercentOffDiscounts = DiscountCalculator.CreatePercentOffOrderDiscounts(source.Discounts).ToList()
                },
                CustomProperties = source.CustomProperties.ToList()
            };

            return result;
        }
    }
}

namespace Cdw.Domain.Partners.Implementation.Orders.DomainToEntity
{
    internal class OrderEntityConverter : TypeConverter<IOrder, OrderEntity>
    {
        protected override OrderEntity ConvertCore(IOrder source)
        {
            var result = new OrderEntity
            {
                TransactionDate = source.TransactionDate,
                Source = source.Source.Name,
                ReferenceNumber = source.ReferenceNumber,
                Account_CustomerNumber = source.Account.CustomerNumber,
                Account_EAccount = source.Account.EAccount,
                Account_EmailAddress = source.Account.EmailAddress,
                FreightCost = source.Shipping.Method.Rate.FreightCost,
                Freight = source.Shipping.Method.Rate.Freight,
                Handling = source.Shipping.Method.Rate.Handling,
                Insurance = source.Shipping.Method.Rate.Insurance,
                Billing_FirstName = source.Billing.Address.FirstName,
                Billing_LastName = source.Billing.Address.LastName,
                Billing_PhoneNumber = source.Billing.Address.PhoneNumber,
                Billing_Company = source.Billing.Address.Company,
                Billing_StreetAddress = source.Billing.Address.StreetAddress,
                Billing_SecondaryStreetAddress = source.Billing.Address.SecondaryStreetAddress,
                Billing_City = source.Billing.Address.City,
                Billing_State = source.Billing.Address.State,
                Billing_PostalCode = source.Billing.Address.PostalCode,
                Billing_IsoCountryCode = source.Billing.Address.IsoCountryCode,
                Billing_Method_PONumber = source.Billing.Method.PONumber,
                Billing_Method_CreditCardTokenID = source.Billing.Method.CreditCard == null ? 0 : source.Billing.Method.CreditCard.Id,
                Billing_Method_Terms = source.Billing.Method.Terms,
                Shipping_FirstName = source.Shipping.Address.FirstName,
                Shipping_LastName = source.Shipping.Address.LastName,
                Shipping_PhoneNumber = source.Shipping.Address.PhoneNumber,
                Shipping_Company = source.Shipping.Address.Company,
                Shipping_StreetAddress = source.Shipping.Address.StreetAddress,
                Shipping_SecondaryStreetAddress = source.Shipping.Address.SecondaryStreetAddress,
                Shipping_City = source.Shipping.Address.City,
                Shipping_State = source.Shipping.Address.State,
                Shipping_PostalCode = source.Shipping.Address.PostalCode,
                Shipping_IsoCountryCode = source.Shipping.Address.IsoCountryCode,
                Shipping_Method_Id = source.Shipping.Method.Rate.ShippingMethodId,
                Shipping_Method_Description = source.Shipping.Method.Rate.ShippingMethodDescription,
                CartID = source.Cart.Id,
                BoxCount = source.Shipping.Method.Rate.BoxCount,
                Weight = source.Shipping.Method.Rate.TotalWeight,
                TotalShippingCharge = source.Shipping.Method.Rate.TotalShippingCharge,
                BoxHandlingCharge = source.Shipping.Method.Rate.BoxHandlingCharge,
                FreightTransactionID = source.Shipping.Method.Rate.TransactionGUID,
                Taxes = Mapper.Map<IList<TaxEntity>>(source.Taxes),
                OrderItems = Mapper.Map<IList<OrderItemShippingRateEntity>>(source.Shipping.Method.Rate.OrderItems),
                RecycleFees = Mapper.Map<IList<RecycleFeeEntity>>(source.RecyclingFees)
            };
            return result;
        }
    }

    internal class RecyclingEntityConverter : TypeConverter<IRecyclingFee, RecycleFeeEntity>
    {
        protected override RecycleFeeEntity ConvertCore(IRecyclingFee source)
        {
            var result = new RecycleFeeEntity
            {
                Amount = source.Amount,
                Code = source.Code,
                Description = source.Description,
                ProductCode = source.ProductCode
            };
            return result;
        }
    }

    internal class TaxesEntityConverter : TypeConverter<ITax, TaxEntity>
    {
        protected override TaxEntity ConvertCore(ITax source)
        {
            var result = new TaxEntity
            {
                Id = source.Id,
                Description = source.Description,
                Rate = source.Rate,
                Amount = source.Amount
            };
            return result;
        }
    }

    internal class OrderItemShippingRateEntityConverter : TypeConverter<IOrderItemShippingRate, OrderItemShippingRateEntity>
    {
        protected override OrderItemShippingRateEntity ConvertCore(IOrderItemShippingRate source)
        {
            var result = new OrderItemShippingRateEntity
            {
                ProductCode = source.ProductCode,
                CdwCost = source.CdwCost,
                Freight = source.Freight,
                Handling = source.Handling,
                BoxHandling = source.BoxHandling,
                Insurance = source.Insurance,
                Weight = source.Weight
            };
            return result;
        }
    }

    internal class CreditCartDomainToEntityConverter : TypeConverter<ICreditCard, CreditCardEntity>
    {
        protected override CreditCardEntity ConvertCore(ICreditCard source)
        {
            var result = new CreditCardEntity
            {
                CreditCardTokenID = source.Id,
                CreditCardHolderName = source.Name,
                CreditCardExpirationDate = new DateTime(source.ExpirationYear, source.ExpirationMonth,
                        DateTime.DaysInMonth(source.ExpirationYear, source.ExpirationMonth)),
                CreditCardNumber = source.Number,
                CreditCardToken = source.Token,
                PaymentMethodOptionID = (int)source.Type.Type
            };
            return result;
        }
    }

    internal class CreditCardTypeDomainToEntityConverter : TypeConverter<ICreditCardType, CreditCardTypeEntity>
    {
        protected override CreditCardTypeEntity ConvertCore(ICreditCardType source)
        {
            var result = new CreditCardTypeEntity
            {
                Type = (PaymentMethodTypeEntity)Enum.Parse(typeof(PaymentMethodTypeEntity), source.Type.ToString()),
                Name = source.Name,
                AlternateNames = source.AlternateNames,
                CardNumberLength = source.CardNumberLength
            };
            return result;
        }
    }

    internal class CartDomainToEntityConverter : TypeConverter<ICart, CartEntity>
    {
        protected override CartEntity ConvertCore(ICart source)
        {
            var result = new CartEntity
            {
                Company = (int)(source.Company),
                Subtotal = source.Subtotal,
                DiscountValue = source.DiscountValue,
                CustomProperties = Mapper.Map<IEnumerable<CustomPropertyEntity>>(source.CustomProperties),
                Discounts = Mapper.Map<CartDiscountsEntity>(source.Discounts),
                CartItems = Mapper.Map<IList<CartItemEntity>>(source.Items)
            };

            return result;
        }
    }

    internal class CartDiscountsDomainToEntityConverter : TypeConverter<ICartDiscounts, CartDiscountsEntity>
    {
        protected override CartDiscountsEntity ConvertCore(ICartDiscounts source)
        {
            var result = new CartDiscountsEntity
            {
                FixedAmountDiscounts = Mapper.Map<IList<DiscountEntity>>(source.FixedAmountDiscounts),
                PercentOffDiscounts = Mapper.Map<IList<DiscountEntity>>(source.PercentOffDiscounts)
            };

            return result;
        }
    }

    internal class DiscountDomainToEntityConverter : TypeConverter<IDiscount, DiscountEntity>
    {
        protected override DiscountEntity ConvertCore(IDiscount source)
        {
            var result = new DiscountEntity
            {
                Id = source.Id,
                Type = source.Type,
                Amount = source.Amount
            };

            return result;
        }
    }

    internal class CartItemDomainToEntityConverter : TypeConverter<ICartItem, CartItemEntity>
    {
        protected override CartItemEntity ConvertCore(ICartItem source)
        {
            var result = new CartItemEntity
            {
                CartItemID = source.Id,
                CustomProperties = Mapper.Map<IList<CustomPropertyEntity>>(source.CustomProperties),
                Discounts = Mapper.Map<CartItemDiscountsEntity>(source.Discounts),
                UnitPrice = source.UnitPrice,
                DiscountedUnitPrice = source.DiscountedUnitPrice,
                LinePrice = source.LinePrice,
                DiscountedLinePrice = source.DiscountedLinePrice,
                ProductId = source.Product.ProductID,
                Quantity = (int)source.Quantity
            };

            return result;
        }
    }

    internal class CustomPropertyDomainToEntityConverter : TypeConverter<ICustomProperty, CustomPropertyEntity>
    {
        protected override CustomPropertyEntity ConvertCore(ICustomProperty source)
        {
            var result = new CustomPropertyEntity
            {
                Name = source.Name,
                Value = source.Value
            };

            return result;
        }
    }

    internal class CartItemDiscountsDomainToEntityConverter : TypeConverter<ICartItemDiscounts, CartItemDiscountsEntity>
    {
        protected override CartItemDiscountsEntity ConvertCore(ICartItemDiscounts source)
        {
            var result = new CartItemDiscountsEntity
            {
                FixedLinePriceDiscounts = Mapper.Map<IList<DiscountEntity>>(source.FixedLinePriceDiscounts),
                FixedUnitPriceDiscounts = Mapper.Map<IList<DiscountEntity>>(source.FixedUnitPriceDiscounts),
                PercentOffLinePriceDiscounts = Mapper.Map<IList<DiscountEntity>>(source.PercentOffLinePriceDiscounts),
                PercentOffUnitPriceDiscounts = Mapper.Map<IList<DiscountEntity>>(source.PercentOffUnitPriceDiscounts)
            };

            return result;
        }
    }
}

namespace Cdw.Domain.Partners.Implementation.Orders.EntityToDomain
{
    internal class OrderDomainConverter : TypeConverter<OrderEntity, Order>
    {
        protected override Order ConvertCore(OrderEntity source)
        {
            var result = new Order
            {
                Status = OrderStatus.Processing,
                OrderNumber = source.OrderCode,
                TransactionDate = source.TransactionDate,
                Source = new OrderSource
                {
                    Name = source.Source
                },
                ReferenceNumber = source.ReferenceNumber,
                Account = new Account
                {
                    CustomerNumber = source.Account_CustomerNumber,
                    EAccount = source.Account_EAccount,
                    EmailAddress = source.Account_EmailAddress
                },
                Shipping = new ShippingInfo
                {
                    Address = new Address
                    {
                        FirstName = source.Shipping_FirstName,
                        LastName = source.Shipping_LastName,
                        PhoneNumber = source.Shipping_PhoneNumber,
                        Company = source.Shipping_Company,
                        StreetAddress = source.Shipping_StreetAddress,
                        SecondaryStreetAddress = source.Shipping_SecondaryStreetAddress,
                        City = source.Shipping_City,
                        State = source.Shipping_State,
                        PostalCode = source.Shipping_PostalCode,
                        IsoCountryCode = source.Shipping_IsoCountryCode
                    },
                    Method = new ShippingMethod
                    {
                        Id = source.Shipping_Method_Id,
                        Rate = new OrderShippingRate
                        {
                            FreightCost = source.FreightCost,
                            Freight = source.Freight,
                            Handling = source.Handling,
                            Insurance = source.Insurance,
                            BoxCount = source.BoxCount,
                            TotalWeight = source.Weight,
                            TotalShippingCharge = source.TotalShippingCharge,
                            BoxHandlingCharge = source.BoxHandlingCharge,
                            TransactionGUID = source.FreightTransactionID,
                            OrderItems = source.OrderItems.Select(e => new OrderItemShippingRate
                            {
                                BoxHandling = e.BoxHandling,
                                CdwCost = e.CdwCost,
                                Freight = e.Freight,
                                Handling = e.Handling,
                                Insurance = e.Insurance,
                                ProductCode = e.ProductCode,
                                Weight = e.Weight
                            })
                        },
                        Description = source.Shipping_Method_Description
                    }
                },
                Billing = new BillingInfo
                {
                    Address = new Address
                    {
                        FirstName = source.Billing_FirstName,
                        LastName = source.Billing_LastName,
                        PhoneNumber = source.Billing_PhoneNumber,
                        Company = source.Billing_Company,
                        StreetAddress = source.Billing_StreetAddress,
                        SecondaryStreetAddress = source.Billing_SecondaryStreetAddress,
                        City = source.Billing_City,
                        State = source.Billing_State,
                        PostalCode = source.Billing_PostalCode,
                        IsoCountryCode = source.Billing_IsoCountryCode
                    },
                    Method = new PaymentMethod
                    {
                        PONumber = source.Billing_Method_PONumber,
                        CreditCard = new CreditCard
                        {
                            Id = source.Billing_Method_CreditCardTokenID
                        },
                        Terms = source.Billing_Method_Terms,
                        TransactionId = source.Billing_Method_TransactionId,
                        ReferenceNumber = source.Billing_Method_ReferenceNumber
                    }
                },
                Cart = new Cart
                {
                    Id = source.CartID
                },
                Taxes = source.Taxes.Select(e => new Partners.Orders.Tax
                {
                    Amount = e.Amount,
                    Description = e.Description,
                    Id = e.Id,
                    Rate = e.Rate
                })
            };
            return result;
        }
    }

    internal class CartDomainConverter : TypeConverter<CartEntity, ICart>
    {
        protected override ICart ConvertCore(CartEntity source)
        {
            var result = new Cart
            {
                Id = source.CartID,
                Company = (CdwCompany)source.Company,
                CustomProperties = Mapper.Map<IList<ICustomProperty>>(source.CustomProperties),
                Discounts = new CartDiscounts
                {
                    FixedAmountDiscounts = Mapper.Map<IList<IDiscount>>(source.Discounts.FixedAmountDiscounts),
                    PercentOffDiscounts = Mapper.Map<IList<IDiscount>>(source.Discounts.PercentOffDiscounts)
                },
                Items = source.CartItems.Select(e => new CartItem
                {
                    Id = e.CartItemID,
                    Quantity = (uint)e.Quantity,
                    UnitPrice = e.UnitPrice,
                    Discounts = new CartItemDiscounts
                    {
                        FixedLinePriceDiscounts = Mapper.Map<IList<IDiscount>>(e.Discounts.FixedLinePriceDiscounts),
                        FixedUnitPriceDiscounts = Mapper.Map<IList<IDiscount>>(e.Discounts.FixedUnitPriceDiscounts),
                        PercentOffLinePriceDiscounts =
                            Mapper.Map<IList<IDiscount>>(e.Discounts.PercentOffLinePriceDiscounts),
                        PercentOffUnitPriceDiscounts =
                            Mapper.Map<IList<IDiscount>>(e.Discounts.PercentOffUnitPriceDiscounts)
                    },
                    CustomProperties = Mapper.Map<IList<ICustomProperty>>(e.CustomProperties),
                    Status = (CartItemStatus)Enum.Parse(typeof(CartItemStatus), e.Status.ToString()),
                    Product = Mapper.Map<IProduct>(e.Product)
                }).Cast<ICartItem>().ToList()
            };

            return result;
        }
    }

    internal class DiscountEntityToDomainConverter : TypeConverter<DiscountEntity, IDiscount>
    {
        protected override IDiscount ConvertCore(DiscountEntity source)
        {
            var result = new Partners.Orders.Discount
            {
                Id = source.Id,
                Type = source.Type,
                Amount = source.Amount
            };

            return result;
        }
    }

    internal class CustomPropertyEntityToDomainConverter : TypeConverter<CustomPropertyEntity, ICustomProperty>
    {
        protected override ICustomProperty ConvertCore(CustomPropertyEntity source)
        {
            var result = new Partners.Orders.CustomProperty
            {
                Name = source.Name,
                Value = source.Value
            };

            return result;
        }
    }

    internal class BundleProductConverter : TypeConverter<BundleProductEntity, IBundleProduct>
    {
        protected override IBundleProduct ConvertCore(BundleProductEntity source)
        {
            var result = new BundleProduct
            {
                Quantity = source.Quantity,
                Product = new Partners.Orders.Product
                {
                    CompanyPartNumber = source.Product.CompanyPartNumber,
                    CustomerSpecificEDC = source.Product.CustomerSpecificEDC,
                    DateCreated = source.Product.DateCreated,
                    DateModified = source.Product.DateModified,
                    DateSellStart = source.Product.DateSellStart,
                    DateSellStop = source.Product.DateSellStop,
                    Description = source.Product.Description,
                    DropShipOnly = source.Product.DropShipOnly,
                    FriendlyDescription = source.Product.FriendlyDescription,
                    FriendlyName = source.Product.FriendlyName,
                    Height = source.Product.Height,
                    ImageEDC = source.Product.ImageEDC,
                    IsBundle = source.Product.IsBundle,
                    Length = source.Product.Length,
                    ManufactureCode = source.Product.ManufactureCode,
                    ManufactureID = source.Product.ManufactureID,
                    ManufactureKey = source.Product.ManufactureKey,
                    ManufactureName = source.Product.ManufactureName,
                    ManufacturePartNumber = source.Product.ManufacturePartNumber,
                    Name = source.Product.Name,
                    NonReturnable = source.Product.NonReturnable,
                    ParentManufactureID = source.Product.ParentManufactureID,
                    ProductClass = source.Product.ProductClass,
                    ProductCode = source.Product.ProductCode,
                    ProductGroup = source.Product.ProductGroup,
                    ProductID = source.Product.ProductID,
                    ProductKey = source.Product.ProductKey,
                    ProductType = source.Product.ProductType,
                    SpinSetName = source.Product.SpinSetName,
                    StockSource = source.Product.StockSource,
                    Weight = source.Product.Weight,
                    Width = source.Product.Width
                }
            };

            return result;
        }
    }

    internal class ProductConverter : TypeConverter<ProductEntity, IProduct>
    {
        protected override IProduct ConvertCore(ProductEntity source)
        {
            var result = new Partners.Orders.Product
            {
                BundledProducts = Mapper.Map<IEnumerable<IBundleProduct>>(source.BundledProducts),
                CompanyPartNumber = source.CompanyPartNumber,
                CustomerSpecificEDC = source.CustomerSpecificEDC,
                DateCreated = source.DateCreated,
                DateModified = source.DateModified,
                DateSellStart = source.DateSellStart,
                DateSellStop = source.DateSellStop,
                Description = source.Description,
                DropShipOnly = source.DropShipOnly,
                FriendlyDescription = source.FriendlyDescription,
                FriendlyName = source.FriendlyName,
                Height = source.Height,
                ImageEDC = source.ImageEDC,
                IsBundle = source.IsBundle,
                Length = source.Length,
                ManufactureCode = source.ManufactureCode,
                ManufactureID = source.ManufactureID,
                ManufactureKey = source.ManufactureKey,
                ManufactureName = source.ManufactureName,
                ManufacturePartNumber = source.ManufacturePartNumber,
                Name = source.Name,
                NonReturnable = source.NonReturnable,
                ParentManufactureID = source.ParentManufactureID,
                ProductClass = source.ProductClass,
                ProductCode = source.ProductCode,
                ProductGroup = source.ProductGroup,
                ProductID = source.ProductID,
                ProductKey = source.ProductKey,
                ProductType = source.ProductType,
                SpinSetName = source.SpinSetName,
                StockSource = source.StockSource,
                Weight = source.Weight,
                Width = source.Width
            };

            return result;
        }
    }

    internal class ProductConverterD : TypeConverter<ProductEntity, Partners.Orders.Product>
    {
        protected override Partners.Orders.Product ConvertCore(ProductEntity source)
        {
            var result = new Partners.Orders.Product
            {
                CompanyPartNumber = source.CompanyPartNumber,
                CustomerSpecificEDC = source.CustomerSpecificEDC,
                DateCreated = source.DateCreated,
                DateModified = source.DateModified,
                DateSellStart = source.DateSellStart,
                DateSellStop = source.DateSellStop,
                Description = source.Description,
                DropShipOnly = source.DropShipOnly,
                FriendlyDescription = source.FriendlyDescription,
                FriendlyName = source.FriendlyName,
                Height = source.Height,
                ImageEDC = source.ImageEDC,
                IsBundle = source.IsBundle,
                Length = source.Length,
                ManufactureCode = source.ManufactureCode,
                ManufactureID = source.ManufactureID,
                ManufactureKey = source.ManufactureKey,
                ManufactureName = source.ManufactureName,
                ManufacturePartNumber = source.ManufacturePartNumber,
                Name = source.Name,
                NonReturnable = source.NonReturnable,
                ParentManufactureID = source.ParentManufactureID,
                ProductClass = source.ProductClass,
                ProductCode = source.ProductCode,
                ProductGroup = source.ProductGroup,
                ProductID = source.ProductID,
                ProductKey = source.ProductKey,
                ProductType = source.ProductType,
                SpinSetName = source.SpinSetName,
                StockSource = source.StockSource,
                Weight = source.Weight,
                Width = source.Width
            };

            return result;
        }
    }
}

namespace Cdw.Domain.Partners.Implementation.Orders.Enterprise
{
    internal class OrderWriterConverter : TypeConverter<IOrder, Ecommerce.Domain.OrderWriter.Order>
    {
        protected override Ecommerce.Domain.OrderWriter.Order ConvertCore(IOrder source)
        {
            var result = new Ecommerce.Domain.OrderWriter.Order
            {
                //ApprovalCode = "WB", //moved this to domain Manager.
                OrderCode = source.OrderNumber,
                OrderDate = source.TransactionDate,
                CdwSiteCode = source.Cart.Company.GetAttributeOfType<DescriptionAttribute>().Description,
                IsQuoteModified = "0", //Required
                BillingAddress = new Ecommerce.Domain.OrderWriter.Address
                {
                    Company = source.Billing.Address.Company,
                    City = source.Billing.Address.City,
                    State = source.Billing.Address.State,
                    Country = source.Billing.Address.IsoCountryCode,
                    LastName = source.Billing.Address.LastName,
                    FirstName = source.Billing.Address.FirstName,
                    PostalCode = source.Billing.Address.PostalCode,
                    Line1 = source.Billing.Address.StreetAddress,
                    Line2 = source.Billing.Address.SecondaryStreetAddress,
                    Attention = ""
                },

                BillingContact = new Contact
                {
                    PhoneNumber = source.Billing.Address.PhoneNumber,
                    Email = source.Account.EmailAddress
                    //FaxNumber =
                    //PhoneExtension =
                }
                ,
                ShippingAddress = new Ecommerce.Domain.OrderWriter.Address
                {
                    Company = source.Shipping.Address.Company,
                    City = source.Shipping.Address.City,
                    State = source.Shipping.Address.State,
                    Country = source.Shipping.Address.IsoCountryCode,
                    LastName = source.Shipping.Address.LastName,
                    FirstName = source.Shipping.Address.FirstName,
                    PostalCode = source.Shipping.Address.PostalCode,
                    Line1 = source.Shipping.Address.StreetAddress,
                    Line2 = source.Shipping.Address.SecondaryStreetAddress,
                    Attention = ""
                },

                ShippingContact = new Contact
                {
                    PhoneNumber = source.Shipping.Address.PhoneNumber,
                    Email = source.Account.EmailAddress
                    //FaxNumber =
                    //PhoneExtension =
                }
                ,
                SourceCode = source.Source.Name,
                CustomFields =
                    source.Cart.CustomProperties.Select(
                        e => new CustomField { CustomFieldCode = e.Name, CustomFieldValue = e.Value })
                ,

                Items = HyderateLineItems(source),

                TotalWeight = source.Shipping.Method.Rate.TotalWeight
                ,
                ShippingMethod = new Ecommerce.Domain.OrderWriter.ShippingMethod
                {
                    Code = source.Shipping.Method.Id,
                    BoxCount = source.Shipping.Method.Rate.BoxCount,
                    AllowPartialDelivery = "Y", //Required
                    TotalWeight = source.Shipping.Method.Rate.TotalWeight,
                    IsOverride = "",
                    RaterGuid = source.Shipping.Method.Rate.TransactionGUID.ToString(),
                    Charges = new OrderShippingMethodCharges
                    {
                        BoxHandling = source.Shipping.Method.Rate.BoxHandlingCharge,
                        FreightCost = source.Shipping.Method.Rate.FreightCost,
                        Handling = source.Shipping.Method.Rate.Handling,
                        Insurance = source.Shipping.Method.Rate.Insurance,
                        TotalShipping = source.Shipping.Method.Rate.TotalShippingCharge
                        //,Shipping = source.Shipping.Method.Rate.FreightCost
                        //OrderHandling = source.Shipping.Method.Rate
                    }
                    //SpecialsCode =
                    //CustomerAccountNumber =
                    //OverrideCharge =
                },
                PaymentMethod = new Ecommerce.Domain.OrderWriter.PaymentMethod
                {
                    CreditCardToken = HydrateCreditCardToken(source.Billing.Method.CreditCard),
                    CreditCardExpiry = HydrateCreditCardExpiry(source.Billing.Method.CreditCard),
                    PurchaseOrderNumber = source.Billing.Method.PONumber,
                    Code = source.Billing.Method.Terms
                }
            };

            return result;
        }

        private DateTime? HydrateCreditCardExpiry(ICreditCard creditCard)
        {
            DateTime? dateTime = null;
            if (creditCard != null)
            {
                dateTime = new DateTime(creditCard.ExpirationYear,
                            creditCard.ExpirationMonth,
                            DateTime.DaysInMonth(creditCard.ExpirationYear,
                                creditCard.ExpirationMonth));
            }
            return dateTime;
        }

        private string HydrateCreditCardToken(ICreditCard creditCard)
        {
            var token = "";
            if (creditCard != null)
            {
                token = creditCard.Token;
            }
            return token;
        }

        private IEnumerable<IOrderItem> HyderateLineItems(IOrder source)
        {
            var orderItems = new List<IOrderItem>();
            int itemIndex = 1;
            foreach (var item in source.Cart.Items)
            {
                var orderitem = new OrderItem
                {
                    ProductCode = item.Product.ProductCode,
                    UnitPrice = CalculateFullyDiscountedUnitPrice(source.Cart, item),
                    Quantity = (int)item.Quantity,
                    LineNumber = itemIndex,
                    ShippingMethodCode = source.Shipping.Method.Id,
                    CustomFields =
                        item.CustomProperties.Select(
                            e1 => new CustomField { CustomFieldCode = e1.Name, CustomFieldValue = e1.Value }),
                    TotalWeight = HyderateTotalWeight(item.Product.ProductCode, source.Shipping.Method.Rate.OrderItems),
                    ShippingCharges =
                        HyderateShippingCharges(item.Product.ProductCode, source.Shipping.Method.Rate.OrderItems),
                    Notes = HydrateNotes(item.CustomProperties)
                    //CustomerPurchaseOrderLineNumber=
                    //CustomerPartNumber=
                    //FreightRuleCode=
                    //PricingCode =
                    //ContractId =
                };
                itemIndex = itemIndex + item.Product.BundledProducts.Count() + 1;
                orderItems.Add(orderitem);
            }
            return orderItems;
        }

        private IEnumerable<string> HydrateNotes(IList<ICustomProperty> customProperties)
        {
            if (customProperties == null || customProperties.Count == 0)
            {
                return new string[] { };
            }

            var notes = new List<string>();
            foreach (var p in customProperties)
            {
                if (p.Name == "ManufacturerPartNumber")
                {
                    notes.Add("ManufacturerPartNumber - " + p.Value);
                }

                if (p.Name == "ManufacturerItemDesc")
                {
                    notes.Add("ManufacturerItemDesc - " + p.Value);
                }
            }
            if (notes.Any())
            {
                return notes;
            }

            return Enumerable.Empty<string>();
        }

        private OrderItemShippingMethodCharges HyderateShippingCharges(string productCode, IEnumerable<IOrderItemShippingRate> orderitems)
        {
            var item = (from oi in orderitems
                        where oi.ProductCode == productCode
                        select oi).ToList();

            if (item.Any())
            {
                var first = item.First();
                return new OrderItemShippingMethodCharges
                {
                    FreightCost = first.Freight,
                    Handling = first.Handling,
                    Insurance = first.Insurance,
                    TotalShipping = first.Freight + first.Handling + first.Insurance
                };
            }
            return new OrderItemShippingMethodCharges();
        }

        private decimal HyderateTotalWeight(string productCode, IEnumerable<IOrderItemShippingRate> orderitems)
        {
            var item = (from oi in orderitems
                        where oi.ProductCode == productCode
                        select oi.Weight).ToList();

            if (item.Any())
            {
                return item.First();
            }
            return 0;
        }

        private decimal CalculateFullyDiscountedUnitPrice(ICart cart, ICartItem item)
        {
            if (item.DiscountedLinePrice == 0)
            {
                return 0;
            }

            var discountedUnitPrice = item.DiscountedLinePrice / item.Quantity;
            var proportionOfOrderDiscountForThisLine = item.DiscountedLinePrice / cart.Subtotal;
            var discountForThisLine = cart.DiscountValue * proportionOfOrderDiscountForThisLine;
            var additionalDiscountPerUnit = discountForThisLine / item.Quantity;
            var fullyDiscountedUnitPrice = discountedUnitPrice - additionalDiscountPerUnit;

            return Math.Round(fullyDiscountedUnitPrice, 2, MidpointRounding.AwayFromZero);
        }
    }

    internal class EnterpriseTaxRequestConverter : TypeConverter<IOrder, ITaxRequest>
    {
        protected override ITaxRequest ConvertCore(IOrder source)
        {
            var result = new Tax.TaxDomain.TaxRequest
            {
                Company = source.Cart.Company.Description(),
                Account = new Tax.TaxDomain.Account
                {
                    EmailAddress = source.Account.EmailAddress,
                    CustomerNumber = source.Account.CustomerNumber,
                    EAccount = source.Account.EAccount
                },
                Address = new Tax.TaxDomain.Address
                {
                    FirstName = source.Shipping.Address.FirstName,
                    LastName = source.Shipping.Address.LastName,
                    PhoneNumber = source.Shipping.Address.PhoneNumber,
                    Company = source.Shipping.Address.Company,
                    StreetAddress = source.Shipping.Address.StreetAddress,
                    SecondaryStreetAddress = source.Shipping.Address.SecondaryStreetAddress,
                    City = source.Shipping.Address.City,
                    State = source.Shipping.Address.State,
                    PostalCode = source.Shipping.Address.PostalCode,
                    IsoCountryCode = source.Shipping.Address.IsoCountryCode
                },
                Freight = source.Shipping.Method.Rate.Freight,
                Handling = source.Shipping.Method.Rate.Handling,
                Discounts = source.Cart.Discounts.FixedAmountDiscounts.Select(d => CreateTaxDiscount(d, 1000))
                    .Union(source.Cart.Discounts.PercentOffDiscounts.Select(d => CreateTaxDiscount(d, 1001))),
                Insurance = source.Shipping.Method.Rate.Insurance,
                LineItems = source.Cart.Items.Select((x, index) => CreateTaxLineItem(source, x, index))
            };

            //Added recycling fee as a lineitem to tax endpoint, beacuse recycling fee is also taxable in some cases based on
            // edc , location, etc.
            List<Domain.Tax.ILineItem> taxlineItem = new List<Domain.Tax.ILineItem>();
            taxlineItem = result.LineItems.ToList();
            if (source.RecyclingFees != null)
            {
                foreach (var recyclingFee in source.RecyclingFees)
                {
                    var rc = result.LineItems.Where(r => r.ProductCode == recyclingFee.ProductCode);
                    if (rc.Any())
                    {
                        taxlineItem.Add(new LineItem
                        {
                            CustomProperties = new List<Domain.Tax.ICustomProperty>(),
                            Discounts = new List<Domain.Tax.IDiscount>(),
                            UnitPrice = recyclingFee.Amount / rc.First().Quantity,
                            Quantity = rc.First().Quantity,
                            ProductCode = recyclingFee.ProductFeeEDC,
                            LineNumber = 1
                        });
                    }
                }
            }

            result.LineItems = taxlineItem;
            return result;
        }

        private LineItem CreateTaxLineItem(IOrder order, ICartItem lineItem, int index)
        {
            return new LineItem
            {
                CustomProperties = lineItem.CustomProperties.Select(CreateTaxCustomProperty),
                Discounts = lineItem.Discounts.FixedUnitPriceDiscounts.Select(d => CreateTaxDiscount(d, 1002))
                    .Union(lineItem.Discounts.PercentOffUnitPriceDiscounts.Select(d => CreateTaxDiscount(d, 1003)))
                    .Union(lineItem.Discounts.FixedLinePriceDiscounts.Select(d => CreateTaxDiscount(d, 1004)))
                    .Union(lineItem.Discounts.PercentOffLinePriceDiscounts.Select(d => CreateTaxDiscount(d, 1005))),
                UnitPrice = lineItem.UnitPrice,
                Quantity = (int)lineItem.Quantity,
                ProductCode = lineItem.Product.ProductCode,
                LineNumber = index + 1
            };
        }

        private CustomProperty CreateTaxCustomProperty(ICustomProperty customProperty)
        {
            return new CustomProperty { Name = customProperty.Name, Value = customProperty.Value };
        }

        private Discount CreateTaxDiscount(IDiscount discount, int discountType)
        {
            return new Discount { Amount = discount.Amount, Type = discountType, Id = discount.Id };
        }
    }

    internal class CreditCardServiceConverter : TypeConverter<ICreditCard, CreditCardAuthorizationRequest>
    {
        protected override CreditCardAuthorizationRequest ConvertCore(ICreditCard source)
        {
            var result = new CreditCardAuthorizationRequest
            {
                ExpirationDate = new DateTime(source.ExpirationYear, source.ExpirationMonth, DateTime.DaysInMonth(source.ExpirationYear, source.ExpirationMonth)),
                IsAuthorizedToSave = true,
                UseAsyncProcessing = false
            };
            return result;
        }
    }

    internal class EnterpriseFreightConverter : TypeConverter<IOrder, RatingRequest>
    {
        protected override RatingRequest ConvertCore(IOrder source)
        {
            var items = source.Cart.Items.Select((x, index) => new RatingRequestFreightItem
            {
                ContractReferenceNumber = null,
                OrderLineNumber = index + 1,
                ProductCode = x.Product.ProductCode,
                UnitPrice = x.UnitPrice,
                Quantity = (int)x.Quantity
            });

            var result = new RatingRequest
            {
                CompanyCode = source.Cart.Company.Description(),
                OrderReferenceNumber = source.ReferenceNumber,
                ItemsToShip = items,
                ShipTo = new RatingRequestShippingAddress
                {
                    CompanyName = source.Shipping.Address.Company,
                    FirstName = source.Shipping.Address.FirstName,
                    LastName = source.Shipping.Address.LastName,
                    Line1 = source.Shipping.Address.StreetAddress,
                    Line2 = source.Shipping.Address.SecondaryStreetAddress,
                    City = source.Shipping.Address.City,
                    State = source.Shipping.Address.State,
                    PostalCode = source.Shipping.Address.PostalCode,
                    Country = source.Shipping.Address.IsoCountryCode
                },
                Options = new RatingRequestOptions { IncludeFreightDetails = true },
                Requester = new RatingRequester
                {
                    ApplicationName = "PartnersAPI",
                    HostName = "it-matters-not",
                    JobName = "OrderCreation",
                    Platform = "CS"
                },
                SalesChannel = new RatingRequestSalesChannel
                {
                    Code = source.Source.FreightRaterSpecialCode,
                    ShipMethodFilter = SalesChannelShipMethodFilter.SpecialsOnly
                }
            };

            return result;
        }
    }

    internal class TaxDomainConverter : TypeConverter<Domain.Tax.ITax, ITax>
    {
        protected override ITax ConvertCore(Domain.Tax.ITax source)
        {
            var result = new Partners.Orders.Tax
            {
                Id = source.Id,
                Description = source.Description,
                Rate = source.Rate,
                Amount = source.Amount
            };

            return result;
        }
    }

    internal class ShippingRateConverter
    {
        public static IOrderShippingRate Convert(
            string shippingMethodId,
            IRatingResponse freightRaterResponse
           )
        {
            var rateHeader =
                freightRaterResponse.Freight.ShippingMethods.First(
                    x => string.Equals(x.Code, shippingMethodId, StringComparison.CurrentCultureIgnoreCase));

            return new OrderShippingRate
            {
                TransactionGUID = new Guid(freightRaterResponse.TransactionIdentifier),
                ShippingMethodId = shippingMethodId,
                ShippingMethodDescription = rateHeader.Name,
                BoxCount = freightRaterResponse.PackageCount,
                TotalWeight = rateHeader.TotalWeight,
                FreightCost = rateHeader.Cost,
                Freight = rateHeader.FreightCharge,
                Insurance = rateHeader.InsuranceCharge,
                Handling = rateHeader.OrderHandlingCharge,
                TotalShippingCharge = rateHeader.TotalCharge,
                BoxHandlingCharge = rateHeader.BoxHandlingCharge,
                OrderItems =
                        freightRaterResponse.Freight.Details.Select(
                            e => CreateOrderItemShippingRate(e, shippingMethodId))
                            .Where(i => i != null)
                            .ToList()
            };
        }

        private static IOrderItemShippingRate CreateOrderItemShippingRate(IRatedFreightDetail orderLine, string shippingMethodId)
        {
            var rate = orderLine.ShippingMethods.FirstOrDefault(r => r.Code == shippingMethodId);

            return (rate == null)
                ? null
                : new OrderItemShippingRate
                {
                    ProductCode = orderLine.ProductCode,
                    CdwCost = rate.Cost,
                    Freight = rate.FreightCharge,
                    Handling = rate.OrderHandlingCharge,
                    BoxHandling = rate.BoxHandlingCharge,
                    Insurance = rate.InsuranceCharge,
                    Weight = orderLine.Weight
                };
        }
    }
}