﻿using Cdw.Domain.Partners.Orders;
using Cdw.Infrastructure.Events;

namespace Cdw.Domain.Partners.Implementation.Orders
{
    public class OrderCreatedEvent : IDomainEvent
    {
        public string EventName => "OrderCreatedEvent";

        public OrderCreatedEvent(IOrder order)
        {
            Order = order;
        }

        public IOrder Order { get; set; }
    }
}