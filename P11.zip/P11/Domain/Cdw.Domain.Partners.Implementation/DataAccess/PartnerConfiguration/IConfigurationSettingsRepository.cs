﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;

namespace Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration
{
    /// <summary>
    /// interface for loading settings
    /// </summary>
    public interface IConfigurationSettingsRepository
    {
        /// <summary>
        /// describes a method to return settings partner by name
        /// </summary>
        /// <param name="clientName"></param>
        /// <returns></returns> 
        Task<PartnerConfigurationSettings> GetPartnerConfigurationSettingsByNameAsync(string clientName);
        /// <summary>
        /// can be called to reload a single instance of the class, which loads al the settings to memory
        /// </summary>
        Task InitAsync();
    }
}
