﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Core.Data.DbClient;
using Cdw.Core.Data.Repositories;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Infrastructure.PartnerOrder;
using Newtonsoft.Json;

namespace Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration
{
    /// <summary>
    /// used to call database to return partners settings for order end point
    /// </summary>
    public class ConfigurationSettingsRepository : RepositoryBase, IConfigurationSettingsRepository
    {
        private List<PartnerConfigurationSettings> _partnerConfigurationSettings;
        private const string GetClientInfoById = "[WebDB].[dbo].[Security_OAuth2_GetClientInfoById]";
        private const string GetShippingMethodPropertiesSProcName = "[WebDb].[dbo].[API_Partners_ShippingMethodProperties]";
        private bool _isInitialized;
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="dbClientFactory"></param>
        public ConfigurationSettingsRepository(Func<IDbClient> dbClientFactory) : base(dbClientFactory) { }

        /// <summary>
        ///TODO:load from DB with all the other properties and change class to singleton
        ///TODO: change to be one call to the database
        /// </summary>
        /// <returns></returns>       
        public async Task InitAsync()
        {
            var key = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\partnersInfov2.json");
            var list = JsonConvert.DeserializeObject<FileLoader>(key);
            _partnerConfigurationSettings = list.PartnerConfigurationSettings;
            foreach (var setting in _partnerConfigurationSettings)
            {
                var orderManagerSettingsTask = GetPartnerOrderManagerSettingsEntityAsync(setting.ClientId);
                var shippingPropertiesTask = GetShippingMethodPropertiesAsync(setting.ClientName);
                await Task.WhenAll(orderManagerSettingsTask, shippingPropertiesTask);
                var orderManagerSettings = await orderManagerSettingsTask;
                setting.ShippingMethodProperties = await shippingPropertiesTask;
                setting.OrderManagerSettings = new OrderManagerSettings
                {
                    FreightRaterSpecialCode = orderManagerSettings?.FreightRaterSpecialCode,
                    SourceCode = orderManagerSettings?.SourceCode
                };
            }
            _isInitialized = true;
        }

        public async Task<PartnerConfigurationSettings> GetPartnerConfigurationSettingsByNameAsync(string clientName)
        {
            if (!_isInitialized)
            {
               await InitAsync().ConfigureAwait(false);
            }
            var partnerSettings = _partnerConfigurationSettings.FirstOrDefault(p => p.ClientName == clientName);
            if (partnerSettings == null)
            {
                throw new Exception($"Client {clientName} is Not found:");
            }
            return partnerSettings;
        }

        private Task<OrderManagerSettings> GetPartnerOrderManagerSettingsEntityAsync(int clientId)
        {
            return Task.Run(() =>
            {
                var client = ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetClientInfoById)
                        .AddNamedParameters(new { ClientId = clientId })
                        .ExecuteFetch<OrderManagerSettings>()).FirstOrDefault();
              
                return client;
            });
        }
        private Task<List<ShippingMethodPropertiesEntity>> GetShippingMethodPropertiesAsync(string clientName)
        {
            return Task.Run(() =>
            {
                var entity = ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetShippingMethodPropertiesSProcName)
                        .AddNamedParameters(new { clientName })
                        .ExecuteFetch<ShippingMethodPropertiesEntity>()).ToList();
                return entity;
            });
        }

        private class FileLoader
        {
            public List<PartnerConfigurationSettings> PartnerConfigurationSettings { get; set; }
        }
    }

  
}
