﻿using System;
using Autofac;
using Cdw.Core.Data.DbClient;
using Cdw.Domain.Partners.Implementation.DataAccess.APILogging;
using Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration;

namespace Cdw.Domain.Partners.Implementation.DataAccess
{
    /// <summary>
    /// New Module  to support new repositories registrations
    /// </summary>
    public class DbModule : Module
    {
        private readonly Func<IDbClient> _dbClient;

        public DbModule(Func<IDbClient> dbClient)
        {
            _dbClient = dbClient;
        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);          
            builder.Register(c => new LogRequestResponseRepository(_dbClient))
                .AsImplementedInterfaces()
                .SingleInstance();
            builder.Register(c => new ConfigurationSettingsRepository(_dbClient))
                .AsImplementedInterfaces()
                .SingleInstance();
        }
    }
}
