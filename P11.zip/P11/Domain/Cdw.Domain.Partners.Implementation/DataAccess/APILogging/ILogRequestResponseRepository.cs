﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.APILogging;

namespace Cdw.Domain.Partners.Implementation.DataAccess.APILogging
{
    public interface ILogRequestResponseRepository
    {
        Task<RequestResponseLog> InsertRequestResponseLogAsync(RequestResponseLog entity);
        Task<List<RequestResponseLog>> SearchLogsByClientNameAsync(  string clientName, DateTime startDate, DateTime endDate, string messageType,string requestPath, int resultCode);
        Task<RequestResponseLog> GetRequestResponseLogsByIdAndClientNameAsync( string clientName,int id );
    
    }
}