﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Core.Data.DbClient;
using Cdw.Core.Data.Repositories;
using Cdw.Domain.Partners.Implementation.APILogging;

namespace Cdw.Domain.Partners.Implementation.DataAccess.APILogging
{
    public class LogRequestResponseRepository : RepositoryBase, ILogRequestResponseRepository
    {

        private const string InsertApiPartnersRequestResponseLogsSp = "[WebDB].[dbo].[Insert_API_Partners_RequestResponseLogs]";
        private const string GetRequestResponseLogsByClientNameSp = "[WebDB].[dbo].[Get_API_Partners_RequestResponseLogsByClientName]";
        private const string GetApiPartnersRequestResponseLogsByIdSp = "[WebDB].[dbo].[Get_API_Partners_RequestResponseLogsById]";
        public LogRequestResponseRepository(Func<IDbClient> dbClientFactory) : base(dbClientFactory) { }

        public Task<RequestResponseLog> InsertRequestResponseLogAsync(RequestResponseLog entity)
        {
  
            var task = Task.Factory.StartNew(() =>
            {
                var firstOrDefault = ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertApiPartnersRequestResponseLogsSp)
                        .AddNamedParameters(new
                        {
                            entity.PartnerName,
                            entity.RequestPath,
                            entity.RequestUri,
                            entity.RequestBody,
                            entity.RequestHeaders,
                            entity.RequestIpFrom,
                            entity.RequestMethod,
                            entity.ResponseHeaders,
                            entity.ResponseBody,
                            entity.ResponseProcessingTime,
                            entity.RequestStartDateUtc, 
                            entity.ResponseResultCode
                        })
                        .ExecuteFetch<RequestResponseLog>()).FirstOrDefault();
                return firstOrDefault;
            });

            return task;
        }

        public async Task<List<RequestResponseLog>> SearchLogsByClientNameAsync(string clientName, DateTime startDate, DateTime endDate, string method,string requestPath, int resultCode)
        {
            var task = Task.Factory.StartNew(() =>
            {
                var list = ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetRequestResponseLogsByClientNameSp)
                        .AddNamedParameters(new { PartnerName = clientName, startDate, endDate, messageType = method,requestPath, resultCode })
                        .ExecuteFetch<RequestResponseLog>());
                return list;
            });

            return await task.ConfigureAwait(false);
        }

        public async Task<RequestResponseLog> GetRequestResponseLogsByIdAndClientNameAsync(string clientName, int id)
        {
            var task = Task.Factory.StartNew(() =>
            {
                var first = ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetApiPartnersRequestResponseLogsByIdSp)
                        .AddNamedParameters(new { PartnerName = clientName, Id = id })
                        .ExecuteFetch<RequestResponseLog>()).FirstOrDefault();
                return first;
            });

            return await task.ConfigureAwait(false);
        }


    }
}
