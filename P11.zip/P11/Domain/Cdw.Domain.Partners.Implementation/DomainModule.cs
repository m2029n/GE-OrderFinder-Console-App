﻿using Autofac;
using AutoMapper;
using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.Freight;
using Cdw.Domain.Partners.Implementation.Mapping;
using Cdw.Domain.Partners.Implementation.Orders;
using Cdw.Domain.Partners.Implementation.Orders.Infrastructure;
using Cdw.Domain.Partners.Implementation.Orders.Services;
using Cdw.Domain.Partners.Implementation.PartnerCart;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Domain.Partners.Implementation.Payments;
using Cdw.Domain.Partners.Implementation.Price;
using Cdw.Domain.Partners.Implementation.Product;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Services;
using Cdw.Domain.Partners.Implementation.Recycling;
using Cdw.Domain.Partners.Implementation.Tax;

namespace Cdw.Domain.Partners.Implementation
{
    public class DomainModule : Module
    {
        private readonly string _cSiteCartHandlerUrl;
        private readonly string _gSiteCartHandlerUrl;
        private readonly string _caSiteCartHandlerUrl;

        public DomainModule(string cSiteCartHandlerUrl, string gSiteCartHandlerUrl, string caSiteCartHandlerUrl)
        {
            _cSiteCartHandlerUrl = cSiteCartHandlerUrl;
            _gSiteCartHandlerUrl = gSiteCartHandlerUrl;
            _caSiteCartHandlerUrl = caSiteCartHandlerUrl;
        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            //TAX
            builder.RegisterType<TaxDomainManager>()
                  .AsImplementedInterfaces()
                  .SingleInstance();

            Mapper.AddProfile(new TaxMappingProfile());

            //Freight
            builder.RegisterType<FreightDomainMapper>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<FreightItemDebundler>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<FreightDomainManager>().AsImplementedInterfaces().SingleInstance();

            //Product
            builder.RegisterType<ProductDomainManager>()
               .AsImplementedInterfaces()
               .SingleInstance();

            Mapper.AddProfile(new ProductMappingProfile());

            //Partner Cart
            builder.RegisterType<PartnerCartDomainManager>()
                .AsImplementedInterfaces()
                .SingleInstance();
            Mapper.AddProfile(new PartnerCartMappingProfile(_cSiteCartHandlerUrl, _gSiteCartHandlerUrl, _caSiteCartHandlerUrl));

            //Order
            builder.RegisterType<OrderManager>()
               .AsImplementedInterfaces()
               .SingleInstance();

            //OrderManager Helpers
            builder.RegisterType<OrderCreateHelperService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<PartnerOrderService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<ProcessCreditCardService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<PostToOrderWriterDomainService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<GetRecycleDetailsService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<GetFreightRaterService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<GetTaxDetailsService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<GetAs400OrderDetailsService>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            builder.RegisterType<AS400OrderDetails>()
                .AsImplementedInterfaces()
                .InstancePerDependency();

            Mapper.AddProfile(new RequestOrdersMappingProfile());
            //Recycling
            builder.RegisterType<RecyclingDomainManager>()
               .AsImplementedInterfaces()
               .SingleInstance();
            
            //Price
            builder.RegisterType<PriceDomainManager>()
             .AsImplementedInterfaces()
             .SingleInstance();
            builder.RegisterType<PartnerDetails>().AsImplementedInterfaces().SingleInstance();
            Mapper.AddProfile(new PriceMappingProfile());

            //CreditCard
            builder.RegisterType<PaymentDomainManager>()
             .AsImplementedInterfaces()
             .SingleInstance();
            Mapper.AddProfile(new PaymentsMappingProfile());

            builder.RegisterType<GetIdentityService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<ProductsCatalogService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<InventoryStatusService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<InventoryPriceService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<SearchProductService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<ProductService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<BundleItemService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<CouponService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<BundleItemService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<CouponRequestService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<BatchFactoryService>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<LogRequestResponseManager>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<PartnerConfigurationSettingsManager>().AsImplementedInterfaces().SingleInstance();
        }
    }
}