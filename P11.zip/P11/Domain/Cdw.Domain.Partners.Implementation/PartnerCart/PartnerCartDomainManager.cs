﻿using System.Threading.Tasks;
using AutoMapper;
using Cdw.Domain.Partners.PartnerCart;
using Cdw.Infrastructure.PartnerCart;
using Cdw.Services.Core;
using Common.Logging;
using HealthCheckMessage = Cdw.Domain.Partners.Implementation.Common.HealthCheckMessage;

namespace Cdw.Domain.Partners.Implementation.PartnerCart
{
    public class PartnerCartDomainManager : IPartnerCartRequestDomainManager
    {
        private readonly ILog _logger;

        private readonly IPartnerCartRequestRepository _partnerCartRequestRepository;

        public PartnerCartDomainManager(ILog logger, IPartnerCartRequestRepository partnerCartRequestRepository)
        {
            _logger = logger;
            _partnerCartRequestRepository = partnerCartRequestRepository;
        }

        public IPartnerCartRequest Create(IPartnerCartRequest partnerCartRequest)
        {
            return Task.Run(() => CreateAsync(partnerCartRequest)).Result;
        }

        public Task<IPartnerCartRequest> CreateAsync(IPartnerCartRequest partnerCartRequest)
        {
            return Task.Run(() =>
            {
                var dbentity = Mapper.Map<IPartnerCartRequestEntity>(partnerCartRequest);
                var dboutEntity = _partnerCartRequestRepository.Create(dbentity);
                var model = Mapper.Map<IPartnerCartRequest>(dboutEntity);
                return model;
            });
        }

        public async Task<IHealthCheckMessage> CheckAsync()
        {
            return await HealthCheck().ConfigureAwait(false);
        }

        public Task<IHealthCheckMessage> HealthCheck()
        {
            var h = new HealthCheckMessage
            {
                Service = "Cart Service",
                Status = HealthStatus.Ready
            };
            return Task.FromResult<IHealthCheckMessage>(h);
        }
    }
}