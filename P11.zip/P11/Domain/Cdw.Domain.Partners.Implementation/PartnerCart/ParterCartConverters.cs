﻿using System.Collections.Generic;
using AutoMapper;
using Cdw.Domain.Partners.PartnerCart;
using Cdw.Infrastructure.PartnerCart;

namespace Cdw.Domain.Partners.Implementation.PartnerCart
{
    internal class PartnerCartRequestConvert : TypeConverter<IPartnerCartRequestEntity, IPartnerCartRequest>
    {
        private readonly string _cSiteCartHandlerUrl;
        private readonly string _gSiteCartHandlerUrl;
        private readonly string _caSiteCartHandlerUrl;

        public PartnerCartRequestConvert(string cSiteCartHandlerUrl, string gSiteCartHandlerUrl, string caSiteCartHandlerUrl)
        {
            _cSiteCartHandlerUrl = cSiteCartHandlerUrl;
            _gSiteCartHandlerUrl = gSiteCartHandlerUrl;
            _caSiteCartHandlerUrl = caSiteCartHandlerUrl;
        }

        protected override IPartnerCartRequest ConvertCore(IPartnerCartRequestEntity source)
        {
            var result = new PartnerCartRequest
            {
                Id = source.VendorCartRequestId,
                Source = source.Source,
                WebSiteId = source.WebSiteID,
                CorrelationId = source.CorrelationId,
                Created = source.DateCreated,
                LineItems = Mapper.Map<IEnumerable<IPartnerCartRequestItem>>(source.LineItems),
                CartUrl = GetCartUrl(source.WebSiteID, source.VendorCartRequestId)
            };

            return result;
        }

        private string GetCartUrl(int websiteId, int id)
        {
            switch (websiteId)
            {
                case 1000://C site
                    return _cSiteCartHandlerUrl + "?vendorcartrequestid=" + id;

                case 1006://G site
                    return _gSiteCartHandlerUrl + "?vendorcartrequestid=" + id;

                case 1014://ca site
                    return _caSiteCartHandlerUrl + "?vendorcartrequestid=" + id;

                default:
                    return "";
            }
        }
    }

    internal class PartnerCartRequestItemConvert : TypeConverter<IPartnerCartRequestItemEntity, IPartnerCartRequestItem>
    {
        protected override IPartnerCartRequestItem ConvertCore(IPartnerCartRequestItemEntity source)
        {
            var result = new PartnerCartRequestItem
            {
                Id = source.VendorCartRequestId,
                Manufacturer = source.Manufacturer,
                ManufacturerPartNumber = source.ManufacturerPartNumber,
                ProductCode = source.MatchedProductCode,
                Quantity = source.Quantity
            };

            return result;
        }
    }
}