﻿namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Common
{
    public class ProductInventory
    {
        private string _productCode;

        public string ProductCode
        {
            get
            {
                if (string.IsNullOrEmpty(_productCode))
                {
                    return string.Empty;
                }
                return _productCode;
            }
            set => _productCode = value;
        }

        public string ManufacturePartNumber { get; set; }
        public decimal PriceAdvertised { get; set; }
        public string ManufactureCode { get; set; }
    }
}