﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions;
using Cdw.Ecommerce.Domain.Product;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class BundleItemService : IBundleItemService
    {
        private readonly IBundleItemsManager _bundleItemsManager;

        public BundleItemService(IBundleItemsManager bundleItemsManager)
        {
            _bundleItemsManager = bundleItemsManager;
        }

        public async Task<string> GetStockStatusAsync(string productItemProductCode, string partnerProductApiCompany)
        {
            var bundleStockStatus = await _bundleItemsManager.GetBundleItemsWithStockStatusAsync(productItemProductCode, partnerProductApiCompany).ConfigureAwait(false);
            if (bundleStockStatus != null)
            {
                return bundleStockStatus.PrimaryProductStatus.StatusMessage();
            }
            return string.Empty;
        }
    }
}