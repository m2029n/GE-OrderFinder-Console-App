using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Price.Product;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class BatchFactoryService : IBatchFactoryService
    {
        private readonly IInventoryStatusService _statusService;
        private readonly IInventoryPriceService _priceService;
        private readonly IProductService _productService;
        private readonly ICouponService _couponService;
        private List<InventoryStatus> _statuses;
        private List<IProductPrices> _prices;
        private List<IProductCore> _productItems;
        private ICouponResponse _couponResponse;

        public BatchFactoryService(IInventoryStatusService statusService, IInventoryPriceService priceService,
            IProductService productService, ICouponService couponService)
        {
            _statusService = statusService;
            _priceService = priceService;
            _productService = productService;
            _couponService = couponService;
            _statuses = new List<InventoryStatus>();
            _prices = new List<IProductPrices>();
            _productItems = new List<IProductCore>();
            _couponResponse = new CouponResponse();
        }

        public async Task LoadBatchedCallsDataAsync(Identity partner, List<ProductInventory> products)
        {
            var statusesCall = _statusService.GetAsync(products, partner.ProductApiCompany);
            var pricesCall = _priceService.GetAsync(products, partner);
            var productDetailsCall = _productService.GetAsync(products, partner);
            await Task.WhenAll(statusesCall, pricesCall, productDetailsCall).ConfigureAwait(false);

            var pricesResults = await pricesCall;
            if (pricesResults != null)
            {
                _prices.AddRange(pricesResults);
            }
            var statusesResults = await statusesCall;
            if (statusesResults != null)
            {
                _statuses.AddRange(statusesResults);
            }
            var productDetailsResults = await productDetailsCall;
            if (productDetailsResults != null)
            {
                _productItems.AddRange(productDetailsResults);
            }

            if (partner.ApplyCoupon)
            {
                _couponResponse = await _couponService.ApplyAsync(_productItems, products, partner).ConfigureAwait(false);
            }
        }

        //TODO: use if fan out calls are save
        //public async Task GetBatchedCallsDataAsyncNew(Identity partner, List<ProductInventory> products)
        //{
        //    var statusesCall = _statusService.GetTasks(products, partner.ProductApiCompany);
        //    var pricesCall = _priceService.GetTasks(products, partner);
        //    var productDetailsCall = _productService.GetTasks(products, partner);

        //    var allTasks = statusesCall.Concat<Task>(pricesCall).Concat(productDetailsCall).ToList();

        //    Task<ICouponResponse> couponCall = null;
        //    if (partner.ApplyCoupon)
        //    {
        //        couponCall = _couponService.ApplyAsync(_productItems, products, partner);
        //        allTasks.Add(couponCall);
        //    }

        //    await Task.WhenAll(allTasks).ConfigureAwait(false);

        //    foreach (var task in pricesCall.ToArray())
        //    {
        //        _prices.AddRange(await task);
        //    }
        //    foreach (var task in statusesCall.ToArray())
        //    {
        //        _statuses.AddRange(await task);
        //    }
        //    foreach (var task in productDetailsCall.ToArray())
        //    {
        //        _productItems.AddRange(await task);
        //    }
        //    if (couponCall != null)
        //    {
        //        _couponResponse = (CouponResponse)await couponCall;
        //    }

        //}

        public List<InventoryStatus> Statuses => _statuses;
        public List<IProductPrices> Prices => _prices;
        public List<IProductCore> ProductItems => _productItems;
        public ICouponResponse CouponResponse => _couponResponse;
    }
}