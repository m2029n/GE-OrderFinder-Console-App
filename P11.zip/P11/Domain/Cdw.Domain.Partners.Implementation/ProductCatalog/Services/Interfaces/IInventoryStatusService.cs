﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IInventoryStatusService
    {
        Task<List<InventoryStatus>> GetAsync(List<ProductInventory> products, string productApiCompanyCode);

        List<Task<IEnumerable<InventoryStatus>>> GetTasks(List<ProductInventory> products, string productApiCompanyCode);
    }
}