﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using IProductPrices = Cdw.Ecommerce.Domain.Price.Product.IProductPrices;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IInventoryPriceService
    {
        Task<List<IProductPrices>> GetAsync(List<ProductInventory> products, Identity partner);

        List<Task<IQueryable<IProductPrices>>> GetTasks(List<ProductInventory> products, Identity partner);
    }
}