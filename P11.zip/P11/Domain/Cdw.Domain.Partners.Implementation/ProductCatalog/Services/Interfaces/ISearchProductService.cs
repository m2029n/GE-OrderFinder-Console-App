﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface ISearchProductService
    {
        Task<List<ProductInventory>> GetAsync(Identity partner);
    }
}