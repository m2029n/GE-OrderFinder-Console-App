﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Price.Product;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IBatchFactoryService
    {
        Task LoadBatchedCallsDataAsync(Identity partner, List<ProductInventory> products);

        List<InventoryStatus> Statuses { get; }
        List<IProductPrices> Prices { get; }
        List<IProductCore> ProductItems { get; }
        ICouponResponse CouponResponse { get; }
    }
}