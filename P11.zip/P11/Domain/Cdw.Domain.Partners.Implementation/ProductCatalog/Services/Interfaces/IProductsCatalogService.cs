﻿using System.Threading.Tasks;
using Cdw.Api.Partners.Model.ProductCatalog;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IProductsCatalogService
    {
        Task<ResponseProductCatalogModel> GetAsync(Identity partner, int limit, int offSet);
    }
}