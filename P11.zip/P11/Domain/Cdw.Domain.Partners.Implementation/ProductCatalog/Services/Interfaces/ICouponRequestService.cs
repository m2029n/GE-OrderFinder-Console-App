﻿using System.Collections.Generic;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface ICouponRequestService
    {
        ICouponRequest BuildCouponRequest(List<IProductCore> products, List<ProductInventory> productinventory, Identity partner, int limit, int offset);
    }
}