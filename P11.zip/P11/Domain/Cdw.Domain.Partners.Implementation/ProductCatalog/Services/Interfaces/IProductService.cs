﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IProductService
    {
        Task<List<IProductCore>> GetAsync(List<ProductInventory> products, Identity partner);

        List<Task<IEnumerable<IProductCore>>> GetTasks(List<ProductInventory> products, Identity partner);
    }
}