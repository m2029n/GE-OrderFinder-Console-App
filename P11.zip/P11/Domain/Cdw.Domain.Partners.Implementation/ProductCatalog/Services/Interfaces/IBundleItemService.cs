﻿using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public interface IBundleItemService
    {
        Task<string> GetStockStatusAsync(string productItemProductCode, string partnerProductApiCompany);
    }
}