﻿using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Product.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class CouponService : ICouponService
    {
        private readonly ICouponDomainManager _couponDomainManager;
        private readonly ICouponRequestService _couponRequestService;

        public CouponService(ICouponDomainManager couponDomainManager, ICouponRequestService couponRequestService)
        {
            _couponDomainManager = couponDomainManager;
            _couponRequestService = couponRequestService;
        }

        public async Task<ICouponResponse> ApplyAsync(List<IProductCore> products, List<ProductInventory> productinventory, Identity partner)
        {
            const int limit = 1000;
            var offset = 0;
            var items = 0;
            var couponItems = new List<ICouponItem>();
            var couponDetails = new List<ICouponDetail>();
            var companyCode = string.Empty;
            var customerNumber = string.Empty;
            var count = products.Count();

            while (items < count)
            {
                var input = _couponRequestService.BuildCouponRequest(products, productinventory, partner, limit, offset);
                var res = await _couponDomainManager.ApplyAsync(input).ConfigureAwait(false);
                if (res == null)
                {
                    break;
                }
                companyCode = res.CompanyCode;
                customerNumber = res.CustomerNumber;
                couponItems.AddRange(res.CouponItems);
                couponDetails.AddRange(res.CouponDetails);
                items += limit;
                offset += limit;
            }

            return new CouponResponse()
            {
                CompanyCode = companyCode,
                CustomerNumber = customerNumber,
                CouponDetails = couponDetails,
                CouponItems = couponItems
            };
        }
    }
}