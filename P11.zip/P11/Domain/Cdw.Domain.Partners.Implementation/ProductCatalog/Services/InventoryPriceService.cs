﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Price;
using Cdw.Ecommerce.Domain.Price.Product;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class InventoryPriceService : IInventoryPriceService
    {
        private readonly IProductPriceManager _productPriceManager;
        private readonly ILog _log;

        public InventoryPriceService(IProductPriceManager productPricemanager, ILog log)
        {
            _productPriceManager = productPricemanager;
            _log = log;
        }

        public async Task<List<IProductPrices>> GetAsync(List<ProductInventory> products, Identity partner)
        {
            var prices = new List<IProductPrices>();

            for (var i = 0; i < products.Count; i = i + 100)
            {
                var codes = products.Select(p => p.ProductCode).Skip(i).Take(100).ToList();

                var request = new PriceRequest
                {
                    CompanyCode = partner.PriceCompanyCode,
                    EDC = codes
                };
                prices.AddRange(await _productPriceManager.GetAsync(request).ConfigureAwait(false));
            }
            return prices;
        }

        public List<Task<IQueryable<IProductPrices>>> GetTasks(List<ProductInventory> products, Identity partner)
        {
            var tasks = new List<Task<IQueryable<IProductPrices>>>();
            if (products == null || partner == null)
            {
                return tasks;
            }
            for (var i = 0; i < products.Count; i = i + 100)
            {
                var codes = products.Select(p => p.ProductCode).Skip(i).Take(100).ToList();
                var request = new PriceRequest
                {
                    CompanyCode = partner.PriceCompanyCode,
                    EDC = codes
                };
                var itemTask = _productPriceManager.GetAsync(request);
                tasks.Add(itemTask);
            }
            return tasks;
        }
    }
}