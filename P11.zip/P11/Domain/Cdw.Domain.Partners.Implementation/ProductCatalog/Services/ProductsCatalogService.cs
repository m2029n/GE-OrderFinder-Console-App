﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Api.Partners.Model.ProductCatalog;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class ProductsCatalogService : IProductsCatalogService
    {
        private readonly ISearchProductService _productSearchService;
        private readonly IBundleItemService _bundleItemService;
        private readonly IBatchFactoryService _batchFactoryService;

        public ProductsCatalogService(ISearchProductService productSearchService,
           IBundleItemService bundleItemService, IBatchFactoryService batchFactoryService)
        {
            _productSearchService = productSearchService;
            _bundleItemService = bundleItemService;
            _batchFactoryService = batchFactoryService;
        }

        public async Task<ResponseProductCatalogModel> GetAsync(Identity partner, int limit, int offSet)
        {
            var model = new ResponseProductCatalogModel();
            if (partner == null)
            {
                return null;
            }
            var productsResult = await _productSearchService.GetAsync(partner).ConfigureAwait(false);
            if (productsResult == null)
            {
                return null;
            }
            model.TotalCount = productsResult.Count;
            var products = productsResult.Skip(offSet).Take(limit).ToList();

            if (limit > model.TotalCount - offSet)
            {
                products = productsResult.Skip(offSet).ToList();
            }

            await _batchFactoryService.LoadBatchedCallsDataAsync(partner, products);
            foreach (var product in products)
            {
                var item = new ProductCatalogModel();
                var productItem = _batchFactoryService.ProductItems.FirstOrDefault(p => p.ProductCode == product.ProductCode);
                item.Price = product.ProductCode.GetPriceByCode(_batchFactoryService.Prices);
                var stockStatus = _batchFactoryService.Statuses?.FirstOrDefault(x => x.ProductCode == product.ProductCode);
                item.StockStatus = stockStatus.StatusMessage();
                item.ProductCode = product.ProductCode;
                if (productItem != null)
                {
                    if (productItem.IsBundle)
                    {
                        item.StockStatus = await _bundleItemService.GetStockStatusAsync(product.ProductCode, partner.ProductApiCompany).ConfigureAwait(false);
                    }
                    item.ApplyCoupon(_batchFactoryService.CouponResponse);
                    if (partner.ShowWeight)
                    {
                        item.Weight = productItem.Weight;
                    }
                }
                item.EstimatedAvailability = item.StockStatus.ToLower().Contains("call for availability")
                    ? DateTime.Today.AddDays(2).ToString("yyyy-MM-dd")
                    : "";

                model.Results.Add(item);

            }
            return model;
        }
    }
}