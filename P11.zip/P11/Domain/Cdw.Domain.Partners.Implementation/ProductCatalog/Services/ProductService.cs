﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductManager _productManager;

        public ProductService(IProductManager productManager)
        {
            _productManager = productManager;
        }

        public async Task<List<IProductCore>> GetAsync(List<ProductInventory> products, Identity partner)
        {
            var productItems = new List<IProductCore>();
            if (products == null || partner == null)
            {
                return productItems;
            }

            for (var i = 0; i < products.ToList().Count; i = i + 100)
            {
                var items = products.ToList().Select(x => x.ProductCode).Skip(i).Take(100).ToList();
                var result = await _productManager.GetProductsAsync(items, partner.CompanyCode.ToString()).ConfigureAwait(false);

                productItems.AddRange(result);
            }
            return productItems;
        }

        public List<Task<IEnumerable<IProductCore>>> GetTasks(List<ProductInventory> products, Identity partner)
        {
            var tasks = new List<Task<IEnumerable<IProductCore>>>();
            if (products == null || partner == null)
            {
                return tasks;
            }
            for (var i = 0; i < products.ToList().Count; i = i + 100)
            {
                var items = products.ToList().Select(x => x.ProductCode).Skip(i).Take(100).ToList();
                var itemTask = _productManager.GetProductsAsync(items, partner.CompanyCode.ToString());

                tasks.Add(itemTask);
            }
            return tasks;
        }
    }
}