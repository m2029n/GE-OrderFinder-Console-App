﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Search;
using Cdw.Ecommerce.Domain.Search.Common;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    internal class SearchProductService : ISearchProductService
    {
        private readonly ISearchDomainManager _searchManager;
        private readonly ILog _log;

        public SearchProductService(ISearchDomainManager searchManager, ILog log)
        {
            _searchManager = searchManager;
            _log = log;
        }

        public async Task<List<ProductInventory>> GetAsync(Identity partner)
        {
            var allResults = new List<ProductInventory>();
            try
            {
                if (partner?.SearchApi?.QueryUri == null)
                {
                    return null;
                }
                var limit = 5000;
                var offSet = 0;
                var keepRunning = true;
                do
                {
                    var searchQuery = new SearchRequest
                    {
                        QueryUri = partner.SearchApi.QueryUri + $"&limit={limit}&offset={offSet}",
                        Catalog = (Catalog)partner.SearchApi.Catalog
                    };

                    var searchResults = await _searchManager.SearchAsync(searchQuery).ConfigureAwait(false);

                    var list = searchResults.Products.Select(source =>
                    {
                        var item = new ProductInventory
                        {
                            ManufactureCode = source.ManufactureCode,
                            ProductCode = source.ProductCode,
                            ManufacturePartNumber = source.ManufacturePartNumber,
                            PriceAdvertised = decimal.Parse(string.IsNullOrEmpty(source.ProductPrice) ? "0" : source.ProductPrice),
                        };
                        return item;
                    }).ToList();
                    if (list.Count > 0)
                    {
                        allResults.AddRange(list);
                        offSet = offSet + limit;
                        if (list.Count < limit)
                        {
                            keepRunning = false;
                        }
                    }
                    else
                    {
                        keepRunning = false;
                    }
                } while (keepRunning);

                return allResults;
            }
            catch (Exception ex)
            {
                _log.Fatal(ex);
                throw;
            }
        }
    }
}