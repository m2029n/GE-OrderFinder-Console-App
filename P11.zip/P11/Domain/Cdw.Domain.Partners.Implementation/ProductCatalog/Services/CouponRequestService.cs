﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class CouponRequestService : ICouponRequestService
    {
        public ICouponRequest BuildCouponRequest(List<IProductCore> products, List<ProductInventory> productinventory, Identity partner, int limit, int offset)
        {
            var companyCode = partner.CompanyCode;
            var list = new List<ProductLine>();
            var i = 1;
            foreach (var product in productinventory)
            {
                var prodItem = products.FirstOrDefault(p => p.ProductCode == product.ProductCode);
                var prodLine = new ProductLine()
                {
                    ProductCode = product.ProductCode,
                    LineNumber = i, // need to be unique if multiple lines used in request
                    QuantityOrdered = 1,
                    QuantityAllocated = 1,
                    QuantityOutstanding = 0,
                    IsCancelled = false,
                    IsDropShip = prodItem?.DropShipOnly == 1,
                    Pricing = new List<ICouponPrice>()
                    {
                        new CouponPrice() {PriceType = EPriceType.Advertised, UnitPrice = product.PriceAdvertised},
                        new CouponPrice() {PriceType = EPriceType.Unit, UnitPrice = product.PriceAdvertised}
                    }
                };
                i++;
                list.Add(prodLine);
            }
            return new CouponRequest()
            {
                CompanyCode = companyCode.ToString(),
                OrderDate = DateTime.Now.Date,
                OrderType = EOrderType.Catalog,
                CouponCodes = partner.CouponPromotionCodes,
                RequestForUser = "WEBUSER",
                ContactSequence = 1,
                DeliverySequence = "000",
                Products = list.Skip(offset).Take(limit)
            };
        }
    }
}