﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.ProductCatalog.Common;
using Cdw.Ecommerce.Domain.Product;
using InventoryStatus = Cdw.Ecommerce.Domain.Product.Models.InventoryStatus;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Services
{
    public class InventoryStatusService : IInventoryStatusService
    {
        private readonly IInventoryStatusManager _inventoryStatusManager;

        public InventoryStatusService(IInventoryStatusManager inventoryStatusManager)
        {
            _inventoryStatusManager = inventoryStatusManager;
        }

        public List<Task<IEnumerable<InventoryStatus>>> GetTasks(List<ProductInventory> products, string productApiCompanyCode)
        {
            var tasks = new List<Task<IEnumerable<InventoryStatus>>>();
            if (products == null || productApiCompanyCode == null)
            {
                return tasks;
            }
            for (var i = 0; i < products.ToList().Count; i = i + 100)
            {
                var items = products.ToList().Select(x => x.ProductCode).Skip(i).Take(100);
                var itemTask = _inventoryStatusManager.GetBulkInventoryStatusAsync(string.Join(",", items), productApiCompanyCode);
                tasks.Add(itemTask);
            }

            return tasks;
        }

        public async Task<List<InventoryStatus>> GetAsync(List<ProductInventory> products, string productApiCompanyCode)
        {
            var productStatusList = new List<InventoryStatus>();
            for (var i = 0; i < products.ToList().Count; i = i + 100)
            {
                var items = products.ToList().Select(x => x.ProductCode).Skip(i).Take(100);
                var result = await _inventoryStatusManager.GetBulkInventoryStatusAsync(string.Join(",", items), productApiCompanyCode).ConfigureAwait(false);
                productStatusList.AddRange(result);
            }
            return productStatusList;
        }
    }
}