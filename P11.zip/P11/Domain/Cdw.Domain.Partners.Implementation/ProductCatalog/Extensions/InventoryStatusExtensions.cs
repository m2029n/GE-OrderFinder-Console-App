﻿using System.Text.RegularExpressions;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions
{
    public static class InventoryStatusExtensions
    {
        public static string StatusMessage(this InventoryStatus stockStatus)
        {
            if (stockStatus == null)
            {
                return string.Empty;
            }
            if (stockStatus.StatusType == 0)
            {
                return string.Empty;
            }
            if (stockStatus.ShortMessage == null)
            {
                return string.Empty;
            }
            string statusMessage = new Regex(@"(In stock)", RegexOptions.Compiled).Replace(stockStatus.ShortMessage, "In Stock");

            switch (stockStatus.StatusType)
            {
                case InventoryStatusType.ShipWithinNumDays:
                case InventoryStatusType.OneToThreeDays:
                case InventoryStatusType.ThreeToSixDays:
                    statusMessage = "Ships in " + stockStatus.ShortMessage;
                    break;

                case InventoryStatusType.NoEta:
                    statusMessage = "Call for Availability";
                    break;

                case InventoryStatusType.InStock:
                case InventoryStatusType.Limited:
                case InventoryStatusType.ElectronicDropShip:
                case InventoryStatusType.AvailableToShipToday:
                    break;
            }

            statusMessage = Regex.Replace(statusMessage, "business ", "", RegexOptions.IgnoreCase);

            return statusMessage;
        }
    }
}