﻿using System.Collections.Generic;
using System.Linq;
using Cdw.Api.Partners.Model.ProductCatalog;
using Cdw.Ecommerce.Domain.Coupon;
using Cdw.Ecommerce.Domain.Price.Product;

namespace Cdw.Domain.Partners.Implementation.ProductCatalog.Extensions
{
    public static class ProductCatalogExtensions
    {
        public static void ApplyCoupon(this ProductCatalogModel item, ICouponResponse couponResponses)
        {
            var couponItem = couponResponses?.CouponItems?.FirstOrDefault(o => o.ProductCode == item.ProductCode);
            var isCouponAvailable = couponItem?.CouponValue > 0;
            if (!isCouponAvailable)
            {
                return;
            }
            var coupon = new CouponModel
            {
                CouponCode = couponItem.CouponCode,
                CouponDisclaimer = couponItem.Disclaimer,
                DiscountedPrice = couponItem.DiscountedPrice
            };
            var couponDetails = couponResponses.CouponDetails?.FirstOrDefault(o => o.CouponCode == coupon.CouponCode);
            coupon.CouponDescription = couponDetails?.CouponDescription;
            if (couponDetails?.EndDate != null)
            {
                coupon.CouponExpiration = couponDetails.EndDate.Value.ToString("M/d/yyyy");
            }
            if (item.Coupons == null)
            {
                item.Coupons = new List<CouponModel>();
            }
            item.Coupons.Add(coupon);
        }

        public static double GetPriceByCode(this string productProductCode, List<IProductPrices> prices)
        {
            var productprices = prices?.FirstOrDefault(ps => ps.ProductCode == productProductCode);
            var product = productprices?.Prices.FirstOrDefault(ps => ps.ProductCode == productProductCode);
            if (product?.Price != null)
            {
                return product.Price;
            }
            return 0;
        }
    }
}