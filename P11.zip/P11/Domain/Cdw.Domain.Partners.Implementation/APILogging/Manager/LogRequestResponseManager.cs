﻿using Cdw.Api.Partners.Model.Logs;
using Cdw.Domain.Partners.Implementation.DataAccess.APILogging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.APILogging
{
    public class LogRequestResponseManager : ILogRequestResponseManager
    {
        private readonly ILogRequestResponseRepository _repository;

        public LogRequestResponseManager(ILogRequestResponseRepository repository)
        {
            _repository = repository;
        }

        public async Task<RequestResponseLog> InsertRequestResponseLogAsync(RequestResponseLog entity)
        {
            return await _repository.InsertRequestResponseLogAsync(entity).ConfigureAwait(false);
        }

        public async Task<ResponseLogsModel> SearchLogsByClientNameAsync(string clientName, DateTime startDate,
            DateTime endDate, string method,string requestPath, int resultCode)
        {
            var models = new List<RequestResponseLogLimitedResponseModel>();
            var list = await _repository.SearchLogsByClientNameAsync(clientName, startDate, endDate, method,requestPath, resultCode).ConfigureAwait(false);
            foreach (var log in list)
            {
                var model = new RequestResponseLogLimitedResponseModel
                {
                    Id = log.Id,
                    HttpStatusCode = log.ResponseResultCode,
                    RequestPath = log.RequestPath,
                    RequestUri = log.RequestUri,
                    Location = $"/logs/{log.Id}",
                    RequestStartDateUtc =  log.RequestStartDateUtc,
                    ResponseProcessingTime = log.ResponseProcessingTime
                };
                models.Add(model);
            }

            var result = new ResponseLogsModel { Results = models };
            return result;
        }

        public async Task<RequestResponseLogModel> GetLogsByIdAsync(string clientName, int id)
        {
            var item = await _repository.GetRequestResponseLogsByIdAndClientNameAsync(clientName, id)
                .ConfigureAwait(false);
            var log = new RequestResponseLogModel
            {
                Id = item.Id,
                PartnerName = item.PartnerName,
                RequestPath = item.RequestPath,
                RequestUri = item.RequestUri,
                RequestBody = item.RequestBody,
                RequestHeaders = item.RequestHeaders,
                RequestIpFrom = item.RequestIpFrom,
                RequestMethod = item.RequestMethod,
                ResponseHeaders = item.ResponseHeaders,
                ResponseBody = item.ResponseBody,
                RequestStartDateUtc = item.RequestStartDateUtc,
                ResponseResultCode = item.ResponseResultCode,
                ResponseProcessingTime = item.ResponseProcessingTime
            };
            return log;
        }
    }
}