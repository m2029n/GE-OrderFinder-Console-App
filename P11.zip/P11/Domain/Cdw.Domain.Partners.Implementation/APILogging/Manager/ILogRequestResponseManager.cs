using Cdw.Api.Partners.Model.Logs;
using System;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.APILogging
{
    public interface ILogRequestResponseManager
    {
        Task<RequestResponseLog> InsertRequestResponseLogAsync(RequestResponseLog entity);

        Task<ResponseLogsModel> SearchLogsByClientNameAsync(string clientName, DateTime startDate, DateTime endDate, string method,string requestPath, int resultCode);

        Task<RequestResponseLogModel> GetLogsByIdAsync(string clientName, int id);
    }
}