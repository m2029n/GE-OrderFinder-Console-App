﻿using System;

namespace Cdw.Domain.Partners.Implementation.APILogging
{
    public class RequestResponseLog
    {
        public int Id { get; set; }
        public string PartnerName { get; set; }
        public string RequestPath { get; set; }
        public string RequestUri { get; set; }
        public string RequestBody { get; set; }
        public string RequestHeaders { get; set; }
        public string RequestIpFrom { get; set; }
        public string RequestMethod { get; set; }
        public string ResponseHeaders { get; set; }
        public string ResponseBody { get; set; } 
        public long ResponseProcessingTime { get; set; }
        public DateTime RequestStartDateUtc { get; set; }
        public DateTime InsertDateUtc { get; set; }
        public int ResponseResultCode { get; set; }
        public string MessageType { get; set; }
    }
}