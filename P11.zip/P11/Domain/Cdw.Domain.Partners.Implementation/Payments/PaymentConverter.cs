﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Payments.CreditCardService;
using Cdw.Domain.Partners.Payments;
using System;

namespace Cdw.Domain.Partners.Implementation.Payments
{
    internal class CreditCardServiceConverter : TypeConverter<ICreditCard, CreditCardAuthorizationRequest>
    {
        protected override CreditCardAuthorizationRequest ConvertCore(ICreditCard source)
        {
            var result = new CreditCardAuthorizationRequest
            {
                ExpirationDate = new DateTime(source.ExpirationYear, source.ExpirationMonth, DateTime.DaysInMonth(source.ExpirationYear, source.ExpirationMonth)),
                IsAuthorizedToSave = true,
                UseAsyncProcessing = false,
                CardVerificationValue = source.CVV,
                CreditCardHolderName = source.Name
            };
            return result;
        }
    }
}