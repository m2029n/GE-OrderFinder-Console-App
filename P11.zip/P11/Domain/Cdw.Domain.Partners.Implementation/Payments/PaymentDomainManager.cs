﻿using AutoMapper;
using Cdw.Api.Partners.Validation;
using Cdw.Domain.Partners.Payments;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Infrastructure.Payments;
using Cdw.Partners.Utilities;
using Cdw.Partners.Validation;
using Common.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CreditCardAuthorizationRequest = Cdw.Domain.Partners.Implementation.Payments.CreditCardService.CreditCardAuthorizationRequest;

namespace Cdw.Domain.Partners.Implementation.Payments
{
    public class PaymentDomainManager : IPaymentDomainManager
    {
        private readonly ILog _logger;
        private readonly ICreditCardServiceDomainManager _creditCardServiceDomainManager;
        private readonly IPartnerSettings _partnerSettings;
        private readonly IPaymentRepository _paymentRepository;

        public PaymentDomainManager(
        ILog logger,
        ICreditCardServiceDomainManager creditCardServiceDomainManager,
        IPaymentRepository paymentRepository,
        IPartnerSettings partnerSettings
        )
        {
            _logger = logger;
            _creditCardServiceDomainManager = creditCardServiceDomainManager;
            _paymentRepository = paymentRepository;
            _partnerSettings = partnerSettings;
        }

        public async Task<IAuthResponse> AuthorizeAsync(IPaymentRequest paymentRequest)
        {
            ICreditCardAuthorizationResponse creditCardResponse;

            try
            {
                var encryptedResult = await _creditCardServiceDomainManager.EncryptAsync(paymentRequest.CreditCard.Number, _partnerSettings.CreditCardAPIKey).ConfigureAwait(false);
                var ccRequest = Mapper.Map<CreditCardAuthorizationRequest>(paymentRequest.CreditCard);

                ccRequest.EncryptedCreditCardText = encryptedResult.EncryptedInfo;

                creditCardResponse = await _creditCardServiceDomainManager.AuthorizeAsync(ccRequest).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                //supress any hard exception which we will get if ETS is down
                _logger.Error("CreditCardService Failed", ex);
                throw;
            }

            if (!creditCardResponse.IsValid)
            {
                var validationmessage = new List<IPaymentValidationFailure>
                    {
                        new FailedRequestValidationResult("CreditCard", creditCardResponse.ErrorMessage)
                    };
                throw new PaymentValidationException(validationmessage);
            }

            try
            {
                var referenceNumber = _paymentRepository
                                        .AddPaymentTokensMapping
                                        (
                                        paymentRequest.TransactionId,
                                        creditCardResponse.CreditCardToken,
                                        paymentRequest.IpAddress,
                                        paymentRequest.GeoLocation,
                                        paymentRequest.UserAgent
                                        );
                return new AuthResponse
                {
                    TransactionId = paymentRequest.TransactionId,
                    ReferenceNumber = referenceNumber
                };
            }
            catch (Exception ex)
            {
                _logger.Error("Payment Authorization failed to retrieve ReferenceNumber", ex);
                throw;
            }
        }
    }
}