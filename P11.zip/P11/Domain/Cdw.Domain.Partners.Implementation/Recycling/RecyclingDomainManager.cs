﻿using Cdw.Api.Partners.Model.Recycling;
using Cdw.Domain.Partners.Recycling;
using Cdw.Infrastructure.Recycling;
using Cdw.Services.Core;
using Common.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCheckMessage = Cdw.Domain.Partners.Implementation.Common.HealthCheckMessage;

namespace Cdw.Domain.Partners.Implementation.Recycling
{
    public class RecyclingDomainManager : IRecyclingDomainManager
    {
        private readonly ILog _logger;

        private readonly IRecyclingRepository _recyclingRepository;

        public RecyclingDomainManager(ILog logger, IRecyclingRepository recyclingRepository)
        {
            _logger = logger;
            _recyclingRepository = recyclingRepository;
        }

        public async Task<IHealthCheckMessage> CheckAsync()
        {
            var h = new HealthCheckMessage { Service = "Recycling Service", Status = HealthStatus.Ready }; // no pass-thru to an external service, so hard-code response;
            return await Task.FromResult<IHealthCheckMessage>(h);
        }

        public async Task<IEnumerable<IRecyclingFeeModel>> GetRecyclingFeesAsync(RecyclingFeeRequestModel recycleFeeRequest)
        {
            if (string.IsNullOrWhiteSpace(recycleFeeRequest?.State) || string.IsNullOrWhiteSpace(recycleFeeRequest.ProductCodes))
            {
                return null;
            }

            var recyclingFeeEntities = await _recyclingRepository.GetRecyclingFeesAsync(recycleFeeRequest.State, recycleFeeRequest.ProductCodes).ConfigureAwait(false);

            if (recyclingFeeEntities == null || !recyclingFeeEntities.Any())
            {
                return null;
            }

            return recyclingFeeEntities.Select(entity => new RecyclingFeeModel
            {
                Amount = entity.UnitFeeAmount,
                Code = entity.FeeEDCName,
                Description = entity.FeeClassName,
                ProductCode = entity.ProductCode,
                ProductFeeEDC = entity.ProductFeeEDC
            }).ToList();
        }

        public async Task<IRecyclingFeeSummaryModel> GetRecyclingFeeSummaryAsync(RecyclingFeeRequestModel recycleFeeRequest)
        {
            var recyclingFees = await GetRecyclingFeesAsync(recycleFeeRequest);

            if (recyclingFees == null || !recyclingFees.Any())
            {
                return null;
            }

            return new RecyclingFeeSummaryModel
            {
                Amount = recyclingFees.Sum(o => o.Amount),
                ProductCodes = string.Join(",", recyclingFees.Select(o => o.ProductCode))
            };
        }
    }
}