﻿using Cdw.Domain.Partners.OrderReader;


namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    internal class ShipmentBoxContent: IShipmentBoxContent
    {
        public string Description { get; set; }
        public string EDC { get; set; }
        public int? EstimatedQuantity { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public int? OrderLineNumber { get; set; }
        public int? QuantityInBox { get; set; }
    }
}
