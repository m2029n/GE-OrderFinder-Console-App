﻿using Cdw.Domain.Partners.OrderReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    internal class ShipmentBox : IShipmentBox
    {
        public int BoxNumber { get; set; }
        public string CarrierCode { get; set; }
        public string CarrierCodeType { get; set; }
        public IEnumerable<IShipmentBoxContent> Contents { get; set; }
        public DateTime? EstimatedDeliveryDate { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? ShipDate { get; set; }
        public string ShipMethod { get; set; }
        public string TrackingNumber { get; set; }
        public decimal? Weight { get; set; }
    }
}
