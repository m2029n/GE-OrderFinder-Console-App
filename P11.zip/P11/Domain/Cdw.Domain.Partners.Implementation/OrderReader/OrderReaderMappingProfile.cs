﻿using AutoMapper;
using Cdw.Domain.Partners.OrderReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    internal class OrderReaderMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();
            Mapper.CreateMap<Ecommerce.Domain.Order.IOrderDetails, OrderDetails>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IOrderLineItem, IOrderLineItem>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IOrderHeader, IOrderHeader>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IBillingAddress, IBillingAddress>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IAddress, IAddress>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IShipmentBox, IShipmentBox>();
            Mapper.CreateMap<Ecommerce.Domain.Order.IShipmentBoxContent, IShipmentBoxContent>();
        }
    }
}
