﻿using Cdw.Domain.Partners.OrderReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    public class BillingAddress : IBillingAddress
    {
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string LastName { get; set; }
        public string ContactName { get; set; }
        public string AttentionName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string CompanyName { get; set; }
        public string City { get; set; }
        public string StateProv { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
    }
}
