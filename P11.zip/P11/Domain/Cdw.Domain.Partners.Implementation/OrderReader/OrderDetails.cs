﻿using Cdw.Domain.Partners.OrderReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    internal class OrderDetails :IOrderDetails
    {     
        public IOrderHeader Header { get; set; }
        public IEnumerable<IOrderLineItem> LineItems { get; set; }
        public IEnumerable<IShipmentBox> Shipments { get; set; }
    }
}
