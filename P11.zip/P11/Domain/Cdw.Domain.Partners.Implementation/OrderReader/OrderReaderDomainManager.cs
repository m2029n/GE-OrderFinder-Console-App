﻿using Cdw.Ecommerce.Domain.Order;
using Cdw.Domain.Partners.OrderReader;
using AutoMapper;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Cdw.Ecommerce.Domain.Product;
using System.Linq;

namespace Cdw.Domain.Partners.Implementation.OrderReader
{
    public class OrderReaderDomainManager : IOrderReaderDomainManager
    {
        private readonly IOrderDomainManager  _orderManager;
        private readonly IProductManager _productManager;
        public OrderReaderDomainManager(IOrderDomainManager orderManager, IProductManager productManager)
        {
            _orderManager = orderManager;
            _productManager = productManager;
        }

        public async Task<Partners.OrderReader.IOrderDetails> GetOrderAsync(string customerNumber, string poNumber)
        {
            var productCodes = new List<string>();
            var orders = await _orderManager.GetOrderHeaderByPONumber(customerNumber, poNumber).ConfigureAwait(false);
            if (orders == null)
            {
                return null;
            }
            var result = await _orderManager.GetOrderDetails((CompanyCode) Enum.Parse(typeof (CompanyCode), orders.CompanyCode),
                        orders.OrderCode, DataMap.Light).ConfigureAwait(false);
            var orderDetails = Mapper.Map<OrderDetails>(result);
            if(orderDetails == null)
            {
                return null;
            }
            productCodes = orderDetails.LineItems.Select(x => x.ProductCode).ToList();
            var products = await _productManager.GetAsync(productCodes).ConfigureAwait(false);
            foreach (var o in orderDetails.LineItems)
            {
                foreach (var p in products.Where(p => p.ProductCode == o.ProductCode))
                {
                    o.FriendlyName = p.FriendlyName;
                    o.FriendlyDescription = p.FriendlyDescription;
                    o.ManuFacturePartNumber = p.ManufacturePartNumber;
                }

            }
            return orderDetails;           
        }
    }
}
