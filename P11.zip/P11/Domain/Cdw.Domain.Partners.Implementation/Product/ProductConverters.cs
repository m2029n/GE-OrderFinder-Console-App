﻿using AutoMapper;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.Product
{
    internal class ProductConverter : TypeConverter<IProductCore, Partners.Product.Product>
    {
        protected override Partners.Product.Product ConvertCore(IProductCore source)
        {
            if (source == null)
            {
                return null;
            }

            var result = new Partners.Product.Product
            {
                ProductCode = source.ProductCode,
                ManufacturerPartNumber = string.IsNullOrEmpty(source.ManufacturePartNumber)
                    ? ""
                    : source.ManufacturePartNumber,
                Description = string.IsNullOrEmpty(source.Description) ? "" : source.Description,
                FriendlyName = string.IsNullOrEmpty(source.FriendlyName) ? "" : source.FriendlyName,
                FriendlyDescription =
                    string.IsNullOrEmpty(source.FriendlyDescription) ? "" : source.FriendlyDescription,
                Name = source.Name
            };

            return result;
        }
    }
}