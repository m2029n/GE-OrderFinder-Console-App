﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.PartnerConfiguration;
using Cdw.Domain.Partners.Product;
using Cdw.Ecommerce.Domain.Product;
using Cdw.Services.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Product
{
    public class ProductDomainManager : IProductDomainManager
    {
        private readonly IProductManager _productManager;
        private readonly IHealthCheck _healthCheck;
        private readonly IPartnerConfigurationSettingsManager _configurationSettings;

        public ProductDomainManager(IProductManager productClientManager, IHealthCheck healthCheck,
       IPartnerConfigurationSettingsManager configurationSettings)
        {
            _configurationSettings = configurationSettings;
            _productManager = productClientManager;
            _healthCheck = healthCheck;
        }

        public IProduct GetProduct(IProductRequest request)
        {
            return Task.Run(() => GetProductAsync(request)).Result;
        }

        public async Task<IProduct> GetProductAsync(IProductRequest request)
        {
            var result = await GetProductsAsync(request).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public IEnumerable<IProduct> GetProducts(IProductRequest request)
        {
            return Task.Run(() => GetProductsAsync(request)).Result;
        }

        public async Task<IEnumerable<IProduct>> GetProductsAsync(IProductRequest request)
        {
            var settings = await _configurationSettings.GetPartnerConfigurationSettingsByNameAsync(request.ClientName).ConfigureAwait(false);
            var ecommresponse = await _productManager.GetProductsAsync(request.ProductCodes.ToList(), settings.CompanyCode.ToString()).ConfigureAwait(false);
            var partnerresponse = Mapper.Map<IEnumerable<Partners.Product.Product>>(ecommresponse);
            return partnerresponse;
        }

        public async Task<IHealthCheckMessage> CheckAsync()
        {
            return await _healthCheck.CheckAsync().ConfigureAwait(false);
        }
    }
}