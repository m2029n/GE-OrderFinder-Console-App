﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Infrastructure.Freight;
using System.Collections.Generic;
using System.Linq;
using FreightPartnerDomainNS = Cdw.Domain.Partners.Freight;
using FreightDomainNS = Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    internal class RatingRequestConverter : TypeConverter<FreightPartnerDomainNS.IRatingRequest, RatingRequest>
    {
        protected override RatingRequest ConvertCore(FreightPartnerDomainNS.IRatingRequest source)
        {
            if (source == null) return null;

            var result = new RatingRequest()
            {
                CompanyCode = source.CompanyCode,
                ItemsToShip = Mapper.Map<IEnumerable<RatingRequestFreightItem>>(source.ItemsToShip),
                Options = Mapper.Map<RatingRequestOptions>(source.Options),
                OrderReferenceNumber = source.OrderReferenceNumber,
                Requester = Mapper.Map<RatingRequester>(source.Requester),
                SalesChannel = Mapper.Map<RatingRequestSalesChannel>(source.SalesChannel),
                ShipTo = Mapper.Map<RatingRequestShippingAddress>(source.ShipTo)
            };
            
            return result;

        }
    }

    internal class RatingResponseConverter : TypeConverter<FreightDomainNS.IRatingResponse, RatingResponsePartner>
    {
        protected override RatingResponsePartner ConvertCore(FreightDomainNS.IRatingResponse source)
        {
            if (source == null) return null;

            var rfdp = source.Freight.Details.Select(rfd => new RatedFreightDetailPartner()
            {
                OrderLineNumber = rfd.OrderLineNumber,
                ProductCode = rfd.ProductCode,
                Weight = rfd.Weight,
                ShippingMethods = Mapper.Map<IEnumerable<RatedFreightDetailShippingMethodPartner>>(rfd.ShippingMethods)
            }).ToList();

            var result = new RatingResponsePartner()
            {
                ErrorMessage = source.ErrorMessage,
                PackageCount = source.PackageCount,
                TransactionIdentifier = source.TransactionIdentifier,
                Freight = new RatedFreightPartner()
                {
                    Details = rfdp,
                    ShippingMethods = Mapper.Map<IEnumerable<RatedFreightShippingMethodPartner>>(source.Freight.ShippingMethods)
                }
            };
            
            return result;
        }
    }

    internal class EnumConvert : TypeConverter<FreightDomainNS.ContractFreightType, FreightPartnerDomainNS.ContractFreightType>
    {
        protected override FreightPartnerDomainNS.ContractFreightType ConvertCore(FreightDomainNS.ContractFreightType source)
        {
            return (FreightPartnerDomainNS.ContractFreightType)((int)source);
        }
    }


}
 
