﻿using Autofac;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    public class FreightDomainModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterType<FreightDomainManager>()
                  .AsImplementedInterfaces()
                  .SingleInstance();
        }
    }
}
