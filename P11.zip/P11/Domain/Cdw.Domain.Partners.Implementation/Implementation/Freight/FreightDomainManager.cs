﻿using AutoMapper;
using Cdw.Domain.Freight;
using Cdw.Domain.Partners.Implementation.Infrastructure.Freight;
using Common.Logging;
using FreightPartnerDomainNS = Cdw.Domain.Partners.Freight;
using FreightDomainNS = Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    public class FreightDomainManager : FreightPartnerDomainNS.IFreightDomainManager
    {
        private readonly ILog _logger;

        private readonly IRatingManager _ratingManager;
        public FreightDomainManager(
            ILog logger,
            IRatingManager ratingManager)
        {
            ConfigureMappings();
            _logger = logger;
            _ratingManager = ratingManager;
        }

        public FreightPartnerDomainNS.IRatingResponse Rate(FreightPartnerDomainNS.IRatingRequest request)
        {
            var ratingRequest = Mapper.Map<RatingRequest>(request);

            var ratingResponse = _ratingManager.RateAsync(ratingRequest).Result;

            var ratingResponsePartner = Mapper.Map<RatingResponsePartner>(ratingResponse);
        
            return ratingResponsePartner;
        }

        private static void ConfigureMappings()
        {
            #region RequestObjectMapping
            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequest, RatingRequest>().
                   ConvertUsing(new RatingRequestConverter());

            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequestFreightItem, RatingRequestFreightItem>();
            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequestOptions, RatingRequestOptions>();
            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequester, RatingRequester>();
            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequestSalesChannel, RatingRequestSalesChannel>();
            Mapper.CreateMap<FreightPartnerDomainNS.IRatingRequestShippingAddress, RatingRequestShippingAddress>();
            #endregion

            #region ResponseObjectMapping
            Mapper.CreateMap<FreightDomainNS.IRatingResponse, RatingResponsePartner>().
                    ConvertUsing(new RatingResponseConverter());

            Mapper.CreateMap<FreightDomainNS.IRatedFreight, RatedFreightPartner>();
            Mapper.CreateMap<FreightDomainNS.IRatedFreightShippingMethod, RatedFreightShippingMethodPartner>();
            Mapper.CreateMap<FreightDomainNS.IRatedFreightDetail, RatedFreightDetailPartner>();
            Mapper.CreateMap<FreightDomainNS.IRatingResponse, RatingResponsePartner>();
            Mapper.CreateMap<FreightDomainNS.IRatedFreightShippingMethod, RatedFreightShippingMethodPartner>();
            Mapper.CreateMap<FreightDomainNS.IRatedFreightDetailShippingMethod, RatedFreightDetailShippingMethodPartner>();
            Mapper.CreateMap<FreightDomainNS.ContractFreightType, FreightPartnerDomainNS.ContractFreightType>().
                ConvertUsing(new EnumConvert()); 
            #endregion
        }
       
    }
}
