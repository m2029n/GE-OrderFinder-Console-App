﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Product;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Implementation.Product
{
    public class ProductDomainManager : IProductDomainManager
    {
        private readonly ILog _logger;
        public ProductDomainManager(ILog logger)
        {
            this._logger = logger;
        }

        public IProduct Get(int productId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IProduct> Get(IEnumerable<int> productIds)
        {
            throw new NotImplementedException();
        }

        public IProduct Get(string productCode)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IProduct> Get(IEnumerable<string> productCodes)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IProduct> GetProductIdsByManufacturerNameAndPartNumber(string manufacturerName, string manufacturePartNumbers)
        {
            throw new NotImplementedException();
        }

        public IProduct GetReplacementProduct(IProduct product)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IProduct> FilterProductsInLogicalCatalog(IEnumerable<IProduct> productIds, int logicalCatalogId)
        {
            throw new NotImplementedException();
        }
    }
}
