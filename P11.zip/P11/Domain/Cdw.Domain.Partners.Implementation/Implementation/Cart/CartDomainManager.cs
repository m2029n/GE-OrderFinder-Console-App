﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Domain.Partners.Cart;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Implementation.Cart
{
    public class CartDomainManager : ICartDomainManager
    {
        private readonly ILog _logger;

        public CartDomainManager(ILog logger)
        {
            this._logger = logger;
        }
        public ICart Create(ICart newCart)
        {
            throw new NotImplementedException();
        }

        public ICart Get(int cartId)
        {
            throw new NotImplementedException();
        }

        public ICart CreateAS400Cart(ICart cart, IEnumerable<ICartItem> cartItems)
        {
            throw new NotImplementedException();
        }
    }
}
