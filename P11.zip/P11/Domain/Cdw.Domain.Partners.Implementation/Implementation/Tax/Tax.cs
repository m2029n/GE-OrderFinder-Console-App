﻿using Cdw.Domain.Partners.Tax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Tax
{
    public class Tax : ITaxPartner
    {
        public decimal Amount
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public string Id
        {
            get;
            set;
        }

        public decimal Rate
        {
            get;
            set;
        }
    }
}
