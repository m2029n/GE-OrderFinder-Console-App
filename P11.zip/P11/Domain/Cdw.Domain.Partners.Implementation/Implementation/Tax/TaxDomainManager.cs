﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Infrastructure.Tax;
using Cdw.Domain.Partners.Tax;
using Cdw.Domain.Tax;
using Common.Logging;
using TaxPartnerDomain = Cdw.Domain.Partners.Tax;
using TaxDomain = Cdw.Domain.Tax;

namespace Cdw.Domain.Partners.Implementation.Tax
{
    public class TaxDomainManager : ITaxDomainManager
    {
        private readonly ILog _logger;

        private readonly ITaxRequestDomainManager _taxRequestDomainManager;

        public TaxDomainManager(ILog logger, ITaxRequestDomainManager taxRequestDomainManager)
        {
            ConfigureMappings();
            _logger = logger;
            _taxRequestDomainManager = taxRequestDomainManager;
        }

        public TaxPartnerDomain.ITax[] GetTaxLines(TaxPartnerDomain.ITaxRequest taxRequest)
        {
            var taxrequest = Mapper.Map<TaxPartnerDomain.ITaxRequest, TaxDomain.ITaxRequest>(taxRequest);

            var itaxentity = _taxRequestDomainManager.GetTaxLines(taxrequest);

            return Mapper.Map<TaxPartner[]>(itaxentity); 
        }

        private static void ConfigureMappings()
        {

            Mapper.CreateMap<TaxPartnerDomain.IAccount, TaxDomain.IAccount>();
            Mapper.CreateMap<TaxPartnerDomain.IAddress, TaxDomain.IAddress>();
            Mapper.CreateMap<TaxPartnerDomain.ICustomProperty, TaxDomain.ICustomProperty>();
            Mapper.CreateMap<TaxPartnerDomain.IDiscount, TaxDomain.IDiscount>();
            Mapper.CreateMap<TaxPartnerDomain.ILineItem, TaxDomain.ILineItem>();
            Mapper.CreateMap<TaxPartnerDomain.ITaxRequest, TaxDomain.ITaxRequest>();


            Mapper.CreateMap<TaxDomain.ITax, TaxPartner>(); //Out Object
        }
    }
}
