﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Ecommerce.Domain.Product;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    public interface IFreightItemDebundler
    {
        Task<RatingRequestFreightItemModel[]> GetDeBundledFreightItemsAsync(RatingRequestModel model);
    }

    public class FreightItemDebundler : IFreightItemDebundler
    {
        private readonly IBundleItemsManager _bundleItemsManager;
        private readonly IProductManager _productManager;

        public FreightItemDebundler(IBundleItemsManager bundleItemsManager, IProductManager productManager)
        {
            _bundleItemsManager = bundleItemsManager;
            _productManager = productManager;
        }

        public async Task<RatingRequestFreightItemModel[]> GetDeBundledFreightItemsAsync(RatingRequestModel model)
        {
            // Get all product codes in request
            var lineItemsProductCodes = string.Join(",", model.ItemsToShip.Select(x => x.ProductCode).ToList());

            // Get product information of all products in request
            var products = await _productManager.GetBulkProductsAsync(lineItemsProductCodes, model.CompanyCode).ConfigureAwait(false);

            var expandedProductsList = new List<RatingRequestFreightItemModel>();

            //Initialize an index for order line number
            var index = 0;
            if (products == null)
            {
                return expandedProductsList.ToArray();
            }

            foreach (var product in products)
            {
                var requestItem = model.ItemsToShip.First(q => q.ProductCode == product.ProductCode);

                if (product.IsBundle)
                {
                    // Get all children products in the bundle
                    var childrenItems = await _bundleItemsManager.GetAsync(product.ProductCode).ConfigureAwait(false);
                    var bundleItemsToShip = childrenItems.Select((x, i) => BuildRatingRequestFreightItemModel(i + index, x.ProductCode, requestItem.UnitPrice, requestItem.Quantity));
                    expandedProductsList.AddRange(bundleItemsToShip);
                    index = index + childrenItems.Count();
                }
                else
                {
                    var itemsToShip = BuildRatingRequestFreightItemModel(index, product.ProductCode, requestItem.UnitPrice, requestItem.Quantity);
                    expandedProductsList.Add(itemsToShip);
                    index = index + 1;
                }
            }

            return expandedProductsList.ToArray();
        }

        private RatingRequestFreightItemModel BuildRatingRequestFreightItemModel(int index, string productCode, decimal unitPrice, int quantity)
        {
            return new RatingRequestFreightItemModel
            {
                ContractReferenceNumber = null,
                OrderLineNumber = index + 1,
                ProductCode = productCode,
                Quantity = quantity,
                UnitPrice = unitPrice
            };
        }
    }
}