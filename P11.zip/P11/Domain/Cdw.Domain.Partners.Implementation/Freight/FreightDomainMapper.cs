﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Domain.Freight;
using Cdw.Domain.Partners.Freight;
using Cdw.Domain.Partners.Implementation.Freight.FreightDomain;
using Cdw.Infrastructure.PartnerOrder;
using Common.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    public interface IFreightDomainMapper
    {
        RatingRequest ToRatingRequest(RatingRequestModel model);

        RatingResponsePartner ToRatingResponsePartner(Domain.Freight.IRatingResponse ratingResponse, IEnumerable<ShippingMethodPropertiesEntity> shippingMethodProperties);
    }

    public class FreightDomainMapper : IFreightDomainMapper
    {
        private readonly ILog _logger;

        public FreightDomainMapper(ILog logger)
        {
            _logger = logger;
        }

        public RatingRequest ToRatingRequest(RatingRequestModel model)
        {
            if (model == null)
            {
                return null;
            }

            try
            {
                var result = new RatingRequest
                {
                    CompanyCode = model.CompanyCode,
                    CustomerNumber = "TODO: VALIDATE WHY THIS PROPERTY IS HERE",
                    OrderReferenceNumber = model.OrderReferenceNumber,
                    ItemsToShip = model.ItemsToShip?.Select(x => ToIRatingRequestFreightItem(x)),
                    Options = ToIRatingRequestOptions(model.Options),
                    Requester = ToIRatingRequester(model.Requester),
                    SalesChannel = ToRatingRequestSalesChannel(model.SalesChannel),
                    ShipTo = ToRatingRequestShippingAddress(model.ShipTo)
                };

                return result;
            }
            catch (Exception ex)
            {
                _logger.Error($"FreightDomainMapper.ToRatingRequest failed. model={JsonConvert.SerializeObject(model)}", ex);
                throw;
            }
        }

        public RatingResponsePartner ToRatingResponsePartner(Domain.Freight.IRatingResponse ratingResponse, IEnumerable<ShippingMethodPropertiesEntity> shippingMethodProperties)
        {
            try
            {
                var suppressItems = shippingMethodProperties?
                                    .Where(x => x.IsSuppressed)
                                    .ToList();

                var shippingMethods = shippingMethodProperties == null ?
                    ratingResponse.Freight.ShippingMethods :
                    ratingResponse.Freight.ShippingMethods.Where(y => suppressItems.All(p1 => p1.ShippingMethod != y.Code));

                return new RatingResponsePartner
                {
                    ErrorMessage = ratingResponse.ErrorMessage,
                    PackageCount = ratingResponse.PackageCount,
                    TransactionIdentifier = ratingResponse.TransactionIdentifier,
                    Freight = new RatedFreightPartner
                    {
                        Details = ratingResponse.Freight.Details?.Select(source => ToRatedFreightDetailPartner(source, suppressItems)).ToList(),
                        ShippingMethods = shippingMethods?
                                            .Select(source => ToIRatedFreightShippingMethod(source, shippingMethodProperties)).ToList()
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.Error($"FreightDomainMapper.ToRatingResponsePartner failed. ratingResponse={JsonConvert.SerializeObject(ratingResponse)} shippingMethodProperties={JsonConvert.SerializeObject(shippingMethodProperties)}", ex);
                throw;
            }
        }

        internal RatedFreightShippingMethodPartner ToIRatedFreightShippingMethod(Domain.Freight.IRatedFreightShippingMethod source, IEnumerable<ShippingMethodPropertiesEntity> shippingMethodProperties)
        {
            if (source == null)
            {
                return null;
            }

            var shippingMethod = shippingMethodProperties?.FirstOrDefault(x => x.ShippingMethod == source.Code);
            var transitBusinessDays = shippingMethod != null ? shippingMethod.TransitBusinessDays : "NA";

            return new RatedFreightShippingMethodPartner
            {
                BoxHandlingCharge = source.BoxHandlingCharge,
                Code = source.Code,
                ContractFreightTypesApplied = (Partners.Freight.ContractFreightType)source.ContractFreightTypesApplied,
                Cost = source.Cost,
                Description = source.Description,
                //  DropShipMethodCode  - // TODO: SMM 3/19 - this property has no source.  Research if it can be dropped from the response object
                EstimatedArrival = source.EstimatedArrival,
                FreightCharge = source.FreightCharge,
                InsuranceCharge = source.InsuranceCharge,
                IsCustomerAccount = source.IsCustomerAccount,
                Name = source.Name,
                OrderHandlingCharge = source.OrderHandlingCharge,
                OtherCharge = source.OtherCharge,
                SaturdayCharge = source.SaturdayCharge,
                SpecialCode = source.SpecialCode,
                TotalCharge = source.TotalCharge,
                TotalWeight = source.TotalWeight,
                TransitBusinessDays = transitBusinessDays,
                WeightType = source.WeightType
            };
        }

        internal RatedFreightDetailPartner ToRatedFreightDetailPartner(Domain.Freight.IRatedFreightDetail source, IEnumerable<ShippingMethodPropertiesEntity> suppressItems)
        {
            if (source == null)
            {
                return null;
            }

            var shippingMethods = suppressItems == null ?
                    source.ShippingMethods :
                    source.ShippingMethods.Where(y => suppressItems.All(p1 => p1.ShippingMethod != y.Code));

            return new RatedFreightDetailPartner
            {
                OrderLineNumber = source.OrderLineNumber,
                ProductCode = source.ProductCode,
                Weight = source.Weight,
                ShippingMethods = shippingMethods.Select(x => ToRatedFreightDetailShippingMethod(x)).ToList()
            };
        }

        internal RatedFreightDetailShippingMethod ToRatedFreightDetailShippingMethod(Domain.Freight.IRatedFreightDetailShippingMethod source)
        {
            if (source == null)
            {
                return null;
            }

            return new RatedFreightDetailShippingMethod
            {
                BoxHandlingCharge = source.BoxHandlingCharge,
                Code = source.Code,
                ContractFreightTypesApplied = (Partners.Freight.ContractFreightType)source.ContractFreightTypesApplied,
                Cost = source.Cost,
                DropShipMethodCode = source.DropShipMethodCode,
                FreightCharge = source.FreightCharge,
                InsuranceCharge = source.InsuranceCharge,
                OrderHandlingCharge = source.OrderHandlingCharge,
                OtherCharge = source.OtherCharge,
                SaturdayCharge = source.SaturdayCharge,
                TotalCharge = source.TotalCharge,
            };
        }

        internal IRatingRequestFreightItem ToIRatingRequestFreightItem(RatingRequestFreightItemModel model)
        {
            if (model == null)
            {
                return null;
            }

            return new RatingRequestFreightItem
            {
                ContractReferenceNumber = model.ContractReferenceNumber,
                OrderLineNumber = model.OrderLineNumber,
                ParentOrderLineNumber = model.ParentOrderLineNumber,
                ProductCode = model.ProductCode,
                Quantity = model.Quantity,
                UnitPrice = model.UnitPrice
            };
        }

        internal IRatingRequestOptions ToIRatingRequestOptions(RatingRequestOptionsModel model)
        {
            if (model == null)
            {
                return null;
            }

            return new RatingRequestOptions
            {
                Debug = model.Debug,
                ExcludeExtendedInfo = model.ExcludeExtendedInfo,
                ExcludePackages = model.ExcludePackages,
                ExcludeRates = model.ExcludeRates,
                IncludeFreightDetails = model.IncludeFreightDetails,
                IncludeUnavailableRates = model.IncludeUnavailableRates,
                IsCod = model.IsCod,
                IsDropShip = model.IsDropShip,
                IsFree = model.IsFree
            };
        }

        internal IRatingRequester ToIRatingRequester(RatingRequesterModel model)
        {
            if (model == null)
            {
                return null;
            }

            return new RatingRequester
            {
                ApplicationName = model.ApplicationName,
                HostName = model.HostName,
                JobName = model.JobName,
                Platform = model.Platform
            };
        }

        internal RatingRequestSalesChannel ToRatingRequestSalesChannel(RatingRequestSalesChannelModel model)
        {
            if (model == null)
            {
                return null;
            }

            return new RatingRequestSalesChannel
            {
                Code = model.Code,
                ShipMethodFilter = (Domain.Freight.SalesChannelShipMethodFilter)Enum.Parse(typeof(Domain.Freight.SalesChannelShipMethodFilter), model.ShipMethodFilter)
            };
        }

        internal RatingRequestShippingAddress ToRatingRequestShippingAddress(RatingRequestShippingAddressModel model)
        {
            if (model == null)
            {
                return null;
            }

            return new RatingRequestShippingAddress
            {
                City = model.City,
                CompanyName = model.CompanyName,
                Country = model.Country,
                FirstName = model.FirstName,
                IsResidence = model.IsResidence,
                LastName = model.LastName,
                Line1 = model.Line1,
                Line2 = model.Line2,
                PostalCode = model.PostalCode,
                State = model.State
            };
        }
    }
}