﻿using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    internal class RatingRequestFreightItem : IRatingRequestFreightItem
    {
        public string ContractReferenceNumber { get; set; }
        public int OrderLineNumber { get; set; }
        public int? ParentOrderLineNumber { get; set; }
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }
}