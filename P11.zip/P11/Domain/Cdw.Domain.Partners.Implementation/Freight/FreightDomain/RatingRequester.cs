﻿using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    internal class RatingRequester : IRatingRequester
    {
        public string ApplicationName { get; set; }
        public string HostName { get; set; }
        public string JobName { get; set; }
        public string Platform { get; set; }
    }
}