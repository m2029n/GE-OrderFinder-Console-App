﻿using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    internal class RatingRequestOptions : IRatingRequestOptions
    {
        public bool Debug { get; set; }
        public bool ExcludeExtendedInfo { get; set; }
        public bool ExcludePackages { get; set; }
        public bool ExcludeRates { get; set; }
        public bool IncludeFreightDetails { get; set; }
        public bool IncludeUnavailableRates { get; set; }
        public bool IsCod { get; set; }
        public bool IsDropShip { get; set; }
        public bool IsFree { get; set; }
    }
}