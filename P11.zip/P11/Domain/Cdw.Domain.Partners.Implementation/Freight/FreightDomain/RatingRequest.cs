﻿using System.Collections.Generic;
using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    public class RatingRequest : IRatingRequest
    {
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
        public IEnumerable<IRatingRequestFreightItem> ItemsToShip { get; set; }
        public IRatingRequestOptions Options { get; set; }
        public string OrderReferenceNumber { get; set; }
        public IRatingRequester Requester { get; set; }
        public IRatingRequestSalesChannel SalesChannel { get; set; }
        public IRatingRequestShippingAddress ShipTo { get; set; }
    }
}