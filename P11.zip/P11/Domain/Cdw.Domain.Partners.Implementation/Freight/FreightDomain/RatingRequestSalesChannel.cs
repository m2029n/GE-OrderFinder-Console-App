﻿using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    internal class RatingRequestSalesChannel : IRatingRequestSalesChannel
    {
        public string Code { get; set; }
        public SalesChannelShipMethodFilter ShipMethodFilter { get; set; }
    }
}