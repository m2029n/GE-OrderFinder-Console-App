﻿using Cdw.Domain.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight.FreightDomain
{
    public class RatingRequestShippingAddress : IRatingRequestShippingAddress
    {
        public string City { get; set; }
        public string CompanyName { get; set; }
        public string Country { get; set; }
        public string FirstName { get; set; }
        public bool IsResidence { get; set; }
        public string LastName { get; set; }
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string PostalCode { get; set; }
        public string State { get; set; }
    }
}