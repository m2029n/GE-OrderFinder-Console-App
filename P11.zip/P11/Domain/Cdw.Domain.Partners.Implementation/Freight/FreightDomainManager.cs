﻿using Cdw.Api.Partners.Model.Freight;
using Cdw.Clients.Freight;
using Cdw.Common;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Partners.Utilities;
using Cdw.Security.OAuth2.Client;
using Cdw.Services.Core;
using Common.Logging;
using System.Threading.Tasks;
using FreightDomainNS = Cdw.Domain.Freight;
using FreightPartnerDomainNS = Cdw.Domain.Partners.Freight;

namespace Cdw.Domain.Partners.Implementation.Freight
{
    public class FreightDomainManager : FreightPartnerDomainNS.IFreightDomainManager
    {
        private readonly IFreightDomainMapper _freightDomainMapper;
        private readonly IFreightItemDebundler _freightItemDebundler;
        private readonly IHealthCheck _healthCheck;
        private readonly ILog _logger;
        private readonly IPartnerOrderRepository _partnerOrderRepository;
        private readonly FreightDomainNS.IRatingManager _ratingClientManager;

        public FreightDomainManager(IFreightDomainMapper freightDomainMapper, IFreightItemDebundler freightItemDebundler, ILog logger, IPartnerOrderRepository partnerOrderRepository, IRatingClientManager ratingClientManager)
        {
            _freightDomainMapper = freightDomainMapper;
            _freightItemDebundler = freightItemDebundler;
            _healthCheck = ratingClientManager;
            _logger = logger;
            _partnerOrderRepository = partnerOrderRepository;
            _ratingClientManager = ratingClientManager;
        }
                
        public async Task<IHealthCheckMessage> CheckAsync()
        {
            return await _healthCheck.CheckAsync().ConfigureAwait(false);
        }

        public async Task<FreightPartnerDomainNS.IRatingResponse> RateAsync(string clientName, RatingRequestModel model, ITrackingValues trackingValues)
        {
            _logger.Debug("FreightDomainManager.RateAsync - Step 1: Freight Rater Mapper", trackingValues);

            model.ItemsToShip = await _freightItemDebundler.GetDeBundledFreightItemsAsync(model);
            var ratingRequest = _freightDomainMapper.ToRatingRequest(model);

            _logger.Debug("FreightDomainManager.RateAsync - Step 2: Freight Rater Client Call & ShippingMethod Mapping", trackingValues);

            var ratingResponseTask = _ratingClientManager.WithTracking(trackingValues).RateAsync(ratingRequest);
            var shippingMethodPropertiesTask = _partnerOrderRepository.GetShippingMethodPropertiesAsync(clientName);

            await Task.WhenAll(ratingResponseTask, shippingMethodPropertiesTask).ConfigureAwait(false);

            var ratingResponse = await ratingResponseTask;
            var shippingMethodProperties = await shippingMethodPropertiesTask;

            _logger.Debug("FreightDomainManager.RateAsync - Step 3: Freight Rater response mapping", trackingValues);
            var result = _freightDomainMapper.ToRatingResponsePartner(ratingResponse, shippingMethodProperties);

            _logger.Debug("FreightDomainManager.RateAsync - Step 4: Freight Rater Call Ends", trackingValues);
            return result;
        }
    }
}