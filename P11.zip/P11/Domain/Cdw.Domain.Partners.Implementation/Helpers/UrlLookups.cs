﻿using System.Configuration;
using Cdw.Domain.Partners.Common;

namespace Cdw.Domain.Partners.Implementation.Helpers
{
    public static class UrlLookups
    {
        public static string GetSiteName(CdwCompany cdwCompanyId, string edc)
        {
            var site = ConfigurationManager.AppSettings["EmailProductUrl"];
            switch (cdwCompanyId)
            {
                case CdwCompany.CDW:
                    return string.Format(site, "www.cdw.com", edc);

                case CdwCompany.CDWG:
                    return string.Format(site, "www.cdwg.com", edc);

                case CdwCompany.CDWCa:
                    return string.Format(site, "www.cdw.ca", edc);

                default:
                    return string.Format(site, "www.cdw.com", edc);
            }
        }
    }
}