﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Tax;
using Cdw.Domain.Partners.Tax;
using Cdw.Domain.Tax;
using Account = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Account;
using Address = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Address;
using CustomProperty = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.CustomProperty;
using Discount = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.Discount;
using IAccount = Cdw.Domain.Partners.Tax.IAccount;
using IAddress = Cdw.Domain.Partners.Tax.IAddress;
using ICustomProperty = Cdw.Domain.Partners.Tax.ICustomProperty;
using IDiscount = Cdw.Domain.Partners.Tax.IDiscount;
using ILineItem = Cdw.Domain.Partners.Tax.ILineItem;
using IProductFee = Cdw.Domain.Partners.Tax.IProductFee;
using ITax = Cdw.Domain.Tax.ITax;
using ITaxRequest = Cdw.Domain.Partners.Tax.ITaxRequest;
using LineItem = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.LineItem;
using ProductFee = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.ProductFee;
using TaxRequest = Cdw.Domain.Partners.Implementation.Tax.TaxDomain.TaxRequest;

namespace Cdw.Domain.Partners.Implementation.Mapping
{
    internal class TaxMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<IAccount, Account>();
            Mapper.CreateMap<IDiscount, Discount>();
            Mapper.CreateMap<IAddress, Address>();
            Mapper.CreateMap<ICustomProperty, CustomProperty>();
            Mapper.CreateMap<ILineItem, LineItem>()
                 .ConvertUsing(new LineItemConverter());
            Mapper.CreateMap<IProductFee, ProductFee>();
            Mapper.CreateMap<ITaxRequest, TaxRequest>()
                .ConvertUsing(new TaxConverter());

            Mapper.CreateMap<ITax, TaxPartner>();

            Mapper.CreateMap<ITax, TaxHeader>()
                .ConvertUsing(new TaxHeaderConverter());

            Mapper.CreateMap<ITax, TaxLineItem>()
                .ConvertUsing(new TaxLineItemConverter());

            Mapper.CreateMap<ITaxResponse, TaxDetailResponse>()
                .ConvertUsing(new TaxDetailResponseConverter());
        }
    }
}