﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Payments;
using Cdw.Domain.Partners.Implementation.Payments.CreditCardService;
using Cdw.Domain.Partners.Payments;

namespace Cdw.Domain.Partners.Implementation.Mapping
{
    internal class PaymentsMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();
            Mapper.CreateMap<ICreditCard, CreditCardAuthorizationRequest>()
               .ConvertUsing(new CreditCardServiceConverter());
        }
    }
}