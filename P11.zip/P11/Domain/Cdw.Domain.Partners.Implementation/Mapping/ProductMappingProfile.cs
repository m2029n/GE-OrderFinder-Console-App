﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Product;
using Cdw.Ecommerce.Domain.Product.Models;

namespace Cdw.Domain.Partners.Implementation.Mapping
{
    internal class ProductMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<IProductCore, Partners.Product.Product>().
                   ConvertUsing(new ProductConverter());
        }
    }
}