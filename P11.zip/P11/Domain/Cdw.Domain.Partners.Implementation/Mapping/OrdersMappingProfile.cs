﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.Freight.FreightDomain;
using Cdw.Domain.Partners.Implementation.Orders.CreditCardService;
using Cdw.Domain.Partners.Implementation.Orders.DomainToEntity;
using Cdw.Domain.Partners.Implementation.Orders.Enterprise;
using Cdw.Domain.Partners.Implementation.Orders.EntityToDomain;
using Cdw.Domain.Partners.Implementation.Orders.RequestToDomain;
using Cdw.Domain.Tax;
using Cdw.Ecommerce.Domain.CreditCardService;
using Cdw.Ecommerce.Domain.Order;
using Cdw.Ecommerce.Domain.OrderWriter;
using Cdw.Infrastructure.PartnerOrder;
using CreditCardAuthorizationRequest = Cdw.Domain.Partners.Implementation.Orders.CreditCardService.CreditCardAuthorizationRequest;
using IAddress = Cdw.Ecommerce.Domain.Order.IAddress;
using PartnerDomain = Cdw.Domain.Partners.Orders;

namespace Cdw.Domain.Partners.Implementation.Mapping
{
    public class RequestOrdersMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();

            #region Request object to domain object

            Mapper.CreateMap<PartnerDomain.IRequestOrder, PartnerDomain.Order>()
                .ConvertUsing(new OrderConverter());

            Mapper.CreateMap<PartnerDomain.IAddress, PartnerDomain.Address>();

            Mapper.CreateMap<PartnerDomain.ICreditCard, PartnerDomain.CreditCard>();

            Mapper.CreateMap<PartnerDomain.IPaymentMethod, PartnerDomain.PaymentMethod>()
                .ConvertUsing(new PaymentMethodConverter());

            Mapper.CreateMap<PartnerDomain.IRequestOrder, PartnerDomain.ICart>()
                .ConvertUsing(new CartConverter());

            Mapper.CreateMap<PartnerDomain.ILineItem, PartnerDomain.CartItem>()
                .ConvertUsing(new CartItemConverter());

            #endregion Request object to domain object

            #region OrderDetails Mapping

            Mapper.CreateMap<PartnerDomain.IOrderLineItem, PartnerDomain.OrderLineItem>();
            Mapper.CreateMap<IOrderDetails, PartnerDomain.OrderDetails>();
            Mapper.CreateMap<IOrderLineItem, PartnerDomain.IOrderLineItem>();
            Mapper.CreateMap<IOrderHeader, PartnerDomain.IOrderHeader>();
            Mapper.CreateMap<IBillingAddress, PartnerDomain.IAddress>()
             .ConvertUsing(new BillingAddressConverter());
            Mapper.CreateMap<IAddress, PartnerDomain.IAddress>()
             .ConvertUsing(new ShippingAddressConverter());
            Mapper.CreateMap<IShipmentBox, PartnerDomain.IShipmentBox>();
            Mapper.CreateMap<IShipmentBoxContent, PartnerDomain.IShipmentBoxContent>();

            #endregion OrderDetails Mapping

            #region Domain Object to Entity

            Mapper.CreateMap<PartnerDomain.ICart, CartEntity>()
                .ConvertUsing(new CartDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICartDiscounts, CartDiscountsEntity>()
                .ConvertUsing(new CartDiscountsDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.IDiscount, DiscountEntity>()
                .ConvertUsing(new DiscountDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICartItemDiscounts, CartItemDiscountsEntity>()
                .ConvertUsing(new CartItemDiscountsDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICartItem, CartItemEntity>()
                .ConvertUsing(new CartItemDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICustomProperty, CustomPropertyEntity>()
                .ConvertUsing(new CustomPropertyDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICreditCard, CreditCardEntity>()
                .ConvertUsing(new CreditCartDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.ICreditCardType, CreditCardTypeEntity>()
                .ConvertUsing(new CreditCardTypeDomainToEntityConverter());

            Mapper.CreateMap<PartnerDomain.IOrder, OrderEntity>()
                .ConvertUsing(new OrderEntityConverter());

            Mapper.CreateMap<PartnerDomain.ITax, TaxEntity>()
                .ConvertUsing(new TaxesEntityConverter());

            Mapper.CreateMap<PartnerDomain.IOrderItemShippingRate, OrderItemShippingRateEntity>()
                .ConvertUsing(new OrderItemShippingRateEntityConverter());

            Mapper.CreateMap<PartnerDomain.IRecyclingFee, RecycleFeeEntity>()
                .ConvertUsing(new RecyclingEntityConverter());

            #endregion Domain Object to Entity

            #region Entity to Domain Object

            Mapper.CreateMap<BundleProductEntity, PartnerDomain.IBundleProduct>()
                .ConvertUsing(new BundleProductConverter());

            Mapper.CreateMap<ProductEntity, PartnerDomain.IProduct>()
                .ConvertUsing(new ProductConverter());

            Mapper.CreateMap<ProductEntity, PartnerDomain.Product>()
                .ConvertUsing(new ProductConverterD());

            Mapper.CreateMap<CartEntity, PartnerDomain.Cart>()
                .IgnoreAllUnmapped()
                .ForMember(src => src.Id, opt => opt.MapFrom(dest => dest.CartID));

            Mapper.CreateMap<CreditCardEntity, PartnerDomain.CreditCard>()
                .IgnoreAllUnmapped()
                .ForMember(src => src.Id, opt => opt.MapFrom(dest => dest.CreditCardTokenID))
                .ForMember(src => src.Token, opt => opt.MapFrom(dest => dest.CreditCardToken));

            Mapper.CreateMap<ICreditCardAuthorizationResponse, PartnerDomain.CreditCard>()
               .IgnoreAllUnmapped()
               .ForMember(src => src.Token, opt => opt.MapFrom(dest => dest.CreditCardToken));

            Mapper.CreateMap<OrderEntity, PartnerDomain.Order>()
                .ConvertUsing(new OrderDomainConverter());

            Mapper.CreateMap<DiscountEntity, PartnerDomain.IDiscount>()
                .ConvertUsing(new DiscountEntityToDomainConverter());

            Mapper.CreateMap<CustomPropertyEntity, PartnerDomain.ICustomProperty>()
                .ConvertUsing(new CustomPropertyEntityToDomainConverter());

            Mapper.CreateMap<CartEntity, PartnerDomain.ICart>()
                .ConvertUsing(new CartDomainConverter());

            Mapper.CreateMap<CartEntity, PartnerDomain.Cart>()
                .IgnoreAllUnmapped()
                .ForMember(src => src.Id, opt => opt.MapFrom(dest => dest.CartID));

            #endregion Entity to Domain Object

            #region Enterprise mapping

            Mapper.CreateMap<PartnerDomain.IOrder, Order>()
                  .ConvertUsing(new OrderWriterConverter());

            Mapper.CreateMap<PartnerDomain.IOrder, RatingRequest>()
                .ConvertUsing(new EnterpriseFreightConverter());

            Mapper.CreateMap<ITax, PartnerDomain.ITax>()
                .ConvertUsing(new TaxDomainConverter());

            Mapper.CreateMap<PartnerDomain.IOrder, ITaxRequest>()
                .ConvertUsing(new EnterpriseTaxRequestConverter());

            Mapper.CreateMap<PartnerDomain.ICreditCard, CreditCardAuthorizationRequest>()
               .ConvertUsing(new CreditCardServiceConverter());

            #endregion Enterprise mapping
        }
    }

    public static class MappingExpressionExtensions
    {
        public static IMappingExpression<TSource, TDest> IgnoreAllUnmapped<TSource, TDest>(this IMappingExpression<TSource, TDest> expression)
        {
            expression.ForAllMembers(opt => opt.Ignore());
            return expression;
        }
    }
}