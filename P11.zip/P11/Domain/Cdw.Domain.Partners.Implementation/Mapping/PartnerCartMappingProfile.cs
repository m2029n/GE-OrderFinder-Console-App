﻿using AutoMapper;
using Cdw.Domain.Partners.Implementation.PartnerCart;
using Cdw.Domain.Partners.PartnerCart;
using Cdw.Infrastructure.PartnerCart;

namespace Cdw.Domain.Partners.Implementation.Mapping
{
    internal class PartnerCartMappingProfile : Profile
    {
        private readonly string _cSiteCartHandlerUrl;
        private readonly string _gSiteCartHandlerUrl;
        private readonly string _caSiteCartHandlerUrl;

        public PartnerCartMappingProfile(string cSiteCartHandlerUrl, string gSiteCartHandlerUrl, string caSiteCartHandlerUrl)
        {
            _cSiteCartHandlerUrl = cSiteCartHandlerUrl;
            _gSiteCartHandlerUrl = gSiteCartHandlerUrl;
            _caSiteCartHandlerUrl = caSiteCartHandlerUrl;
        }

        protected override void Configure()
        {
            base.Configure();

            Mapper.CreateMap<IPartnerCartRequestItem, IPartnerCartRequestItemEntity>();

            Mapper.CreateMap<IPartnerCartRequest, IPartnerCartRequestEntity>()
                .ForMember(dest => dest.DateCreated, opt => opt.MapFrom(src => src.Created))
                .ForMember(dest => dest.WebSiteID, opt => opt.MapFrom(src => src.WebSiteId));

            Mapper.CreateMap<IPartnerCartRequestItemEntity, IPartnerCartRequestItem>()
                .ConvertUsing(new PartnerCartRequestItemConvert());

            Mapper.CreateMap<IPartnerCartRequestEntity, IPartnerCartRequest>()
                .ConvertUsing(new PartnerCartRequestConvert(_cSiteCartHandlerUrl, _gSiteCartHandlerUrl, _caSiteCartHandlerUrl));
        }
    }
}