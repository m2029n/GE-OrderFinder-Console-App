﻿using System.Threading.Tasks;
using Cdw.Domain.Partners.Implementation.DataAccess.PartnerConfiguration;

namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// manages the partner settings calls
    /// </summary>
    public class PartnerConfigurationSettingsManager : IPartnerConfigurationSettingsManager
    {
        private readonly IConfigurationSettingsRepository _repository;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="repository"></param>
        public PartnerConfigurationSettingsManager(IConfigurationSettingsRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Gets the settings by Identity name
        /// </summary>
        /// <param name="clientName"></param>
        /// <returns></returns>
        public async Task<PartnerConfigurationSettings> GetPartnerConfigurationSettingsByNameAsync(string clientName)
        {
            var settings = await _repository.GetPartnerConfigurationSettingsByNameAsync(clientName).ConfigureAwait(false);
            return settings;
        }

        public async Task ReInitSettingAsync()
        {
            await _repository.InitAsync().ConfigureAwait(false);
        }
    }
}