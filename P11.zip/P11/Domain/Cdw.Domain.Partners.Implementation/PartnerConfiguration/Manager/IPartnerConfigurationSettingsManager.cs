﻿using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// Interface for loading Partner configuration settings
    /// </summary>
    public interface IPartnerConfigurationSettingsManager
    {
        Task<PartnerConfigurationSettings> GetPartnerConfigurationSettingsByNameAsync(string clientName);

        Task ReInitSettingAsync();
    }
}