﻿using System.Collections.Generic;
using Cdw.Infrastructure.PartnerOrder;

namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// holds partner specific settings
    /// </summary>
    public class PartnerConfigurationSettings
    {
        /// <summary>
        /// Must be 1000  CDW to be valid. Compared to the Order CompanyCode
        /// </summary>
        public int CompanyCode { get; set; }

        /// <summary>
        /// Field in the Database which identifies a partners login
        /// </summary>
        public int ClientId { get; set; }

        /// <summary>
        /// Name of the Partner identified via Auth2 token
        /// </summary>
        public string ClientName { get; set; }

        /// <summary>
        /// settings used in /Products End point
        /// </summary>
        public ProductCatalogSettings ProductCatalogSettings { get; set; }

        /// <summary>
        ///settings used to create order
        /// </summary>
        public OrderManagerSettings OrderManagerSettings { get; set; }

        /// <summary>
        /// List of Shipping Method Properties used in Order manager per partner
        /// </summary>
        public IEnumerable<ShippingMethodPropertiesEntity> ShippingMethodProperties { get; set; }
    }
}