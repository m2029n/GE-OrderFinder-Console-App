﻿namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// Holds settings from a database, used in Order Controller
    /// </summary>
    public class OrderManagerSettings
    {
        /// <summary>
        /// Source code from OrderUploadSourceCodes used in Order Create
        /// </summary>
        public string SourceCode { get; set; }

        /// <summary>
        /// Code from Orders_FreightRaterSpecialCodeByOrderSource
        /// </summary>
        public string FreightRaterSpecialCode { get; set; }
    }
}