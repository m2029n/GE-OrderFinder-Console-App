﻿namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// holds settings for products end point logic
    /// </summary>
    public class ProductCatalogSettings
    {
        /// <summary>
        /// Apply Coupon used to call a coupon service
        /// </summary>
        public bool ApplyCoupon { get; set; }

        /// <summary>
        /// Holds settings for the serach API
        /// </summary>
        public ProductCatalogSearchApiSettings SearchApiSettings { get; set; }

        /// <summary>
        /// holds company code for LoadBatchedCallsDataAsync status API call
        /// </summary>
        public string ProductApiCompany { get; set; }

        /// <summary>
        /// holds a company code for price api call
        /// </summary>
        public string PriceCompanyCode { get; set; }

        /// <summary>
        /// Flag to include weight
        /// </summary>
        public bool ShowWeight { get; set; }
    }
}