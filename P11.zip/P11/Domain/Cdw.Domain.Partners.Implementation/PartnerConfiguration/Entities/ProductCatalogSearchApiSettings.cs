﻿namespace Cdw.Domain.Partners.Implementation.PartnerConfiguration
{
    /// <summary>
    /// used if UseSearchApi is true in Identity
    /// </summary>
    public class ProductCatalogSearchApiSettings
    {
        /// <summary>
        /// value passed to search API
        /// </summary>
        public string QueryUri { get; set; }

        /// <summary>
        /// value passed to search API
        /// </summary>
        public int Catalog { get; set; }
    }
}