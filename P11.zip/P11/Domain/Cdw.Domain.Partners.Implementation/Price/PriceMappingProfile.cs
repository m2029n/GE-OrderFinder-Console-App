﻿using System.Collections.Generic;
using AutoMapper;
using Cdw.Domain.Partners.Price;
using IProductPrice = Cdw.Ecommerce.Domain.Price.Product.IProductPrice;
using IProductPrices = Cdw.Ecommerce.Domain.Price.Product.IProductPrices;

namespace Cdw.Domain.Partners.Implementation.Price
{
    internal class PriceMappingProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();
            Mapper.CreateMap<IProductPriceRequest, Ecommerce.Domain.Price.Product.IProductPriceRequest>();

            Mapper.CreateMap<List<IProductPrices>, List<Partners.Price.IProductPrices>>();
            Mapper.CreateMap<IProductPrices, Partners.Price.IProductPrices>();

            Mapper.CreateMap<List<IProductPrice>, List<Partners.Price.IProductPrice>>();
            Mapper.CreateMap<IProductPrice, Partners.Price.IProductPrice>();
        }
    }
}