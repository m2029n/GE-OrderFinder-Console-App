﻿using Cdw.Domain.Partners.Price;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Price
{
    internal class ProductPrices : IProductPrices
    {
        public ProductPrices()
        {
            this.Prices = new List<IProductPrice>();
        }

        public List<IProductPrice> Prices { get; set; }

        public string ProductCode { get; set; }

        public int ProductId { get; set; }
    }
}