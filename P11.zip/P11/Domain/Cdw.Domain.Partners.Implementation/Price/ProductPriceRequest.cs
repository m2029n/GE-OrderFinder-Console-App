﻿using Cdw.Domain.Partners.Price;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cdw.Common;

namespace Cdw.Domain.Partners.Implementation.Price
{
    public class ProductPriceRequest : IProductPriceRequest
    {
        public ProductPriceRequest()
        {
            this.EDC = new List<string>();
            this.Contracts = new List<string>();
        }
        public List<string> EDC { get; set; }
        public string UserTrackingId { get; set; }
        public string CompanyCode { get; set; }
        public bool IsLoggedIn { get; set; }
        public string CustomPageKey { get; set; }
        public bool IsClosedLoop { get; set; }
        public string SessionKey { get; set; }
        public List<string> Contracts { get; set; }
        public bool IsEppUser { get; set; }
        public ITrackingValues TrackingValues { get; set; }
        public bool LowestPrice { get; set; }
        public bool ShowRestricted { get; set; }
        public bool IsTransactiveUser { get; set; }
        public bool IsEProcurementUser { get; set; }
    }
}