﻿using Cdw.Domain.Partners.Price;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cdw.Domain.Partners.Implementation.Price
{
    internal class ProductPrice : IProductPrice
    {
        private static readonly decimal _callPrice = new Decimal(0.02);

        public int ProductId { get; set; }

        public IProductPrice BStockOriginalPrice { get; set; }

        public bool HasStaticPrice { get; set; }

        public int Id { get; set; }

        public bool IsMandatory { get; set; }

        public IProductPrice ModeMsrp { get; set; }

        public string Name { get; set; }

        public string PriceCode { get; set; }

        public string PriceFormatted
        {
            get
            {
                return Price.ToString("C");
            }
        }

        public string PriceFormattedLong
        {
            get
            {
                return this.Price <= (double)_callPrice ? "Request Pricing" : Price.ToString("c");
            }
        }

        public string PriceKey
        {
            get
            {
                return string.IsNullOrWhiteSpace(this.PricingType) ? string.Empty : string.Format("{0}-{1}", this.GetType().FullName, this.PricingType).GetHashCode().ToString(CultureInfo.InvariantCulture);
            }
        }

        public string PricingType { get; set; }

        public double Price { get; set; }

        public string ProductCode { get; set; }
    }
}