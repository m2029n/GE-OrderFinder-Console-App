﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Cdw.Domain.Partners.Price;
using Cdw.Ecommerce.Domain.Price;
using Cdw.Security.OAuth2.Client;
using Common.Logging;

namespace Cdw.Domain.Partners.Implementation.Price
{
    public class PriceDomainManager : IPriceDomainManager
    {
        private readonly ILog _logger;
        private readonly IProductPriceManager _priceRepository;

        public PriceDomainManager(ILog logger, IProductPriceManager clientPriceManager)
        {
            _logger = logger;
            _priceRepository = clientPriceManager;
        }

        public IQueryable<IProductPrices> Get(IProductPriceRequest pricingRequest)
        {
            return Task.Run(() => GetAsync(pricingRequest)).Result;
        }

        public async Task<IQueryable<IProductPrices>> GetAsync(IProductPriceRequest pricingRequest)
        {
            var request = Mapper.Map<IProductPriceRequest, Ecommerce.Domain.Price.Product.IProductPriceRequest>(pricingRequest);
            var result = await _priceRepository.WithTracking(pricingRequest.TrackingValues).GetAsync(request).ConfigureAwait(false);

            if (result == null)
            {
                return null;
            }

            var mappedResult = new List<IProductPrices>();
            result.ToList().ForEach(x =>
            {
                var mappedPrices = new List<IProductPrice>();
                x.Prices?.ForEach(y =>
                {
                    mappedPrices.Add(Mapper.Map<Ecommerce.Domain.Price.Product.IProductPrice, IProductPrice>(y));
                });
                var prices = Mapper.Map<Ecommerce.Domain.Price.Product.IProductPrices, IProductPrices>(x);
                prices.Prices = mappedPrices;
                mappedResult.Add(prices);
            });

            return mappedResult.AsQueryable();
        }
    }
}