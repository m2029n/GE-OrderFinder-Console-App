﻿using Autofac;
using Cdw.Api.Partners.Service;
using Cdw.Clients.Freight;
using Cdw.Core.Data;
using Cdw.Core.Data.DbClient;
using Cdw.Domain.Messaging;
using Cdw.Domain.Partners.Implementation;
using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Domain.Partners.Implementation.Common;
using Cdw.Domain.Partners.Implementation.DataAccess;
using Cdw.Domain.Partners.Implementation.Orders;
using Cdw.Ecommerce.Client.Coupon;
using Cdw.Ecommerce.Clients.Order;
using Cdw.Ecommerce.Clients.Price;
using Cdw.Ecommerce.Clients.Product;
using Cdw.Ecommerce.Clients.Search;
using Cdw.Infrastructure.Data.Messaging;
using Cdw.Infrastructure.Events;
using Cdw.Infrastructure.PartnerCart.DB;
using Cdw.Infrastructure.PartnerOrder.DB;
using Cdw.Infrastructure.Payments.DB;
using Cdw.Infrastructure.Recycling.DB;
using Cdw.Infrastructure.Services.OrdersWebService;
using Cdw.Partners.Host.Middleware;
using Cdw.Partners.Utilities;
using Cdw.Services.OrderStatus.Client;
using Cdw.WebApi.Host.Core;
using Common.Logging;
using Microsoft.ApplicationInsights.Extensibility;
using Newtonsoft.Json;
using Owin;
using System;
using System.Configuration;
using System.Text.RegularExpressions;
using Cdw.Ecommerce.Clients.Tax;

namespace Cdw.Partners.Host
{
    public class Startup : OwinStartupBase
    {
        private IAppBuilder _app;
        internal static readonly Regex VersionMatchRegex = new Regex(@"(?<version>[Vv][0-9]\.[0-9])\\(?<host>[A-Za-z0-9]+)\\", RegexOptions.Compiled);
        private readonly string _appPath;
        public Startup() : this(null) { }

        public Startup(string appPath) // when running in test, this constructor will be used solely 
        {
            _appPath = appPath;
            log4net.GlobalContext.Properties["AppVersion"] = !string.IsNullOrWhiteSpace(_appPath) ? ExtractAppVersion(_appPath) : ExtractAppVersion(System.Web.HttpRuntime.AppDomainAppPath);
        }
         protected override void RegisterModules(IAppBuilder appBuilder, ContainerBuilder containerBuilder)
        {
            _app = appBuilder;
            
            var logger = LogManager.GetCurrentClassLogger();
            var settings = new PartnerApiSettings();
            var dbInstance = new Func<IDbClient>(() => DbClient.Create(ConnectionBuilder.CreateDbConnection(ConnectionType.ReadWriteExternal)));

            //new DB Repository Module
            containerBuilder.RegisterModule(new DbModule(dbInstance));

            //Partner Settings
            containerBuilder.RegisterInstance(PartnerSettings.Settings).As<IPartnerSettings>().SingleInstance();

            //CORE
            containerBuilder.RegisterModule(new PartnersModule(PartnerSettings.Settings.CreditCardCertificateName));
            containerBuilder.RegisterModule(new DomainModule(settings.Csitecart.BaseUri.ToString(), settings.Gsitecart.BaseUri.ToString(), settings.Casitecart.BaseUri.ToString()));

            //TAX
            containerBuilder.RegisterModule(new TaxAPIHttpClientModule(settings.TaxApi.BaseUri.ToString(), settings.TaxApi.ClientKey, settings.TaxApi.ClientSecret, logger));

            ////Freight
            containerBuilder.RegisterModule(new FreightRaterClientModule(settings.Base.BaseUri.ToString(), settings.Base.ClientKey, settings.Base.ClientSecret, logger));

            //OrderWriter
            containerBuilder.RegisterModule(new Ecommerce.Client.OrderWriter.ClientModule(settings.OrderWriterApi.BaseUri.ToString(), settings.OrderWriterApi.ClientKey, settings.OrderWriterApi.ClientSecret));

            //Product
            containerBuilder.RegisterModule(new ProductApiHttpClientModule(settings.ProductApi.BaseUri.ToString(), settings.ProductApi.ClientKey, settings.ProductApi.ClientSecret));

            //Price
            containerBuilder.RegisterModule(new PriceApiHttpClientModule(settings.PriceApi.BaseUri.ToString(), settings.PriceApi.ClientKey, settings.PriceApi.ClientSecret, logger));

            //CreditCard
            containerBuilder.RegisterModule(new Ecommerce.Clients.CreditCardService.ClientModule(settings.CreditCardApi.BaseUri.ToString(), settings.CreditCardApi.ClientKey, settings.CreditCardApi.ClientSecret));

            //Order
            containerBuilder.RegisterModule(new OrderClientModule(settings.Base.BaseUri.ToString(), settings.Base.ClientKey, settings.Base.ClientSecret, logger));

            //Cart

            //EmailAdapter
            containerBuilder.RegisterModule(new Ecommerce.Clients.Email.ClientModule(settings.Base.BaseUri.ToString(), settings.Base.ClientKey, settings.Base.ClientSecret));

            containerBuilder.RegisterModule(new PartnerCartDbModule(dbInstance));

            //Recycling
            containerBuilder.RegisterModule(new RecyclingDbModule(dbInstance));

            //Order
            containerBuilder.RegisterModule(new PartnerOrderDbModule(dbInstance));

            //Payments
            containerBuilder.RegisterModule(new PaymentDBModule(dbInstance));

            //OrderStatus Client
            var client = OrderStatusClientFactory.Create(settings.OrderStatus.BaseUri.ToString(), settings.OrderStatus.ClientKey);
            containerBuilder.Register(c => client).As<IOrderStatusClient>().SingleInstance();

            //AS400 order service
            containerBuilder.RegisterModule(new OrdersWebServiceModule("OrdersWebServiceSoap"));

            containerBuilder.RegisterModule(new MessagingDomainModule());
            containerBuilder.RegisterModule(new MessagingDataModule());
            containerBuilder.RegisterType<OrderCreatedHandler>().As<IDomainEventHandler<OrderCreatedEvent>>();

            containerBuilder.RegisterModule(new Ecommerce.Client.AppSettings.ClientModule(settings.Base.BaseUri.ToString(), settings.Base.ClientKey, settings.Base.ClientSecret));
            containerBuilder.Register(c =>
                {
                    string key = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\partnersInfo.json");
                    var config = new PartnersInfoConfigurationSettings
                    {
                        PartnersInfo = JsonConvert.DeserializeObject<PartnersInfo>(key)
                    };
                    return config;
                })
                .As<PartnersInfoConfigurationSettings>()
                .SingleInstance();

            //Search
            containerBuilder.RegisterModule(new SearchApiHttpClientModule(settings.SearchApi.BaseUri.ToString(), settings.SearchApi.ClientKey, settings.SearchApi.ClientSecret));

            //Coupon
            containerBuilder.RegisterModule(new ClientModule(settings.Base.BaseUri.ToString(), settings.Base.ClientKey, settings.Base.ClientSecret));
        }

        protected override void Bootstrap(System.Web.Http.HttpConfiguration config)
        {
            TelemetryConfiguration.Active.InstrumentationKey = ConfigurationManager.AppSettings["ApplicationInsights-InstrumentationKey"];

            SwaggerConfig.Register(config);
            //TODO: This Domain Event wire-up is an architectural workaround. Wire-up needs to change based on completion of new/improved Messaging architecture.
            DomainEvents.Raiser = new AutofacEventRaiser(Container);

            var enabled = Convert.ToBoolean(ConfigurationManager.AppSettings["isLoggingEnabled"]);
            if (enabled)
            {
                _app.UseApiCallCaptureMiddleware(new LogRequestResponseMiddlewareOptions { Enabled = enabled, Service = Container.Resolve<ILogRequestResponseManager>() });                
            }
        }

        internal static string ExtractAppVersion(string appPath)
        {

            var match = VersionMatchRegex.Match(appPath);
            return match.Success ? $"{match.Groups["host"].Value}-{match.Groups["version"].Value}".ToLower() : "local";
        }
    }
}