﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Web.Http;
using Cdw.Api.Partners.Service.APIDocumentation;
using Swashbuckle.Application;

namespace Cdw.Partners.Host
{
    public partial class SwaggerConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var info = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
            config.EnableSwagger(c =>
            {
                c.UseFullTypeNameInSchemaIds();
                c.SingleApiVersion("v1", "CDW Partners API")
                .Description($"CDW utilizes OAuth 2.0 to securely authenticate and authorize access to the Partner API. The official specification can be found at http://tools.ietf.org/html/rfc6749. The specification defines a number of flows. Supported flows are outlined below. v{info.ProductVersion} ({info.FileVersion})");
                c.IncludeXmlComments(GetXmlCommentsPath("Cdw.Api.Partners.Service"));
                c.IncludeXmlComments(GetXmlCommentsPath("Cdw.Partners.Validation"));
                c.IncludeXmlComments(GetXmlCommentsPath("Cdw.Api.Partners.Model"));
                c.DescribeAllEnumsAsStrings();
                c.IgnoreObsoleteActions();
                c.OAuth2("OAuth 2.0 Client Credentials")
                    .Description(
                        @"CDW utilizes the client credentials flow which allows for a trusted application to exchange a predetermined client identifier and client secret for an authenticated bearer token.
                            The authenticated bearer token is then passed in the Authorization header in subsequent API requests.
                            Each issued bearer token has an expiration.
                            Upon expiration, the client credentials exchange should take place again and a new bearer token will be issued.
                           To obtain client credentials (identifier and secret), contact your CDW Integration Specialist.")
                    .Flow("application")
                    .TokenUrl("https://{HOST}/external/{VERSION}/partners/token")
                        .Description("An AccessToken object is the authorization token issued by the API when valid authentication is submitted.")
                       ;
                c.Schemes(new List<string> { "https" });
                c.OperationFilter<AssignOAuth2SecurityRequirements>();
            });
        }

        private static string GetXmlCommentsPath(string assemblyName)
        {
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var commentsFileName = assemblyName + ".XML";
            var commentsFile = Path.Combine(baseDirectory, "bin", commentsFileName);
            return commentsFile;
        }
    }
}