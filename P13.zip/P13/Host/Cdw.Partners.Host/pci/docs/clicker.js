﻿$().ready(function () {
    $('.back').on('click', function () {
        window.location = 'ReadMe.html';
    });
    $('.withC').on('click', function () {
        $('.withCDW_text').show();
        $('.withPartner_text').hide();
        $('.withD_text').hide();
    });
    $('.withP').on('click', function () {
        $('.withCDW_text').hide();
        $('.withPartner_text').show();
        $('.withD_text').hide();
    });
    //withD_text
    $('.withD').on('click', function () {
        $('.withCDW_text').hide();
        $('.withPartner_text').hide();
        $('.withD_text').show();
    });
});