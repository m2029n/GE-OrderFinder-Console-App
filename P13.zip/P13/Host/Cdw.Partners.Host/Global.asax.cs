﻿using System;
using System.Web;

namespace Cdw.Partners.Host
{
    public class Global : HttpApplication
    {
        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (!ApplicationSettings.ModeLevel.Equals(ApplicationSettings.ModeTypeLevel.Production))
            {
                if (ReferenceEquals(null, HttpContext.Current.Request.Headers["Authorization"]))
                {
                    var token = HttpContext.Current.Request.Params["api_key"];
                    if (!String.IsNullOrEmpty(token))
                    {
                        HttpContext.Current.Request.Headers.Add("Authorization", "Bearer " + token);
                    }
                }
            }
            //this for CORS to open payments end point to be called from js file
            if (HttpContext.Current.Request.CurrentExecutionFilePath.Contains("/payments/_authorize"))
            {
                if (string.IsNullOrEmpty(Response.Headers["Access-Control-Allow-Origin"]))
                {
                    Response.Headers.Add("Access-Control-Allow-Origin", "*");
                }
                Response.Headers.Add("Access-Control-Allow-Headers", "authorization");
                if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
                {
                    HttpContext.Current.Response.End();
                }
            }
        }
    }
}