﻿using System.Configuration;
using Cdw.Partners.Utilities;

namespace Cdw.Partners.Host
{
    public class PartnerSettings : ConfigurationSection, IPartnerSettings
    {
        public static PartnerSettings Settings { get; } = ConfigurationManager.GetSection("PartnerSettings") as PartnerSettings;

        [ConfigurationProperty("CreditCardCertificateName")]
        public string CreditCardCertificateName => (string)this["CreditCardCertificateName"];

        [ConfigurationProperty("CreditCardAPIKey")]
        public string CreditCardAPIKey => (string)this["CreditCardAPIKey"];
    }
}