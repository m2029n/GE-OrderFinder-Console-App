﻿using Cdw.Common.Configuration;
using Cdw.Common.Settings;
using System;
using System.Linq;

namespace Cdw.Partners.Host
{
    public class PartnerApiSettings
    {
        public PartnerApiSettings()
        {
            var settings = new SettingsConfiguration(new Resolver());
            var api = settings.LoadApiSettings();

            Base = api.Single(a => a.Key == "base").Value;
            Csitecart = api.Single(a => a.Key == "csitecart").Value;
            Gsitecart = api.Single(a => a.Key == "gsitecart").Value;
            Casitecart = api.Single(a => a.Key == "casitecart").Value;
            OrderStatus = api.Single(a => a.Key == "orderstatus").Value;
            ProductApi = api.Single(a => a.Key == "product").Value;
            PriceApi = api.Single(a => a.Key == "price").Value;
            SearchApi = api.Single(a => a.Key == "search").Value;
            TaxApi = api.Single(a => a.Key == "tax").Value;
            CreditCardApi = api.Single(a => a.Key == "creditcard").Value;
            OrderWriterApi = api.Single(a => a.Key == "orderwriter").Value;

        }
        public IApiSetting OrderWriterApi { get; private set; }

        public IApiSetting CreditCardApi { get; private set; }

        public IApiSetting Base { get; private set; }

        public IApiSetting Casitecart { get; private set; }

        public IApiSetting Csitecart { get; private set; }

        public IApiSetting Gsitecart { get; private set; }

        public IApiSetting OrderStatus { get; private set; }

        public IApiSetting PriceApi { get; private set; }

        public IApiSetting ProductApi { get; private set; }

        public IApiSetting SearchApi { get; private set; }

        public IApiSetting TaxApi { get; private set; }
    }

    public class Resolver : ISettingResolver
    {
        public string ResolveView()
        {
            throw new NotImplementedException();
        }

        public string ResolveDeviceType()
        {
            throw new NotImplementedException();
        }
    }
}