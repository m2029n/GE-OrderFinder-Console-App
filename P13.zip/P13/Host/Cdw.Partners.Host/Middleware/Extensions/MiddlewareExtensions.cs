﻿using Microsoft.Owin;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace Cdw.Partners.Host.Middleware.Extensions
{
    public static class MiddlewareExtensions
    {
        public static JToken GetResponseBodyObject(this string body)
        {
            try
            {
                return JToken.Parse(body);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static JObject GetRequestBodyObject(this string body, bool isOrder)
        {
            try
            {
                if (!string.IsNullOrEmpty(body))
                {
                    var dec = JsonConvert.DeserializeObject(body);

                    var requestBodyObj = JObject.Parse(dec.ToString());
                    if (requestBodyObj != null && isOrder)
                    {
                        try
                        {
                            requestBodyObj["Billing"]["Method"]["EncryptedCreditCard"] = "XXXX";
                        }
                        catch (Exception)
                        {
                            //left blank on purpose
                        }
                    }
                    return requestBodyObj;
                }
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static string GetUri(this IOwinRequest request)
        {
            try
            {
                return request.Uri.ToString();
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string GetHeaders(this IOwinRequest request)
        {
            try
            {
                var allheaders = new
                {
                    TrackingValues = request.TrackingValues(),
                    Headers = request.Headers
                };
                return JsonConvert.SerializeObject(allheaders);
                 
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string GetHeaders(this IOwinResponse response)
        {
            try
            {
                return JsonConvert.SerializeObject(response.Headers);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}