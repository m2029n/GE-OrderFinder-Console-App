﻿using System;
using System.Linq;
using Cdw.Common;
using Microsoft.Owin;

namespace Cdw.Partners.Host.Middleware.Extensions
{
    public static class OwinRequestExtensions
    {
        public const string TrackingHeader = "x-cdw-tracking-id";
        public const string CorrelationHeader = "x-cdw-correlation-id";

        /// <summary>
        /// Method returns tracking values from request header if they exist, otherwise returns new values.
        /// </summary>
        /// <param name="request">IOwinRequest request</param>
        /// <returns>new ITrackingValues instance</returns>
        public static ITrackingValues TrackingValues(this IOwinRequest request)
        {
            Mandate.ParameterNotNull(request, nameof(request));

            Guid guid;
            var trackingId = Guid.TryParse(GetHeader(request, TrackingHeader), out guid) ? guid : Guid.NewGuid();
            var correlationId = Guid.TryParse(GetHeader(request, CorrelationHeader), out guid) ? guid : Guid.NewGuid();
            return new TrackingValues(trackingId, correlationId);
        }

        /// <summary>
        /// Method returns a specific header from the request, or null if it does not exist
        /// </summary>
        /// <param name="request">HTTP request</param>
        /// <param name="headerName">name of header to return</param>
        /// <returns>value of header, or null</returns>
        public static string GetHeader(this IOwinRequest request, string headerName)
        {
            Mandate.ParameterNotNull(request, nameof(request));

            var item = request.Headers[headerName];
            return item;
        }
    }
}