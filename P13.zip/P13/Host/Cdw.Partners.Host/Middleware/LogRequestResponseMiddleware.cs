﻿using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Partners.Host.Middleware.Extensions;
using Cdw.Partners.Utilities;
using Common.Logging;
using Microsoft.Owin;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AppFunc = System.Func<System.Collections.Generic.IDictionary<string, object>, System.Threading.Tasks.Task>;

namespace Cdw.Partners.Host.Middleware
{
    public class LogRequestResponseMiddleware
    {
        private readonly LogRequestResponseMiddlewareOptions _options;
        private readonly ILogRequestResponseManager _partnerService;
        private readonly ILog _logger;
        private readonly AppFunc _next;
        private Stopwatch _stopwatch;
        private MemoryStream _responseBuffer;
        private Stream _stream;
        private bool _getbody;
        private readonly RequestResponseLog _logResponse = new RequestResponseLog { RequestStartDateUtc = DateTime.UtcNow };
        private readonly List<string> _pathsToExclude = new List<string> { "", "token", "healthcheck", "logs" };
        private string _controller;

        public LogRequestResponseMiddleware(AppFunc environment, LogRequestResponseMiddlewareOptions options)
        {
            _logger = LogManager.GetCurrentClassLogger();
            _options = options;
            _partnerService = options.Service;
            _next = environment;
        }

        public async Task Invoke(IDictionary<string, object> environment)
        {
            try
            {
                _stopwatch = Stopwatch.StartNew();
                var context = new OwinContext(environment);
                _controller = context.Request.Path.ToString().Split('/').Skip(1).FirstOrDefault()?.ToLower();
                if (_controller == null)
                {
                    _controller = string.Empty;
                }
                if (!_options.Enabled || _pathsToExclude.Contains(_controller) || context.Request.Path.ToString().Contains("healthcheck"))
                {
                    await _next(environment);
                    return;
                }

                _getbody = !context.Request.Path.ToString().EndsWith("/products", StringComparison.OrdinalIgnoreCase);
                await OnIncomingRequest(context);
                await _next(environment);
                await OnOutgoingRequest(context);
            }
            catch (Exception ex)
            {
                _logger.Error("Middleware failed starting to log ", ex, _logResponse);
            }
        }

        private async Task OnIncomingRequest(OwinContext context)
        {
            try
            {
                var isOrder = context.Request.Path.ToString().EndsWith("orders", StringComparison.OrdinalIgnoreCase) && context.Request.Method == "POST";
                if (context.Request.Body != null)
                {
                    var requestBody = await new StreamReader(context.Request.Body).ReadToEndAsync();
                    _logResponse.RequestBody = requestBody.GetRequestBodyObject(isOrder)?.ToString();
                }
                if (_getbody)
                {
                    if (context.Request.Body == null)
                    {
                        _getbody = false;
                        return;
                    }
                    //get stream for response body so we can copy it back later down the pipeline
                    context.Request.Body.Position = 0;
                    _stream = context.Response.Body;
                    _responseBuffer = new MemoryStream();
                    context.Response.Body = _responseBuffer;
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Middleware failed creating a log ", ex, _logResponse);
            }
        }

        private async Task OnOutgoingRequest(OwinContext context)
        {
            try
            {
                var responseBody = "{'message': 'not loaded to avoid overflow'}";
                if (_getbody)
                {
                    //read response body from stream
                    _responseBuffer.Seek(0, SeekOrigin.Begin);
                    responseBody = new StreamReader(_responseBuffer).ReadToEndAsync().Result;
                }

                _logResponse.PartnerName = context.Request.User?.Identity.Name;
                _logResponse.MessageType = _controller;
                _logResponse.RequestPath = context.Request.Path.ToString();
                _logResponse.RequestUri = context.Request.GetUri();
                _logResponse.RequestHeaders = context.Request.GetHeaders();
                _logResponse.RequestIpFrom = context.Request.RemoteIpAddress;
                _logResponse.RequestMethod = context.Request.Method;
                _logResponse.ResponseHeaders = context.Response.GetHeaders();
                _logResponse.ResponseBody = responseBody.GetResponseBodyObject()?.ToString();
                _logResponse.ResponseProcessingTime = _stopwatch.ElapsedMilliseconds;
                _logResponse.ResponseResultCode = context.Response.StatusCode;

                if (_getbody)
                {
                    _responseBuffer.Seek(0, SeekOrigin.Begin);
                    await _responseBuffer.CopyToAsync(_stream);
                }
                await _partnerService.InsertRequestResponseLogAsync(_logResponse).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.Error("Middleware failed adding a log", ex, _logResponse);
            }
        }
    }
}