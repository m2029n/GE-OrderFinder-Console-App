﻿using Owin;

namespace Cdw.Partners.Host.Middleware
{
    public static class LogRequestResponseMiddlewareExtensions
    {
        public static void UseApiCallCaptureMiddleware(this IAppBuilder app, LogRequestResponseMiddlewareOptions options)
        {
            app.Use<LogRequestResponseMiddleware>(options);
        }
    }
}