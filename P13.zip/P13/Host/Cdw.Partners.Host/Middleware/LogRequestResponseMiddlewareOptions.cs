﻿using Cdw.Domain.Partners.Implementation.APILogging;

namespace Cdw.Partners.Host.Middleware
{
    public class LogRequestResponseMiddlewareOptions
    {
        public bool Enabled { get; set; }
        public ILogRequestResponseManager Service { get; set; }
    }
}