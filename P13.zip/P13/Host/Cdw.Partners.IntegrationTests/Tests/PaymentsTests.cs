﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class PaymentsTests
    {
        private readonly Helper _helper;

        public PaymentsTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task AuthorizeWithEmptyTransactionId()
        {
            var request = File.ReadAllText("TestJson/Payments/EmptyTransactionIdRequest.json");
            var response = File.ReadAllText("TestJson/Payments/EmptyTransactionIdResponse.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeCreditCard()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest1.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse1.json");

            await PaymentsTestAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithEmptyCreditCardNumber()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest2.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse2.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithEmptyMonth()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest3.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse3.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithEmptyYear()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest4.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse4.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithInvalidCreditCard()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest5.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse5.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithMonthOutOfRange()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest6.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse6.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithYearOutOfRange()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest7.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse7.json");

            await PaymentsTestErrorAsync(request, response);
        }

        [Fact]
        public async Task AuthorizeWithInvalidExpDate()
        {
            var request = File.ReadAllText("TestJson/Payments/PostPaymentRequest8.json");
            var response = File.ReadAllText("TestJson/Payments/PostPaymentResponse8.json");

            await PaymentsTestErrorAsync(request, response);
        }

        private async Task PaymentsTestErrorAsync(string request, string response)
        {
            // Arrange
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("payments/_authorize", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task PaymentsTestAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            expected["ReferenceNumber"] = "";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("payments/_authorize", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            actual["ReferenceNumber"] = "";
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.Equal(actual, expected);
        }
    }
}