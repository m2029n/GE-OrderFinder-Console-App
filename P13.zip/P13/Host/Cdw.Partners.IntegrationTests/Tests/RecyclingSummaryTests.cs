﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class RecyclingSummaryTests
    {
        private readonly Helper _helper;

        public RecyclingSummaryTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetRecyclingFeeSummary()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost1Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal("12", actual["Amount"]);
            Assert.Equal("197154,198543", actual["ProductCodes"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForOneEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost2Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal("6", actual["Amount"]);
            Assert.Equal("197154", actual["ProductCodes"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryFor10EDCs()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost3Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal("43", actual["Amount"]);
            Assert.Equal("197154,3890865,3912974,3912999,3980383,3980439,4168571,4355350", actual["ProductCodes"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryCAState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost4Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        /// <summary>
        /// 2 EDC's one has recycle fee and one does not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task GetRecyclingFeeSummaryForMixedEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost5Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal("5", actual["Amount"]);
            Assert.Equal("4168571", actual["ProductCodes"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        /// <summary>
        /// IL state does not have recycle fee, Hence the test is to check for null
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task GetRecyclingFeeSummaryForILState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost6Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Asset
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForEDCWithNoRecycle()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost7Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForValidStateNoEDC()
        {
            // Arrange
            var response = "\"ProductCodes code not found\"";
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost8Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(response, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForInvalidEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost9Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForEmptyStateEmptyProduct()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost10Request.json");
            var response = "\"State not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(response, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForEmptyState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost11Request.json");
            var response = "\"State not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(response, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForInvalidState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost12Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeSummaryForCAEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost13Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public void RecyclingHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Recycling Service", Status = "Ready" }),
            };
            Helper.HealthCheck(null, EndPoint.Recycling, expected);
        }
    }
}