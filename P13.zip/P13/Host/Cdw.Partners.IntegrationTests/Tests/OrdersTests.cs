﻿using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class OrdersTests
    {
        private readonly Helper _helper;

        public OrdersTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetOrderWithPostCode()
        {
            var httpresponse = await _helper.GetFromXeroxUsApiAsync("orders/1BKDC67");
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetOrder()
        {
            var response = File.ReadAllText("TestJson/Orders/OrderGet1Response.json");
            await GetOrderAsync("1BKV77J", response);
        }

        [Fact]
        public async Task GetOrderWithDiscounts()
        {
            // Arrange
            var response = File.ReadAllText("TestJson/Orders/OrderGet2Response.json");
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.GetFromXeroxUsApiAsync("orders/1BFLW8Z");
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        }

        //[Fact]
        //public async Task GetOrderWithShipments()
        //{
        //    // Arrange
        //    var response = File.ReadAllText("TestJson/Orders/OrderGet4Response.json");
        //    var expected = JObject.Parse(response);

        //    // Act
        //    var httpresponse = await _helper.GetFromXeroxUsApiAsync("orders/1CR1XZM");
        //    var responseObject = await httpresponse.Content.ReadAsStringAsync();

        //    // Assert
        //    var actual = JObject.Parse(responseObject);
        //    Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        //    Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        //}

        //[Fact]
        //public async Task GetOrderWithOrderLevelDiscount()
        //{
        //    // Arrange
        //    var response = File.ReadAllText("TestJson/Orders/OrderGet3Response.json");
        //    var expected = JObject.Parse(response);

        //    // Act
        //    var httpresponse = await _helper.GetFromXeroxUsApiAsync("orders/1CR1WKT");
        //    var responseObject = await httpresponse.Content.ReadAsStringAsync();

        //    // Assert
        //    var actual = JObject.Parse(responseObject);

        //    Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        //    Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        //}

        [Fact]
        public async Task Validation_TransactionDate()
        {
            await PostWithErrorAsync("ErrorCheck1Request", "ErrorCheck1Response");
        }

        [Fact]
        public async Task Validation_Discount_Id()
        {
            await PostWithErrorAsync("ErrorCheck3Request", "ErrorCheck3Response");
        }

        [Fact]
        public async Task Validation_Discount_Amount_Between_0_100()
        {
            await PostWithErrorAsync("ErrorCheck4Request", "ErrorCheck4Response");
        }

        [Fact]
        public async Task Validation_Discount_Amount_Greater_Than_0()
        {
            await PostWithErrorAsync("ErrorCheck7Request", "ErrorCheck7Response");
        }

        [Fact]
        public async Task Validation_Discount_Type_1000_1001()
        {
            await PostWithErrorAsync("ErrorCheck5Request", "ErrorCheck5Response");
        }

        [Fact]
        public async Task Validation_Discount_Type_1002_1003_1004()
        {
            await PostWithErrorAsync("ErrorCheck6Request", "ErrorCheck6Response");
        }

        [Fact]
        public async Task Validation_EmailAddress_Empty_Invalid()
        {
            await PostWithErrorAsync("ErrorCheck8Request", "ErrorCheck8Response");
        }

        [Fact]
        public async Task Validation_EmailAddress_Invalid()
        {
            await PostWithErrorAsync("ErrorCheck9Request", "ErrorCheck9Response");
        }

        [Fact]
        public async Task Validation_Shipping_Method()
        {
            await PostWithErrorAsync("ErrorCheck11Request", "ErrorCheck11Response");
        }

        [Fact]
        public async Task Validation_Address_FirstName()
        {
            await PostWithErrorAsync("ErrorCheck10Request", "ErrorCheck10Response");
        }

        [Fact]
        public async Task Validation_Address_StreetAddress()
        {
            await PostWithErrorAsync("ErrorCheck12Request", "ErrorCheck12Response");
        }

        [Fact]
        public async Task Validation_Address_City()
        {
            await PostWithErrorAsync("ErrorCheck13Request", "ErrorCheck13Response");
        }

        [Fact]
        public async Task Validation_Address_State()
        {
            await PostWithErrorAsync("ErrorCheck14Request", "ErrorCheck14Response");
        }

        [Fact]
        public async Task Validation_Address_Postalcode_Empty()
        {
            await PostWithErrorAsync("ErrorCheck15Request", "ErrorCheck15Response");
        }

        [Fact]
        public async Task Validation_Address_Postalcode_Length()
        {
            await PostWithErrorAsync("ErrorCheck16Request", "ErrorCheck16Response");
        }

        [Fact]
        public async Task Validation_Billing_Address()
        {
            await PostWithErrorAsync("ErrorCheck17Request", "ErrorCheck17Response");
        }

        [Fact]
        public async Task Validation_Shipping_Address()
        {
            await PostWithErrorAsync("ErrorCheck18Request", "ErrorCheck18Response");
        }

        [Fact]
        public async Task Validation_Used_Reference_Number()
        {
            await PostWithErrorRefNumAsync("ErrorCheck19Request", "ErrorCheck19Response");
        }

        [Fact]
        public async Task PostUsOrderWithNoProductCode()
        {
            await PostWithErrorAsync("ErrorCheck20Request", "ErrorCheck20Response");
        }

        [Fact]
        public async Task PostUsOrderWithNETTerms()
        {
            await PostWithErrorAsync("ErrorCheck21Request", "ErrorCheck21Response");
        }

        [Fact]
        public async Task PostUsOrderWithInvalidFreight()
        {
            await PostWithErrorAsync("ErrorCheck23Request", "ErrorCheck23Response");
        }

        [Fact]
        public async Task PostCAOrderWithNETTerms()
        {
            await PostWithErrorCAAsync("ErrorCheck22Request", "ErrorCheck22Response");
        }

        [Fact]
        public async Task PostCAOrderWithInvalidFreight()
        {
            await PostWithErrorCAAsync("ErrorCheck24Request", "ErrorCheck24Response");
        }

        [Fact]
        public async Task PostBBOrderWithInvalidFreight()
        {
            await PostWithErrorBBAsync("ErrorCheck25Request", "ErrorCheck25Response");
        }

        [Fact]
        public async Task PostBBOrderWithNoProductCodeMnfNumber()
        {
            await PostWithErrorBBAsync("ErrorCheck26Request", "ErrorCheck26Response");
        }

        [Fact]
        public async Task PostBBOrderWithNoProductCodeMnfNumberMnfDesc()
        {
            await PostWithErrorBBAsync("ErrorCheck27Request", "ErrorCheck27Response");
        }

        [Fact]
        public async Task PostBBOrderWithMissingProductCodeMnfNumberMnfDesc()
        {
            await PostWithErrorBBAsync("ErrorCheck28Request", "ErrorCheck28Response");
        }

        [Fact]
        public async Task PostUsOrderWithDiscontinuedProduct()
        {
            await PostWithErrorAsync("ErrorCheck29Request", "ErrorCheck29Response");
        }

        [Fact]
        public async Task PostUsOrderWithNegativeQty()
        {
            await PostWithErrorAsync("ErrorCheck30Request", "ErrorCheck30Response");
        }

        [Fact]
        public async Task PostXeroxOrderWithTransactionIDPayment()
        {
            await PostWithErrorAsync("ErrorCheck32Request", "ErrorCheck32Response");
        }

        [Fact]
        public async Task PostXeroxOrderWithEncryptedAndTransactionID()
        {
            await PostWithErrorAsync("ErrorCheck34Request", "ErrorCheck33Response");
        }

        [Fact]
        public async Task PostXeroxOrderWithEncryptedAndTransactionIDAndNetTerms()
        {
            await PostWithErrorAsync("ErrorCheck35Request", "ErrorCheck33Response");
        }

        [Fact]
        public async Task PostBBOrderWithEncryptedAndTransactionIDAndNetTerms()
        {
            await PostWithErrorBBAsync("ErrorCheck35Request", "ErrorCheck33Response");
        }

        [Fact]
        public async Task PostBBOrderWithTransactionIDAndNetTerms()
        {
            await PostWithErrorBBAsync("ErrorCheck36Request", "ErrorCheck33Response");
        }

        [Fact]
        public async Task PostUsOrder()
        {
            await PostOrderAsync("PostOrder1Request", "PostOrder1Response");
        }

        [Fact]
        public async Task PostUsOrderAK()
        {
            await PostOrderAsync("PostOrder4Request", "PostOrder4Response");
        }

        [Fact]
        public async Task PostUsOrderHI()
        {
            await PostOrderAsync("PostOrder5Request", "PostOrder5Response");
        }

        [Fact]
        public async Task PostUsOrderWithBundleAndNonBundleItems()
        {
            await PostOrderAsync("PostOrder8Request", "PostOrder8Response");
        }

        [Fact]
        public async Task PostUsOrderWithFreeShipping()
        {
            await PostOrderAsync("PostOrder10Request", "PostOrder10Response");
        }

        [Fact]
        public async Task PostUsOrderWith9DigitZipcode()
        {
            await PostOrderAsync("PostOrder10Request", "PostOrder10Response");
        }

        [Fact]
        public async Task PostUsOrder2()
        {
            await PostOrderAsync("PostOrder2Request", "PostOrder2Response");
        }

        [Fact]
        public async Task PostCanadaOrder()
        {
            await PostCanadaOrderAsync("PostOrder3Request", "PostOrder3Response");
        }

        [Fact]
        public async Task PostBlackboxUSOrder()
        {
            await PostOrderUSBlackboxAsync("PostOrder6Request", "PostOrder6Response");
        }

        [Fact]
        public async Task PostBlackboxOrderWithNetTerms()
        {
            await PostOrderUSBlackboxAsync("PostOrder7Request", "PostOrder7Response");
        }

        [Fact]
        public async Task PostBlackboxOrderWithOutProductCode()
        {
            await PostOrderUSBlackboxAsync("PostOrder9Request", "PostOrder9Response");
        }

        [Fact]
        public async Task PostXeroxOrderWithTransactionIDAndRefIDPayment()
        {
            await PostOrderAsync("PostOrder12Request", "PostOrder12Response");
        }

        private async Task PostOrderAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            request["ReferenceNumber"] = refNumber;
            var response = JObject.Parse(responseBase);
            response["ReferenceNumber"] = refNumber;
            var expected = JObject.Parse(response.ToString());
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);
            Assert.Equal(HttpStatusCode.Created, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        }

        private async Task PostCanadaOrderAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            request["ReferenceNumber"] = refNumber;
            var response = JObject.Parse(responseBase);
            response["ReferenceNumber"] = refNumber;
            var expected = JObject.Parse(response.ToString());
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);

            Assert.Equal(HttpStatusCode.Created, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        }

        private async Task PostOrderUSBlackboxAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            request["ReferenceNumber"] = refNumber;
            var response = JObject.Parse(responseBase);
            response["ReferenceNumber"] = refNumber;
            var expected = JObject.Parse(response.ToString());
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("orders", request.ToString()).ConfigureAwait(false);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);
            Assert.Equal(HttpStatusCode.Created, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual), "Actual and expected response does not match");
        }

        private async Task PostWithErrorAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            var tokenReq = request["ReferenceNumber"];
            if (tokenReq != null)
            {
                request["ReferenceNumber"] = refNumber;
            }

            var expected = JArray.Parse(responseBase);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);

            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task PostWithErrorCAAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            var tokenReq = request["ReferenceNumber"];
            if (tokenReq != null)
            {
                request["ReferenceNumber"] = refNumber;
            }

            var expected = JArray.Parse(responseBase);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task PostWithErrorBBAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var expected = JArray.Parse(responseBase);
            var refNumber = "TEST40761143" + GetRandomNumber();
            var request = JObject.Parse(requestBase);
            var tokenReq = request["ReferenceNumber"];
            if (tokenReq != null)
            {
                request["ReferenceNumber"] = refNumber;
            }

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task PostWithErrorRefNumAsync(string requestfile, string responsefile)
        {
            // Arrange
            var requestBase = File.ReadAllText("TestJson/Orders/" + requestfile + ".json");
            var responseBase = File.ReadAllText("TestJson/Orders/" + responsefile + ".json");
            var request = JObject.Parse(requestBase);
            var expected = JArray.Parse(responseBase);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("orders", request.ToString());
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task GetOrderAsync(string orderId, string response)
        {
            // Arrange
            var url = "orders/" + orderId;
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.GetFromXeroxUsApiAsync(url);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.NotNull(actual);
        }

        public void ScrubEnvironmentalSpecificVariable(JObject objectToScrub)
        {
            objectToScrub["OrderNumber"] = string.Empty;

            if (objectToScrub["Billing"]?["Method"]?["CreditCard"]?["Number"] != null)
            {
                objectToScrub["Billing"]["Method"]["CreditCard"]["Number"] = string.Empty; // Card can be swapped out based on environment.
            }
        }

        private string GetRandomNumber()
        {
            return DateTime.Now.Year.ToString() +
                         DateTime.Now.Month.ToString() +
                         DateTime.Now.Day.ToString() +
                         DateTime.Now.Hour.ToString() +
                         DateTime.Now.Minute.ToString() +
                         DateTime.Now.Second.ToString() +
                         DateTime.Now.Millisecond.ToString();
        }
    }
}