﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class PartnerTests
    {
        [Fact(DisplayName = "PartnerHealthCheck")]
        public void PartnerHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Tax Service", Status = "Ready" }),
                JObject.FromObject(new { Service = "Freight Service", Status = "Ready"}),
                JObject.FromObject(new { Service = "Cart Service", Status = "Ready"}),
                JObject.FromObject(new { Service = "Product Service", Status = "Ready"}),
                JObject.FromObject(new { Service = "Recycling Service", Status = "Ready"})
            };
            Helper.HealthCheck(null, EndPoint.Partners, expected);
        }
    }
}