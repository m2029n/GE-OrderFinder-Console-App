﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class FreightBlackboxTests
    {
        private readonly Helper _helper;

        public FreightBlackboxTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetFreightBBWithTwoItems()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost1Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost1Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithOneItem()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost2Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost2Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithElectronicDropShipItem()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost3Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost3Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithEmptyProductCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost4Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost4Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithEmptyShippingAddress()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost5Request.json");

            await FreightTestMissingAddressAsync(request);
        }

        [Fact]
        public async Task GetFreightBBWithInvalidCompanyCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost6Request.json");

            await FreightTestInvalidCompanyCodeAsync(request);
        }

        [Fact]
        public async Task GetFreightBBWithInvalidProductCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost7Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost7Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithInvalidPostalCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost8Request.json");

            await FreightTestInvalidPostalCodeAsync(request);
        }

        [Fact]
        public async Task GetFreightBBWithInvalidState()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost9Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost9Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithInvalidCountry()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost10Request.json");

            await FreightTestInvalidCountryAsync(request);
        }

        [Fact]
        public async Task GetFreightBBWithCAEDC()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost11Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost11Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithXeroxEDC()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost12Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost12Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWith9DigitPostalCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost13Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost13Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithBundleEDC()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost14Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost14Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithAKAddress()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost15Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost15Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithHIAddress()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost16Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost16Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithDetails()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost17Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost17Response.json");

            await FreightTestDetailsAsync(request, response);
        }

        [Fact]
        public async Task GetFreightBBWithoutProductCode()
        {
            var request = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost18Request.json");
            var response = File.ReadAllText("TestJson/FreightBlackBox/FreightBBPost18Response.json");

            await FreightTestBBNewItemValidationAsync(request, response);
        }

        private async Task FreightTestAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            expected["TransactionIdentifier"] = string.Empty;

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            actual["TransactionIdentifier"] = string.Empty;

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = expected["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestDetailsAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            expected["TransactionIdentifier"] = string.Empty;

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            actual["TransactionIdentifier"] = string.Empty;

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCodeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            var expectedCodeDetail = expected["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCodeDetail, actualCodeDetail);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            var actualChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            var expectedChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedChargeDetail, actualChargeDetail);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        //NEW-ITEM validation
        private async Task FreightTestBBNewItemValidationAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            if (responseObject != "null")
            {
                var actual = JObject.Parse(responseObject);
                Assert.Equal(expected["Freight"]["Details"][0]["ProductCode"], actual["Freight"]["Details"][0]["ProductCode"]);
                Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            }
        }

        private async Task FreightTestMessageAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);

            Assert.Equal(expected["ErrorMessage"], actual["ErrorMessage"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestMissingAddressAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Country code not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCompanyCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidPostalCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Invalid US postal code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCountryAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Company code 01 is invalid for country code 'XX'\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }
    }
}