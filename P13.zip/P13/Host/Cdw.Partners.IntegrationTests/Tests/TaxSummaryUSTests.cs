﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class TaxSummaryUSTests
    {
        private const string FileFormatRequest = "TestJson/Tax/TaxPost{0}Request.json";
        private const string FileFormatResponse = "TestJson/Tax/TaxPost{0}Response.json";
        private const string FileFormatDetailRequest = "TestJson/Tax/TaxPost{0}DetailRequest.json";
        private const string FileFormatDetailResponse = "TestJson/Tax/TaxPost{0}DetailResponse.json";

        private readonly Helper _helper;

        public TaxSummaryUSTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetTaxSummaryWithProductFee()
        {
            await TaxTestAsync("tax", "TaxPostSummaryWithProductFee", ResponseType.Array);
        }

        [Fact]
        public async Task GetTaxSummaryWithoutProductFee()
        {
            await TaxTestAsync("tax", "TaxPostSummaryWithoutProductFee", ResponseType.Array);
        }

        [Fact]
        public async Task GetTaxWithItemDiscount()
        {
            await TaxTestAsync(1);
        }

        [Fact]
        public async Task GetTaxWithNoItemDiscount()
        {
            await TaxTestAsync(2);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Id_5PERCOFF()
        {
            await TaxTestAsync(3);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Id_OrderLevelDiscount1()
        {
            await TaxTestAsync(4);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Type_1001_Amt_50()
        {
            await TaxTestAsync(5);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Type_1001_Amt_75()
        {
            await TaxTestAsync(6);
        }

        [Fact]
        public async Task GetTaxWithItemDiscount_With_Amt_75()
        {
            await TaxTestAsync(7);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Type_1001_Amt_100()
        {
            await TaxTestAsync(8);
        }

        [Fact]
        public async Task GetTaxWithDiscount_No_Id_ErrorCheck()
        {
            await TaxTestAsync(9, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Amt_Grt_100_ErrorCheck()
        {
            await TaxTestAsync(10, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Amt_Less_0_ErrorCheck()
        {
            await TaxTestAsync(11, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithDiscount_No_Type_ErrorCheck()
        {
            await TaxTestAsync(12, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Type_1002_ErrorCheck()
        {
            await TaxTestAsync(13, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithDiscount_Amt_Negative_ErrorCheck()
        {
            await TaxTestAsync(14, HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task GetTaxWithItemDiscount_With_Amt_60()
        {
            await TaxTestAsync(15);
        }

        [Fact]
        public async Task GetTax_Empty_Request()
        {
            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", string.Empty);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = responseObject.ToString().Replace("\"", "");
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTax_Empty_ProductCode_BlackBox()
        {
            await TaxTest_BlackBoxAsync(38);
        }

        [Fact]
        public async Task GetTax_Empty_ProductCode_XeroxUS()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost16Request.json");
            var response = File.ReadAllText("TestJson/Tax/TaxPost16Response.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxWith2EDC()
        {
            await TaxTestAsync(17);
        }

        [Fact]
        public async Task GetTaxWith10EDC()
        {
            await TaxTestAsync(18);
        }

        [Fact]
        public async Task GetTaxWithInvalidCompanyCode()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost19Request.json");
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxWithMissingAddress()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost20Request.json");
            var response = File.ReadAllText("TestJson/Tax/TaxPost20Response.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxWithEmptyState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost21Request.json");
            var response = File.ReadAllText("TestJson/Tax/TaxPost21Response.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxWithInvalidPostalCode()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost22Request.json");
            var expectedMessage = "\"Invalid US postal code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxWithInvalidState()
        {
            await TaxTestAsync(23);
        }

        [Fact]
        public async Task GetTaxWithInvalidCountry()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost24Request.json");
            var expectedMessage = "\"Company code 1000 is invalid for country code 'XX'\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxWithCAEDC()
        {
            await TaxTestAsync(25);
        }

        [Fact]
        public async Task GetTaxWith9DigitZipCode()
        {
            await TaxTestAsync(26);
        }

        [Fact]
        public async Task GetTaxWithBundleItem()
        {
            await TaxTestAsync(27);
        }

        [Fact]
        //one bundle item and one non bundle item
        public async Task GetTaxWithMixedProducts()
        {
            await TaxTestAsync(28);
        }

        [Fact]
        //one bundle item, one non bundle item, drop ship item
        public async Task GetTaxWithMixedProducts1()
        {
            await TaxTestAsync(29);
        }

        [Fact]
        public async Task GetTaxWithDropshipItem()
        {
            await TaxTestAsync(30);
        }

        [Fact]
        public async Task GetTaxWithOrderLevelDiscount1000()
        {
            await TaxTestAsync(31);
        }

        [Fact]
        public async Task GetTaxWithOrderLevelDiscount1001()
        {
            await TaxTestAsync(32);
        }

        [Fact]
        public async Task GetTaxWithLineLevelDiscount1002()
        {
            await TaxTestAsync(33);
        }

        [Fact]
        public async Task GetTaxWithLineLevelDiscount1003()
        {
            await TaxTestAsync(34);
        }

        [Fact]
        public async Task GetTaxWithLineLevelDiscount1004()
        {
            await TaxTestAsync(35);
        }

        [Fact]
        public async Task GetTaxWithLineLevelDiscount1005()
        {
            await TaxTestAsync(36);
        }

        [Fact]
        public async Task GetTaxWithComboDiscount()
        {
            await TaxTestAsync(37);
        }

        private enum ResponseType
        {
            Array,
            Object
        }

        private async Task TaxTestAsync(string url, string fileName, ResponseType type, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText($"TestJson/Tax/{fileName}.json");
            var response = File.ReadAllText($"TestJson/Tax/{fileName}Response.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync(url, request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            if (type == ResponseType.Object)
            {
                var actual = JObject.Parse(responseObject);
                var expected = JObject.Parse(response);
                Assert.True(JToken.DeepEquals(expected, actual));
                Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            }
            else if (type == ResponseType.Array)
            {
                var actual = JArray.Parse(responseObject);
                var expected = JArray.Parse(response);
                Assert.True(JToken.DeepEquals(expected, actual));
                Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            }
        }

        private async Task TaxTestAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatResponse, fileNumber));
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));

        }

        private async Task TaxTest_BlackBoxAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatResponse, fileNumber));
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxDetail_ValidRequest()
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatDetailRequest, 1));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, 1));
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact(DisplayName = "TaxHealthCheck")]
        public void TaxHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Tax Service", Status = "Ready" }),
            };
            Helper.HealthCheck(null, EndPoint.Tax, expected);
        }
    }
}