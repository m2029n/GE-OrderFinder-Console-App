﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class TaxDetailsCATests
    {
        private const string FileFormatRequest = "TestJson/TAXSummaryCA/TaxPost{0}Request.json";
        private const string FileFormatResponse = "TestJson/TAXSummaryCA/TaxPost{0}Response.json";
        private const string FileFormatDetailRequest = "TestJson/TAXDetailsCA/TaxCAPost{0}DetailRequest.json";
        private const string FileFormatDetailResponse = "TestJson/TAXDetailsCA/TaxCAPost{0}DetailResponse.json";

        private readonly Helper _helper;

        public TaxDetailsCATests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetTaxCADetailsWithProductFee()
        {
            await TaxTestAsync("tax/details", "TaxCAPostWithProductFee", ResponseType.Object);
        }

        [Fact]
        public async Task GetTaxCADetailsWithoutProductFee()
        {
            await TaxTestAsync("tax/details", "TaxCAPostWithoutProductFee", ResponseType.Object);
        }

        [Fact]
        public async Task GetTaxCADetailsWithItemDiscount()
        {
            await TaxTestAsync(1);
        }

        [Fact]
        public async Task GetTaxCADetailsWithNoItemDiscount()
        {
            await TaxTestAsync(2);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Id_5PERCOFF()
        {
            await TaxTestAsync(3);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Id_OrderLevelDiscount1()
        {
            await TaxTestAsync(4);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Type_1001_Amt_50()
        {
            await TaxTestAsync(5);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Type_1001_Amt_75()
        {
            await TaxTestAsync(6);
        }

        [Fact]
        public async Task GetTaxCADetailsWithItemDiscount_With_Amt_75()
        {
            await TaxTestAsync(7);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Type_1001_Amt_100()
        {
            await TaxTestAsync(8);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_No_Id_ErrorCheck()
        {
            await TaxTestErrorCheck(9);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Amt_Grt_100_ErrorCheck()
        {
            await TaxTestErrorCheck(10);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Amt_Less_0_ErrorCheck()
        {
            await TaxTestErrorCheck(11);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_No_Type_ErrorCheck()
        {
            await TaxTestErrorCheck(12);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Type_1002_ErrorCheck()
        {
            await TaxTestErrorCheck(13);
        }

        [Fact]
        public async Task GetTaxCADetailsWithDiscount_Amt_Negative_ErrorCheck()
        {
            await TaxTestErrorCheck(14);
        }

        [Fact]
        public async Task GetTaxCADetailsWithItemDiscount_With_Amt_60()
        {
            await TaxTestAsync(15);
        }

        [Fact]
        public async Task GetTaxCADetails_Empty_Request()
        {
            // Arrange

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", string.Empty);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = responseObject.ToString().Replace("\"", string.Empty);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            // TODO: Figure out what this should be testing and assert here
        }

        [Fact]
        public async Task GetTaxCADetails_Empty_ProductCode_XeroxUS()
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatDetailRequest, 16));

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);

            // Assert
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            // TODO: Figure out what this should be testing and assert here
        }

        [Fact]
        public async Task GetTaxCADetailsWith2EDC()
        {
            await TaxTestAsync(17);
        }

        [Fact]
        public async Task GetTaxCADetailsWith5EDC()
        {
            await TaxTestAsync(18);
        }

        [Fact]
        public async Task GetTaxCADetailsWithInvalidCompanyCode()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/TaxDetailsCA/TaxCAPost19DetailRequest.json");
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxCADetailsWithMissingAddress()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/TaxDetailsCA/TaxCAPost20DetailRequest.json");
            var response = File.ReadAllText("TestJson/TaxDetailsCA/TaxCAPost20DetailResponse.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact(DisplayName = "TaxHealthCheck")]
        public void TaxHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Tax Service", Status = "Ready" }),
            };
            Helper.HealthCheck(null, EndPoint.Tax, expected);
        }

        private enum ResponseType
        {
            Array,
            Object
        }

        private async Task TaxTestAsync(string url, string fileName, ResponseType type, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText($"TestJson/TaxDetailsCA/{fileName}.json");
            var response = File.ReadAllText($"TestJson/TaxDetailsCA/{fileName}Response.json");
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync(url, request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();
            if (responseObject != "null")
            {
                if (type == ResponseType.Object)
                {
                    var actual = JObject.Parse(responseObject);
                    Assert.True(JToken.DeepEquals(expected, actual));
                    Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
                }
                else if (type == ResponseType.Array)
                {
                    var actual = JArray.Parse(responseObject);
                    Assert.True(JToken.DeepEquals(expected, actual));
                    Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
                }
            }
        }

        private async Task TaxTestAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatDetailRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, fileNumber));
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));

        }

        private async Task TaxTestErrorCheck(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.InternalServerError)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatDetailRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, fileNumber));
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }
    }
}