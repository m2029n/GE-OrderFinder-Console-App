﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class LogsTests
    {
        private readonly Helper _helper;

        public LogsTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetLogsAsyncTest()
        {
            var httpresponse = await GetLogsHttpResponseMessage();
            string responseObject = await httpresponse.Content.ReadAsStringAsync();
            var request = JObject.Parse(responseObject);
            Assert.NotEqual((int)request["ResultCount"], -1);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task<HttpResponseMessage> GetLogsHttpResponseMessage()
        {
            var sdate = DateTime.Now.AddDays(-10).ToString("MM'/'dd'/'yyyy");
            var edate = DateTime.Now.ToString("MM'/'dd'/'yyyy");
            var httpresponse = await _helper.GetFromXeroxUsApiAsync($"logs?startDate={sdate}&endDate={edate}&httpmethod=post");
            return httpresponse;
        }

        [Fact]
        public async Task GetLogTest()
        {
            var httpresponse = await GetLogsHttpResponseMessage();
            string responseObject = await httpresponse.Content.ReadAsStringAsync();
            var request = JObject.Parse(responseObject);
            var count = (int)request["ResultCount"];
            if (count > 0)
            {
                var id = request["Results"][0]["Id"];
                httpresponse = await _helper.GetFromXeroxUsApiAsync($"logs/{id}");
                responseObject = await httpresponse.Content.ReadAsStringAsync();
                request = JObject.Parse(responseObject);
                var idExpected = request["Id"];
                Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
                Assert.Equal(idExpected, id);
            }
        }
    }
}