﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Cdw.Partners.IntegrationTests.Tests
{
    internal class CcHelper
    {
        public static JToken Encrypt(JToken jToken)
        {
            var name = jToken["Firstname"] + " " + jToken["Lastname"];

            var plainText = "{\"Name\": \"John Doe\", \"Number\": \"4111111111111111\", \"ExpirationMonth\": 6, \"ExpirationYear\": 2025, \"CSC\": \"123\" }".Replace("John Doe", name);
            var distinguishedName = "CN=XDR";

            var x509Cert = GetCertificate(distinguishedName);

            var publicKey = (RSACryptoServiceProvider)x509Cert.PublicKey.Key;

            var cipher = Encrypt(publicKey, plainText);

            return Convert.ToBase64String(cipher);
        }

        private static X509Certificate2 GetCertificate(string distinguishedName)
        {
            var store = new X509Store(StoreLocation.LocalMachine);

            store.Open(OpenFlags.ReadOnly);

            var certCollection = store.Certificates;
            var currentCerts = certCollection.Find(X509FindType.FindByTimeValid, DateTime.Now, false);
            var signingCert = currentCerts.Find(X509FindType.FindBySubjectDistinguishedName, distinguishedName, false);

            return signingCert[0];
        }

        private static byte[] Encrypt(RSACryptoServiceProvider publicKey, string plainText)
        {
            using (var aes = new AesCryptoServiceProvider())
            {
                var cipher = Encrypt(plainText, aes.Key, aes.IV);

                var keyFormatter = new RSAPKCS1KeyExchangeFormatter(publicKey);

                var encryptedKey = keyFormatter.CreateKeyExchange(aes.Key, aes.GetType());
                var encryptedKeyLength = encryptedKey.Length;
                var initializationVectorLength = aes.IV.Length;
                var initializationVector = aes.IV;

                using (var memoryStream = new MemoryStream())
                {
                    memoryStream.Write(BitConverter.GetBytes(encryptedKeyLength), 0, 4);
                    memoryStream.Write(BitConverter.GetBytes(initializationVectorLength), 0, 4);
                    memoryStream.Write(encryptedKey, 0, encryptedKeyLength);
                    memoryStream.Write(initializationVector, 0, initializationVectorLength);
                    memoryStream.Write(cipher, 0, cipher.Length);

                    memoryStream.Flush();

                    return memoryStream.ToArray();
                }
            }
        }

        private static byte[] Encrypt(string plainText, byte[] key, byte[] iv)
        {
            using (var aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;
                aes.IV = iv;

                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (var memoryStream = new MemoryStream())
                {
                    using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (var writer = new StreamWriter(cryptoStream))
                        {
                            writer.Write(plainText);
                        }

                        return memoryStream.ToArray();
                    }
                }
            }
        }

        private string Decrypt(RSACryptoServiceProvider privateKey, byte[] cipher)
        {
            using (var memoryStream = new MemoryStream(cipher))
            {
                var keyLengthBytes = new byte[4];
                var initializationVectorLengthBytes = new byte[4];

                memoryStream.Seek(0, SeekOrigin.Begin);
                memoryStream.Read(keyLengthBytes, 0, 4);
                memoryStream.Read(initializationVectorLengthBytes, 0, 4);

                var keyLength = BitConverter.ToInt32(keyLengthBytes, 0);
                var initializationVectorLength = BitConverter.ToInt32(initializationVectorLengthBytes, 0);

                var encryptedAesKeyBytes = new byte[keyLength];
                var initializationVectorBytes = new byte[initializationVectorLength];

                memoryStream.Read(encryptedAesKeyBytes, 0, keyLength);
                memoryStream.Read(initializationVectorBytes, 0, initializationVectorLength);

                var aesKeyDecrypted = privateKey.Decrypt(encryptedAesKeyBytes, false);

                byte[] plainTextBytes = null;

                using (var aes = new AesCryptoServiceProvider())
                {
                    aes.Key = aesKeyDecrypted;
                    aes.IV = initializationVectorBytes;

                    using (var transform = aes.CreateDecryptor())
                    {
                        using (var outputStream = new MemoryStream())
                        {
                            using (var cryptoStream = new CryptoStream(outputStream, transform, CryptoStreamMode.Write))
                            {
                                var count = 0;
                                var readBytes = new byte[1024];

                                do
                                {
                                    count = memoryStream.Read(readBytes, 0, 1024);
                                    cryptoStream.Write(readBytes, 0, count);
                                } while (count > 0);

                                cryptoStream.FlushFinalBlock();
                            }

                            plainTextBytes = outputStream.ToArray();

                            return Encoding.UTF8.GetString(plainTextBytes);
                        }
                    }
                }
            }
        }
    }
}