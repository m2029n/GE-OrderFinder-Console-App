﻿namespace Cdw.Partners.IntegrationTests.Tests
{
    internal class OrderReaderTests
    {
    }
}