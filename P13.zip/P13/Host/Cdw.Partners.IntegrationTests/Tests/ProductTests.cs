﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class ProductTests
    {
        private readonly Helper _helper;

        public ProductTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public void ProductHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new {Service = "Product Service", Status = "Ready"}),
            };
            Helper.HealthCheck(null, EndPoint.Products, expected);
        }

        [Fact]
        public async Task GetProducts_pass_for_XeroxCanada()
        {
            // Arrange
            
            // Act
            var httpresponse = await _helper.GetFromXeroxCanadaApiAsync("products");
            var responseObject = httpresponse.Content.ReadAsStringAsync().Result;
            
            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.NotNull(actual["Results"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetProducts_pass_for_BlackBox()
        {
            // Arrange

            // Act
            var httpresponse = await _helper.GetFromBlackBoxApiAsync("products");
            var responseObject = await httpresponse.Content.ReadAsStringAsync();
            
            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.NotNull(actual["Results"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }
    }
}