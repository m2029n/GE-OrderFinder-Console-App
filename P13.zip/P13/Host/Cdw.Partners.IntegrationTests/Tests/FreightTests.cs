﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class FreightTests
    {
        private readonly Helper _helper;

        public FreightTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetFreightWithTwoItems()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost1Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost1Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightWithOneItems()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost3Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost3Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithEmptyProductCode()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost4Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost4Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithEmptyShippingAddress()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost8Request.json");

            await FreightTestMissingAddressAsync(request);
        }

        [Fact]
        public async Task GetFreightWithOneBundleItem()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost5Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost5Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightWithTwoBundleItems()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost6Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost6Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightWithTwoBundleItemsOneNonBundleItem()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost7Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost7Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightWithInvalidCompanyCode()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost9Request.json");

            await FreightTestInvalidCompanyCodeAsync(request);
        }

        [Fact]
        public async Task GetFreigthWithInvalidProductCode()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost10Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost10Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreightWithInvalidCountry()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost11Request.json");

            await FreightTestInvalidCountryAsync(request);
        }

        [Fact]
        public async Task GetFreightWithInvalidPostalCode()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost12Request.json");

            await FreightTestInvalidPostalCodeAsync(request);
        }

        [Fact]
        public async Task GetFreigthWithInvalidState()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost13Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost13Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWith9DigitPostalCode()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost14Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost14Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithBlackboxEDC()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost15Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost15Response.json");

            await FreightTestNoShipMethodsAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithCAEDC()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost16Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost16Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithHeavyEDC()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost17Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost15Response.json");

            await FreightTestNoShipMethodsAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithDropShipEDC()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost18Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost18Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithElectronicDropShipEDC()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost19Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost19Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithAKAddress()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost20Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost20Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithHIAddress()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost21Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost21Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithFreightDetails()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost22Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost22Response.json");

            await FreightTestDetailsAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthWithoutRequestorSection()
        {
            var request = File.ReadAllText("TestJson/Freight/FreightPost23Request.json");
            var response = File.ReadAllText("TestJson/Freight/FreightPost23Response.json");

            await FreightTestNoRequestorAsync(request, response);
        }

        private async Task FreightTestAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestDetailsAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCodeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            var expectedCodeDetail = expected["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCodeDetail, actualCodeDetail);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            var actualChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            var expectedChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedChargeDetail, actualChargeDetail);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestNoShipMethodsAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.Equal(actual["Freight"]["ShippingMethods"].Count(), 0);
        }

        private async Task FreightTestNoRequestorAsync(string request, string response)
        {
            // Arrange
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            // TODO: Determine intent of this test and assert here...
        }

        private async Task FreightTestMissingAddressAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Country code not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCompanyCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCountryAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Company code 01 is invalid for country code 'XX'\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidPostalCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Invalid US postal code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestMessageAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(expected["ErrorMessage"], actual["ErrorMessage"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact(DisplayName = "FreightHealthCheck")]
        public void FreightHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Freight Service", Status = "Ready" }),
            };
            Helper.HealthCheck(null, EndPoint.Freight, expected);
        }

        public void ScrubEnvironmentalSpecificVariable(JObject objectToScrub)
        {
            objectToScrub["TransactionIdentifier"] = string.Empty;
        }
    }
}