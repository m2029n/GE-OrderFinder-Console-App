﻿using Cdw.Api.Partners.Service.Infrastructure.Extension;
using Cdw.Test.Common.Xunit;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class StringExtensionTests
    {
        [Theory(DisplayName = "IsValidUSPostalCode_IsEmpty_IsNotValid")]
        [InlineData("", false)]
        [InlineData(null, false)]
        [InlineData(60656, true)]
        [InlineData("60656-0000", true)]
        [InlineData("606560", false)]
        [InlineData("6065", false)]
        [InlineData("60656-", false)]
        [InlineData("60656-00000", false)]
        [InlineData("60656-000", false)]
        [InlineData("6065A", false)]
        [InlineData("60656-000A", false)]
        public void IsValidUSPostalCode_IsEmpty_IsNotValid(string postalCode, bool expected)
        {
            var isValid = postalCode.IsValidUSPostalCode();
            Assert.Equal(expected, isValid);
        }

        [Theory(DisplayName = "IsValidCanadaPostalCode_IsEmpty_IsNotValid")]
        [InlineData("", false)]
        [InlineData(null, false)]
        [InlineData("A1A1A1", true)]
        [InlineData("A1A 1A1", true)]
        [InlineData("a1a1a1", true)]
        [InlineData("A1A1A19", false)]
        [InlineData("A1A1A", false)]
        [InlineData("A1A1A ", false)]
        [InlineData("11A1A1 ", false)]
        [InlineData("AAA1A1 ", false)]
        [InlineData("A111A1 ", false)]
        [InlineData("A1AAA1 ", false)]
        [InlineData("A1A11A ", false)]
        [InlineData("A1A1AA ", false)]
        public void IsValidCanadaPostalCode_IsEmpty_IsNotValid(string postalCode, bool expected)
        {
            var isValid = postalCode.IsValidCanadaPostalCode();
            Assert.Equal(expected, isValid);
        }
    }
}