﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class FreightCATests
    {
        private readonly Helper _helper;

        public FreightCATests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetFreightCAWithTwoItems()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost1Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost1Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithOneItems()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost2Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost2Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithElectronicDropShipItem()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost3Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost3Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithEmptyProductCode()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost4Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost4Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreigthCAWithEmptyShippingAddress()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost5Request.json");

            await FreightTestMissingAddressAsync(request);
        }

        [Fact]
        public async Task GetFreightCAWithInvalidCountry()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost6Request.json");

            await FreightTestInvalidCountryAsync(request);
        }

        [Fact]
        public async Task GetFreigthCAWithInvalidProductCode()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost7Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost7Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithInvalidCompanyCode()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost8Request.json");

            await FreightTestInvalidCompanyCodeAsync(request);
        }

        [Fact]
        public async Task GetFreightCAWithInvalidPostalCode()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost9Request.json");

            await FreightTestInvalidPostalCodeAsync(request);
        }

        [Fact]
        public async Task GetFreightCAWithInvalidState()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost10Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost10Response.json");

            await FreightTestAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithUSEDC()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost11Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost11Response.json");

            await FreightTestMessageAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithHeavyEDC()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost12Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost12Response.json");

            await FreightTestNoShipMethodsAsync(request, response);
        }

        [Fact]
        public async Task GetFreightCAWithFreightDetails()
        {
            var request = File.ReadAllText("TestJson/FreightCA/FreightCAPost13Request.json");
            var response = File.ReadAllText("TestJson/FreightCA/FreightCAPost13Response.json");

            await FreightTestDetailsAsync(request, response);
        }

        private async Task FreightTestAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestDetailsAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);
            ScrubEnvironmentalSpecificVariable(expected);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            ScrubEnvironmentalSpecificVariable(actual);

            var actualCode = actual["Freight"]["ShippingMethods"][0]["Code"];
            var expectedCode = expected["Freight"]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCode, actualCode);

            var actualCodeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            var expectedCodeDetail = expected["Freight"]["Details"][0]["ShippingMethods"][0]["Code"];
            Assert.Equal(expectedCodeDetail, actualCodeDetail);

            var actualCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            var expectedCharge = actual["Freight"]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedCharge, actualCharge);

            var actualChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            var expectedChargeDetail = actual["Freight"]["Details"][0]["ShippingMethods"][0]["FreightCharge"];
            Assert.Equal(expectedChargeDetail, actualChargeDetail);

            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestMessageAsync(string request, string response)
        {
            // Arrange
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);

            Assert.Equal(expected["ErrorMessage"], actual["ErrorMessage"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        private async Task FreightTestMissingAddressAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Country code not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCountryAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Company code 17 is invalid for country code 'XX'\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidCompanyCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestInvalidPostalCodeAsync(string request)
        {
            // Arrange
            var expectedMessage = "\"Invalid Canada postal code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        private async Task FreightTestNoShipMethodsAsync(string request, string response)
        {
            // Arrange

            // Act
            var httpresponse = await _helper.PostToXeroxCanadaApiAsync("freight", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();
            var actual = JObject.Parse(responseObject);

            // Assert
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.Equal(actual["Freight"]["ShippingMethods"].Count(), 0);
        }

        public void ScrubEnvironmentalSpecificVariable(JObject objectToScrub)
        {
            objectToScrub["TransactionIdentifier"] = string.Empty;
        }
    }
}