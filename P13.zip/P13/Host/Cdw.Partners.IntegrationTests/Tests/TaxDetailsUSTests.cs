﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class TaxDetailsUSTests
    {
        private const string FileFormatRequest = "TestJson/Tax/TaxPost{0}Request.json";
        private const string FileFormatResponse = "TestJson/Tax/TaxPost{0}Response.json";
        private const string FileFormatDetailRequest = "TestJson/Tax/TaxPost{0}DetailRequest.json";
        private const string FileFormatDetailResponse = "TestJson/TaxDetails/TaxPost{0}DetailResponse.json";

        private readonly Helper _helper;

        public TaxDetailsUSTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetTaxDetailsWithProductFee()
        {
            await TaxTestAsync("tax/details", "TaxPostWithProductFee", ResponseType.Object);
        }

        [Fact]
        public async Task GetTaxDetailsWithoutProductFee()
        {
            await TaxTestAsync("tax/details", "TaxPostWithoutProductFee", ResponseType.Object);
        }

        [Fact]
        public async Task GetTaxDetailsWithItemDiscount()
        {
            await TaxTestAsync(1);
        }

        [Fact]
        public async Task GetTaxDetailsWithNoItemDiscount()
        {
            await TaxTestAsync(2);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Id_5PERCOFF()
        {
            await TaxTestAsync(3);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Id_OrderLevelDiscount1()
        {
            await TaxTestAsync(4);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Type_1001_Amt_50()
        {
            await TaxTestAsync(5);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Type_1001_Amt_75()
        {
            await TaxTestAsync(6);
        }

        [Fact]
        public async Task GetTaxDetailsWithItemDiscount_With_Amt_75()
        {
            await TaxTestAsync(7);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Type_1001_Amt_100()
        {
            await TaxTestAsync(8);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_No_Id_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(9);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Amt_Grt_100_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(10);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Amt_Less_0_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(11);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_No_Type_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(12);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Type_1002_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(13);
        }

        [Fact]
        public async Task GetTaxDetailsWithDiscount_Amt_Negative_ErrorCheck()
        {
            await TaxTestErrorCheckAsync(14);
        }

        [Fact]
        public async Task GetTaxDetailsWithItemDiscount_With_Amt_60()
        {
            await TaxTestAsync(15);
        }

        [Fact]
        public async Task GetTaxDetails_Empty_Request()
        {
            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", string.Empty);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = responseObject.ToString().Replace("\"", "");
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
            // TODO: Figure out what this should be testing and assert here
        }

        [Fact]
        public async Task GetTaxDetails_Empty_ProductCode_BlackBox()
        {
            await TaxTest_BlackBoxAsync(38);
        }

        [Fact]
        public async Task GetTaxDetails_Empty_ProductCode_XeroxUS()
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, 16));

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);

            // Assert
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            // TODO: Figure out what this should be testing and assert here
        }

        [Fact]
        public async Task GetTaxDetailsWith2EDC()
        {
            await TaxTestAsync(17);
        }

        [Fact]
        public async Task GetTaxDetailsWith10EDC()
        {
            await TaxTestAsync(18);
        }

        [Fact]
        public async Task GetTaxDetailsWithInvalidCompanyCode()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost19Request.json");
            var expectedMessage = "\"Unsupported company code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxDetailsWithMissingAddress()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost20Request.json");
            var response = File.ReadAllText("TestJson/Tax/TaxPost20Response.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();
            var actual = JArray.Parse(responseObject);

            // Assert
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxDetailsWithEmptyState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost21Request.json");
            var response = File.ReadAllText("TestJson/Tax/TaxPost21Response.json");
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(HttpStatusCode.InternalServerError, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        [Fact]
        public async Task GetTaxDetailsWithInvalidPostalCode()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost22Request.json");
            var expectedMessage = "\"Invalid US postal code\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxDetailsWithInvalidState()
        {
            await TaxTestAsync(23);
        }

        [Fact]
        public async Task GetTaxDetailsWithInvalidCountry()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Tax/TaxPost24Request.json");
            var expectedMessage = "\"Company code 1000 is invalid for country code 'XX'\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expectedMessage, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetTaxDetailsWithCAEDC()
        {
            await TaxTestAsync(25);
        }

        [Fact]
        public async Task GetTaxDetailsWith9DigitZipCode()
        {
            await TaxTestAsync(26);
        }

        [Fact]
        public async Task GetTaxDetailsWithBundleItem()
        {
            await TaxTestAsync(27);
        }

        [Fact]
        //one bundle item and one non bundle item
        public async Task GetTaxDetailsWithMixedProducts()
        {
            await TaxTestAsync(28);
        }

        [Fact]
        //one bundle item, one non bundle item, drop ship item
        public async Task GetTaxDetailsWithMixedProducts1()
        {
            await TaxTestAsync(29);
        }

        [Fact]
        public async Task GetTaxDetailsWithDropshipItem()
        {
            await TaxTestAsync(30);
        }

        [Fact]
        public async Task GetTaxDetailsWithOrderLevelDiscount1000()
        {
            await TaxTestAsync(31);
        }

        [Fact]
        public async Task GetTaxDetailsWithOrderLevelDiscount1001()
        {
            await TaxTestAsync(32);
        }

        [Fact]
        public async Task GetTaxDetailsWithLineLevelDiscount1002()
        {
            await TaxTestAsync(33);
        }

        [Fact]
        public async Task GetTaxDetailsWithLineLevelDiscount1003()
        {
            await TaxTestAsync(34);
        }

        [Fact]
        public async Task GetTaxDetailsWithLineLevelDiscount1004()
        {
            await TaxTestAsync(35);
        }

        [Fact]
        public async Task GetTaxDetailsWithLineLevelDiscount1005()
        {
            await TaxTestAsync(36);
        }

        [Fact]
        public async Task GetTaxDetailsWithComboDiscount()
        {
            await TaxTestAsync(37);
        }

        [Fact(DisplayName = "TaxHealthCheck")]
        public void TaxHealthCheck()
        {
            var expected = new JArray()
            {
                JObject.FromObject(new { Service = "Tax Service", Status = "Ready" }),
            };
            Helper.HealthCheck(null, EndPoint.Tax, expected);
        }

        private enum ResponseType
        {
            Array,
            Object
        }

        private async Task TaxTestAsync(string url, string fileName, ResponseType type, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText($"TestJson/Tax/{fileName}.json");
            var response = File.ReadAllText($"TestJson/Tax/{fileName}Response.json");
            

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync(url, request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            if (responseObject != "null")
            {
                if (type == ResponseType.Object)
                {
                    var actual = JObject.Parse(responseObject);
                    var expected = JObject.Parse(response);
                    Assert.True(JToken.DeepEquals(expected, actual));
                    Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
                }
                else if (type == ResponseType.Array)
                {
                    var actual = JArray.Parse(responseObject);
                    var expected = JArray.Parse(response);
                    Assert.True(JToken.DeepEquals(expected, actual));
                    Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
                }
            }
        }

        private async Task TaxTestAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, fileNumber));
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task TaxTestErrorCheckAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.InternalServerError)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, fileNumber));
            var expected = JArray.Parse(response);

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));
        }

        private async Task TaxTest_BlackBoxAsync(int fileNumber, HttpStatusCode expectedStatusCode = HttpStatusCode.OK)
        {
            // Arrange
            var request = File.ReadAllText(string.Format(FileFormatRequest, fileNumber));
            var response = File.ReadAllText(string.Format(FileFormatDetailResponse, fileNumber));
            var expected = JObject.Parse(response);

            // Act
            var httpresponse = await _helper.PostToBlackBoxApiAsync("tax/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JObject.Parse(responseObject);
            Assert.Equal(expectedStatusCode, httpresponse.StatusCode);
            Assert.True(JToken.DeepEquals(expected, actual));

        }
    }
}