﻿using Cdw.Test.Common.Xunit;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests.Tests
{
    [Integration]
    public class RecyclingDetailsTests
    {
        private readonly Helper _helper;

        public RecyclingDetailsTests()
        {
            _helper = new Helper();
        }

        [Fact]
        public async Task GetRecyclingFeesDetailsFor2EDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost1Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal("6", actual[0]["Amount"]);
            Assert.Equal("197154", actual[0]["ProductCode"]);
            Assert.Equal("654810", actual[0]["ProductFeeEDC"]);
            Assert.Equal("6", actual[1]["Amount"]);
            Assert.Equal("198543", actual[1]["ProductCode"]);
            Assert.Equal("654810", actual[1]["ProductFeeEDC"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForOneEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost2Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal("6", actual[0]["Amount"]);
            Assert.Equal("197154", actual[0]["ProductCode"]);
            Assert.Equal("654810", actual[0]["ProductFeeEDC"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsFor10EDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost3Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal("6", actual[0]["Amount"]);
            Assert.Equal("197154", actual[0]["ProductCode"]);
            Assert.Equal("654810", actual[0]["ProductFeeEDC"]);
            Assert.Equal("5", actual[6]["Amount"]);
            Assert.Equal("4168571", actual[6]["ProductCode"]);
            Assert.Equal("654809", actual[6]["ProductFeeEDC"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsCAState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost4Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForMixedEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost5Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            var actual = JArray.Parse(responseObject);
            Assert.Equal("5", actual[0]["Amount"]);
            Assert.Equal("4168571", actual[0]["ProductCode"]);
            Assert.Equal("654809", actual[0]["ProductFeeEDC"]);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForILState()
        {
            //IL state does not have recycle fee, Hence the test is to check for null

            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost6Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForEDCWithNoRecycle()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost7Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForValidStateNoEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost8Request.json");
            var expected = "\"ProductCodes code not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();
            

            // Assert
            Assert.Equal(expected, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForInvalidEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost9Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForEmptyStateEmptyProduct()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost10Request.json");
            var expected = "\"State not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expected, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForEmptyState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost11Request.json");
            var expected = "\"State not found\"";

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal(expected, responseObject);
            Assert.Equal(HttpStatusCode.BadRequest, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForInvalidState()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost12Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }

        [Fact]
        public async Task GetRecyclingFeeDetailsForCAEDC()
        {
            // Arrange
            var request = File.ReadAllText("TestJson/Recycling/RecyclingFeeSummaryPost13Request.json");

            // Act
            var httpresponse = await _helper.PostToXeroxUsApiAsync("recycling/details", request);
            var responseObject = await httpresponse.Content.ReadAsStringAsync();

            // Assert
            Assert.Equal("null", responseObject);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
        }
    }
}