﻿using System;
using Cdw.Partners.Host;
using Microsoft.Owin.Hosting;

namespace Cdw.Partners.IntegrationTests
{
    public class AssemblyStartup
    {
        private static readonly object _object = new object();

        public static readonly int Port = new Random().Next(10000, 29999);
        public static bool IsRunning = false;

        internal static string ServiceBaseUrl => $"http://localhost:{Port}/";

        public static void StartServer()
        {
            lock (_object)
            {
                if (!IsRunning)
                {
                    var contentFolderPath = "D:\\Inetsrv\\API\\External\\V2.3\\Partners\\Cdw.Partners.Host"; 
                    WebApp.Start(new StartOptions {Port = Port}, (appBuilder) =>
                    {
                        new Startup(contentFolderPath).Configuration(appBuilder);
                    });
                    IsRunning = true;
                }
            }
        }
    }
}