﻿using Cdw.Security.OAuth2.Client;
using Flurl;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Partners.IntegrationTests
{
    internal enum EndPoint
    {
        Tax,
        Freight,
        Cart,
        Products,
        Partners,
        Recycling
    }

    internal class Helper
    {
        private const string ClientKey = "2FD7BA6B429841158F15BF618730ADA5"; // for Cdw App
        private const string ClientSecret = "1F725FB4F9464749A55AB6C17DB56E48"; // for Cdw App

        public static void HealthCheck(CdwHttpClient httpClient, EndPoint endPoint, JArray expectedStatusMessage)
        {
            AssemblyStartup.StartServer();
            var settings = new CdwHttpClientSettings()
            {
                BaseUrl = new Flurl.Url(AssemblyStartup.ServiceBaseUrl),
                ClientKey = ClientKey,
                ClientSecret = ClientSecret,
                ServiceRoute = "",
                AllowedHttpStatusRange = "*"
            };
            var client = new CdwHttpClient(settings);
            var endpoint = endPoint == EndPoint.Partners ? "" : endPoint.ToString();

            var httpurl = AssemblyStartup.ServiceBaseUrl.AppendPathSegment(endpoint).AppendPathSegment("healthcheck");
            HttpResponseMessage httpresponse;
            if (httpClient != null)
            {
                httpresponse = httpClient.GetAsync(httpurl).Result;
            }
            else
            {
                httpresponse = client.GetAsync("healthcheck").Result;
            }

            var responseObject = httpresponse.Content.ReadAsStringAsync().Result;

            var actual = JArray.Parse(responseObject);

            Assert.NotNull(actual);
            Assert.Equal(HttpStatusCode.OK, httpresponse.StatusCode);
            Assert.NotNull(expectedStatusMessage);
        }

        private static string _basicTokenXeroxUs = "MDcwMDFFNzQzRUJBNEUyNUEyQ0NFOTMyMkRCNTBFM0U6MThBNzBDRjdERjI3NDFBNThEOEExN0VBQjg1QjEzNjA=";
        private static string _basicTokenXeroxCanada = "NEM5QzJCMURBMDBDNDU3QkE2MjAyRkYxRjhCRDI0QkM6NUY5RDcwNDU4OERGNDcyOEJBNzYxMDQ3M0YyRTYwNTE=";
        private static string _basicTokenNonXerox = "NDUxNzA4MkQ1OTA2MEE4RDFDMUEwNkZCNTc1QTNDNjM6MDI0NjI2REU5RjUzOTc4RkFGNzg1MjM0MTYzQzU5RkQ=";
        private static string _basicTokenBlackBox = "QUM2OEY2NzkzN0M0NDU1NUIyODc3OTMxRUM3RTEwQkM6MDIxNzA0NDU1NkEzNEQ3NjgwQzM5RkVEODYyNzg0OUY=";

        public async Task<HttpResponseMessage> PostToXeroxCanadaApiAsync(string serviceSuffixUrl, string inputJson)
        {
            var token = await GetTokenAsync(_basicTokenXeroxCanada);
            return await PostToApiAync(token, serviceSuffixUrl, inputJson);
        }

        public async Task<HttpResponseMessage> PostToXeroxUsApiAsync(string serviceSuffixUrl, string inputJson)
        {
            var token = await GetTokenAsync(_basicTokenXeroxUs);
            return await PostToApiAync(token, serviceSuffixUrl, inputJson);
        }

        public async Task<HttpResponseMessage> PostToBlackBoxApiAsync(string serviceSuffixUrl, string inputJson)
        {
            var token = await GetTokenAsync(_basicTokenBlackBox);
            return await PostToApiAync(token, serviceSuffixUrl, inputJson);
        }

        public async Task<HttpResponseMessage> GetFromXeroxUsApiAsync(string serviceSuffixUrl)
        {
            var token = await GetTokenAsync(_basicTokenXeroxUs);
            return await GetFromApiAsync(token, serviceSuffixUrl);
        }

        public async Task<HttpResponseMessage> GetFromXeroxCanadaApiAsync(string serviceSuffixUrl)
        {
            var token = await GetTokenAsync(_basicTokenXeroxCanada);
            return await GetFromApiAsync(token, serviceSuffixUrl);
        }

        public async Task<HttpResponseMessage> GetFromBlackBoxApiAsync(string serviceSuffixUrl)
        {
            var token = await GetTokenAsync(_basicTokenBlackBox);
            return await GetFromApiAsync(token, serviceSuffixUrl);
        }

        private async Task<HttpResponseMessage> PostToApiAync(string token, string serviceSuffixUrl, string inputJson)
        {
            var serviceBaseUrl = AssemblyStartup.ServiceBaseUrl;
            var requestUri = serviceSuffixUrl;

            // Comment above lines and uncomment below lines to target staging environment
            //var serviceBaseUrl = "http://apistage.cdw.com/";
            //var requestUri = $"external/v2.3/partners/{serviceSuffixUrl}";

            //var nonDevCreditCard = "AAEAABAAAACBPZu+I4aPTtYh0xduK3UEM7mr6BZBozd47CjTfVXWw6pECEo5befy81PFIuyKINh345PT9Uak+gqo75/RaaGxkGSsHtQCfcbQmWn3KxTn/rNs4tMdgr9hQCvsGcEndpWjsihxLvxHaMliCaa8W4ALK47KWVuyWzl3GTBDatKR1WCB6uBrhPo1TU3+Zw2PIpLg8hJvAYSkKA4Poscaquq80Tv5osBRtDEWdzpeL5CmTUKUqDl+l8FUbpJNe7TJqaoN+4j512D5EmMW3lcAL/oDQeAEP91utzhgLjXv5ezERzEb/XN4ju7IEspsy5/lIYgSZn6o42+LKzPoNVQjzqOqDbHRo0qa1j0C0/CNrnIKt8fFaxigSQZRzo15w2iaX21Ie61ZVXLTOOYP9HC1SroMGpoFcWQPlZT6/qvfwWnBuKBolgjUR2uBKbN7yW9FcmLo/pnBKXxSETJWPrj6J3ExFT/B6etjYrQl475BtQIlvw==";
            //inputJson = inputJson.Replace("AAEAABAAAAAV5eIP3mbnXSCBLf1EeWOOBWNcYGI1w7Mm88Pib0i2YbkgDssmWAe28g9aB3X1u9nRlyr5QyVRQC3z05c5RQLfG8awUpsr1imuHOaSPX+hog/Aq4heKLMkehIZVRcO6p1ZrRiV4ku2XmcX9ZyhBvmovptD7BNFJWTKnfgV+GDrc8QsmC0VhFmvg71IhOuLV4w5/W/faiVfHA4cEb4Wlm3KFwedSY4KTY2U+2J96HcL0J9GVzPPHyNZFFDd7lXy90UB96tA2FITeQ6poC6kvTJtPLdiu0KyBdtAD7e53ZB/P1xMZrP0P3IwwS89remHaAnfigRwDs/P2u5U+FiPqgC0C9vAGzLnHG/2qyuL3GddJrdI5+3q/KFBZgxBIlUCCmRVsMmKBWIl3xBUZuC8xCZ0jjDs2wYW09voSUfkBwFHBVHy2WQqKgeMo1YJ+vnDBF24bal6OfNMNKNgH1bGY265uvsRctCzfGw5zWPHKULG7xzEJYkki7novs0BoRzuJ2D4MXSR7SrDk90jxKhnLPUa", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAACyBI0PB0lz4FyXSIXktFeYVc+KepUAsUm3SAvOwUWhymSPsqEipmrFsvLgyqpb1RHauSYwX1df1EucfnDQoa1s6tP15XfgHlrCAg2O9q7naHF2ENFqw0+SEyFajmjvOaz8wESkBYbp4RlUN3VUJGyI9HREDtQwguDxJnDxSWwWEIDKKKTB/rzjPkbm5DGZ7AlCHz5aRO5Htnwdl2qGgqfdGWfUsTElT2W4dsEbRoL7OopTcYP4s9YdfrHsnd2z1ZcFbHOffIvzAEQ8xuhQJgmZoZNglQ2RIuPQfpZ9xMb/BnOQbFqWdvcBIo18diK0c6bRZiFKKAwu48ehc8swKIaKcQ8Phddn9XUxqBQou18ActVt8LX8Snu0C/6ts3IIGZCSPcTbeIlwoZ46GMB+HaWpg6BjY9b1vIGinF7XdsExKJji4zktleGKqiv7hDijjYDGf+trGyyOr0izP3gPz7gkl/T9bfHGm+9IhmelJ8ekKG24vvlL8yilrAaLQYuL2NvUKYjjgGSX0DHpc9C+FT+g", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAACLDFmdSN8uG5Q/nX7H5Ca/7stpruoeLFmCtv/NlZ4oiR6mZtcUXyZxk0GWef0i0h1WpifIV6dA/2PIMY3sYVdgeIkQUBa0DSQflKGCKPyppirAIM37gtzufDulFYrAN0g2X8zcmYVXeoJltRgZueYDta+E++Q0zOdmAVcpAKF/JG5UpfOgpTTBWF/AWMc3gPziWCWln8nKdr6wuGTscRF11jvVUTcW7XApXCcLKUwbBwWaOoVAldQnX2hmZrEmnrDJx3uUnPozJJqUedzOUdjNNNTBJgGDbvhTFSI0qD2Mvahuv1bo6BYCd8Rytc8XHHMQHmUSjoX+wCRQQZYUnpVy1AlgfPeNaCrkvKlCJXcD0fSHP8kBGLyLVWqKJU/aRz0F9+PJXPOABmkE2E6eJb3pnU7ZQ8HL/AzvCdT+cFSmLZh9Lj6UZCxOMA6H+yHUYCHA4PU2lF0yL/j0cAmODthlKw/Yf69FXKC824rd7/+CBXM3zCYYHhkBrN3wsRQsKVNLc2o3KTVPdFOwhZfy0qK+", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAAA869bwhCf0cWYioAYhXfBwUU0IkKdVV3cgJXgLOMbdmjsx7AcP0WfMwj5+3P5J4HFtiXx5AR2umy5+9Mv2bnj9L4qUbnSFR/Hxm4EBxR38rSSbDGK25WUry9XlTDQGhciC1NpTEs9Sub6VwiIr61QpOvSnjjlh5ghOh1IVoOLgl0L+yKnzEdWCwfnB5k+CvgEjskJzo/hgnLxQaHdbdnGl9GCf4qXKNc1umO1xARM8eDJgiIHD4WJKX1Konip+mqyDJaAm4eYXfAhPXHILu/6GXb7yZH/aYP+GOde8OtFkEfZDidg9KwXAA8FASeBS536U/8CwqMbvQqbd6Ne+IhQZ7KNBGGV2u7zbwl5g0bbYcgEh1hdU0doDeSYOP7XWuUlXVDQR7//QGs8fPZk2gGc7lXpcjN2kwHuCGr8YCvLY9GUW+IlKYlJw02qVuZ1DIVDiJ5j818I2chXEy4yTRkQDpoajuC4khJUv9+EiUdbLpFW3JOZWFLf8/8TjD7Isust3e6z7t6/AF2mhea7qFsTB", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAACK7Ki343GP6qtQm7HPqLR9uaHnKT6urG/Y+P4zgn+SzZqdr2uQDEGQWL34sjWnU/oxhXFLQh1L3stPYISsmB3hncHs2xBfiS+mnjhSGNax1CvuPg0BZfaae9NrC5kKbFaE+lCAY4hD/Z7UvG3qLSRrvL9MdOnJc8TtuMFijtjjgEe8XQwMjzBh9ry4xA5Q8VEfQtJ1iOPwagvO9lUF/QijszpkibcYz3AhghyPkaB0n/uy9RtE8dllLLivy+QsXVSapFPXzw6/MR45D1ekm/otEx/+5QoqhtR0VoPavNUnnKXCNdU+xwYJnvMmogaTAZQo4TMJlLPOytSs0jKlq0Fdi0ye/LgcOsd1QZyjAigKkQR4mm4BbHPSHEBUagvS5ahLqT+Fz0eHfnfo0Hy93mUqYiJmBrBesNvbVE5KHdWIQwqI6xfCrKlAQij7s6ItQc+neYC8fS8WpiZal6n1dG9mvTs115Nfr163gnCKd+XubkF7cwTgvqx9Y9wwDm2ocLiXtc2aP42UZef0E8B245au", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAAAXPpquXkL9vr37g/59jG13MYKcwqMDtLbkSQnghbrw8UIEyYDeSEjrm4zD8tRKBNSPEMbHBoNYNhZGkDtMUe7Aa8a/zSV30mZ7Q7AyIJeetVfGtVZYnczIzAQwvVkV8I3piimaHNdMCBhmya98E9TwAIWRStUFBgExqmloeXz9uOWcShFoMQk4Psz+awUKw3LW9Sx/RzTyQtmYev5ozYU71kfUyHsNUyBSBW9JgaR1cIAOHUYgikz/MgEkxF32WARbwWAcKKl1R6B01oy09fUtNGav5mm3BrNoGRKTVVAD0WolnjssygsWAJZLdvccQycwdgz7HQ3rPgvaajn/QKUZ8aMX9HDDpptdDSW872RTQlXHYBr0RynhV1YqDDeWIEK5ky9BNim06I7BZFnCmQx2zMRG9ZtVKvhoDh9X8VDykX0zc5p5zxMnaRHNCVQYzPkraK5F2M6nGC7DPBEx6cz18YB69Lr4nDjaqLERV5LymH9qf/TqPQfi8HRzkj39RqVkbOhch5sXhII5Vt6HT9so", nonDevCreditCard);
            //inputJson = inputJson.Replace("AAEAABAAAADTw97sKdT0zNaouGS3L/a8I2F6mRFhfqrgXo0B0z6wiQWTutChlxAjt0V61SNQ/AquM9fH/NLCuTMnbG469+EDOUy925MBjPDchCNnD7h7XNnPmDRUr1HCs+1HHa1QO7Lb+VPP13aPI8xKS4vHaPLoSINQcSIDR0LfR6IRI+MdTRz+iAYme253wIL6uesiRhISIgZUgOgNBpY2rJ9bsRY9KxA8twdTbkQa2QTaA6z4ZbjvJMFUmc7akGRP9tvnKeZkylFAXkLVPWKAq8OF+yhqLx1nYIiNZmY6P4WsM2Ij6SqAptRxAk3sU17/rVY0POv2fuoa0QYmNuzGramQFK1HEjIop75Ipgk8xb4oN+AM8teD371ASRKfJtLRQPaFpRfqKpnW2jS24Lii+M9Satxvrf7h0QYWiN3DPr6Vv93k+J/SKfglCjxl0erTbSt00VuFmF6MnBGB45NMzckqv5YWmNE0xQVs0aB+0pSeC/FOhP+q6IZ9pbexwiRXRtQY/wsfba5sDIVN6r/Wy+jDXTgb", nonDevCreditCard);
            // end of code to target staging environment

            using (var clientForApi = new HttpClient { BaseAddress = new Uri(serviceBaseUrl) })
            {
                clientForApi.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
                var content = new StringContent(inputJson);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                return await clientForApi.PostAsync(requestUri, content);
            }
        }

        private async Task<HttpResponseMessage> GetFromApiAsync(string token, string serviceSuffixUrl)
        {
            var serviceBaseUrl = AssemblyStartup.ServiceBaseUrl;
            var requestUri = serviceSuffixUrl;

            // Comment above lines and uncomment below 2 lines to target staging environment
            //var serviceBaseUrl = "https://apistage.cdw.com/";
            //var requestUri = $"external/v2.3/partners/{serviceSuffixUrl}";
            // end of code to target staging environment

            using (var httpClient = new HttpClient { BaseAddress = new Uri(serviceBaseUrl) })
            {
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
                return await httpClient.GetAsync($"{requestUri}");
            }
        }

        private async Task<string> GetTokenAsync(string basicToken)
        {
            AssemblyStartup.StartServer();
            var serviceBaseUrl = AssemblyStartup.ServiceBaseUrl;
            var requestUri = "/token";

            // Comment above lines and uncomment below 2 lines to target staging environment
            //var serviceBaseUrl = "https://apistage.cdw.com/";
            //var requestUri = "external/v2.3/partners/token";
            // end of code to target staging environment

            using (var clientforApi = new HttpClient { BaseAddress = new Uri(serviceBaseUrl) })
            {
                clientforApi.DefaultRequestHeaders.Add("Authorization", $"Basic {basicToken}");
                var content = new StringContent("grant_type=client_credentials");
                var result = await clientforApi.PostAsync(requestUri, content);
                var resultContent = await result.Content.ReadAsStringAsync();
                var parseTree = JsonConvert.DeserializeObject<JObject>(resultContent);
                return parseTree.Properties().ToList()[0].Value.ToString();
            }
        }
    }
}