﻿var helpers = require('../modules/test-helpers'),
    utils = require('utils'),
    http = require('http'),
    fs = require('fs');
var testUrl;
var env;
var tenant;

////TC1
casper.test.begin('CreditCardFormTest', function suite(test) {
    casper.start("https://localhost:44366/Test.html",
        function () {
            casper.waitForSelector('#cdw_Number',
                function (success) {
                    casper.test.assertExists("#cdw_Number", "Credit card field loaded");
                    this.sendKeys('#cdw_Number', '4012000033330026');
                    this.sendKeys('#cdw_Name', 'QATester');
                    this.evaluate(function () {
                        var form = document.querySelector('#cdw_ExpirationMonth');
                        form.selectedIndex = 10;
                        $(form).change();
                    });
                    this.evaluate(function () {
                        var form = document.querySelector('#cdw_ExpirationYear');
                        form.selectedIndex = 2;
                        $(form).change();
                    });
                    this.sendKeys('#cdw_CVV', '258');
                    helpers.clickobject(".cdw_button");
                });
            casper.waitForSelectorTextChange('#cdw-callback', function () {
                var cctoken = casper.fetchText("#cdw-callback");
                casper.test.assertNotEquals(cctoken, '');
                console.log(cctoken);
            });
            helpers.takeScreenshot();
        });
    casper.run(function () {
        test.done();
    });
});

//TC2
casper.test.begin('CreditCardFormTestNegative', function suite(test) {
    casper.start("https://localhost:44366/Test.html",
        function () {
            casper.waitForSelector('.cdw_button',
                function (success) {
                    casper.test.assertExists("#cdw_Number", "Credit card field loaded");
                    helpers.clickobject(".cdw_button");
                });
            casper.waitForSelectorTextChange('.cdw_validations', function () {
                var errormsg = casper.fetchText(".cdw_validations");
                casper.test.assertEquals(errormsg, 'Number is requiredName is requiredExpirationMonth is requiredExpirationYear is requiredCVV is required');
                console.log(errormsg);
                helpers.takeScreenshot();
            });
        });
    casper.run(function () {
        test.done();
    });
});