// module includes
var require = patchRequire(require),
    fs = require('fs');
var system = require('system');
var absoluteFilePath = system.args[system.args.length - 1];
var absoluteFileDir = absoluteFilePath.split('\\');
absoluteFileDir.pop();
absoluteFileDir = absoluteFileDir.join('/') + "/";
var moduledir = absoluteFileDir.split('/Scripts');
moduledir.pop();
moduledir.push('Scripts');
moduledir.push('modules');
moduledir = moduledir.join('/') + "/";

/*
    testIndex - The current step of the test.
    screenshotFolder - This is where screenshots will be saved.
*/
var exit = false,
    metaData = {
        'TestStatus': 'PASS'
    },
    screenshotFolder = screenshotFolder = absoluteFileDir + 'Screenshots/' + new Date().toISOString().replace(/:/g, '') + '/Step';
testIndex = 0,
    testStart = Date.now(),
    splunkURL = "https://splnkfrprdvh3:8089/services/receivers/simple?sourcetype=CDW_ECommerceWeb_TestAutomation&index=sdlc";

/*
    Wrapper for the screenshot feature
*/
function takeScreenshot() {
    casper.then(function () {
        casper.capture(screenshotFolder + testIndex + ".png");
    });
}

/*
    Increments the test step value.
*/
function incrementStep() {
    testIndex++;
    console.log('Test Execution in progress >> Step ' + testIndex);
}

//function to click objects
function clickobject(obj) {
    casper.waitForSelector(obj,
        function success() {
            if (this.test.currentSuite.failed == 0) {
                incrementStep();
                this.click(obj);
            }
        }, function fail() {
            casper.test.fail("unable to click object " + obj);
        });
}
/*
   Any function that needs to be accessed from a test case file needs to be
   added to the exports object.
*/
module.exports = {
    takeScreenshot: takeScreenshot,
    clickobject: clickobject,
};