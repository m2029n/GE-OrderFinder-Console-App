﻿using System;
using Autofac;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.PartnerOrder.DB.Repository;

namespace Cdw.Infrastructure.PartnerOrder.DB
{
    public class PartnerOrderDbModule : Module
    {
        private readonly Func<IDbClient> _dbClient;

        public PartnerOrderDbModule(Func<IDbClient> dbClient)
        {
            _dbClient = dbClient;
        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);
            builder.Register(c => new PartnerOrderRepository(_dbClient))
                .AsImplementedInterfaces()
                .SingleInstance();
          
        }
    }
}