﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    //internal class BundleProductEntity : IBundleProductEntity
    //{
    //    public BundleProductEntity(BundleChildProductEntity entity)
    //    {
    //        this.Product = entity.Product;
    //        this.Quantity = entity.ProductChildQuantity;
    //    }

    //    public IProductEntity Product { get; private set; }

    //    public int Quantity { get; private set; }
    //}
}
