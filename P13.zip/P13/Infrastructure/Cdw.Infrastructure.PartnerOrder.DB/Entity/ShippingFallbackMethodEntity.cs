﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
//{
    

//    public class ShippingFallbackMethodEntity  
//    {
//        public string RequestedShippingMethod { get; set; }

//        public string FallbackShippingMethod { get; set; }

//        public int Priority { get; set; }
//    }
//}
