﻿using System.Collections.Generic;
using System.Linq;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    internal class RetrievedProduct : ProductEntity
    {
        public RetrievedProduct(ProductEntity entity)
        {
            this.ProductID = entity.ProductID;
            this.ProductCode = GetSafeString(entity.ProductCode);
            this.ProductKey = GetSafeString(entity.ProductKey);
            this.Name = GetSafeString(entity.Name);
            this.FriendlyName = GetSafeString(entity.FriendlyName);
            this.Description = GetSafeString(entity.Description);
            this.FriendlyDescription = GetSafeString(entity.FriendlyDescription);
            this.CompanyPartNumber = GetSafeString(entity.CompanyPartNumber);
            this.ParentManufactureID = entity.ParentManufactureID;
            this.ManufactureID = entity.ManufactureID;
            this.ManufactureKey = GetSafeString(entity.ManufactureKey);
            this.ManufactureCode = GetSafeString(entity.ManufactureCode);
            this.ManufactureName = GetSafeString(entity.ManufactureName);
            this.ManufacturePartNumber = GetSafeString(entity.ManufacturePartNumber);
            this.Weight = entity.Weight;
            this.Height = entity.Height;
            this.Width = entity.Width;
            this.Length = entity.Length;
            this.NonReturnable = entity.NonReturnable;
            this.DropShipOnly = entity.DropShipOnly;
            this.DateSellStart = entity.DateSellStart;
            this.DateSellStop = entity.DateSellStop;
            this.DateCreated = entity.DateCreated;
            this.DateModified = entity.DateModified;
            this.ImageEDC = GetSafeString(entity.ImageEDC);
            this.SpinSetName = GetSafeString(entity.SpinSetName);
            this.StockSource = GetSafeString(entity.StockSource);
            this.ProductClass = GetSafeString(entity.ProductClass);
            this.ProductGroup = GetSafeString(entity.ProductGroup);
            this.IsBundle = entity.IsBundle;
            this.ProductType = GetSafeString(entity.ProductType);
            this.CustomerSpecificEDC = entity.CustomerSpecificEDC;
            this.BundledProducts = Enumerable.Empty<BundleProductEntity>();
        }

        public RetrievedProduct(
            ProductEntity entity,
            IEnumerable<BundleChildProductEntity> bundleChildren)
            : this(entity)
        {
            this.BundledProducts = bundleChildren.Select(c => new BundleProductEntity(c));
        }

        private static string GetSafeString(string val)
        {
            return string.IsNullOrEmpty(val) ? string.Empty : val.Trim();
        }
    }
}