﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    //public class IdentityEntity : IIdentityEntity
    //{
    //    public int ClientId { get; set; }
    //    public string ClientName { get; set; }
    //}
}
