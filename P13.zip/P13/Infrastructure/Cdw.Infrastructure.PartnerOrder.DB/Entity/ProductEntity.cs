﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    //public class ProductEntity : IProductEntity
    //{
    //    public string ProductKey { get; set; }
    //    public int ProductID { get; set; }
    //    public string ProductCode { get; set; }
    //    public string Name { get; set; }
    //    public string FriendlyName { get; set; }
    //    public string Description { get; set; }
    //    public string FriendlyDescription { get; set; }
    //    public string CompanyPartNumber { get; set; }
    //    public int ParentManufactureID { get; set; }
    //    public string ManufactureID { get; set; }
    //    public string ManufactureKey { get; set; }
    //    public string ManufactureCode { get; set; }
    //    public string ManufactureName { get; set; }
    //    public string ManufacturePartNumber { get; set; }
    //    public decimal Weight { get; set; }
    //    public decimal Height { get; set; }
    //    public decimal Width { get; set; }
    //    public decimal Length { get; set; }
    //    public bool NonReturnable { get; set; }
    //    public bool DropShipOnly { get; set; }
    //    public DateTime DateSellStart { get; set; }
    //    public DateTime DateSellStop { get; set; }
    //    public DateTime DateCreated { get; set; }
    //    public DateTime DateModified { get; set; }
    //    public string ImageEDC { get; set; }
    //    public string SpinSetName { get; set; }
    //    public string StockSource { get; set; }
    //    public string ProductClass { get; set; }
    //    public string ProductGroup { get; set; }
    //    public bool IsBundle { get; set; }
    //    public string ProductType { get; set; }
    //    public bool CustomerSpecificEDC { get; set; }
    //    public IEnumerable<IBundleProductEntity> BundledProducts { get; set; }
    //}
}
