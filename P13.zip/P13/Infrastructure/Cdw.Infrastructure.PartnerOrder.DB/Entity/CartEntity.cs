﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    //public class CartEntity : ICartEntity
    //{
    //    public int Id { get; set; }
    //    public CdwCompany Company { get; set; }
    //    public decimal Subtotal { get; set; }
    //    public decimal DiscountValue { get; set; }
    //    public decimal DiscountedSubtotal { get; set; }
    //    public ICartDiscountsEntity Discounts { get; set; }
    //    public IList<ICartItemEntity> Items { get; set; }
    //    public IList<ICustomPropertyEntity> CustomProperties { get; set; }
    //}
}
