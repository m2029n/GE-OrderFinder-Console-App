﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cdw.Infrastructure.PartnerOrder.DB.Entity
{
    //public class BundleChildProductEntity
    //{
    //    public int ProductID { get; set; }

    //    public int ProductChildQuantity { get; set; }

    //    public IProductEntity Product { get; set; }
    //}
}
