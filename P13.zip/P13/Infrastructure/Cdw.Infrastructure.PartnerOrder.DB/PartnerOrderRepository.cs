﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Cdw.Core.Data.DbClient;
using Cdw.Core.Data.Repositories;
using Cdw.Infrastructure.PartnerOrder.DB.Entity;

namespace Cdw.Infrastructure.PartnerOrder.DB.Repository
{
    public class PartnerOrderRepository : RepositoryBase, IPartnerOrderRepository
    {
        private const string GetClientInfoById = "[WebDB].[dbo].[Security_OAuth2_GetClientInfoById]";
        private const string GetClientByNameSProcName = "[WebDB].[dbo].[Security_OAuth2_GetClientByName]";
        private const string GetClientByIdSProcName = "[WebDB].[dbo].[Security_OAuth2_GetClientById]";
        private const string GetOrderSourceForOAuthClient = "[WebDB].[dbo].[API_Orders_GetOrderSourceByOAuth2ClientID]";
        private const string GetFreightRaterSpecialCodeForOrderSourceSProcName = "[WebDB].[dbo].[API_Orders_GetFreightRaterSpecialCodeForOrderSource]";
        private const string GetShippingMethodFallbacksSProcName = "[WebDB].[dbo].[API_Orders_GetFallbackShippingMethodForOAuth2ClientID]";
        private const string AddCreditCardTokenSProcName = "[WebDB].[dbo].[API_PaymentMethods_AddCreditCardToken]";
        private const string GetOrderBySourceAndReferenceNumberSProcName = "[WebDB].[dbo].[API_Orders_GetOrderBySourceAndReferenceNumber]";
        private const string GetBulkProductsSprocName = "[WebDB].[dbo].[API_CDW_Ecomm_Product_GetProducts]";
        private const string InsertCartSProcName = "[WebDB].[dbo].[API_Carts_InsertCart]";
        private const string InsertCartDiscountSProcName = "[WebDB].[dbo].[API_Carts_InsertCartDiscount]";
        private const string InsertCartItemSProcName = "[WebDB].[dbo].[API_Carts_InsertCartItem2]";
        private const string InsertCartItemDiscountSProcName = "[WebDB].[dbo].[API_Carts_InsertCartItemDiscount]";
        private const string InsertCartItemCustomPropertySProcName = "[WebDB].[dbo].[API_Carts_InsertCartItemCustomProperty]";
        private const string InsertCartCustomPropertySProcName = "[WebDB].[dbo].[API_Carts_InsertCartCustomProperty]";
        private const string GetNextOrderCodeSProcName = "[WebDB].[dbo].[API_Orders_GetNextOrderCode]";
        private const string CheckOrderUploadStatusSProcName = "[WebDB].[dbo].[API_Orders_GetAS400UploadStatus]";
        private const string InsertOrderSProcName = "[WebDB].[dbo].[API_Orders_InsertOrder]";
        private const string InsertOrderTaxSProcName = "[WebDB].[dbo].[API_Orders_InsertOrderTax]";
        private const string GetOrderSProcName = "[WebDB].[dbo].[API_Orders_GetOrder]";
        private const string GetOrderSProcNameNew = "[WebDB].[dbo].[API_Orders_GetOrder_new]";
        private const string GetCreditCardTokenByIdSProcName = "[WebDB].[dbo].[API_PaymentMethods_GetCreditCardTokenById]";
        private const string GetCreditCardDetailsByToken = "[WebDB].[dbo].[API_Partner_GetCreditCardDetails]";
        private const string GetCartSProcName = "[WebDB].[dbo].[API_Carts_GetCart]";
        private const string GetCartDiscountsSProcName = "[WebDB].[dbo].[API_Carts_GetCartDiscounts]";
        private const string GetCartCustomPropertiesSProcName = "[WebDB].[dbo].[API_Carts_GetCartCustomProperties]";
        private const string GetCartItemsSProcName = "[WebDB].[dbo].[API_Carts_GetCartItems]";
        private const string GetCartItemCustomPropertiesSProcName = "[WebDB].[dbo].[API_Carts_GetCartItemCustomProperties]";
        private const string GetCartItemDiscountsSProcName = "[WebDB].[dbo].[API_Carts_GetCartItemDiscounts]";
        private const string GetOrderItemShippingChargesSProcName = "[WebDB].[dbo].[API_Orders_GetOrderItemShippingCharges]";
        private const string GetOrderTaxesSProcName = "[WebDB].[dbo].[API_Orders_GetOrderTaxes]";
        private const string GetBundleChildrenSProcName = "[WebDB].[dbo].[API_Product_GetProductBundles]";
        private const string GetBulkProductsByIdSprocName = "[WebDB].[dbo].[API_CDW_Ecomm_Product_GetProducts_By_ProductId]";
        private const string InsertOrderItemShippingChargesSProcName = "[WebDB].[dbo].[API_Orders_InsertOrderItemShippingCharges]";
        private const string InsertOrderRecyleSProcName = "[WebDB].[dbo].[API_Orders_InsertOrderRecycle]";
        private const string GetShippingMethodPropertiesSProcName = "[WebDb].[dbo].[API_Partners_ShippingMethodProperties]";
        private const string GetAllowedPaymentMethodsSprocName = "[WebDb].[dbo].[API_Partners_GetAllowedPaymentMethods]";
        private const string GetAuthCreditCardTokenSprocName = "[WebDb].[dbo].[API_Orders_GetAuthCreditCardToken]";

        public PartnerOrderRepository(Func<IDbClient> dbClientFactory)
            : base(dbClientFactory)
        {
        }

        public Task<List<ShippingMethodPropertiesEntity>> GetShippingMethodPropertiesAsync(string clientName)
        {
            return Task.Run(() =>
            {
                var entity = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetShippingMethodPropertiesSProcName)
                        .AddNamedParameters(new { clientName = clientName })
                        .ExecuteFetch<ShippingMethodPropertiesEntity>()).ToList();
                return entity;
            });
        }

        public Task<ShippingMethodPropertiesEntity> GetShippingMethodProperty(string clientName,
            string shippingMethod)
        {
            return Task.Run(() =>
            {
                var entity = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetShippingMethodPropertiesSProcName)
                        .AddNamedParameters(new { clientName = clientName, shippingMethod = shippingMethod })
                        .ExecuteFetch<ShippingMethodPropertiesEntity>()).FirstOrDefault();
                return entity;
            });
        }

        public OrderEntity GetOrderEntity(string orderCode, string sourceCode)
        {
            var entity = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetOrderSProcNameNew)
                    .AddNamedParameters(new { OrderCode = orderCode, SourceCode = sourceCode })
                    .ExecuteFetch<OrderEntity>())
                .FirstOrDefault();

            if (entity == null)
            {
                return null;
            }

            entity.Taxes = GetTaxes(entity.OrderID);
            entity.OrderItems = GetOrderItemShippingRates(entity.OrderID);

            return entity;
        }

        public CreditCardEntity GetCreditCardById(int creditCardTokenId)
        {
            return ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCreditCardTokenByIdSProcName)
                    .AddNamedParameters(new { CreditCardTokenId = creditCardTokenId })
                    .ExecuteFetch<CreditCardEntity>()).FirstOrDefault();
        }

        public CreditCardEntity GetCreditCardByToken(string creditCardToken)
        {
            return ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCreditCardDetailsByToken)
                    .AddNamedParameters(new { Creditardtoken = creditCardToken })
                    .ExecuteFetch<CreditCardEntity>()).FirstOrDefault();
        }

        public CartEntity GetCartEntity(int cartId)
        {
            var carts = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCartSProcName)
                    .AddNamedParameters(new { CartId = cartId })
                    .ExecuteFetch<CartEntity>());

            var cartEntity = carts.FirstOrDefault();

            if (cartEntity == null)
            {
                return new CartEntity()
                {
                    CartID = cartId,
                    Discounts = new CartDiscountsEntity()
                    {
                        FixedAmountDiscounts = new List<DiscountEntity>(),
                        PercentOffDiscounts = new List<DiscountEntity>()
                    },
                    CustomProperties = new List<CustomPropertyEntity>(),
                    CartItems = new List<CartItemEntity>()
                };
            }
            cartEntity.Discounts = GetCartDiscounts(cartEntity.CartID);
            cartEntity.CustomProperties = GetCartCustomPropertiesList(cartEntity.CartID);
            cartEntity.CartItems = GetCartItemsList(cartEntity.CartID);

            return cartEntity;
        }

        private CartDiscountsEntity GetCartDiscounts(int cartId)
        {
            var discountEntities = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCartDiscountsSProcName)
                    .AddNamedParameters(new { CartId = cartId })
                    .ExecuteFetch<DiscountEntity>());

            var discounts = new CartDiscountsEntity()
            {
                FixedAmountDiscounts = new List<DiscountEntity>(),
                PercentOffDiscounts = new List<DiscountEntity>()
            };

            discounts.FixedAmountDiscounts =
                discountEntities
                    .Where(d => d.Type == 1000)
                    .Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();

            discounts.PercentOffDiscounts =
                discountEntities
                    .Where(d => d.Type == 1001)
                    .Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();

            return discounts;
        }

        private IList<CustomPropertyEntity> GetCartCustomPropertiesList(int cartId)
        {
            return this.ExecuteDbAction(dbClient =>
               dbClient
                   .SetProcedureName(GetCartCustomPropertiesSProcName)
                   .AddNamedParameters(new { CartId = cartId })
                   .ExecuteFetch<CustomPropertyEntity>())
                .Select(cp => new CustomPropertyEntity() { Name = cp.Name, Value = cp.Value })
                .ToList();
        }

        private IList<CartItemEntity> GetCartItemsList(int cartId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCartItemsSProcName)
                    .AddNamedParameters(new { CartId = cartId })
                    .ExecuteFetch<CartItemEntity>())
                .Select(entity =>

                    new CartItemEntity()
                    {
                        CartItemID = entity.CartItemID,
                        Status = GetCartItemStatus(entity.Status.ToString()),
                        ProductId = entity.ProductId,
                        UnitPrice = entity.UnitPrice,
                        Quantity = entity.Quantity,
                        Discounts = GetCartItemDiscounts(entity.CartItemID),
                        CustomProperties = GetCartItemCustomProperties(entity.CartItemID)
                    }
                ).ToList();
        }

        private IList<CustomPropertyEntity> GetCartItemCustomProperties(int cartItemId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCartItemCustomPropertiesSProcName)
                    .AddNamedParameters(new { CartItemID = cartItemId })
                    .ExecuteFetch<CustomPropertyEntity>())
                .Select(e => new CustomPropertyEntity() { Name = e.Name, Value = e.Value })
                .Cast<CustomPropertyEntity>()
                .ToList();
        }

        private CartItemDiscountsEntity GetCartItemDiscounts(int cartItemId)
        {
            var discountEntities = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetCartItemDiscountsSProcName)
                    .AddNamedParameters(new { CartItemID = cartItemId })
                    .ExecuteFetch<DiscountEntity>());

            var discounts = new CartItemDiscountsEntity()
            {
                FixedLinePriceDiscounts = new List<DiscountEntity>(),
                FixedUnitPriceDiscounts = new List<DiscountEntity>(),
                PercentOffLinePriceDiscounts = new List<DiscountEntity>(),
                PercentOffUnitPriceDiscounts = new List<DiscountEntity>()
            };

            discounts.FixedUnitPriceDiscounts = discountEntities
                .Where(e => e.Type == 1002).Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();
            discounts.PercentOffUnitPriceDiscounts = discountEntities
                .Where(e => e.Type == 1003).Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();
            discounts.FixedLinePriceDiscounts = discountEntities
                .Where(e => e.Type == 1004).Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();
            discounts.PercentOffLinePriceDiscounts = discountEntities
                .Where(e => e.Type == 1005).Select(d => new DiscountEntity() { Id = d.Id, Amount = d.Amount }).ToList();

            return discounts;
        }

        private CartItemStatus GetCartItemStatus(string cartItemStatus)
        {
            if (cartItemStatus == null)
            {
                return CartItemStatus.Pending;
            }
            CartItemStatus retrievedStatus;
            var cartItemStatuses =
                new Dictionary<string, CartItemStatus>
                    {
                        {"BackOrdered", CartItemStatus.Backordered},
                        {"Backordered", CartItemStatus.Backordered},
                        {"C", CartItemStatus.Shipped},
                        {"X", CartItemStatus.Canceled},
                        {"Complete", CartItemStatus.Shipped},
                        {"Canceled", CartItemStatus.Canceled},
                        {"Not Shipped", CartItemStatus.Pending},
                        {"WaitingForPickup", CartItemStatus.Pending},
                        {"ShippedFromWillCall",CartItemStatus.Shipped},
                        {"Shipped",CartItemStatus.Shipped},
                        {"Partial",CartItemStatus.Partial}
                    };

            var status = cartItemStatuses.TryGetValue(cartItemStatus, out retrievedStatus)
                            ? retrievedStatus
                            : CartItemStatus.Pending;

            return status;
        }

        private IList<OrderItemShippingRateEntity> GetOrderItemShippingRates(int orderId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetOrderItemShippingChargesSProcName)
                    .AddNamedParameters(new { OrderID = orderId })
                    .ExecuteFetch<OrderItemShippingRateEntity>());
        }

        private IList<TaxEntity> GetTaxes(int orderId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetOrderTaxesSProcName)
                    .AddNamedParameters(new { OrderID = orderId })
                    .ExecuteFetch<TaxEntity>())
                .ToArray();
        }

        public bool? IsUploadedToAs400(string orderCode)
        {
            var parameters = new List<SqlParameter>()
            {
                new SqlParameter("OrderCode", orderCode)
                {
                    Direction = ParameterDirection.Input,
                    SqlDbType = SqlDbType.VarChar,
                    Size = 7
                },
                new SqlParameter("uploadstatus", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                },
                new SqlParameter()
            {
                Direction = ParameterDirection.ReturnValue
            }
            };

            var result = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(CheckOrderUploadStatusSProcName)
                    .AddDbParameters(parameters)
                    .ExecuteNonQuery());

            return (int)parameters[1].Value > 0;
        }

        private string GetNextOrderCode()
        {
            var outputParameters = new List<SqlParameter>()
            {
                new SqlParameter("NewOrderCode", SqlDbType.VarChar, 7)
                {
                    Direction = ParameterDirection.Output
                }
            };

            ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetNextOrderCodeSProcName)
                    .AddDbParameters(outputParameters)
                    .ExecuteNonQuery());

            return outputParameters[0].Value.ToString();
        }

        public OrderEntity Create(OrderEntity newOrder)
        {
            var orderCode = this.GetNextOrderCode();

            newOrder.OrderCode = orderCode;
            var persistedOrder = this.ExecuteDbAction(dbClient =>
                dbClient.SetProcedureName(InsertOrderSProcName)
                    .AddNamedParameters(newOrder, CrudMethod.Insert)
                    .ExecuteFetch<OrderEntity>())
                .FirstOrDefault();

            InsertOrderTaxes(
                persistedOrder.OrderID,
                newOrder.Taxes);

            InsertOrderRecycleFees(persistedOrder.OrderID,
                newOrder.RecycleFees);

            InsertOrderItemShippingRates(
                persistedOrder.OrderID, newOrder.OrderItems);

            return newOrder;
        }

        private OrderItemShippingRateEntity[] InsertOrderItemShippingRates(int orderId, IEnumerable<OrderItemShippingRateEntity> orderItemShippingRates)
        {
            return orderItemShippingRates
                .Select(r => this.InsertOrderItemShippingRates(orderId, r))
                .ToArray();
        }

        private OrderItemShippingRateEntity InsertOrderItemShippingRates(
           int orderId,
           OrderItemShippingRateEntity orderItemShippingRate)
        {
            orderItemShippingRate.OrderID = orderId;

            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(InsertOrderItemShippingChargesSProcName)
                    .AddNamedParameters(orderItemShippingRate, CrudMethod.Insert)
                    .ExecuteFetch<OrderItemShippingRateEntity>()
                    .FirstOrDefault());
        }

        private RecycleFeeEntity[] InsertOrderRecycleFees(int orderId, IEnumerable<RecycleFeeEntity> recycle)
        {
            return recycle == null ? null : recycle.Select(t => InsertOrderRecycleFee(orderId, t)).ToArray();
        }

        private RecycleFeeEntity InsertOrderRecycleFee(int orderId, RecycleFeeEntity recycle)
        {
            recycle.OrderId = orderId;
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(InsertOrderRecyleSProcName)
                    .AddNamedParameters(recycle, CrudMethod.Insert)
                    .ExecuteFetch<RecycleFeeEntity>())
                .FirstOrDefault();
        }

        private TaxEntity[] InsertOrderTaxes(int orderId, IEnumerable<TaxEntity> taxes)
        {
            return taxes.Select(t => this.InsertOrderTax(orderId, t)).ToArray();
        }

        private TaxEntity InsertOrderTax(int orderId, TaxEntity tax)
        {
            tax.OrderID = orderId;
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(InsertOrderTaxSProcName)
                    .AddNamedParameters(tax, CrudMethod.Insert)
                    .ExecuteFetch<TaxEntity>())
                .FirstOrDefault();
        }

        public bool UniqueReferenceNumber(string source, string referenceNumber)
        {
            var orderEntity = this.ExecuteDbAction(dbClient =>
               dbClient
                   .SetProcedureName(GetOrderBySourceAndReferenceNumberSProcName)
                   .AddNamedParameters(new { Source = source, ReferenceNumber = referenceNumber })
                   .ExecuteFetch<OrderEntity>()).FirstOrDefault();

            return (orderEntity == null);
        }

        public bool IsTermsAllowed(string source, string terms)
        {
            bool allowed = false;
            var allowedTerms = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetAllowedPaymentMethodsSprocName)
                        .AddNamedParameters(new { Source = source, PaymentMethod = terms })
                        .ExecuteFetch<TermsEntity>());

            allowed = allowedTerms.Any(c => c.Source == source && c.PaymentMethod == terms);
            return allowed;
        }

        public TermsEntity GetPaymentMethodDetails(string source, string method)
        {
            return this.ExecuteDbAction(dbClient =>
                       dbClient
                           .SetProcedureName(GetAllowedPaymentMethodsSprocName)
                           .AddNamedParameters(new { Source = source, PaymentMethod = method })
                           .ExecuteFetch<TermsEntity>().FirstOrDefault());
        }

        public string GetAuthCreditCardToken(string transactionId, string referenceNumber)
        {
            return this.ExecuteDbAction(dbClient =>
                       dbClient
                           .SetProcedureName(GetAuthCreditCardTokenSprocName)
                           .AddNamedParameters(new { TransactionId = transactionId, ReferenceNumber = referenceNumber })
                           .ExecuteFetch<string>().FirstOrDefault());
        }

        public IEnumerable<ProductEntity> GetProduct(IEnumerable<string> productCodes)
        {
            var clients = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetBulkProductsSprocName)
                    .AddNamedParameters(new { ProductCodes = string.Join(",", productCodes) })
                    .ExecuteFetch<ProductEntity>());

            var standardProducts = from b in clients
                                   where !b.IsBundle
                                   select new RetrievedProduct(b);

            var bundleProducts = from b in clients
                                 where b.IsBundle
                                 select new RetrievedProduct(b, GetBundleChildren(b.ProductID));
            return standardProducts.Union(bundleProducts).ToList();
        }

        public CartEntity InsertApiCarts(CartEntity newCart)
        {
            var cartEntity = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(InsertCartSProcName)
                    .AddNamedParameters(new { Company = (int)newCart.Company })
                    .ExecuteFetch<CartEntity>());

            newCart.CartID = cartEntity.First().CartID;

            InsertAPICartDiscounts(newCart.Discounts, newCart.CartID);

            InsertApiCustomProperties(newCart.CustomProperties, newCart.CartID);

            InsertAPICartItems(newCart, newCart.CartItems);

            return newCart;
        }

        private CartDiscountsEntity InsertAPICartDiscounts(CartDiscountsEntity cartDiscountsEntity, int cartId)
        {
            foreach (var discount in cartDiscountsEntity.FixedAmountDiscounts.Union(cartDiscountsEntity.PercentOffDiscounts))
            {
                var discount1 = discount;

                var persistedDiscounts = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertCartDiscountSProcName)
                        .AddNamedParameters(
                            new { CartID = cartId, Type = discount1.Type, Id = discount1.Id, Amount = discount1.Amount })
                        .ExecuteFetch<DiscountEntity>());

                discount.DiscountId = persistedDiscounts.First().DiscountId;
            }
            return cartDiscountsEntity;
        }

        private IEnumerable<CartItemEntity> InsertAPICartItems(CartEntity cart, IEnumerable<CartItemEntity> cartItemEntities)
        {
            foreach (var cartItemEntity in cartItemEntities)
            {
                var cartitems = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertCartItemSProcName)
                        .AddNamedParameters(new
                        {
                            CartID = cart.CartID,
                            ProductID = cartItemEntity.ProductId,
                            Quantity = cartItemEntity.Quantity,
                            UnitPrice = cartItemEntity.UnitPrice,
                            DiscountedUnitPrice = CalculateFullyDiscountedUnitPrice(cart, cartItemEntity)
                        })
                        .ExecuteFetch<CartItemEntity>());

                cartItemEntity.CartItemID = cartitems.First().CartItemID;

                InsertCartItemDiscounts(cartitems.First().CartItemID, cartItemEntity.Discounts);

                InsertCartItemCustomProperties(cartitems.First().CartItemID, cartItemEntity.CustomProperties);
            }

            return cartItemEntities;
        }

        private void InsertCartItemDiscounts(int cartItemId, CartItemDiscountsEntity cartItemDiscountsEntity)
        {
            var cartitemDiscounts =
                cartItemDiscountsEntity.FixedUnitPriceDiscounts.Union(cartItemDiscountsEntity.FixedLinePriceDiscounts)
                    .Union(cartItemDiscountsEntity.PercentOffLinePriceDiscounts)
                    .Union(cartItemDiscountsEntity.PercentOffUnitPriceDiscounts);

            foreach (var discount in cartitemDiscounts)
            {
                var innerPersistedDiscounts = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertCartItemDiscountSProcName)
                        .AddNamedParameters(new
                        {
                            CartItemID = cartItemId,
                            Type = discount.Type,
                            Id = discount.Id,
                            Amount = discount.Amount
                        })
                        .ExecuteFetch<DiscountEntity>());

                discount.DiscountId = innerPersistedDiscounts.First().DiscountId;
            }
        }

        private void InsertCartItemCustomProperties(int cartItemId, IList<CustomPropertyEntity> cartCustomPropertyEntities)
        {
            foreach (var cp in cartCustomPropertyEntities)
            {
                var customEntity = this.ExecuteDbAction(dbClient =>
                      dbClient
                          .SetProcedureName(InsertCartItemCustomPropertySProcName)
                          .AddNamedParameters(new
                          {
                              CartItemID = cartItemId,
                              Name = cp.Name,
                              value = cp.Value
                          })
                          .ExecuteFetch<CustomPropertyEntity>());

                cp.CustomPropertyID = customEntity.First().CustomPropertyID;
            }
        }

        private IEnumerable<CustomPropertyEntity> InsertApiCustomProperties(IEnumerable<CustomPropertyEntity> customPropertyEntities, int cartId)
        {
            foreach (var customPropertyEntity in customPropertyEntities)
            {
                var entity = customPropertyEntity;
                var cp = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertCartCustomPropertySProcName)
                        .AddNamedParameters(
                            new { CartID = cartId, Name = entity.Name, Value = entity.Value })
                        .ExecuteFetch<CustomPropertyEntity>());

                customPropertyEntity.CustomPropertyID = cp.First().CustomPropertyID;
            }

            return customPropertyEntities;
        }

        private IEnumerable<BundleChildProductEntity> GetBundleChildren(int bundleProductId)
        {
            var bundleChildEntities = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetBundleChildrenSProcName)
                    .AddNamedParameters(new { ProductID = bundleProductId })
                    .ExecuteFetch<BundleChildProductEntity>());

            var productsById = GetProduct(bundleChildEntities.Select(bce => bce.ProductID).Distinct())
                .ToDictionary(p => p.ProductID);

            foreach (var bundleChildEntity in bundleChildEntities)
            {
                bundleChildEntity.Product = productsById[bundleChildEntity.ProductID];
            }

            return bundleChildEntities;
        }

        public IEnumerable<ProductEntity> GetProduct(IEnumerable<int> productIds)
        {
            return
                this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(GetBulkProductsByIdSprocName)
                        .AddNamedParameters(
                            new { ProductIds = string.Join(",", productIds.Select(pid => pid.ToString()).ToArray()) })
                        .ExecuteFetch<ProductEntity>());
        }

        public IdentityEntity GetIdentityDetails(int clientId)
        {
            var client = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetClientInfoById)
                    .AddNamedParameters(new { ClientId = clientId })
                    .ExecuteFetch<IdentityEntity>()).FirstOrDefault();

            if (client == null)
            {
                throw new Exception($"PartnerId {clientId} is Not found:");
            }
            return client;
        }

        [System.Obsolete("GetIdentityDetails is deprecated, please use {IdentityEntity GetIdentityDetails(int clientId)} instead.")]
        public IdentityEntity GetIdentityDetails(string clientName)
        {
            var clients = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetClientByNameSProcName)
                    .AddNamedParameters(new { ClientName = clientName })
                    .ExecuteFetch<IdentityEntity>());

            var client = GetClientFromReturnSet(clients);

            if (client != null)
            {
                client.SourceCode = GetOrderSource(client.ClientId);
                client.FreightRaterSpecialCode = GetFreightRaterSpecialCode(client.ClientId);
            }
            return client ?? null;
        }

        private IdentityEntity GetClientFromReturnSet(IEnumerable<IdentityEntity> clients)
        {
            var identityEntities = clients as IList<IdentityEntity> ?? clients.ToList();

            return !identityEntities.Any() || identityEntities.Count() > 1
                ? null
                : identityEntities.First();
        }

        private string GetOrderSource(int clientId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetOrderSourceForOAuthClient)
                    .AddNamedParameters(new { OAuth2ClientID = clientId })
                    .ExecuteFetch<string>())
                .FirstOrDefault();
        }

        private string GetFreightRaterSpecialCode(int clientId)
        {
            return this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetFreightRaterSpecialCodeForOrderSourceSProcName)
                    .AddNamedParameters(new { OAuth2ClientID = clientId })
                    .ExecuteFetch<string>())
                .Select(c => c.Trim())
                .FirstOrDefault();
        }

        // This probably doesn't belong down here in persistance, except
        // that it is only used in persistance. But, the decision to spread
        // the order level discounts across cart items is a business decision
        // so it probably belongs in the domain objects.
        private decimal CalculateFullyDiscountedUnitPrice(CartEntity cart, CartItemEntity item)
        {
            if (item.DiscountedLinePrice == 0)
            {
                return 0;
            }

            var discountedUnitPrice = item.DiscountedLinePrice / item.Quantity;
            var proportionOfOrderDiscountForThisLine = item.DiscountedLinePrice / cart.Subtotal;
            var discountForThisLine = cart.DiscountValue * proportionOfOrderDiscountForThisLine;
            var additionalDiscountPerUnit = discountForThisLine / item.Quantity;
            var fullyDiscountedUnitPrice = discountedUnitPrice - additionalDiscountPerUnit;

            return Math.Round(fullyDiscountedUnitPrice, 2, MidpointRounding.AwayFromZero);
        }
    }
}