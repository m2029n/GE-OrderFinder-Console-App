﻿namespace Cdw.Infrastructure.PartnerCart
{
    public interface IPartnerCartRequestItemEntity
    {
        int VendorCartRequestItemId { get; set; }
        int VendorCartRequestId { get; set; }
        string Manufacturer { get; set; }
        string ManufacturerPartNumber { get; set; }
        int? MatchedProductID { get; set; }
        string MatchedProductCode { get; set; }
        int Quantity { get; set; }
    }
}