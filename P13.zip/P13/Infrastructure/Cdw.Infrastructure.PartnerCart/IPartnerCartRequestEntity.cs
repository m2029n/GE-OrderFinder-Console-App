﻿using System;
using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerCart
{
    public interface IPartnerCartRequestEntity
    {
        int VendorCartRequestId { get; set; }
        string Source { get; set; }
        string CorrelationId { get; set; }
        int WebSiteID { get; set; }
        DateTime DateCreated { get; set; }
        IEnumerable<IPartnerCartRequestItemEntity> LineItems { get; set; }
    }
}