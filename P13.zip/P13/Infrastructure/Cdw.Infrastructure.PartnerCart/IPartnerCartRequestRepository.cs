﻿namespace Cdw.Infrastructure.PartnerCart
{
    public interface IPartnerCartRequestRepository
    {
        IPartnerCartRequestEntity Create(IPartnerCartRequestEntity request);
    }
}