﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autofac;
using Autofac.Core;
using Autofac.Core.Registration;

namespace Cdw.Infrastructure.UnitTests
{
    public static class ModuleHelper
    {
        public static List<Type> GetTypesRegisteredInModule(this Module module)
        {
            var componentRegistry = new ComponentRegistry();

            module.Configure(componentRegistry);

            var typesRegistered =
                componentRegistry.Registrations.SelectMany(x => x.Services)
                    .Cast<TypedService>()
                    .Select(x => x.ServiceType);

            return typesRegistered.ToList();
        }
    }
}