﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Domain.Partners.Implementation.DataAccess.APILogging;
using Cdw.Infrastructure.PartnerOrder.DB;
using Cdw.Infrastructure.PartnerOrder.DB.Repository;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerOrder
{
    public class PartnerOrderDbModuleTests
    {
        [Fact(DisplayName = "PartnerOrderDbModule_Should_Be_Module")]
        public void Should_Be_Module()
        {
            //Arrange
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var module = new PartnerOrderDbModule(dbInstance);

            Assert.NotNull(module);
        }

        [Fact(DisplayName = "PartnerOrderDbModule_Should_Have_Register_Types")]
        public void Should_Have_Register_Types()
        {
            //Arrange
            var typesToCheck = new List<Type>
            {
                typeof (PartnerOrderRepository), 
            };
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var typesRegistered = new PartnerOrderDbModule(dbInstance).GetTypesRegisteredInModule();

            //Assert
            Assert.NotNull(typesRegistered);
            Assert.Equal(typesToCheck.Count, typesRegistered.Count());

            foreach (var typeToCheck in typesToCheck)
            {
                Assert.True(typesRegistered.Any(x => x.Name == "IPartnerOrderRepository"), typeToCheck.Name + " was not found in module");
            }
        }
    }
}