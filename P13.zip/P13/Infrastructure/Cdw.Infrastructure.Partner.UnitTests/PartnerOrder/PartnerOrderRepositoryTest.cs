﻿using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.PartnerOrder;
using Cdw.Infrastructure.PartnerOrder.DB.Repository;
using Moq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerOrder
{
    public class PartnerOrderRepositoryTest
    {
        private readonly PartnerOrderRepository _sut;
        private readonly Mock<IDbClient> _dbInstance;

        public PartnerOrderRepositoryTest()
        {
            _dbInstance = new Mock<IDbClient>();
            _dbInstance.Name = "Kate";

            _dbInstance.Setup(f => f.SetProcedureName(It.IsAny<string>())).Returns(_dbInstance.Object);
            _dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>(), CrudMethod.Insert)).Returns(_dbInstance.Object);
            _dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(_dbInstance.Object);
            _dbInstance.Setup(x => x.AddDbParameter(It.IsAny<SqlParameter>())).Callback<IDataParameter>(r =>
            {
                r.Value = 123;
            }).Returns(_dbInstance.Object);

            _dbInstance.Setup(f => f.ExecuteNonQuery()).Returns(123);
            Func<IDbClient> dbFunc = () => _dbInstance.Object;
            _sut = new PartnerOrderRepository(dbFunc);
        }

        [Fact(DisplayName = "PartnerOrderRepository_ShouldNotBeNull")]
        public void PartnerOrderRepositoryTest_ShouldNotBeNull()
        {
            Assert.NotNull(_sut);
        }

        [Fact(DisplayName = "GetShippingMethodProperties")]
        public void GetShippingMethodProperties()

        {
            _dbInstance.Setup(f => f.ExecuteFetch<ShippingMethodPropertiesEntity>()).Returns(new List<ShippingMethodPropertiesEntity>());
            var actual = _sut.GetShippingMethodPropertiesAsync("123");

            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetShippingMethodProperties_Should_Fail_when_no_name")]
        public void GetShippingMethodProperties_Should_Fail_when_no_name()
        {
            var actual = Assert.ThrowsAsync<ArgumentNullException>(async () => await _sut.GetShippingMethodPropertiesAsync(null).ConfigureAwait(false));
            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetShippingMethodProperty")]
        public void GetShippingMethodProperty()

        {
            _dbInstance.Setup(f => f.ExecuteFetch<ShippingMethodPropertiesEntity>()).Returns(new List<ShippingMethodPropertiesEntity>());
            var actual = _sut.GetShippingMethodProperty("123", "123");

            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetShippingMethodProperty_Should_Fail_when_no_name")]
        public void GetShippingMethodPropertiy_Should_Fail_when_no_name()
        {
            var actual = Assert.ThrowsAsync<ArgumentNullException>(async () => await _sut.GetShippingMethodProperty(null, null).ConfigureAwait(false));
            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetOrderEntity")]
        public void GetOrderEntity()
        {
            _dbInstance.Setup(f => f.ExecuteFetch<OrderEntity>()).Returns(new List<OrderEntity>());
            var actual = _sut.GetOrderEntity("123", "123");

            Assert.Null(actual);
        }

        [Fact(DisplayName = "GetOrderEntity_Should_Fail_when_no_name")]
        public void GetOrderEntity_Should_Fail_when_no_name()
        {
            var actual = Assert.Throws<ArgumentNullException>(() => _sut.GetOrderEntity(null, null));
            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetIdentityDetailsTest")]
        public void GetIdentityTest()
        {
            var list = new List<IdentityEntity>();
            list.Add(new IdentityEntity());
            _dbInstance.Setup(f => f.ExecuteFetch<IdentityEntity>()).Returns(list);

            var actual = _sut.GetIdentityDetails(123);
            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "GetIdentityDetailsTestNotFound")]
        public void GetIdentityExcTest()
        {
            var list = new List<IdentityEntity>();

            _dbInstance.Setup(f => f.ExecuteFetch<IdentityEntity>()).Returns(list);
            var actual = Assert.Throws<Exception>(() => _sut.GetIdentityDetails(123));
            Assert.NotNull(actual);
        }
    }
}