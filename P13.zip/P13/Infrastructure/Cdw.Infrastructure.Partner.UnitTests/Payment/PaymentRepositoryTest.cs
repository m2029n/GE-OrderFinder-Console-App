﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.PartnerCart;
using Cdw.Infrastructure.PartnerCart.DB;
using Cdw.Infrastructure.Payments.DB;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.Payment
{
    public class PaymentRepositoryTests
    {
        private readonly PaymentRepository _sut;

        public PaymentRepositoryTests()
        {
            var dbInstance = new Mock<IDbClient>();
            var temp = new List<TempProduct>();
            temp.Add(new TempProduct { ProductCode = "123", ProductID = 123 });
            var request = new PartnerCartRequestEntity();
            var lineItems = new List<IPartnerCartRequestItemEntity>();
            lineItems.Add(new PartnerCartRequestItemEntity());
            request.LineItems = lineItems;
            dbInstance.Name = "Kate";

            dbInstance.Setup(f => f.SetProcedureName(It.IsAny<string>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>(), CrudMethod.Insert)).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.ExecuteFetch<TempProduct>()).Returns(temp);
            dbInstance.Setup(x => x.AddDbParameters(It.IsAny<IEnumerable<IDataParameter>>())).Callback<IEnumerable<IDataParameter>>(r =>
            {
                r.ToList()[0].Value = 123;
            }).Returns(dbInstance.Object);

            dbInstance.Setup(f => f.ExecuteNonQuery()).Returns(123);
            Func<IDbClient> dbFunc = () => dbInstance.Object;
            _sut = new PaymentRepository(dbFunc);
        }

        [Fact(DisplayName = "PaymentRepository_Should_NotBeNull")]
        public void PaymentRepository_Should_NotBeNull()
        {
            Assert.NotNull(_sut);
        }

        [Fact(DisplayName = "PaymentRepository_Should_AddPaymentTokensMapping")]
        public void AddPaymentTokensMappingTest()

        {
            var actual = _sut.AddPaymentTokensMapping("123", "123", "123", "123");
            Assert.NotNull(actual);
            Assert.Equal(actual, "123");
        }

        [Fact(DisplayName = "PaymentRepository_Should_returnNull")]
        public void AddPaymentTokensMappingNullTest()

        {
            var actual = _sut.AddPaymentTokensMapping(null, "123", "123", "123");
            Assert.Null(actual);
        }
    }
}