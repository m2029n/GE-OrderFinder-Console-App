﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.Payments.DB;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.Payment
{
    public class PaymentDbModuleTests
    {
        [Fact(DisplayName = "PaymentDbModuleTests_ShouldNotBeNull")]
        public void PaymentDbModuleTestsNotNull()
        {
            //Arrange
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var module = new PaymentDBModule(dbInstance);

            Assert.NotNull(module);
        }

        [Fact(DisplayName = "PaymentDBModule_Should_Have_Register_Types")]
        public void Should_Have_Register_Types()
        {
            //Arrange
            var typesToCheck = new List<Type>
            {
                typeof (PaymentRepository),
            };
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var typesRegistered = new PaymentDBModule(dbInstance).GetTypesRegisteredInModule();

            //Assert
            Assert.NotNull(typesRegistered);
            Assert.Equal(typesToCheck.Count, typesRegistered.Count());

            foreach (var typeToCheck in typesToCheck)
            {
                Assert.True(typesRegistered.Any(x => x.Name == "IPaymentRepository"), typeToCheck.Name + " was not found in module");
            }
        }
    }
}