﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cdw.Core.Data.DbClient;
using Cdw.Domain.Partners.Implementation.APILogging;
using Cdw.Domain.Partners.Implementation.DataAccess.APILogging;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.DataAccess.APILogging
{
    public class LogRequestResponseRepositoryTests
    {
        [Fact]
        public async Task InsertRequestResponseLogAsync_should_pass()
        {
            //Arrange
            var model = new RequestResponseLog();
            var temp = new List<RequestResponseLog>();
            temp.Add(model);
            var dbInstance = new Mock<IDbClient>();
            dbInstance.Name = "Kate";
            dbInstance.Setup(f => f.SetProcedureName("[WebDB].[dbo].[Insert_API_Partners_RequestResponseLogs]")).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.ExecuteFetch<RequestResponseLog>()).Returns(temp);
            IDbClient DbFunc() => dbInstance.Object;
            var sut = new LogRequestResponseRepository(DbFunc);

            //Act
            var actual = await sut.InsertRequestResponseLogAsync(model).ConfigureAwait(false);

            //Assert
            Assert.Equal(model.PartnerName, actual.PartnerName);
        }
        [Fact]
        public async Task SearchLogsByClientNameAsyncTest()
        {
            //Arrange
            var clientName = "Black Box";
            var startDate = DateTime.Now.AddDays(-1);
            var endDate = DateTime.Now;
            var messageType = "GET";
            var resultCode = 200;
            var requestPath = "/orders";
            var temp = new List<RequestResponseLog>
            {
                new RequestResponseLog {Id = 1},
                new RequestResponseLog {Id = 2},
                new RequestResponseLog {Id = 3}
            };
            var dbInstance = new Mock<IDbClient>();
            dbInstance.Name = "Kate";
            dbInstance.Setup(f => f.SetProcedureName("[WebDB].[dbo].[Get_API_Partners_RequestResponseLogsByClientName]")).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.ExecuteFetch<RequestResponseLog>()).Returns(temp);
            IDbClient DbFunc() => dbInstance.Object;
            var sut = new LogRequestResponseRepository(DbFunc);

            //Act
            var actual = await sut.SearchLogsByClientNameAsync(clientName, startDate, endDate, messageType,requestPath, resultCode).ConfigureAwait(false);

            //Assert
            Assert.Equal(3, actual.Count);
        }

        [Fact]
        public async Task GetRequestResponseLogsByIdAndClientNameAsyncTest()
        {
            //Arrange
            var clientName = "Black Box";
            var id = 200;
            var temp = new List<RequestResponseLog>
            {
                new RequestResponseLog {Id = 1,PartnerName = "Black Box"},
                new RequestResponseLog {Id = 2},
                new RequestResponseLog {Id = 3}
            };
            var dbInstance = new Mock<IDbClient>();
            dbInstance.Name = "Kate";
            dbInstance.Setup(f => f.SetProcedureName("[WebDB].[dbo].[Get_API_Partners_RequestResponseLogsById]")).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.ExecuteFetch<RequestResponseLog>()).Returns(temp);
            IDbClient DbFunc() => dbInstance.Object;
            var sut = new LogRequestResponseRepository(DbFunc);

            //Act
            var actual = await sut.GetRequestResponseLogsByIdAndClientNameAsync(clientName, id).ConfigureAwait(false);

            //Assert
            Assert.Equal("Black Box", actual.PartnerName);
        }
    }
}