﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.Recycling.DB;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.Recycling
{
    public class RecyclingDbModuleTests
    {
        [Fact]
        public void TestMethod1()
        {
            //Arrange
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var module = new RecyclingDbModule(dbInstance);

            Assert.NotNull(module);
        }

        [Fact(DisplayName = "RecyclingDbModule_Should_Have_Register_Types")]
        public void Should_Have_Register_Types()
        {
            //Arrange
            var typesToCheck = new List<Type>
                {
                    typeof (RecyclingRepository),
                };
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var typesRegistered = new RecyclingDbModule(dbInstance).GetTypesRegisteredInModule();

            //Assert
            Assert.NotNull(typesRegistered);
            Assert.Equal(typesToCheck.Count, typesRegistered.Count());

            foreach (var typeToCheck in typesToCheck)
            {
                Assert.True(typesRegistered.Any(x => x.Name == "IRecyclingRepository"), typeToCheck.Name + " was not found in module");
            }
        }
    }
}