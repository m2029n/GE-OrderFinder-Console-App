﻿using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.Recycling;
using Cdw.Infrastructure.Recycling.DB;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.Recycling
{
    public class RecyclingRepositoryTests
    {
        private readonly RecyclingRepository _sut;

        public RecyclingRepositoryTests()
        {
            var dbInstance = new Mock<IDbClient>();
            var temp = new List<IRecyclingFeeEntity>();

            dbInstance.Name = "Kate";

            dbInstance.Setup(f => f.SetProcedureName(It.IsAny<string>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(dbInstance.Object);
            dbInstance.Setup(f => f.ExecuteFetch<IRecyclingFeeEntity>()).Returns(temp);

            Func<IDbClient> dbFunc = () => dbInstance.Object;
            _sut = new RecyclingRepository(dbFunc);
        }

        [Fact]
        public void RecyclingRepositoryTest()
        {
            Assert.NotNull(_sut);
        }

        [Fact]
        public async Task GetRecyclingFees()
        {
            var actual = await _sut.GetRecyclingFeesAsync("123", "123");
            //invalid use of internal class
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetRecyclingFeesAsync_ShouldReturnNullIfStateCodeIsNull()
        {
            var testCases = new[]
            {
                new { StateCode = "123", ProductCodes = (string)null },
                new { StateCode = "123", ProductCodes = "   " },
                new { StateCode = (string)null, ProductCodes = "123" },
                new { StateCode = "   ", ProductCodes = "123" },
            };

            foreach (var testCase in testCases)
            {
                var actual = await _sut.GetRecyclingFeesAsync(testCase.StateCode, testCase.ProductCodes);
                Assert.Null(actual);
            }
        }
    }
}