﻿using System;
using System.Collections.Generic;
using Cdw.Infrastructure.PartnerCart;
using Cdw.Infrastructure.PartnerCart.DB;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerCart
{
    public class PartnerCartRequestEntityTest
    {
        [Fact(DisplayName = "PartnerCartRequestEntity_Should_HoldValues")]
        public void PartnerCartRequestEntity_Should_Holdvalues()
        {
            var sut = new PartnerCartRequestEntity
            {
                CorrelationId = "CorrelationId",
                VendorCartRequestId = 123,
                WebSiteID = 123,
                DateCreated = DateTime.MaxValue,
                Source = "Source",
                LineItems = new List<IPartnerCartRequestItemEntity>()
            };

            Assert.Equal(sut.CorrelationId, "CorrelationId");
            Assert.Equal(sut.Source, "Source");
            Assert.Equal(sut.VendorCartRequestId, 123);
            Assert.Equal(sut.WebSiteID, 123);
            Assert.Equal(sut.DateCreated, DateTime.MaxValue);
            Assert.NotNull(sut.LineItems);
        }
    }
}