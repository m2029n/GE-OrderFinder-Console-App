﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.PartnerCart;
using Cdw.Infrastructure.PartnerCart.DB;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerCart
{
    public class PartnerCartRequestRepositoryTests
    {
        private readonly PartnerCartRequestEntity _request;
        private readonly PartnerCartRequestRepository _sut;
        private readonly Mock<IDbClient> _dbInstance;

        public PartnerCartRequestRepositoryTests()
        {
            _dbInstance = new Mock<IDbClient>();
            var temp = new List<TempProduct>();
            temp.Add(new TempProduct { ProductCode = "123", ProductID = 123 });
            _request = new PartnerCartRequestEntity();
            var lineItems = new List<IPartnerCartRequestItemEntity>();
            lineItems.Add(new PartnerCartRequestItemEntity());
            _request.LineItems = lineItems;
            _dbInstance.Name = "Kate";

            _dbInstance.Setup(f => f.SetProcedureName(It.IsAny<string>())).Returns(_dbInstance.Object);
            _dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>(), CrudMethod.Insert)).Returns(_dbInstance.Object);
            _dbInstance.Setup(f => f.AddNamedParameters(It.IsAny<object>())).Returns(_dbInstance.Object);
            _dbInstance.Setup(f => f.ExecuteFetch<TempProduct>()).Returns(temp);
            _dbInstance.Setup(x => x.AddDbParameter(It.IsAny<SqlParameter>())).Callback<IDataParameter>(r =>
            {
                r.Value = 123;
            }).Returns(_dbInstance.Object);

            _dbInstance.Setup(f => f.ExecuteNonQuery()).Returns(123);
            Func<IDbClient> dbFunc = () => _dbInstance.Object;
            _sut = new PartnerCartRequestRepository(dbFunc);
        }

        [Fact(DisplayName = "PartnerCartRequestRepository_ShouldNotBeNull")]
        public void PartnerCartRequestRepositoryTest()

        {
            Assert.NotNull(_sut);
        }

        [Fact(DisplayName = "PartnerCartRequestRepository_ShouldCreate")]
        public void CreateTest()
        {
            var actual = _sut.Create(_request);

            Assert.NotNull(actual);
            Assert.Equal(actual.VendorCartRequestId, 123);
        }

        [Fact(DisplayName = "PartnerCartRequestRepository_Should_Fail_when_no_line_items")]
        public void PartnerCartRequestRepository_Should_Fail_when_no_line_items()
        {
            _request.LineItems = null;

            var actual = Assert.Throws<NullReferenceException>(() => _sut.Create(_request));

            Assert.NotNull(actual);
        }

        [Fact(DisplayName = "PartnerCartRequestRepository_Should_Fail_when_no_Products")]
        public void PartnerCartRequestRepository_Should_Fail_when_no_Products()
        {
            _dbInstance.Setup(f => f.ExecuteFetch<TempProduct>()).Returns((List<TempProduct>)null);

            var actual = Assert.Throws<ArgumentNullException>(() => _sut.Create(_request));

            Assert.NotNull(actual);
        }
    }
}