﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Infrastructure.PartnerCart.DB;
using Moq;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerCart
{
    public class PartnerCartDbModuleTests
    {
        [Fact(DisplayName = "PartnerCartDbModule_Should_Be_Module")]
        public void Should_Be_Module()
        {
            //Arrange
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var module = new PartnerCartDbModule(dbInstance);

            Assert.NotNull(module);
        }

        [Fact(DisplayName = "PartnerCartDbModule_Should_Have_Register_Types")]
        public void Should_Have_Register_Types()
        {
            //Arrange
            var typesToCheck = new List<Type>
            {
                typeof (PartnerCartRequestRepository),
            };
            var mock = new Mock<IDbClient>();
            var dbInstance = new Func<IDbClient>(() => mock.Object);

            //Act
            var typesRegistered = new PartnerCartDbModule(dbInstance).GetTypesRegisteredInModule();

            //Assert
            Assert.NotNull(typesRegistered);
            Assert.Equal(typesToCheck.Count, typesRegistered.Count());

            foreach (var typeToCheck in typesToCheck)
            {
                Assert.True(typesRegistered.Any(x => x.Name == "IPartnerCartRequestRepository"), typeToCheck.Name + " was not found in module");
            }
        }
    }
}