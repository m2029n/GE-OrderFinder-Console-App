﻿using Cdw.Infrastructure.PartnerCart.DB;
using Xunit;

namespace Cdw.Infrastructure.UnitTests.PartnerCart
{
    public class PartnerCartRequestItemEntityTests
    {
        [Fact(DisplayName = "PartnerCartRequestItemEntityTests_Should_HoldValues")]
        public void PartnerCartRequestItemEntityTests_Should_Holdvalues()
        {
            var sut = new PartnerCartRequestItemEntity
            {
                Manufacturer = "Manufacturer",
                VendorCartRequestItemId = 123,
                VendorCartRequestId = 123,
                Quantity = 123,
                MatchedProductID = 123,
                MatchedProductCode = "MatchedProductCode",
                ManufacturerPartNumber = "ManufacturerPartNumber",
            };

            Assert.Equal(sut.Manufacturer, "Manufacturer");
            Assert.Equal(sut.MatchedProductCode, "MatchedProductCode");
            Assert.Equal(sut.ManufacturerPartNumber, "ManufacturerPartNumber");
            Assert.Equal(sut.VendorCartRequestItemId, 123);
            Assert.Equal(sut.VendorCartRequestId, 123);
            Assert.Equal(sut.Quantity, 123);
            Assert.Equal(sut.MatchedProductID, 123);
        }
    }
}