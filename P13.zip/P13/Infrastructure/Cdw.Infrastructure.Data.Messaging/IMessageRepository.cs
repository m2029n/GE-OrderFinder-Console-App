﻿namespace Cdw.Infrastructure.Data.Messaging
{
    public interface IMessagingRepository
    {
        MessageEntity Create(MessageEntity messageEntity);

        MessageEntity GetFirstUnprocessed();

        MessageEntity Update(MessageEntity messageEntity);
    }
}