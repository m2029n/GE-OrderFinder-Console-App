﻿using Cdw.Core.Data.DbClient.Attributes;

namespace Cdw.Infrastructure.Data.Messaging
{
    public class MessageEntity
    {
        [IgnoreOnInsert]
        public int MessageId { get; set; }

        [Ignore]
        public MessageHeaderEntity[] Headers { get; set; }

        public string Body { get; set; }
        public short State { get; set; }
    }
}