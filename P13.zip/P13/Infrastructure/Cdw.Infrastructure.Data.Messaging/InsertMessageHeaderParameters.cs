﻿namespace Cdw.Infrastructure.Data.Messaging
{
    internal class InsertMessageHeaderParameters
    {
        private readonly MessageHeaderEntity _headerEntity;

        public InsertMessageHeaderParameters(MessageHeaderEntity entity)
        {
            _headerEntity = entity;
        }

        public int MessageID { get { return this._headerEntity.MessageId; } }
        public string Key { get { return this._headerEntity.Key; } }
        public string Value { get { return this._headerEntity.Value; } }
    }
}