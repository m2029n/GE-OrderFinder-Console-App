﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Core.Data.Repositories;

namespace Cdw.Infrastructure.Data.Messaging
{
    public class MessagingRepository : RepositoryBase, IMessagingRepository
    {
        private const string InsertMessageSProcName = "[WebDB].[dbo].[MessageQueue_InsertMessage]";
        private const string InsertMessageHeaderSProcName = "[WebDB].[dbo].[MessageQueue_InsertMessageHeader]";
        private const string GetFirstUnprocessedMessageSProcName = "[WebDB].[dbo].[MessageQueue_GetFirstUnprocessedMessage]";
        private const string GetMessageHeadersSProcName = "[WebDB].[dbo].[MessageQueue_GetMessageHeaders]";
        private const string UpdateMessageSProcName = "[WebDB].[dbo].[MessageQueue_UpdateMessage]";

        public MessagingRepository(Func<IDbClient> dbClientFactory)
            : base(dbClientFactory)
        {
        }

        public MessageEntity Create(MessageEntity messageEntity)
        {
            var persistedMessage = CreateMessage(messageEntity);

            persistedMessage.Headers = CreateMessageHeaders(persistedMessage.MessageId, messageEntity.Headers);

            return persistedMessage;
        }

        private MessageEntity CreateMessage(MessageEntity messageEntity)
        {
            var persistedMessage = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(InsertMessageSProcName)
                    .AddNamedParameters(new InsertMessageParameters(messageEntity))
                    .ExecuteFetch<MessageEntity>()).SingleOrDefault();

            return persistedMessage;
        }

        private MessageHeaderEntity[] CreateMessageHeaders(int messageId, IEnumerable<MessageHeaderEntity> messageHeaders)
        {
            if (messageHeaders == null)
            {
                return null;
            }

            var persistedMessageHeaders = new List<MessageHeaderEntity>();

            foreach (var messageHeader in messageHeaders)
            {
                messageHeader.MessageId = messageId;

                var innerPersistedHeaders = this.ExecuteDbAction(dbClient =>
                    dbClient
                        .SetProcedureName(InsertMessageHeaderSProcName)
                        .AddNamedParameters(new InsertMessageHeaderParameters(messageHeader))
                        .ExecuteFetch<MessageHeaderEntity>());

                persistedMessageHeaders.AddRange(innerPersistedHeaders);
            }

            return persistedMessageHeaders.ToArray();
        }

        public MessageEntity GetFirstUnprocessed()
        {
            var message = GetMessage();
            if (message == null)
            {
                return null;
            }

            message.Headers = GetMessageHeaders(message.MessageId);

            return message;
        }

        private MessageEntity GetMessage()
        {
            var message = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetFirstUnprocessedMessageSProcName)
                    .ExecuteFetch<MessageEntity>()).SingleOrDefault();

            return message;
        }

        private MessageHeaderEntity[] GetMessageHeaders(int messageId)
        {
            var headers = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(GetMessageHeadersSProcName)
                    .AddNamedParameters(new { MessageId = messageId })
                    .ExecuteFetch<MessageHeaderEntity>());

            return headers.ToArray();
        }

        public MessageEntity Update(MessageEntity messageEntity)
        {
            var message = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(UpdateMessageSProcName)
                    .AddNamedParameters(messageEntity)
                    .ExecuteFetch<MessageEntity>()).SingleOrDefault();

            message.Headers = messageEntity.Headers;

            return message;
        }
    }
}