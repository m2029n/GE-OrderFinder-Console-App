﻿namespace Cdw.Infrastructure.Data.Messaging
{
    public class MessageHeaderEntity
    {
        public int MessageHeaderId { get; set; }
        public int MessageId { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}