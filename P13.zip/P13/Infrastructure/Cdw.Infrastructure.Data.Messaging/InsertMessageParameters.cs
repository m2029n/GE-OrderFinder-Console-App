﻿namespace Cdw.Infrastructure.Data.Messaging
{
    internal class InsertMessageParameters
    {
        private readonly MessageEntity _messageEntity;

        public InsertMessageParameters(MessageEntity entity)
        {
            _messageEntity = entity;
        }

        public string Body { get { return this._messageEntity.Body; } }
        public short State { get { return this._messageEntity.State; } }
    }
}