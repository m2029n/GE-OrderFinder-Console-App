﻿using Autofac;

namespace Cdw.Infrastructure.Data.Messaging
{
    public class MessagingDataModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterType<MessagingRepository>().AsImplementedInterfaces();
        }
    }
}