﻿using System.Collections.Generic;

namespace Cdw.Infrastructure.Events
{
    public interface IEventContainer
    {
        IEnumerable<IDomainEventHandler<T>> Handlers<T>(T domainEvent)
            where T : IDomainEvent;
    }
}