﻿namespace Cdw.Infrastructure.Events
{
    public interface IDomainEvent
    {
        string EventName { get; }
    }
}