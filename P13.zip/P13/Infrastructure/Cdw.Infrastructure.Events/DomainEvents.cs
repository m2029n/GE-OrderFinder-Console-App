﻿using System;
using System.Collections.Generic;

namespace Cdw.Infrastructure.Events
{
    /// <summary>
    /// The domain events container for registering domain event callbacks.
    /// </summary>
    public static class DomainEvents
    {
        /// <summary>
        /// The _actions.
        /// </summary>
        /// <remarks>Marked as ThreadStatic that each thread has its own callbacks</remarks>
        [ThreadStatic]
        private static List<Delegate> _actions;

        /// <summary>
        /// The container
        /// </summary>
        public static IEventContainer Container;

        public static IEventRaiser Raiser;

        /// <summary>
        /// Registers the specified callback for the given domain event.
        /// </summary>
        /// <typeparam name="T">
        /// </typeparam>
        /// <param name="callback">
        /// The callback.
        /// </param>
        public static void Register<T>(Action<T> callback) where T : IDomainEvent
        {
            if (_actions == null)
            {
                _actions = new List<Delegate>();
            }

            _actions.Add(callback);
        }

        public static void Raise<TEvent>(TEvent domainEvent) where TEvent : IDomainEvent
        {
            if (Raiser != null)
            {
                Raiser.Raise(domainEvent);
            }

            // registered actions, typically used for unit tests.
            if (_actions != null)
            {
                foreach (var action in _actions)
                {
                    if (action is Action<TEvent>)
                    {
                        ((Action<TEvent>)action)(domainEvent);
                    }
                }
            }
        }

        //Clears callbacks passed to Register on the current thread
        public static void ClearCallbacks()
        {
            _actions = null;
        }
    }
}