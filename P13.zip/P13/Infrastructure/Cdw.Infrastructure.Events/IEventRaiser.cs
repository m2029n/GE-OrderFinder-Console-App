﻿namespace Cdw.Infrastructure.Events
{
    public interface IEventRaiser
    {
        void Raise<TEvent>(TEvent @event) where TEvent : IDomainEvent;
    }
}