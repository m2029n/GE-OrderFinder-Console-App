﻿using System.Collections.Generic;
using Autofac;

namespace Cdw.Infrastructure.Events
{
    public class AutofacEventRaiser : IEventRaiser
    {
        private readonly IComponentContext _compconntext;

        public AutofacEventRaiser(IComponentContext compconntext)
        {
            this._compconntext = compconntext;
        }

        public void Raise<TEvent>(TEvent domainEvent) where TEvent : IDomainEvent
        {
            //using (var scope = context.BeginLifetimeScope("EventRaiser"))
            {
                foreach (var handler in _compconntext.Resolve<IEnumerable<IDomainEventHandler<TEvent>>>())
                {
                    handler.Handle(domainEvent);
                }
                //}
            }
        }
    }
}