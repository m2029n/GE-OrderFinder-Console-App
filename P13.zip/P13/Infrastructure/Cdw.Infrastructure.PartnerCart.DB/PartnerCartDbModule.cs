﻿using System;
using Autofac;
using Cdw.Core.Data.DbClient;

namespace Cdw.Infrastructure.PartnerCart.DB
{
    public class PartnerCartDbModule : Module
    {
        private readonly Func<IDbClient> _dbClient;

        public PartnerCartDbModule(Func<IDbClient> dbClient)
        {
            _dbClient = dbClient;
        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);
            builder.Register(c => new PartnerCartRequestRepository(_dbClient))
                .AsImplementedInterfaces()
                .SingleInstance();
        }
    }
}