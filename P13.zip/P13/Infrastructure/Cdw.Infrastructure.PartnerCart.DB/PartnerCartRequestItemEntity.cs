﻿namespace Cdw.Infrastructure.PartnerCart.DB
{
    public class PartnerCartRequestItemEntity : IPartnerCartRequestItemEntity
    {
        public int VendorCartRequestItemId { get; set; }
        public int VendorCartRequestId { get; set; }
        public string Manufacturer { get; set; }
        public string ManufacturerPartNumber { get; set; }
        public int? MatchedProductID { get; set; }
        public string MatchedProductCode { get; set; }
        public int Quantity { get; set; }
    }
}