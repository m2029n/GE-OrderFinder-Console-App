﻿using System;
using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerCart.DB
{
    public class PartnerCartRequestEntity : IPartnerCartRequestEntity
    {
        public int VendorCartRequestId { get; set; }
        public string Source { get; set; }
        public string CorrelationId { get; set; }
        public int WebSiteID { get; set; }
        public DateTime DateCreated { get; set; }
        public IEnumerable<IPartnerCartRequestItemEntity> LineItems { get; set; }
    }
}