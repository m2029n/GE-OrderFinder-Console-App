﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Cdw.Core.Data.DbClient;
using Cdw.Core.Data.Repositories;

namespace Cdw.Infrastructure.PartnerCart.DB
{
    public class PartnerCartRequestRepository : RepositoryBase, IPartnerCartRequestRepository
    {
        private const string AddVendorCartRequestSProcName
           = "webdb.[dbo].[API_AddVendorCartRequest]";

        private const string AddVendorCartRequestItemSProcName
            = "webdb.[dbo].[API_AddVendorCartRequestItem]";

        private const string GetProductsByManufacturerNameAndPartNumberSProcName =
            "[ProductDB].[dbo].[Product_GetProductsByManufacturerNameAndPartNumber]";

        public PartnerCartRequestRepository(Func<IDbClient> dbClientFactory)
            : base(dbClientFactory)
        {
        }

        public IPartnerCartRequestEntity Create(IPartnerCartRequestEntity request)
        {
            this.ExecuteDbAction(dbClient =>
            {
                var vendorCartRequestId = new SqlParameter(
                    "VendorCartRequestID",
                    SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                dbClient.SetProcedureName(AddVendorCartRequestSProcName)
                    .AddNamedParameters(
                        new
                        {
                            Source = request.Source,
                            CorrelationId = request.CorrelationId,
                            WebSiteID = request.WebSiteID,
                            DateCreated = request.DateCreated
                        }
                        , CrudMethod.Insert)
                    .AddDbParameter(vendorCartRequestId)
                    .ExecuteNonQuery();

                request.VendorCartRequestId = (int)vendorCartRequestId.Value;
            });

            foreach (var requestItem in request.LineItems)
            {
                requestItem.VendorCartRequestId = request.VendorCartRequestId;
                var temp = GetProductCode(requestItem.Manufacturer, requestItem.ManufacturerPartNumber);

                requestItem.MatchedProductID = temp.ProductID;
                requestItem.MatchedProductCode = temp.ProductCode;

                IPartnerCartRequestItemEntity item = requestItem;
                this.ExecuteDbAction(dbClient =>
                {
                    var vendorCartRequestItemId = new SqlParameter(
                        "VendorCartRequestItemID",
                        SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };

                    dbClient.SetProcedureName(AddVendorCartRequestItemSProcName)
                        .AddNamedParameters(
                            new
                            {
                                VendorCartRequestID = item.VendorCartRequestId,
                                Manufacturer = item.Manufacturer,
                                ManufacturerPartNumber = item.ManufacturerPartNumber,
                                Quantity = item.Quantity,
                                MatchedProductId = item.MatchedProductID,
                                MatchedProductCode = item.MatchedProductCode,
                            },
                            CrudMethod.Insert)
                        .AddDbParameter(vendorCartRequestItemId)
                        .ExecuteNonQuery();

                    item.VendorCartRequestItemId
                        = (int)vendorCartRequestItemId.Value;
                });
            }

            return request;
        }

        private TempProduct GetProductCode(string manufacturerName, string manufacturerPartNumber)
        {
            var matches = this.ExecuteDbAction(dbClient =>
                dbClient
                    .SetProcedureName(
                        GetProductsByManufacturerNameAndPartNumberSProcName)
                    .AddNamedParameters(
                        new
                        {
                            ManufacturerName = manufacturerName,
                            ManufacturerPartNumber = manufacturerPartNumber
                        })
                    .ExecuteFetch<TempProduct>()).FirstOrDefault();

            return matches;
        }
    }

    public class TempProduct
    {
        public int ProductID { get; set; }
        public string ProductCode { get; set; }
    }
}