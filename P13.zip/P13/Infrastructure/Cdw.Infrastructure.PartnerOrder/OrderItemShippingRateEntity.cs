﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public class OrderItemShippingRateEntity
    {
        public int OrderID { get; set; }

        public string ProductCode { get; set; }

        public decimal CdwCost { get; set; }

        public decimal Freight { get; set; }

        public decimal Handling { get; set; }

        public decimal BoxHandling { get; set; }

        public decimal Insurance { get; set; }

        public decimal Weight { get; set; }
    }
}