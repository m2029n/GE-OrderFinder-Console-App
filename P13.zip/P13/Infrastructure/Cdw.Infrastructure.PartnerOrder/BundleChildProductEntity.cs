namespace Cdw.Infrastructure.PartnerOrder
{
    public class BundleChildProductEntity
    {
        public int ProductID { get; set; }

        public int ProductChildQuantity { get; set; }

        public ProductEntity Product { get; set; }
    }
}