﻿using System;
using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CartEntity
    {
        public int CartID { get; set; }
        public int Company { get; set; }
        public DateTime DateCreated { get; set; }
        public CartDiscountsEntity Discounts { get; set; }
        public IEnumerable<CustomPropertyEntity> CustomProperties { get; set; }
        public IList<CartItemEntity> CartItems { get; set; }
        public decimal Subtotal { get; set; }
        public decimal DiscountValue { get; set; }
    }
}