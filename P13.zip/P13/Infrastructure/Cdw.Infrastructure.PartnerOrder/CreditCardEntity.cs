﻿using System;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CreditCardEntity
    {
        public int CreditCardTokenID { get; set; }

        public string CreditCardToken { get; set; }

        public string CreditCardHolderName { get; set; }

        public string CreditCardNumber { get; set; }

        public string CreditCardNumberLastFour { get; set; }

        public DateTime CreditCardExpirationDate { get; set; }

        public PaymentMethodTypeEntity CreditCardType { get; set; }

        public int PaymentMethodOptionID { get; set; }
    }
}