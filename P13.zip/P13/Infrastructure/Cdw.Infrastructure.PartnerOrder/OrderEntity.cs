﻿using System;
using System.Collections.Generic;
using Cdw.Core.Data.DbClient.Attributes;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class OrderEntity
    {
        [IgnoreOnInsert]
        public int OrderID { get; set; }

        public DateTime TransactionDate { get; set; }
        public string Source { get; set; }
        public string ReferenceNumber { get; set; }
        public string Account_CustomerNumber { get; set; }
        public string Account_EAccount { get; set; }
        public string Account_EmailAddress { get; set; }
        public decimal FreightCost { get; set; }
        public decimal Freight { get; set; }
        public decimal Handling { get; set; }
        public decimal Insurance { get; set; }
        public string Billing_FirstName { get; set; }
        public string Billing_LastName { get; set; }
        public string Billing_PhoneNumber { get; set; }
        public string Billing_Company { get; set; }
        public string Billing_StreetAddress { get; set; }
        public string Billing_SecondaryStreetAddress { get; set; }
        public string Billing_City { get; set; }
        public string Billing_State { get; set; }
        public string Billing_PostalCode { get; set; }
        public string Billing_IsoCountryCode { get; set; }
        public string Billing_Method_PONumber { get; set; }
        public int Billing_Method_CreditCardTokenID { get; set; }
        public string Billing_Method_Terms { get; set; }
        public string Shipping_FirstName { get; set; }
        public string Shipping_LastName { get; set; }
        public string Shipping_PhoneNumber { get; set; }
        public string Shipping_Company { get; set; }
        public string Shipping_StreetAddress { get; set; }
        public string Shipping_SecondaryStreetAddress { get; set; }
        public string Shipping_City { get; set; }
        public string Shipping_State { get; set; }
        public string Shipping_PostalCode { get; set; }
        public string Shipping_IsoCountryCode { get; set; }
        public string Shipping_Method_Id { get; set; }
        public string Shipping_Method_Description { get; set; }
        public int CartID { get; set; }
        public string OrderCode { get; set; }
        public int BoxCount { get; set; }
        public decimal Weight { get; set; }
        public decimal TotalShippingCharge { get; set; }
        public decimal BoxHandlingCharge { get; set; }
        public Guid FreightTransactionID { get; set; }

        public string IpAddress { get; set; }
        public string Geolocation { get; set; }
        public string UserAgent { get; set; }

        [IgnoreOnInsert]
        public IList<TaxEntity> Taxes { get; set; }

        [IgnoreOnInsert]
        public IList<RecycleFeeEntity> RecycleFees { get; set; }

        [IgnoreOnInsert]
        public IList<OrderItemShippingRateEntity> OrderItems { get; set; }

        [IgnoreOnInsert]
        public string Billing_Method_TransactionId { get; set; }

        [IgnoreOnInsert]
        public string Billing_Method_ReferenceNumber { get; set; }
    }
}