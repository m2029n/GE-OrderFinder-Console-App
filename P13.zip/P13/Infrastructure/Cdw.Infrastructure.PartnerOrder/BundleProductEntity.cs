﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public class BundleProductEntity
    {
        public BundleProductEntity(BundleChildProductEntity entity)
        {
            this.Product = entity.Product;
            this.Quantity = entity.ProductChildQuantity;
        }

        public ProductEntity Product { get; private set; }

        public int Quantity { get; private set; }
    }
}