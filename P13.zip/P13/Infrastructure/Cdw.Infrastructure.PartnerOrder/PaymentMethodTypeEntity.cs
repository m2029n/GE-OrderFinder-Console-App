namespace Cdw.Infrastructure.PartnerOrder
{
    public enum PaymentMethodTypeEntity
    {
        Unknown = 1,
        AmericanExpress = 1001,
        DiscoverNetwork = 1002,
        Visa = 1003,
        MasterCard = 1004,
        DinersClub = 1011
    }
}