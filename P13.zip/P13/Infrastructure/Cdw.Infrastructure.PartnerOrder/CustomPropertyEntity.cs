namespace Cdw.Infrastructure.PartnerOrder
{
    public class CustomPropertyEntity
    {
        public int CustomPropertyID { get; set; }

        public string Name { get; set; }

        public string Value { get; set; }
    }
}