﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public class IdentityEntity
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string SourceCode { get; set; }
        public string FreightRaterSpecialCode { get; set; }
    }
}