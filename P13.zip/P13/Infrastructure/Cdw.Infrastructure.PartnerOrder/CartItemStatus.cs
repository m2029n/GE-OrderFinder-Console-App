﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public enum CartItemStatus
    {
        Pending,
        Partial,
        Shipped,
        Backordered,
        Canceled
    }
}