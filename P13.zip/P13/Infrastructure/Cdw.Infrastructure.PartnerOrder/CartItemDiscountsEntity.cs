﻿using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CartItemDiscountsEntity
    {
        public IList<DiscountEntity> FixedLinePriceDiscounts { get; set; }
        public IList<DiscountEntity> FixedUnitPriceDiscounts { get; set; }
        public IList<DiscountEntity> PercentOffLinePriceDiscounts { get; set; }
        public IList<DiscountEntity> PercentOffUnitPriceDiscounts { get; set; }
    }
}