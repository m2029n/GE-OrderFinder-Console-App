﻿using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CreditCardTypeEntity
    {
        public PaymentMethodTypeEntity Type { get; set; }
        public string Name { get; set; }
        public IEnumerable<string> AlternateNames { get; set; }
        public int CardNumberLength { get; set; }
    }
}