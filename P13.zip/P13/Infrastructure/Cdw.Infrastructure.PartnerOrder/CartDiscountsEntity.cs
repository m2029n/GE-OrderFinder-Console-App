﻿using System.Collections.Generic;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CartDiscountsEntity
    {
        public IList<DiscountEntity> FixedAmountDiscounts { get; set; }
        public IList<DiscountEntity> PercentOffDiscounts { get; set; }
    }
}