﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public enum CdwCompany
    {
        CDW = 1000,
        CDWG = 1006,
        CDWCa = 1012
    }
}