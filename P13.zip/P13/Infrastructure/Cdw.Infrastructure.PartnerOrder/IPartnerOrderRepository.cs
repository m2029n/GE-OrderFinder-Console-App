﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cdw.Infrastructure.PartnerOrder
{
    public interface IPartnerOrderRepository
    {
        Task<List<ShippingMethodPropertiesEntity>> GetShippingMethodPropertiesAsync(string clientName);

        Task<ShippingMethodPropertiesEntity> GetShippingMethodProperty(string clientName, string shippingMethod);

        bool UniqueReferenceNumber(string source, string referenceNumber);

        IdentityEntity GetIdentityDetails(int clientId);

        [System.Obsolete("GetIdentityDetails(string clientName) is deprecated, please use {IdentityEntity GetIdentityDetails(int clientId)} instead.")]
        IdentityEntity GetIdentityDetails(string clientName);

        IEnumerable<ProductEntity> GetProduct(IEnumerable<string> productCodes);

        IEnumerable<ProductEntity> GetProduct(IEnumerable<int> productIds);

        CartEntity InsertApiCarts(CartEntity newCart);

        OrderEntity Create(OrderEntity newOrder);

        bool? IsUploadedToAs400(string orderCode);

        OrderEntity GetOrderEntity(string orderCode, string sourceCode);

        CartEntity GetCartEntity(int cartId);

        CreditCardEntity GetCreditCardById(int creditCardTokenId);

        CreditCardEntity GetCreditCardByToken(string creditCardToken);

        bool IsTermsAllowed(string source, string terms);

        TermsEntity GetPaymentMethodDetails(string source, string method);

        string GetAuthCreditCardToken(string transactionId, string referenceNumber);
    }
}