﻿namespace Cdw.Infrastructure.PartnerOrder
{
    public class DiscountEntity
    {
        public int Type { get; set; }

        public string Id { get; set; }

        public decimal Amount { get; set; }
        public int DiscountId { get; set; }
    }
}