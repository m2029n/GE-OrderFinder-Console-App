﻿using System.Collections.Generic;
using Cdw.Core.Data.DbClient.Attributes;

namespace Cdw.Infrastructure.PartnerOrder
{
    public class CartItemEntity
    {
        public int CartItemID { get; set; }
        public CartItemStatus Status { get; set; }
        public IList<CustomPropertyEntity> CustomProperties { get; set; }
        public CartItemDiscountsEntity Discounts { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal DiscountedUnitPrice { get; set; }
        public decimal LinePrice { get; set; }
        public decimal DiscountedLinePrice { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }

        [IgnoreOnInsert]
        public ProductEntity Product { get; set; }
    }
}